"""Load the BKK Traffic Parquet snapshot into the PostgreSQL schema bkk_traffic.

Source: the friend's published, gate-passed Parquet datasets (one folder per
dataset with a _manifest.json). SQLite is not used. Mapping and rules:
docs/integration/bkk_traffic_parquet_mapping.md.

    python database/load/load_bkk_traffic.py \
        --source-dir data/bkk_traffic/source_snapshots/<snapshot> \
        --expected-database <db> [--dsn ... | BKK_TRAFFIC_DATABASE_URL] [--dry-run]

* Every dataset is validated (manifest, schema, timestamps, flags, coordinates,
  keys, NULL rules) before anything is written; one invalid row fails the load.
* incidents_bangkok -> incidents, traffic_index -> traffic_index_history and
  travel_times -> travel_times are written by COPY in ONE transaction, together
  with the load_history row. accidents_bangkok is not stored: it is verified,
  row for row, against the view accidents_bangkok.
* Same snapshot already loaded -> "unchanged" (data untouched, audit row only).
  A new snapshot replaces the previous baseline rows atomically. Rows written by
  the pipeline (baseline_load_id IS NULL) make the loader refuse.
* The target must equal --expected-database. namtang_db additionally needs
  --production-approved; itproject_db and host port 5432 are always refused.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

SCHEMA = "bkk_traffic"
REQUIRED_MIGRATION = "006_parquet_baseline"
PRODUCTION_DATABASE = "namtang_db"
FORBIDDEN_DATABASES = ("itproject_db",)
ROWS_PER_FILE = 10_000
GATE_CHECKS = {"G1_schema", "G2_has_rows", "G3_non_bangkok_rows", "G4_required_not_null",
               "G5_no_coords_pct", "G6_quarantine_pct", "G7_no_big_drop", "G8_clean_backlog",
               "G9_non_traffic_rows"}
TS_PATTERN = r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$"
TS_FORMAT = "%Y-%m-%d %H:%M:%S"
BANGKOK_UTC_OFFSET_SECONDS = 7 * 3600      # Asia/Bangkok, no DST
BANGKOK_BBOX = (13.4, 14.1, 100.3, 101.0)  # informational only (lat_min, lat_max, lon_min, lon_max)
NULL_TOKEN = r"\N"

# Schemas of the friend's parquet_export.py (verified against the files).
INCIDENT_SCHEMA = pa.schema([
    ("eid", pa.int64()), ("nid", pa.int64()),
    ("start_time", pa.string()), ("stop_time", pa.string()),
    ("createtime", pa.string()), ("updatedtime", pa.string()),
    ("event_type_id", pa.int16()), ("event_type", pa.string()), ("traffic_relevance", pa.string()),
    ("is_accident", pa.int8()), ("is_bangkok", pa.int8()),
    ("severity", pa.int16()),
    ("title", pa.string()), ("title_en", pa.string()),
    ("comment", pa.string()), ("comment_en", pa.string()),
    ("latitude", pa.float64()), ("longitude", pa.float64()),
    ("province_guess", pa.string()), ("contributor", pa.string()), ("source", pa.string()),
    ("status", pa.string()), ("fetched_via", pa.string()),
    ("first_seen_at", pa.string()), ("last_seen_at", pa.string()),
    ("dq_flags", pa.string()),
])
TRAFFIC_INDEX_SCHEMA = pa.schema([("ts", pa.int64()), ("ts_local", pa.string()),
                                  ("index_value", pa.float64()), ("source", pa.string())])
TRAVEL_TIMES_SCHEMA = pa.schema([("route", pa.string()), ("fetched_at", pa.string()),
                                 ("distance_m", pa.float64()), ("duration_s", pa.float64()),
                                 ("duration_min", pa.float64()), ("from_lat", pa.float64()),
                                 ("from_lon", pa.float64()), ("to_lat", pa.float64()),
                                 ("to_lon", pa.float64())])


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    schema: pa.Schema
    table: str | None                     # None = verified only (accidents_bangkok)
    key: tuple[str, ...]
    timestamps: tuple[str, ...]
    required: tuple[str, ...]
    flags: tuple[str, ...] = ()
    constant: dict[str, int] = field(default_factory=dict)   # column -> required value
    coordinates: tuple[tuple[str, str], ...] = ()
    extra_columns: tuple[str, ...] = ()                       # target columns not in Parquet


INCIDENT_TIMESTAMPS = ("start_time", "stop_time", "createtime", "updatedtime", "first_seen_at", "last_seen_at")
INCIDENT_REQUIRED = ("eid", "start_time", "title", "traffic_relevance", "is_accident", "is_bangkok",
                     "fetched_via", "first_seen_at", "last_seen_at")
DATASETS = (
    DatasetSpec("incidents_bangkok", INCIDENT_SCHEMA, "incidents", ("eid",), INCIDENT_TIMESTAMPS,
                INCIDENT_REQUIRED, ("is_accident", "is_bangkok"), {"is_bangkok": 1},
                (("latitude", "longitude"),), ("is_duplicate", "baseline_load_id")),
    DatasetSpec("accidents_bangkok", INCIDENT_SCHEMA, None, ("eid",), INCIDENT_TIMESTAMPS,
                INCIDENT_REQUIRED, ("is_accident", "is_bangkok"), {"is_bangkok": 1, "is_accident": 1},
                (("latitude", "longitude"),)),
    DatasetSpec("traffic_index", TRAFFIC_INDEX_SCHEMA, "traffic_index_history", ("ts",), ("ts_local",),
                ("ts", "ts_local", "source"), extra_columns=("baseline_load_id",)),
    DatasetSpec("travel_times", TRAVEL_TIMES_SCHEMA, "travel_times", ("route", "fetched_at"), ("fetched_at",),
                ("route", "fetched_at"), coordinates=(("from_lat", "from_lon"), ("to_lat", "to_lon")),
                extra_columns=("baseline_load_id",)),
)
SPECS = {spec.name: spec for spec in DATASETS}
LOADED = tuple(spec for spec in DATASETS if spec.table)


class LoadError(RuntimeError):
    """The snapshot or the target failed a check; nothing was written."""


class TargetRefused(LoadError):
    """The database target is not allowed (guard)."""


# --------------------------------------------------------------------------
# Source validation (streaming; only key columns are kept in memory)
# --------------------------------------------------------------------------

@dataclass
class DatasetReport:
    name: str
    files: list[Path]
    manifest: dict[str, Any]
    rows: int = 0
    file_sha256: dict[str, str] = field(default_factory=dict)
    fingerprint: dict[str, Any] = field(default_factory=dict)
    outside_bangkok_bbox: int = 0
    errors: list[str] = field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        return {"manifest_rows": self.manifest.get("total_rows"), "parquet_rows": self.rows,
                "files": len(self.files), "generated_at": self.manifest.get("generated_at"),
                "signature": self.manifest.get("signature"),
                "gate_passed_at": (self.manifest.get("validation") or {}).get("gate_passed_at"),
                "outside_bangkok_bbox": self.outside_bangkok_bbox}


@dataclass
class Snapshot:
    source_dir: Path
    reports: dict[str, DatasetReport]

    @property
    def sha256(self) -> str:
        digest = hashlib.sha256()
        for name in sorted(self.reports):
            for fname, sha in sorted(self.reports[name].file_sha256.items()):
                digest.update(f"{name}/{fname}:{sha}\n".encode())
        return digest.hexdigest()

    @property
    def signature(self) -> str:
        return ";".join(f"{name}={self.reports[name].manifest.get('signature')}" for name in sorted(self.reports))

    def manifests(self) -> dict[str, Any]:
        return {name: report.summary() for name, report in sorted(self.reports.items())}


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_manifest(spec: DatasetSpec, directory: Path, report: DatasetReport) -> None:
    m = report.manifest
    err = report.errors.append
    if m.get("dataset") != spec.name:
        err(f"manifest dataset {m.get('dataset')!r} != folder {spec.name!r}")
    if m.get("rows_per_file") != ROWS_PER_FILE:
        err(f"rows_per_file {m.get('rows_per_file')!r} != {ROWS_PER_FILE}")
    gate = (m.get("validation") or {}).get("gate") or {}
    if set(gate) != GATE_CHECKS:
        err(f"gate checks {sorted(gate)} != {sorted(GATE_CHECKS)}")
    not_pass = {k: v for k, v in gate.items() if v != "PASS"}
    if not_pass:
        err(f"validation gate not PASS: {not_pass}")
    listed = [f.get("file") for f in m.get("files") or []]
    on_disk = sorted(p.name for p in directory.glob("*.parquet"))
    if sorted(listed) != on_disk:
        err(f"manifest files != parquet files on disk (missing {sorted(set(listed) - set(on_disk))}, "
            f"extra {sorted(set(on_disk) - set(listed))})")
    if sum(int(f.get("rows") or 0) for f in m.get("files") or []) != m.get("total_rows"):
        err("sum of manifest file rows != total_rows")


def _nonnull(array: pa.ChunkedArray | pa.Array) -> int:
    return len(array) - array.null_count


def _check_batch(spec: DatasetSpec, batch: pa.RecordBatch, report: DatasetReport, where: str) -> None:
    err = report.errors.append
    for col in spec.required:
        values = batch.column(col)
        if values.null_count:
            err(f"{where}: {values.null_count} NULL in required column {col}")
    if "title" in spec.required:
        empty = pc.sum(pc.equal(batch.column("title"), "")).as_py() or 0
        if empty:
            err(f"{where}: {empty} empty title")
    for col in spec.timestamps:
        values = batch.column(col)
        valid = values.filter(pc.is_valid(values))
        bad_format = len(valid) - (pc.sum(pc.match_substring_regex(valid, TS_PATTERN)).as_py() or 0)
        parsed = pc.strptime(valid, format=TS_FORMAT, unit="s", error_is_null=True)
        # strptime normalizes impossible dates (2026-02-30, 0000-00-00); an exact round trip rejects them
        not_round_trip = pc.sum(pc.fill_null(pc.not_equal(pc.strftime(parsed, format=TS_FORMAT), valid),
                                             True)).as_py() or 0
        if bad_format or not_round_trip:
            err(f"{where}: {max(bad_format, not_round_trip)} invalid timestamp(s) in {col}")
    for col in spec.flags:
        bad = pc.sum(pc.invert(pc.is_in(batch.column(col), pa.array([0, 1], batch.column(col).type)))).as_py()
        if bad:
            err(f"{where}: {bad} value(s) of {col} not in (0, 1)")
    for col, value in spec.constant.items():
        bad = pc.sum(pc.not_equal(batch.column(col), value)).as_py()
        if bad:
            err(f"{where}: {bad} row(s) with {col} != {value} (dataset definition)")
    if "severity" in batch.schema.names:
        sev = batch.column("severity")
        bad = pc.sum(pc.invert(pc.is_in(sev.filter(pc.is_valid(sev)), pa.array([1, 2, 3], sev.type)))).as_py()
        if bad:
            err(f"{where}: {bad} severity value(s) outside 1-3")
    if "traffic_relevance" in batch.schema.names:
        rel = batch.column("traffic_relevance")
        bad = pc.sum(pc.invert(pc.is_in(rel, pa.array(["direct", "affects", "keyword"])))).as_py()
        if bad:
            err(f"{where}: {bad} traffic_relevance value(s) outside direct/affects/keyword")
    for lat_col, lon_col in spec.coordinates:
        lat, lon = batch.column(lat_col), batch.column(lon_col)
        bad = (pc.sum(pc.or_(pc.less(lat, -90), pc.greater(lat, 90))).as_py() or 0) + \
              (pc.sum(pc.or_(pc.less(lon, -180), pc.greater(lon, 180))).as_py() or 0)
        if bad:
            err(f"{where}: {bad} coordinate value(s) outside the geographic range ({lat_col}/{lon_col})")
        inside = pc.and_(pc.and_(pc.greater_equal(lat, BANGKOK_BBOX[0]), pc.less_equal(lat, BANGKOK_BBOX[1])),
                         pc.and_(pc.greater_equal(lon, BANGKOK_BBOX[2]), pc.less_equal(lon, BANGKOK_BBOX[3])))
        both = pc.and_(pc.is_valid(lat), pc.is_valid(lon))
        report.outside_bangkok_bbox += pc.sum(pc.and_(both, pc.invert(inside))).as_py() or 0
    for name, typ in zip(batch.schema.names, batch.schema.types):
        if pa.types.is_string(typ):
            hits = pc.sum(pc.equal(batch.column(name), NULL_TOKEN)).as_py()
            if hits:
                err(f"{where}: {hits} literal {NULL_TOKEN!r} value(s) in {name} (reserved NULL token)")
    if spec.name == "traffic_index":
        ts = batch.column("ts")
        expected = pc.strftime(pc.cast(pc.add(ts, BANGKOK_UTC_OFFSET_SECONDS), pa.timestamp("s")),
                               format=TS_FORMAT)
        mismatch = pc.sum(pc.not_equal(expected, batch.column("ts_local"))).as_py()
        if mismatch:
            err(f"{where}: {mismatch} row(s) where ts_local != ts as Asia/Bangkok local time")


def _accumulate_fingerprint(spec: DatasetSpec, batch: pa.RecordBatch, fp: dict[str, Any]) -> None:
    for name, typ in zip(batch.schema.names, batch.schema.types):
        col = batch.column(name)
        entry = fp.setdefault(name, {"nonnull": 0})
        entry["nonnull"] += _nonnull(col)
        if name in spec.timestamps:
            if _nonnull(col):
                low, high = pc.min(col).as_py(), pc.max(col).as_py()
                entry["min"] = low if "min" not in entry else min(entry["min"], low)
                entry["max"] = high if "max" not in entry else max(entry["max"], high)
        elif pa.types.is_integer(typ):
            entry["sum"] = entry.get("sum", 0) + int(pc.sum(col).as_py() or 0)
        elif pa.types.is_floating(typ):
            entry.setdefault("parts", []).append(pc.sum(col).as_py() or 0.0)
        elif pa.types.is_string(typ):
            entry["chars"] = entry.get("chars", 0) + int(pc.sum(pc.utf8_length(col)).as_py() or 0)


def validate_dataset(source_dir: Path, spec: DatasetSpec, batch_size: int = 50_000) -> DatasetReport:
    directory = source_dir / spec.name
    manifest_path = directory / "_manifest.json"
    if not manifest_path.is_file():
        raise LoadError(f"{spec.name}: {manifest_path} not found")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except ValueError as exc:
        raise LoadError(f"{spec.name}: manifest is not valid JSON: {exc}") from exc
    report = DatasetReport(spec.name, sorted(directory.glob("*.parquet")), manifest)
    check_manifest(spec, directory, report)
    listed_rows = {f.get("file"): f.get("rows") for f in manifest.get("files") or []}
    key_chunks: dict[str, list[pa.Array]] = {k: [] for k in spec.key}
    for path in report.files:
        report.file_sha256[path.name] = _file_sha256(path)
        parquet = pq.ParquetFile(path)
        schema = parquet.schema_arrow.remove_metadata()
        if not schema.equals(spec.schema):
            report.errors.append(f"{path.name}: schema differs from the expected {spec.name} schema")
            continue
        if parquet.metadata.num_rows != listed_rows.get(path.name):
            report.errors.append(f"{path.name}: {parquet.metadata.num_rows} rows, manifest says "
                                 f"{listed_rows.get(path.name)}")
        for batch in parquet.iter_batches(batch_size=batch_size):
            report.rows += batch.num_rows
            _check_batch(spec, batch, report, f"{spec.name}/{path.name}")
            _accumulate_fingerprint(spec, batch, report.fingerprint)
            for k in spec.key:
                key_chunks[k].append(batch.column(k))
    report.file_sha256["_manifest.json"] = _file_sha256(manifest_path)
    if report.rows != manifest.get("total_rows"):
        report.errors.append(f"{report.rows} Parquet rows != manifest total_rows {manifest.get('total_rows')}")
    if key_chunks[spec.key[0]]:
        if len(spec.key) == 1:
            keys = pa.chunked_array(key_chunks[spec.key[0]])
            distinct = pc.count_distinct(keys).as_py()
        else:
            table = pa.table({k: pa.chunked_array(v) for k, v in key_chunks.items()})
            distinct = table.group_by(list(spec.key)).aggregate([]).num_rows
        if distinct != report.rows:
            report.errors.append(f"{report.rows - distinct} duplicate key value(s) on {spec.key}")
    for entry in report.fingerprint.values():
        if "parts" in entry:
            entry["sum"] = math.fsum(entry.pop("parts"))
    return report


def validate_snapshot(source_dir: Path, batch_size: int = 50_000) -> Snapshot:
    source_dir = Path(source_dir)
    if not source_dir.is_dir():
        raise LoadError(f"source directory {source_dir} does not exist")
    reports = {spec.name: validate_dataset(source_dir, spec, batch_size) for spec in DATASETS}
    problems = [f"{name}: {e}" for name, r in reports.items() for e in r.errors]
    if problems:
        raise LoadError("snapshot validation failed:\n  " + "\n  ".join(problems[:50]))
    return Snapshot(source_dir, reports)


# --------------------------------------------------------------------------
# Target guard
# --------------------------------------------------------------------------

def check_target_dsn(dsn: str, expected_database: str, production_approved: bool) -> dict[str, Any]:
    from psycopg.conninfo import conninfo_to_dict

    info = conninfo_to_dict(dsn)
    dbname, host, port = info.get("dbname"), info.get("host"), str(info.get("port") or "5432")
    if dbname in FORBIDDEN_DATABASES or host in FORBIDDEN_DATABASES:
        raise TargetRefused(f"refusing forbidden database target {dbname or host!r}")
    if host in (None, "", "localhost", "127.0.0.1", "::1") and port == "5432":
        raise TargetRefused("refusing host port 5432 (itproject_db on this machine)")
    if dbname != expected_database:
        raise TargetRefused(f"DSN database {dbname!r} != --expected-database {expected_database!r}")
    is_production = dbname == PRODUCTION_DATABASE or host == PRODUCTION_DATABASE or port == "5433"
    if is_production and not production_approved:
        raise TargetRefused("production target (namtang_db / port 5433) requires --production-approved")
    return info


def connect(dsn: str, expected_database: str, production_approved: bool = False, read_only: bool = False):
    import psycopg

    check_target_dsn(dsn, expected_database, production_approved)
    conn = psycopg.connect(dsn, connect_timeout=10)
    try:
        name = conn.execute("SELECT current_database()").fetchone()[0]
        if name != expected_database:
            raise TargetRefused(f"connected to {name!r}, expected {expected_database!r}")
        if name == PRODUCTION_DATABASE and not production_approved:
            raise TargetRefused("connected to the production database without --production-approved")
        if read_only:
            conn.execute("SET default_transaction_read_only = on")
        conn.commit()
    except BaseException:
        conn.close()
        raise
    return conn


# --------------------------------------------------------------------------
# Database state
# --------------------------------------------------------------------------

def require_schema(cur) -> None:
    cur.execute("SELECT to_regclass('bkk_traffic.migration_history')")
    if cur.fetchone()[0] is None:
        raise LoadError("schema bkk_traffic is not migrated (run database/migrations/bkk_traffic)")
    cur.execute("SELECT 1 FROM bkk_traffic.migration_history WHERE version = %s", (REQUIRED_MIGRATION,))
    if cur.fetchone() is None:
        raise LoadError(f"migration {REQUIRED_MIGRATION} is not applied")


def db_state(cur) -> dict[str, Any]:
    state: dict[str, Any] = {"tables": {}}
    for spec in LOADED:
        cur.execute(f"SELECT count(*) FILTER (WHERE baseline_load_id IS NOT NULL), "
                    f"count(*) FILTER (WHERE baseline_load_id IS NULL), "
                    f"min(baseline_load_id), max(baseline_load_id) FROM {SCHEMA}.{spec.table}")
        baseline, pipeline, low, high = cur.fetchone()
        state["tables"][spec.table] = {"baseline_rows": baseline, "pipeline_rows": pipeline,
                                       "baseline_load_ids": sorted({low, high} - {None})}
    cur.execute("SELECT load_id, source_sha256 FROM bkk_traffic.load_history "
                "WHERE status = 'success' ORDER BY load_id DESC LIMIT 1")
    row = cur.fetchone()
    state["current_load"] = {"load_id": row[0], "source_sha256": row[1]} if row else None
    return state


def pipeline_rows(state: dict[str, Any]) -> dict[str, int]:
    return {t: s["pipeline_rows"] for t, s in state["tables"].items() if s["pipeline_rows"]}


def is_unchanged(state: dict[str, Any], snapshot: Snapshot) -> bool:
    current = state["current_load"]
    if not current or current["source_sha256"] != snapshot.sha256 or pipeline_rows(state):
        return False
    for spec in LOADED:
        t = state["tables"][spec.table]
        if t["baseline_rows"] != snapshot.reports[spec.name].rows or t["baseline_load_ids"] != [current["load_id"]]:
            return False
    return True


# --------------------------------------------------------------------------
# COPY
# --------------------------------------------------------------------------

def _csv_value(value: object) -> object:
    return NULL_TOKEN if value is None else value


def csv_batches(files: Iterable[Path], extra: tuple[object, ...], batch_size: int) -> Iterable[str]:
    for path in files:
        for batch in pq.ParquetFile(path).iter_batches(batch_size=batch_size):
            columns = batch.to_pydict()
            output = io.StringIO()
            writer = csv.writer(output, lineterminator="\n")
            for row in zip(*columns.values()):
                writer.writerow([_csv_value(v) for v in row] + list(extra))
            yield output.getvalue()


def copy_dataset(cur, target: str, report: DatasetReport, spec: DatasetSpec, extra_columns: tuple[str, ...],
                 extra_values: tuple[object, ...], batch_size: int) -> None:
    from psycopg import sql

    columns = list(spec.schema.names) + list(extra_columns)
    statement = sql.SQL("COPY {} ({}) FROM STDIN WITH (FORMAT csv, NULL {})").format(
        sql.SQL(target), sql.SQL(", ").join(sql.Identifier(c) for c in columns), sql.Literal(NULL_TOKEN))
    with cur.copy(statement) as copy:
        for chunk in csv_batches(report.files, extra_values, batch_size):
            copy.write(chunk)


def db_fingerprint(cur, spec: DatasetSpec, load_id: int) -> dict[str, Any]:
    parts = []
    for name, typ in zip(spec.schema.names, spec.schema.types):
        col = f'"{name}"'
        parts.append(f"count({col})")
        if name in spec.timestamps:
            parts += [f"to_char(min({col}), 'YYYY-MM-DD HH24:MI:SS')", f"to_char(max({col}), 'YYYY-MM-DD HH24:MI:SS')"]
        elif pa.types.is_integer(typ):
            parts.append(f"coalesce(sum({col}), 0)::numeric")
        elif pa.types.is_floating(typ):
            parts.append(f"coalesce(sum({col}), 0)::float8")
        elif pa.types.is_string(typ):
            parts.append(f"coalesce(sum(char_length({col})), 0)")
    cur.execute(f"SELECT {', '.join(parts)} FROM {SCHEMA}.{spec.table} WHERE baseline_load_id = %s", (load_id,))
    values = list(cur.fetchone())
    fp: dict[str, Any] = {}
    for name, typ in zip(spec.schema.names, spec.schema.types):
        entry = {"nonnull": int(values.pop(0))}
        if name in spec.timestamps:
            low, high = values.pop(0), values.pop(0)
            if low is not None:
                entry["min"], entry["max"] = low, high
        elif pa.types.is_integer(typ):
            entry["sum"] = int(values.pop(0))
        elif pa.types.is_floating(typ):
            entry["sum"] = float(values.pop(0))
        elif pa.types.is_string(typ):
            entry["chars"] = int(values.pop(0))
        fp[name] = entry
    return fp


def compare_fingerprints(name: str, source: dict[str, Any], target: dict[str, Any]) -> list[str]:
    problems = []
    for col, expected in source.items():
        got = target.get(col, {})
        for key, value in expected.items():
            other = got.get(key)
            if isinstance(value, float):
                same = other is not None and math.isclose(value, other, rel_tol=1e-9, abs_tol=1e-6)
            else:
                same = value == other
            if not same:
                problems.append(f"{name}.{col}.{key}: parquet {value!r} != postgresql {other!r}")
    return problems


# --------------------------------------------------------------------------
# Load
# --------------------------------------------------------------------------

DUPLICATE_KEY_SQL = """
SELECT count(*) FROM (
    SELECT ROW_NUMBER() OVER (PARTITION BY contributor, title, start_time,
           round(latitude::numeric, 4), round(longitude::numeric, 4) ORDER BY eid) AS rn
    FROM bkk_traffic.incidents) ranked
WHERE rn > 1"""


class InjectedFailure(RuntimeError):
    """Raised by tests through fail_after to prove the rollback."""


def _record(conn, run_id: str, snapshot: Snapshot | None, status: str, row_counts: dict, message: str) -> None:
    with conn.transaction():
        conn.execute(
            "INSERT INTO bkk_traffic.load_history (run_id, source_db, source_sha256, source_signature, "
            "source_manifests, status, finished_at, row_counts, message) VALUES (%s, %s, %s, %s, %s, %s, now(), %s, %s)",
            (run_id, f"parquet:{snapshot.source_dir.as_posix()}" if snapshot else "parquet:unknown",
             snapshot.sha256 if snapshot else None, snapshot.signature if snapshot else None,
             json.dumps(snapshot.manifests()) if snapshot else None, status, json.dumps(row_counts),
             message[:2000]))


def load_snapshot(conn, snapshot: Snapshot, run_id: str, batch_size: int = 50_000,
                  fail_after: str | None = None) -> dict[str, Any]:
    """Replace the baseline rows with this snapshot in ONE transaction; returns the result."""
    result: dict[str, Any] = {"run_id": run_id, "source_sha256": snapshot.sha256}
    with conn.transaction():
        cur = conn.cursor()
        cur.execute("SET LOCAL lock_timeout = '10s'")
        require_schema(cur)
        cur.execute("LOCK TABLE bkk_traffic.incidents, bkk_traffic.traffic_index_history, "
                    "bkk_traffic.travel_times IN EXCLUSIVE MODE")
        state = db_state(cur)
        if pipeline_rows(state):
            raise LoadError(f"pipeline-written rows exist {pipeline_rows(state)}; PostgreSQL is the source "
                            "of truth after cutover and a Parquet snapshot must not replace it")
        previous = state["current_load"]
        cur.execute(
            "INSERT INTO bkk_traffic.load_history (run_id, source_db, source_sha256, source_signature, "
            "source_manifests, status, row_counts, message) VALUES (%s, %s, %s, %s, %s, 'started', '{}', %s) "
            "RETURNING load_id",
            (run_id, f"parquet:{snapshot.source_dir.as_posix()}", snapshot.sha256, snapshot.signature,
             json.dumps(snapshot.manifests()), "loading"))
        load_id = cur.fetchone()[0]
        replaced = {}
        for spec in LOADED:
            cur.execute(f"DELETE FROM {SCHEMA}.{spec.table} WHERE baseline_load_id IS NOT NULL")
            replaced[spec.table] = cur.rowcount
        for spec in LOADED:
            extra_values = (0, load_id) if spec.table == "incidents" else (load_id,)
            copy_dataset(cur, f"{SCHEMA}.{spec.table}", snapshot.reports[spec.name], spec,
                         spec.extra_columns, extra_values, batch_size)
            if fail_after == spec.table:
                raise InjectedFailure(f"injected failure after copying {spec.table}")

        # accidents_bangkok: verified against the view, never stored.
        cur.execute("CREATE TEMP TABLE tmp_accidents_bangkok ON COMMIT DROP AS "
                    "SELECT * FROM bkk_traffic.accidents_bangkok WITH NO DATA")
        copy_dataset(cur, "tmp_accidents_bangkok", snapshot.reports["accidents_bangkok"],
                     SPECS["accidents_bangkok"], (), (), batch_size)
        cur.execute("SELECT (SELECT count(*) FROM (SELECT * FROM tmp_accidents_bangkok EXCEPT ALL "
                    "SELECT * FROM bkk_traffic.accidents_bangkok) a), "
                    "(SELECT count(*) FROM (SELECT * FROM bkk_traffic.accidents_bangkok EXCEPT ALL "
                    "SELECT * FROM tmp_accidents_bangkok) b), "
                    "(SELECT count(*) FROM bkk_traffic.accidents_bangkok)")
        only_file, only_view, view_rows = cur.fetchone()
        accidents_rows = snapshot.reports["accidents_bangkok"].rows
        if only_file or only_view or view_rows != accidents_rows:
            raise LoadError(f"accidents_bangkok is not the is_accident=1 subset of incidents: {only_file} row(s) "
                            f"only in the file, {only_view} only in the view, view {view_rows} vs file {accidents_rows}")

        row_counts: dict[str, Any] = {}
        problems: list[str] = []
        for spec in LOADED:
            report = snapshot.reports[spec.name]
            cur.execute(f"SELECT count(*) FROM {SCHEMA}.{spec.table} WHERE baseline_load_id = %s", (load_id,))
            loaded = cur.fetchone()[0]
            row_counts[spec.name] = {"target": spec.table, "manifest_rows": report.manifest["total_rows"],
                                     "parquet_rows": report.rows, "loaded_rows": loaded, "rejected_rows": 0,
                                     "replaced_rows": replaced[spec.table]}
            if not (report.manifest["total_rows"] == report.rows == loaded):
                problems.append(f"{spec.name}: manifest {report.manifest['total_rows']}, parquet {report.rows}, "
                                f"loaded {loaded}")
            problems += compare_fingerprints(spec.name, report.fingerprint, db_fingerprint(cur, spec, load_id))
        row_counts["accidents_bangkok"] = {"target": "view bkk_traffic.accidents_bangkok",
                                           "manifest_rows": snapshot.reports["accidents_bangkok"].manifest["total_rows"],
                                           "parquet_rows": accidents_rows, "view_rows": view_rows,
                                           "loaded_rows": 0, "rejected_rows": 0, "physical_copies": 0}
        if problems:
            raise LoadError("reconciliation failed:\n  " + "\n  ".join(problems))

        cur.execute("SET CONSTRAINTS ALL IMMEDIATE")      # deferred FKs are checked now, inside the load
        cur.execute(DUPLICATE_KEY_SQL)
        duplicates = cur.fetchone()[0]
        row_counts["incidents_bangkok"]["business_key_duplicates"] = duplicates
        message = (f"loaded snapshot {snapshot.sha256[:12]}; previous load "
                   f"{previous['load_id'] if previous else None}; business-key duplicates {duplicates}")
        cur.execute("UPDATE bkk_traffic.load_history SET status = 'success', finished_at = now(), "
                    "row_counts = %s, message = %s WHERE load_id = %s",
                    (json.dumps(row_counts), message, load_id))
        result.update({"status": "success", "load_id": load_id, "previous_load_id": previous and previous["load_id"],
                       "row_counts": row_counts, "message": message})
    return result


def run(dsn: str, source_dir: Path, expected_database: str, *, dry_run: bool = False,
        production_approved: bool = False, run_id: str | None = None, batch_size: int = 50_000,
        fail_after: str | None = None) -> dict[str, Any]:
    run_id = run_id or f"bkk-parquet-{datetime.now():%Y%m%dT%H%M%S}"
    check_target_dsn(dsn, expected_database, production_approved)   # refuse before reading anything
    snapshot_error: LoadError | None = None
    try:
        snapshot = validate_snapshot(Path(source_dir), batch_size)
    except LoadError as exc:
        snapshot, snapshot_error = None, exc
    conn = connect(dsn, expected_database, production_approved, read_only=dry_run)
    try:
        with conn.transaction():
            cur = conn.cursor()
            require_schema(cur)
            state = db_state(cur)
        if snapshot_error:
            if not dry_run:
                _record(conn, run_id, None, "failed", {}, str(snapshot_error))
            raise snapshot_error
        base = {"run_id": run_id, "source_sha256": snapshot.sha256, "datasets": snapshot.manifests(),
                "state_before": state}
        if is_unchanged(state, snapshot):
            if not dry_run:
                _record(conn, run_id, snapshot, "unchanged", {"current_load_id": state["current_load"]["load_id"]},
                        "same snapshot already loaded; nothing written")
            return {**base, "status": "unchanged", "dry_run": dry_run}
        if pipeline_rows(state):
            raise LoadError(f"pipeline-written rows exist {pipeline_rows(state)}; refusing to replace them")
        if dry_run:
            return {**base, "status": "would_load", "dry_run": True}
        try:
            return {**base, **load_snapshot(conn, snapshot, run_id, batch_size, fail_after), "dry_run": False}
        except BaseException as exc:
            try:
                _record(conn, run_id, snapshot, "failed", {}, f"{type(exc).__name__}: {exc}")
            except Exception:  # noqa: BLE001 - the original error matters more
                pass
            raise
    finally:
        conn.close()


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Load the BKK Traffic Parquet snapshot into bkk_traffic.")
    parser.add_argument("--source-dir", type=Path, required=True,
                        help="folder holding incidents_bangkok/, accidents_bangkok/, traffic_index/, travel_times/")
    parser.add_argument("--expected-database", required=True, help="must equal the DSN's database name")
    parser.add_argument("--dsn", default=os.environ.get("BKK_TRAFFIC_DATABASE_URL"),
                        help="PostgreSQL DSN; may also be supplied as BKK_TRAFFIC_DATABASE_URL")
    parser.add_argument("--dry-run", action="store_true", help="validate and report; never writes")
    parser.add_argument("--production-approved", action="store_true",
                        help="required for namtang_db; use only with explicit approval")
    parser.add_argument("--run-id")
    parser.add_argument("--batch-size", type=int, default=50_000)
    args = parser.parse_args(argv)
    if not args.dsn:
        parser.error("--dsn or BKK_TRAFFIC_DATABASE_URL is required")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        result = run(args.dsn, args.source_dir, args.expected_database, dry_run=args.dry_run,
                     production_approved=args.production_approved, run_id=args.run_id,
                     batch_size=args.batch_size)
    except TargetRefused as exc:
        print(json.dumps({"status": "refused", "error": str(exc)}, ensure_ascii=False))
        return 2
    except Exception as exc:  # noqa: BLE001 - reported, non-zero exit
        print(json.dumps({"status": "failed", "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
