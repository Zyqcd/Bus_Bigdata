"""Bulk-load one Namtang feed (clean + derived Parquet) into PostgreSQL.

The loader streams Parquet record batches into PostgreSQL COPY. It does not
materialize the 5.96M-row feed in Python memory and never changes Parquet.

Latest-snapshot model: the database holds exactly one feed at a time.

* The caller must name the feed directories explicitly (no default feed).
* Inputs must be complete: ``_SUCCESS`` plus successful metadata, and the
  analysis output must come from the same clean run and feed SHA-256.
* If every selected table already holds exactly this feed (same SHA-256 and
  the expected row counts), nothing is written and the result is "unchanged".
* Otherwise the selected tables are truncated and reloaded inside ONE
  transaction; row counts and feed identity are verified and a
  ``namtang.load_history`` row is written before COMMIT. Any failure rolls the
  whole transaction back, so the previous snapshot stays intact.
* ``--replace`` forces that reload even when the feed is unchanged.

Usage:
    python database/load/load_namtang.py --clean-dir data/clean/namtang/<feed> \\
        --analysis-dir data/analysis/namtang/<feed> [--dsn ... | DATABASE_URL]
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

import pyarrow.parquet as pq


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
from namtang_scraper import RUN_ROW_FILE, append_log  # noqa: E402  shared run log

SCRAPE_LOG = ROOT / "data" / "metadata" / "scrape_log.csv"
SUCCESS_MARKER = "_SUCCESS"

SOURCE_TABLES = (
    "agency", "routes", "trips", "stop_times", "stops", "calendar",
    "calendar_dates", "shapes", "frequencies", "fare_attributes",
    "fare_rules", "feed_info",
)
ANALYSIS_TABLES = (
    "agencies_analysis", "fare_analysis", "frequencies_analysis",
    "routes_analysis", "shapes_analysis", "stop_times_analysis",
    "stops_analysis", "trips_analysis",
)


class LoadError(Exception):
    """Inputs or database state that make a safe load impossible."""


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Load one Namtang feed into PostgreSQL.")
    parser.add_argument("--dsn", default=os.environ.get("DATABASE_URL"),
                        help="PostgreSQL DSN; may also be supplied as DATABASE_URL")
    parser.add_argument("--clean-dir", type=Path, required=True,
                        help="completed clean feed directory, e.g. data/clean/namtang/<feed>")
    parser.add_argument("--analysis-dir", type=Path,
                        help="completed analysis directory for the same feed "
                             "(required unless --source-only)")
    parser.add_argument("--source-only", action="store_true",
                        help="Load only the 12 source GTFS tables (analysis tables untouched)")
    parser.add_argument("--replace", action="store_true",
                        help="Reload even if the database already holds this feed")
    parser.add_argument("--dry-run", action="store_true",
                        help="Only report whether the feed is unchanged or would be loaded")
    parser.add_argument("--batch-size", type=int, default=100_000)
    args = parser.parse_args(argv)
    if not args.dsn:
        parser.error("--dsn or DATABASE_URL is required")
    if args.batch_size < 1:
        parser.error("--batch-size must be positive")
    if not args.source_only and args.analysis_dir is None:
        parser.error("--analysis-dir is required unless --source-only is given")
    return args


# --------------------------------------------------------------------------
# Inputs
# --------------------------------------------------------------------------

def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise LoadError(f"cannot read {path}: {exc}") from exc


def read_metadata(clean_dir: Path) -> dict:
    if not (clean_dir / SUCCESS_MARKER).is_file():
        raise LoadError(f"{clean_dir} has no {SUCCESS_MARKER}; clean output is incomplete")
    metadata = _read_json(clean_dir / "metadata.json")
    if metadata.get("status") != "success":
        raise LoadError("clean metadata is not marked successful")
    if metadata.get("feed_sha256_verified") is not True:
        raise LoadError("clean metadata does not verify feed_sha256")
    if not metadata.get("feed_sha256"):
        raise LoadError("clean metadata has no feed_sha256")
    return metadata


def read_analysis_metadata(analysis_dir: Path, clean_metadata: dict) -> dict:
    if not (analysis_dir / SUCCESS_MARKER).is_file():
        raise LoadError(f"{analysis_dir} has no {SUCCESS_MARKER}; analysis output is incomplete")
    metadata = _read_json(analysis_dir / "metadata.json")
    if metadata.get("status") != "success":
        raise LoadError("analysis metadata is not marked successful")
    source = metadata.get("source", {})
    if source.get("feed_sha256") != clean_metadata["feed_sha256"]:
        raise LoadError("analysis and clean feed_sha256 values do not match")
    if source.get("feed_version") != clean_metadata["feed_version"]:
        raise LoadError("analysis and clean feed_version values do not match")
    if source.get("clean_run_id") != clean_metadata.get("run_id"):
        raise LoadError("analysis was built from a different clean run; rebuild it first")
    return metadata


class FeedInputs:
    """Validated, explicitly selected inputs for one feed."""

    def __init__(self, clean_dir: Path, analysis_dir: Path | None, source_only: bool):
        self.clean_dir = clean_dir
        self.analysis_dir = analysis_dir
        self.clean_metadata = read_metadata(clean_dir)
        self.analysis_metadata = None
        if not source_only:
            if analysis_dir is None:
                raise LoadError("an analysis directory is required unless source_only")
            self.analysis_metadata = read_analysis_metadata(analysis_dir, self.clean_metadata)
        self.feed_sha256: str = self.clean_metadata["feed_sha256"]
        self.feed_version: str = self.clean_metadata["feed_version"]

        self.selected: list[tuple[str, str, Path]] = []
        self.expected: dict[tuple[str, str], int] = {}
        for table in SOURCE_TABLES:
            self._add("namtang", table, clean_dir,
                      self.clean_metadata["tables"][table]["clean_rows"])
        if self.analysis_metadata is not None:
            for table in ANALYSIS_TABLES:
                self._add("namtang_analysis", table, analysis_dir,
                          self.analysis_metadata["output_tables"][f"{table}.parquet"])

    def _add(self, schema: str, table: str, directory: Path, expected_rows: Any) -> None:
        path = directory / f"{table}.parquet"
        if not path.is_file():
            raise LoadError(f"missing input file {path}")
        self.selected.append((schema, table, path))
        self.expected[(schema, table)] = int(expected_rows)


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------

def scalar_text(value: object) -> object:
    if value is None:
        return r"\N"
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return value


def csv_batches(parquet_path: Path, batch_size: int) -> Iterable[str]:
    parquet = pq.ParquetFile(parquet_path)
    for batch in parquet.iter_batches(batch_size=batch_size):
        columns = batch.to_pydict()
        names = list(columns)
        rows = zip(*(columns[name] for name in names))
        output = io.StringIO()
        writer = csv.writer(output, lineterminator="\n")
        for row in rows:
            writer.writerow([scalar_text(value) for value in row])
        yield output.getvalue()


def copy_table(cur, schema: str, table: str, parquet_path: Path, batch_size: int) -> None:
    from psycopg import sql

    columns = pq.ParquetFile(parquet_path).schema_arrow.names
    statement = sql.SQL("COPY {}.{} ({}) FROM STDIN WITH (FORMAT csv, NULL '\\N')").format(
        sql.Identifier(schema),
        sql.Identifier(table),
        sql.SQL(", ").join(sql.Identifier(column) for column in columns),
    )
    with cur.copy(statement) as copy:
        for chunk in csv_batches(parquet_path, batch_size):
            copy.write(chunk)


def qualified(schema: str, table: str) -> str:
    # Table names come only from the fixed allowlists above.
    return f'"{schema}"."{table}"'


def snapshot_state(cur, inputs: FeedInputs) -> dict[tuple[str, str], dict[str, Any]]:
    """Row count and feed identity currently stored in each selected table."""
    state = {}
    for schema, table, _ in inputs.selected:
        cur.execute(f"SELECT count(*), min(feed_sha256), max(feed_sha256) "
                    f"FROM {qualified(schema, table)}")
        rows, low, high = cur.fetchone()
        state[(schema, table)] = {"rows": int(rows), "min_sha": low, "max_sha": high}
    return state


def holds_feed(state: dict[tuple[str, str], dict[str, Any]], inputs: FeedInputs) -> bool:
    """True when every selected table holds exactly this feed with the expected rows."""
    return all(
        s["rows"] == inputs.expected[key]
        and (s["rows"] == 0 or s["min_sha"] == s["max_sha"] == inputs.feed_sha256)
        for key, s in state.items()
    )


def previous_feed(state: dict[tuple[str, str], dict[str, Any]]) -> str | None:
    shas = {s["min_sha"] for s in state.values() if s["rows"]} | \
        {s["max_sha"] for s in state.values() if s["rows"]}
    return next(iter(shas)) if len(shas) == 1 else (",".join(sorted(shas)) or None)


def require_history_table(cur) -> None:
    cur.execute("SELECT to_regclass('namtang.load_history')")
    if cur.fetchone()[0] is None:
        raise LoadError("namtang.load_history is missing; apply migration "
                        "005_create_load_history.sql first")


def replace_snapshot(cur, inputs: FeedInputs, run_id: str, previous: str | None,
                     batch_size: int) -> dict[str, int]:
    """TRUNCATE + COPY + verify + history row. Caller owns the transaction."""
    for schema, table, _ in reversed(inputs.selected):
        cur.execute(f"TRUNCATE TABLE {qualified(schema, table)}")
    for schema, table, path in inputs.selected:
        copy_table(cur, schema, table, path, batch_size)
    after = snapshot_state(cur, inputs)
    for key, s in after.items():
        if s["rows"] != inputs.expected[key]:
            raise LoadError(f"row-count mismatch for {key[0]}.{key[1]}: "
                            f"expected {inputs.expected[key]}, got {s['rows']}")
        if s["rows"] and not (s["min_sha"] == s["max_sha"] == inputs.feed_sha256):
            raise LoadError(f"feed identity mismatch in {key[0]}.{key[1]}")
    counts = {f"{schema}.{table}": after[(schema, table)]["rows"]
              for schema, table, _ in inputs.selected}
    cur.execute(
        "INSERT INTO namtang.load_history (run_id, feed_sha256, feed_version, clean_run_id, "
        "analysis_run_id, status, previous_feed_sha256, row_counts, message) "
        "VALUES (%s, %s, %s, %s, %s, 'success', %s, %s::jsonb, %s)",
        (run_id, inputs.feed_sha256, inputs.feed_version, inputs.clean_metadata.get("run_id"),
         (inputs.analysis_metadata or {}).get("run_id"), previous, json.dumps(counts),
         f"replaced snapshot {previous or '(empty)'} with {inputs.feed_sha256}"
         + (" (source tables only)" if inputs.analysis_metadata is None else "")),
    )
    return counts


# --------------------------------------------------------------------------
# Entry point
# --------------------------------------------------------------------------

def load_feed(
    dsn: str,
    clean_dir: Path,
    analysis_dir: Path | None = None,
    *,
    source_only: bool = False,
    force: bool = False,
    dry_run: bool = False,
    batch_size: int = 100_000,
    run_id: str | None = None,
    log_path: Path | None = SCRAPE_LOG,
    connect: Callable[[str], Any] | None = None,
) -> dict[str, Any]:
    """Load one feed; returns {"status": "unchanged" | "loaded" | "would_load", ...}.

    Raises LoadError on any failure, after the transaction has been rolled back.
    """
    run_id = run_id or f"load-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    inputs = FeedInputs(clean_dir, analysis_dir, source_only)
    if connect is None:
        try:
            import psycopg
        except ImportError as exc:
            raise LoadError("Install the PostgreSQL driver with: "
                            "python -m pip install -r requirements.txt") from exc
        connect = psycopg.connect

    result: dict[str, Any] = {"run_id": run_id, "feed_sha256": inputs.feed_sha256,
                              "feed_version": inputs.feed_version,
                              "clean_dir": str(clean_dir),
                              "analysis_dir": str(analysis_dir) if analysis_dir else None,
                              "tables_selected": len(inputs.selected)}
    try:
        # psycopg: leaving the block normally commits, an exception rolls back.
        with connect(dsn) as connection:
            with connection.cursor() as cur:
                state = snapshot_state(cur, inputs)
                previous = previous_feed(state)
                result["previous_feed_sha256"] = previous
                if holds_feed(state, inputs) and not force:
                    result.update(status="unchanged", row_counts={
                        f"{k[0]}.{k[1]}": s["rows"] for k, s in state.items()})
                elif dry_run:
                    result.update(status="would_load")
                else:
                    require_history_table(cur)
                    result["row_counts"] = replace_snapshot(cur, inputs, run_id, previous,
                                                            batch_size)
                    result["status"] = "loaded"
    except Exception as exc:
        _log(log_path, result, "failed", f"{type(exc).__name__}: {exc}", inputs)
        if isinstance(exc, LoadError):
            raise
        raise LoadError(f"{type(exc).__name__}: {exc}") from exc
    result["row_counts_verified"] = result["status"] in ("unchanged", "loaded")
    _log(log_path, result, result["status"], None, inputs)
    return result


def _log(log_path: Path | None, result: dict[str, Any], status: str, error: str | None,
         inputs: FeedInputs) -> None:
    if log_path is None:
        return
    counts = result.get("row_counts") or {}
    source_rows = sum(v for k, v in counts.items() if k.startswith("namtang."))
    append_log(log_path, [{
        "run_id": result["run_id"],
        "scrape_timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": "namtang_gtfs", "feed_version": inputs.feed_version,
        "zip_sha256": inputs.feed_sha256, "raw_path": inputs.clean_metadata.get("source_raw_dir"),
        "file": RUN_ROW_FILE, "status": status,
        "clean_rows": source_rows if counts else None,
        "error": error or (f"previous={result.get('previous_feed_sha256')} "
                           f"current={inputs.feed_sha256}"
                           if status in ("loaded", "unchanged") else None),
        "stage": "load",
    }])


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        result = load_feed(args.dsn, args.clean_dir, args.analysis_dir,
                           source_only=args.source_only, force=args.replace,
                           dry_run=args.dry_run, batch_size=args.batch_size)
    except LoadError as exc:
        print(json.dumps({"status": "failed", "error": str(exc)}, indent=2), file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
