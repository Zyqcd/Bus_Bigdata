# Namtang PostgreSQL migration and export

This database workflow owns only the Namtang GTFS / public-transportation dataset. Source GTFS tables are in the `namtang` schema. The eight existing derived analysis snapshots are loaded, unchanged, into the separate `namtang_analysis` schema. No accident data, schema, tables, migrations, or loaders are part of this workflow.

The loader reads the existing clean and analysis Parquet files; it does not rewrite them, expand frequency rows, create service instances, or repair source values.

## Status: Phase 5 complete

Runtime was checked on 2026-10-02 against the `namtang_db` container, using read-only queries (`default_transaction_read_only=on`):

- `namtang.migration_history` has `001_create_schema`, `002_create_tables`, `003_create_indexes` and `004_create_constraints`.
- All 12 `namtang` tables and 8 `namtang_analysis` tables exist. The `public` schema has no tables.
- Every table's row count matches the clean and analysis metadata. The source total is 5,958,939.
- All 16 `idx_*` indexes from 003 exist, and all 12 `<table>_source_row_pk` primary keys from 004 exist.
- Every source row carries one feed identity: SHA `6b1a6a2d…1f42`, `feed_version` 20260930.
- DQ counts in the database match the policy: DQ-001 4, DQ-002 120, DQ-004 555, DQ-011 564, DQ-012 1,092.

## Local Docker database (this project)

| Setting | Value |
|---|---|
| Container | `namtang_db` (`docker compose up -d namtang-db`, image `postgres:18`) |
| Host port | **5433**. Port 5432 belongs to the separate `itproject_db` container; do not use or modify it |
| Database / user | `namtang_db` / `postgres` (local development password in `docker-compose.yml`) |
| DSN | `postgresql://postgres:postgres@localhost:5433/namtang_db` |

The two containers use separate volumes (`bangkok-traffic-project_namtang_pgdata` and `it_project_pgdata18`) and separate Docker networks.

Run the migrations through the container. No local `psql` is needed:

```powershell
foreach ($m in "001_create_schema","002_create_tables","003_create_indexes","004_create_constraints","005_create_load_history") {
  Get-Content "database/migrations/namtang/$m.sql" -Raw |
    docker exec -i namtang_db psql -U postgres -d namtang_db -v ON_ERROR_STOP=1
}
```

**Migration 005 (`namtang.load_history`) is new and not yet applied to the running `namtang_db`.** It was only checked inside a rolled-back transaction. Apply it once (it is additive and safe to re-run) before the first loader run that replaces a snapshot. The loader refuses to replace a snapshot without it; `unchanged` and `--dry-run` checks work either way.

The sections below describe the same steps with a local `psql` client, for any other PostgreSQL server.

## Prerequisites

- PostgreSQL 14 or newer and the `psql` client on `PATH`.
- Python 3.11 or newer.
- Project dependencies installed in the project virtual environment.

From PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

## Create a database

Create an empty database using a PostgreSQL role that can create schemas and tables. For example:

```powershell
$env:PGHOST = "localhost"
$env:PGPORT = "5433"   # namtang_db container; 5432 is itproject_db
$env:PGUSER = "postgres"
$env:PGDATABASE = "namtang_db"
createdb namtang_db
```

If the database already exists, do not run `createdb`; connect to that empty database instead. The commands below use the standard PostgreSQL environment variables. A DSN can be supplied to the loader with `--dsn` or `DATABASE_URL`.

## Run migrations

Run migrations in numeric order. Each script is safe to rerun for this repository state and records its version in `namtang.migration_history`.

```powershell
psql -v ON_ERROR_STOP=1 -f database/migrations/namtang/001_create_schema.sql
psql -v ON_ERROR_STOP=1 -f database/migrations/namtang/002_create_tables.sql
psql -v ON_ERROR_STOP=1 -f database/migrations/namtang/003_create_indexes.sql
psql -v ON_ERROR_STOP=1 -f database/migrations/namtang/004_create_constraints.sql
psql -v ON_ERROR_STOP=1 -f database/migrations/namtang/005_create_load_history.sql
```

The source schema contains these 12 tables: `agency`, `routes`, `trips`, `stop_times`, `stops`, `calendar`, `calendar_dates`, `shapes`, `frequencies`, `fare_attributes`, `fare_rules`, and `feed_info`.

## Load Namtang data

The loader streams Parquet batches through PostgreSQL `COPY`; it does not load all 5.96 million rows into Python memory. **The feed directories must be named explicitly**; there is no default feed. Both inputs must be complete (`_SUCCESS` and successful metadata), and the analysis output must come from the same clean run and feed SHA-256.

The database uses a **latest-snapshot model**: it holds exactly one feed at a time.

| Database state | What the loader does |
|---|---|
| Every selected table already holds this feed SHA-256 with the expected row counts | `unchanged`: nothing is written, so no duplicate records are created |
| Empty, or holding another feed | Truncates and reloads the selected tables, checks every row count and the feed identity, writes a `namtang.load_history` row, then commits, all in **one transaction** |
| Any error during the load | The whole transaction rolls back and the previous snapshot stays intact. The failure is recorded in `scrape_log.csv` (`stage=load`), not in the database |

```powershell
$env:DATABASE_URL = "postgresql://postgres:postgres@localhost:5433/namtang_db"
$feed = "2026-10-01"
.\.venv\Scripts\python.exe database/load/load_namtang.py `
  --clean-dir "data/clean/namtang/$feed" --analysis-dir "data/analysis/namtang/$feed"

# Report only (unchanged / would_load); never writes:
.\.venv\Scripts\python.exe database/load/load_namtang.py `
  --clean-dir "data/clean/namtang/$feed" --analysis-dir "data/analysis/namtang/$feed" --dry-run

# Force a reload of the same feed (same single transaction):
.\.venv\Scripts\python.exe database/load/load_namtang.py `
  --clean-dir "data/clean/namtang/$feed" --analysis-dir "data/analysis/namtang/$feed" --replace

# Source GTFS tables only (analysis tables are left untouched):
.\.venv\Scripts\python.exe database/load/load_namtang.py `
  --clean-dir "data/clean/namtang/$feed" --source-only
```

## Verify status and row counts

Migration status:

```powershell
psql -c "SELECT version, applied_at FROM namtang.migration_history ORDER BY version;"
```

Schema isolation and table inventory:

```powershell
psql -c "SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema IN ('namtang','namtang_analysis') ORDER BY table_schema, table_name;"
```

Source row counts (the expected total is 5,958,939 rows across the 12 source tables):

```powershell
psql -c "SELECT 'agency' AS table_name, count(*) FROM namtang.agency UNION ALL SELECT 'routes', count(*) FROM namtang.routes UNION ALL SELECT 'trips', count(*) FROM namtang.trips UNION ALL SELECT 'stop_times', count(*) FROM namtang.stop_times UNION ALL SELECT 'stops', count(*) FROM namtang.stops UNION ALL SELECT 'calendar', count(*) FROM namtang.calendar UNION ALL SELECT 'calendar_dates', count(*) FROM namtang.calendar_dates UNION ALL SELECT 'shapes', count(*) FROM namtang.shapes UNION ALL SELECT 'frequencies', count(*) FROM namtang.frequencies UNION ALL SELECT 'fare_attributes', count(*) FROM namtang.fare_attributes UNION ALL SELECT 'fare_rules', count(*) FROM namtang.fare_rules UNION ALL SELECT 'feed_info', count(*) FROM namtang.feed_info ORDER BY table_name;"
```

The clean metadata records 5,958,939 clean rows and 0 rejected rows. The loader verifies individual table counts and prints `row_counts_verified: true`; do not claim a database count unless that command has completed successfully.

## Data-quality and constraint decisions

The database preserves the Phase 3, 3.5, and 4.5 decisions. Source-row primary keys preserve lineage without imposing invalid natural keys. There is deliberately no `agency_id` uniqueness constraint because DQ-001 contains CCT/SBT collisions, and no fare-zone foreign key because DQ-002 contains valid source rows referencing missing zone 221. The duplicate frequency row, single-departure rows, repeated shape points, unused records, zero-time segments, and unrealistic derived speeds are loaded/preserved rather than repaired or discarded.

Analysis tables are snapshots of the existing Parquet outputs. Their DQ flags and relative-template semantics are not converted into service instances; `stop_times_are_relative_template` remains as published in the analysis snapshot. The PostgreSQL `stop_times_analysis` table exposes DQ-011 and DQ-012 as generated flags (`unrealistic_segment_speed` and `zero_second_segment`) from the existing derived values; this does not alter the source or analysis Parquet files, coordinates, or times.

## Fresh database procedure

1. Create an empty PostgreSQL database.
2. Run migrations 001 through 005 in order.
3. Run `load_namtang.py` with the database DSN and explicit `--clean-dir` / `--analysis-dir`, or run the daily pipeline (`data/scraper/run_pipeline.py`).
4. Check `migration_history`, schema inventory, and the loader's row-count verification.

Do not point these commands at a shared database unless the target database and role are explicitly approved. Keep the `namtang` and `namtang_analysis` schemas independent from any other project dataset. This workflow must not be extended with accident-related objects; that pipeline belongs to another team member.
