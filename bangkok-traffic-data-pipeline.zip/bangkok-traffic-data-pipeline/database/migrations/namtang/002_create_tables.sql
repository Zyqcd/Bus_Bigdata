-- Source GTFS tables. Source lineage columns are retained from clean Parquet.
CREATE TABLE IF NOT EXISTS namtang.agency (
    agency_id text NOT NULL, agency_name text, agency_url text,
    agency_timezone text, source_row bigint NOT NULL, feed_sha256 text NOT NULL,
    feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.routes (
    route_id text NOT NULL, agency_id text, route_short_name text,
    route_long_name text, route_desc text, route_type integer, route_color text,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.trips (
    route_id text NOT NULL, service_id text NOT NULL, trip_id text NOT NULL,
    trip_headsign text, direction_id integer, shape_id text,
    wheelchair_accessible integer, source_row bigint NOT NULL,
    feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.stop_times (
    trip_id text NOT NULL, arrival_time text, arrival_time_secs bigint,
    departure_time text, departure_time_secs bigint, stop_id text NOT NULL,
    stop_sequence bigint NOT NULL, timepoint integer, source_row bigint NOT NULL,
    feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.stops (
    stop_id text NOT NULL, stop_name text, stop_lat double precision,
    stop_lon double precision, zone_id text, wheelchair_boarding integer,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.calendar (
    service_id text NOT NULL, monday integer, tuesday integer, wednesday integer,
    thursday integer, friday integer, saturday integer, sunday integer,
    start_date date, end_date date, source_row bigint NOT NULL,
    feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.calendar_dates (
    service_id text NOT NULL, date date NOT NULL, exception_type integer NOT NULL,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.shapes (
    shape_id text NOT NULL, shape_pt_lat double precision,
    shape_pt_lon double precision, shape_pt_sequence bigint NOT NULL,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.frequencies (
    trip_id text NOT NULL, start_time text, start_time_secs bigint,
    end_time text, end_time_secs bigint, headway_secs bigint,
    is_single_departure boolean, source_row bigint NOT NULL,
    feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.fare_attributes (
    fare_id text NOT NULL, price double precision, currency_type text,
    payment_method integer, transfers integer, agency_id text,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.fare_rules (
    fare_id text NOT NULL, route_id text, origin_id text, destination_id text,
    source_row bigint NOT NULL, feed_sha256 text NOT NULL, feed_version text NOT NULL
);
CREATE TABLE IF NOT EXISTS namtang.feed_info (
    feed_publisher_name text, feed_publisher_url text, feed_lang text,
    feed_start_date date, feed_end_date date, feed_version text,
    feed_contact_url text, source_row bigint NOT NULL, feed_sha256 text NOT NULL
);

-- Analysis tables are derived snapshots, kept out of the source schema.
CREATE TABLE IF NOT EXISTS namtang_analysis.agencies_analysis (
    source_table text, agency_id text, agency_name text, agency_url text,
    agency_timezone text, source_row bigint, agency_identity_unresolved boolean,
    n_rows_sharing_agency_id bigint, n_routes_with_agency_id bigint,
    n_trips_with_agency_id bigint, n_fare_attributes_with_agency_id bigint,
    feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.fare_analysis (
    source_table text, fare_id text, route_id text, origin_id text, destination_id text,
    fare_rules_source_row bigint, price double precision, currency_type text,
    payment_method integer, transfers integer, agency_id text,
    fare_attributes_source_row bigint, origin_zone_resolved boolean,
    destination_zone_resolved boolean, unresolved_fare_zone boolean,
    agency_identity_unresolved boolean, selector_pattern text, feed_sha256 text,
    feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.frequencies_analysis (
    source_table text, trip_id text, start_time text, start_time_secs bigint,
    end_time text, end_time_secs bigint, headway_secs bigint,
    is_single_departure boolean, source_row bigint, window_secs bigint,
    is_duplicate_window boolean, counted_in_derived boolean,
    duplicate_of_source_row bigint, departures_per_hour double precision,
    estimated_departures_in_window bigint, counted_estimated_departures bigint,
    feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.routes_analysis (
    source_table text, route_id text, agency_id text, route_short_name text,
    route_long_name text, route_desc text, route_type integer, route_color text,
    source_row bigint, agency_identity_unresolved boolean, agency_name text,
    agency_name_candidates text, n_trips bigint, n_directions bigint,
    n_shapes bigint, n_services bigint, n_services_in_effect_at_scrape_date bigint,
    n_frequency_based_trips bigint, n_scheduled_trips bigint, n_stop_times bigint,
    n_stops bigint, n_fare_rules bigint, n_fare_rules_unresolved_zone bigint,
    is_unused boolean, feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.shapes_analysis (
    source_table text, shape_id text, n_points_source bigint,
    n_repeated_consecutive_points bigint, length_m double precision,
    min_shape_pt_sequence bigint, max_shape_pt_sequence bigint,
    min_lat double precision, max_lat double precision, min_lon double precision,
    max_lon double precision, start_lat double precision, start_lon double precision,
    end_lat double precision, end_lon double precision, first_source_row bigint,
    last_source_row bigint, n_points_collapsed bigint, n_trips bigint,
    is_unused boolean, feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.stop_times_analysis (
    source_table text, trip_id text, arrival_time text, arrival_time_secs bigint,
    departure_time text, departure_time_secs bigint, stop_id text,
    stop_sequence bigint, timepoint integer, source_row bigint, route_id text,
    stop_lat double precision, stop_lon double precision, stop_index bigint,
    is_first_stop boolean, is_last_stop boolean, is_consecutive_repeat_stop boolean,
    next_stop_id text, next_stop_sequence bigint, dwell_time_secs bigint,
    travel_time_to_next_secs bigint, segment_distance_m double precision,
    next_is_same_stop boolean, segment_speed_kmh double precision,
    unrealistic_segment_speed boolean GENERATED ALWAYS AS
        (segment_speed_kmh > 150) STORED,
    zero_second_segment boolean GENERATED ALWAYS AS
        (stop_id IS NOT NULL AND next_stop_id IS NOT NULL
         AND stop_id <> next_stop_id AND travel_time_to_next_secs = 0) STORED,
    stop_times_are_relative_template boolean, feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.stops_analysis (
    source_table text, stop_id text, stop_name text, stop_lat double precision,
    stop_lon double precision, zone_id text, wheelchair_boarding integer,
    source_row bigint, n_stop_occurrences bigint, n_trips bigint, n_routes bigint,
    n_consecutive_repeat_occurrences bigint, n_trips_visiting_more_than_once bigint,
    n_fare_rules_origin_zone bigint, n_fare_rules_destination_zone bigint,
    is_unused boolean, feed_sha256 text, feed_version text
);
CREATE TABLE IF NOT EXISTS namtang_analysis.trips_analysis (
    source_table text, route_id text, service_id text, trip_id text,
    trip_headsign text, direction_id integer, shape_id text, wheelchair_accessible integer,
    source_row bigint, n_stops bigint, n_distinct_stops bigint,
    has_consecutive_repeat_stop boolean, first_stop_id text, last_stop_id text,
    first_departure_time text, first_departure_secs bigint, last_arrival_time text,
    last_arrival_secs bigint, duration_seconds bigint, agency_id text,
    agency_identity_unresolved boolean, schedule_type text,
    n_frequency_windows_source bigint, n_frequency_windows_counted bigint,
    n_single_departure_windows bigint, estimated_departures_per_service_day bigint,
    service_in_effect_at_scrape_date boolean, feed_sha256 text, feed_version text
);

INSERT INTO namtang.migration_history (version)
VALUES ('002_create_tables')
ON CONFLICT (version) DO NOTHING;
