-- Phase 5: Namtang PostgreSQL migration.
-- Run files in numeric order with psql.
CREATE SCHEMA IF NOT EXISTS namtang;
CREATE SCHEMA IF NOT EXISTS namtang_analysis;

CREATE TABLE IF NOT EXISTS namtang.migration_history (
    version text PRIMARY KEY,
    applied_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO namtang.migration_history (version)
VALUES ('001_create_schema')
ON CONFLICT (version) DO NOTHING;
