-- Load history for the latest-snapshot model. One row is written, inside the
-- load transaction, for every successful snapshot replacement. Unchanged feeds
-- and failed loads write nothing to the database (they are recorded in
-- data/metadata/scrape_log.csv with stage=load), so a failure never modifies it.
CREATE TABLE IF NOT EXISTS namtang.load_history (
    load_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id text NOT NULL,
    feed_sha256 text NOT NULL,
    feed_version text,
    clean_run_id text,
    analysis_run_id text,
    loaded_at timestamptz NOT NULL DEFAULT now(),
    status text NOT NULL CHECK (status IN ('success', 'failed', 'unchanged')),
    previous_feed_sha256 text,
    row_counts jsonb NOT NULL,
    message text
);

CREATE INDEX IF NOT EXISTS idx_load_history_feed_sha256
    ON namtang.load_history (feed_sha256, loaded_at DESC);

INSERT INTO namtang.migration_history (version)
VALUES ('005_create_load_history')
ON CONFLICT (version) DO NOTHING;
