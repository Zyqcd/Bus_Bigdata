-- Source-row keys preserve row identity without imposing invalid GTFS natural keys.
-- In particular, agency_id is not unique because DQ-001 contains CCT/SBT collisions;
-- fare_rules has no zone foreign key because DQ-002 contains zone 221 references.
DO $$
DECLARE
    table_name text;
BEGIN
    FOREACH table_name IN ARRAY ARRAY[
        'agency', 'routes', 'trips', 'stop_times', 'stops', 'calendar',
        'calendar_dates', 'shapes', 'frequencies', 'fare_attributes',
        'fare_rules', 'feed_info'
    ] LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_constraint c
            JOIN pg_class r ON r.oid = c.conrelid
            JOIN pg_namespace n ON n.oid = r.relnamespace
            WHERE n.nspname = 'namtang'
              AND r.relname = table_name
              AND c.conname = table_name || '_source_row_pk'
        ) THEN
            EXECUTE format(
                'ALTER TABLE namtang.%I ADD CONSTRAINT %I PRIMARY KEY (source_row)',
                table_name, table_name || '_source_row_pk'
            );
        END IF;
    END LOOP;
END $$;

INSERT INTO namtang.migration_history (version)
VALUES ('004_create_constraints')
ON CONFLICT (version) DO NOTHING;
