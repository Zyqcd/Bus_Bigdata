-- Indexes support lineage, common GTFS joins, and analysis queries.
CREATE INDEX IF NOT EXISTS idx_routes_agency_id ON namtang.routes (agency_id);
CREATE INDEX IF NOT EXISTS idx_trips_route_id ON namtang.trips (route_id);
CREATE INDEX IF NOT EXISTS idx_trips_service_id ON namtang.trips (service_id);
CREATE INDEX IF NOT EXISTS idx_stop_times_trip_sequence ON namtang.stop_times (trip_id, stop_sequence);
CREATE INDEX IF NOT EXISTS idx_stop_times_stop_id ON namtang.stop_times (stop_id);
CREATE INDEX IF NOT EXISTS idx_calendar_dates_service_date ON namtang.calendar_dates (service_id, date);
CREATE INDEX IF NOT EXISTS idx_shapes_shape_sequence ON namtang.shapes (shape_id, shape_pt_sequence);
CREATE INDEX IF NOT EXISTS idx_frequencies_trip_id ON namtang.frequencies (trip_id);
CREATE INDEX IF NOT EXISTS idx_fare_rules_fare_id ON namtang.fare_rules (fare_id);
CREATE INDEX IF NOT EXISTS idx_fare_rules_route_id ON namtang.fare_rules (route_id);
CREATE INDEX IF NOT EXISTS idx_fare_rules_origin_id ON namtang.fare_rules (origin_id);
CREATE INDEX IF NOT EXISTS idx_fare_rules_destination_id ON namtang.fare_rules (destination_id);

CREATE INDEX IF NOT EXISTS idx_analysis_stop_times_trip_sequence
    ON namtang_analysis.stop_times_analysis (trip_id, stop_sequence);
CREATE INDEX IF NOT EXISTS idx_analysis_trips_route_id
    ON namtang_analysis.trips_analysis (route_id);
CREATE INDEX IF NOT EXISTS idx_analysis_frequencies_trip_id
    ON namtang_analysis.frequencies_analysis (trip_id);
CREATE INDEX IF NOT EXISTS idx_analysis_fare_unresolved
    ON namtang_analysis.fare_analysis (unresolved_fare_zone)
    WHERE unresolved_fare_zone;

INSERT INTO namtang.migration_history (version)
VALUES ('003_create_indexes')
ON CONFLICT (version) DO NOTHING;
