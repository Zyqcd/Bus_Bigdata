-- Phase 9.2: bkk_traffic PostgreSQL migration (Longdo traffic pipeline).
-- Design: docs/integration/bkk_traffic_phase9_2.md.
--
-- Run the files in numeric order, each in its own psql session:
--   PGOPTIONS='-c bkk_traffic.expected_database=<target db>' \
--     psql -v ON_ERROR_STOP=1 -d <target db> -f 001_create_schema.sql
-- Every file is one transaction, is idempotent, and refuses to run unless
-- bkk_traffic.expected_database names the connected database. Phase 9.2
-- applies them ONLY to the isolated test database namtang_bkk_traffic_test_db.
-- This schema is independent of the namtang / namtang_analysis schemas.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

CREATE SCHEMA IF NOT EXISTS bkk_traffic;
COMMENT ON SCHEMA bkk_traffic IS
    'Longdo Bangkok traffic pipeline (bronze/silver/quarantine + traffic index + travel times). '
    'Timestamps without time zone hold Asia/Bangkok wall-clock time.';

CREATE TABLE IF NOT EXISTS bkk_traffic.migration_history (
    version text PRIMARY KEY,
    applied_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('001_create_schema')
ON CONFLICT (version) DO NOTHING;

COMMIT;
