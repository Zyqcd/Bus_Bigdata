-- Phase 9.3: Parquet baseline support (docs/integration/bkk_traffic_phase9_3.md).
-- The initial load comes from the friend's published, gate-passed Parquet snapshot
-- (database/load/load_bkk_traffic.py), not from SQLite. Parquet carries silver rows
-- only: no raw JSON, so those incidents have no bronze parent.
--   * baseline_load_id (incidents, traffic_index_history, travel_times): the
--     load_history row a baseline row came from; NULL = written by the pipeline.
--   * incidents.bronze_eid is generated: eid for pipeline rows, NULL for baseline
--     rows. The deferred FK moves from eid to bronze_eid, so pipeline rows still
--     need a bronze parent and baseline rows are exempt (no raw is invented).
--   * load_history gains the snapshot identity and the 'unchanged' status.
--   * Coordinates must be valid geographic values.
--   * Views incidents_bangkok / accidents_bangkok are the published datasets'
--     definitions; accidents are a filtered subset, never stored twice.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

-- load_history: snapshot identity and 'unchanged' audit rows.
ALTER TABLE bkk_traffic.load_history ADD COLUMN IF NOT EXISTS source_signature text;
ALTER TABLE bkk_traffic.load_history ADD COLUMN IF NOT EXISTS source_manifests jsonb;
ALTER TABLE bkk_traffic.load_history DROP CONSTRAINT IF EXISTS load_history_status_check;
ALTER TABLE bkk_traffic.load_history ADD CONSTRAINT load_history_status_check
    CHECK (status IN ('started', 'success', 'failed', 'unchanged'));

-- Row provenance.
ALTER TABLE bkk_traffic.incidents ADD COLUMN IF NOT EXISTS baseline_load_id bigint;
ALTER TABLE bkk_traffic.traffic_index_history ADD COLUMN IF NOT EXISTS baseline_load_id bigint;
ALTER TABLE bkk_traffic.travel_times ADD COLUMN IF NOT EXISTS baseline_load_id bigint;
ALTER TABLE bkk_traffic.incidents ADD COLUMN IF NOT EXISTS bronze_eid bigint
    GENERATED ALWAYS AS (CASE WHEN baseline_load_id IS NULL THEN eid END) STORED;

ALTER TABLE bkk_traffic.incidents DROP CONSTRAINT IF EXISTS incidents_eid_bronze_fk;

DO $$
DECLARE
    spec text[];
BEGIN
    FOREACH spec SLICE 1 IN ARRAY ARRAY[
        ['incidents', 'incidents_bronze_eid_fk',
         'FOREIGN KEY (bronze_eid) REFERENCES bkk_traffic.bronze_incidents (eid) '
         'ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED'],
        ['incidents', 'incidents_baseline_load_fk',
         'FOREIGN KEY (baseline_load_id) REFERENCES bkk_traffic.load_history (load_id)'],
        ['traffic_index_history', 'traffic_index_history_baseline_load_fk',
         'FOREIGN KEY (baseline_load_id) REFERENCES bkk_traffic.load_history (load_id)'],
        ['travel_times', 'travel_times_baseline_load_fk',
         'FOREIGN KEY (baseline_load_id) REFERENCES bkk_traffic.load_history (load_id)'],
        ['incidents', 'incidents_coordinates_check',
         'CHECK (latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180)'],
        ['travel_times', 'travel_times_coordinates_check',
         'CHECK (from_lat BETWEEN -90 AND 90 AND to_lat BETWEEN -90 AND 90 '
         'AND from_lon BETWEEN -180 AND 180 AND to_lon BETWEEN -180 AND 180)']
    ] LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_constraint c
            JOIN pg_class r ON r.oid = c.conrelid
            JOIN pg_namespace n ON n.oid = r.relnamespace
            WHERE n.nspname = 'bkk_traffic' AND r.relname = spec[1] AND c.conname = spec[2]
        ) THEN
            EXECUTE format('ALTER TABLE bkk_traffic.%I ADD CONSTRAINT %I %s', spec[1], spec[2], spec[3]);
        END IF;
    END LOOP;
END $$;

-- The published datasets as views (column order of the friend's INCIDENT_SCHEMA).
CREATE OR REPLACE VIEW bkk_traffic.incidents_bangkok AS
SELECT eid, nid, start_time, stop_time, createtime, updatedtime, event_type_id, event_type,
       traffic_relevance, is_accident, is_bangkok, severity, title, title_en, comment, comment_en,
       latitude, longitude, province_guess, contributor, source, status, fetched_via,
       first_seen_at, last_seen_at, dq_flags
FROM bkk_traffic.incidents
WHERE is_bangkok = 1 AND is_duplicate = 0;

CREATE OR REPLACE VIEW bkk_traffic.accidents_bangkok AS
SELECT * FROM bkk_traffic.incidents_bangkok WHERE is_accident = 1;

ALTER VIEW bkk_traffic.incidents_bangkok OWNER TO bkk_traffic_owner;
ALTER VIEW bkk_traffic.accidents_bangkok OWNER TO bkk_traffic_owner;
REVOKE ALL ON bkk_traffic.incidents_bangkok, bkk_traffic.accidents_bangkok FROM PUBLIC;
GRANT SELECT ON bkk_traffic.incidents_bangkok, bkk_traffic.accidents_bangkok
    TO bkk_traffic_app, bkk_traffic_readonly;

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('006_parquet_baseline')
ON CONFLICT (version) DO NOTHING;

COMMIT;
