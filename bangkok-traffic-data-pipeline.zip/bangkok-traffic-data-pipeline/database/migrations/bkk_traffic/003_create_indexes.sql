-- Phase 9.2: secondary indexes, each tied to a query in the friend's code
-- (docs/integration/bkk_traffic_phase9_2.md section 8). Primary keys already
-- cover eid / ts lookups, MAX(eid), BETWEEN ranges and ORDER BY eid scans.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

-- clean.clean_pending, publish G8, quality/progress backlog counts: WHERE cleaned_at IS NULL.
CREATE INDEX IF NOT EXISTS ix_bronze_incidents_pending
    ON bkk_traffic.bronze_incidents (eid) WHERE cleaned_at IS NULL;

-- scrape.detect_missing_eids (start_time >= ?), quality daily counts (date ranges),
-- realtime/progress MAX/MIN(start_time).
CREATE INDEX IF NOT EXISTS ix_incidents_start_time
    ON bkk_traffic.incidents (start_time);

-- quality newest_event_age: MAX(createtime) WHERE createtime <= now.
CREATE INDEX IF NOT EXISTS ix_incidents_createtime
    ON bkk_traffic.incidents (createtime);

-- scrape.recover_missing_eids / quality: WHERE status = 'pending' ORDER BY eid DESC LIMIT n.
CREATE INDEX IF NOT EXISTS ix_missing_eids_status_eid
    ON bkk_traffic.missing_eids (status, eid DESC);

-- quality failed_runs_24h and progress runs_last_24h: started_at >= now - 1 day.
CREATE INDEX IF NOT EXISTS ix_scrape_runs_started_at
    ON bkk_traffic.scrape_runs (started_at);

-- quality 15-minute coverage: one day of fetched_at, and MIN(fetched_at).
CREATE INDEX IF NOT EXISTS ix_traffic_index_fetched_at
    ON bkk_traffic.traffic_index (fetched_at);

-- Same coverage query, plus the export order (ORDER BY fetched_at, route).
CREATE INDEX IF NOT EXISTS ix_travel_times_fetched_at_route
    ON bkk_traffic.travel_times (fetched_at, route);

-- Loader idempotency check: has this source snapshot already been loaded?
CREATE INDEX IF NOT EXISTS ix_load_history_source_sha256
    ON bkk_traffic.load_history (source_sha256, started_at DESC);

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('003_create_indexes')
ON CONFLICT (version) DO NOTHING;

COMMIT;
