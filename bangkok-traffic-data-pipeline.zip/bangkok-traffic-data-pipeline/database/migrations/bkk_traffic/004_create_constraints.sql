-- Phase 9.2: silver and quarantine rows must have a bronze parent.
-- DEFERRABLE INITIALLY DEFERRED because the friend's code deletes the bronze
-- parent before its children inside one transaction (scripts/migrate_v3_traffic_only.py
-- deletes bronze_incidents, then incidents, then quarantine) and the one-off
-- SQLite load may insert tables in any order; the check runs at COMMIT.
-- ON DELETE NO ACTION: the code always deletes children explicitly, so a
-- cascade would only hide a missed delete. event_type_id has no FK (D5).
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

DO $$
DECLARE
    child text;
BEGIN
    FOREACH child IN ARRAY ARRAY['incidents', 'quarantine'] LOOP
        IF NOT EXISTS (
            SELECT 1 FROM pg_constraint c
            JOIN pg_class r ON r.oid = c.conrelid
            JOIN pg_namespace n ON n.oid = r.relnamespace
            WHERE n.nspname = 'bkk_traffic'
              AND r.relname = child
              -- 006 replaces incidents' FK by incidents_bronze_eid_fk; re-running 004 must not restore the old one
              AND c.conname IN (child || '_eid_bronze_fk', child || '_bronze_eid_fk')
        ) THEN
            EXECUTE format(
                'ALTER TABLE bkk_traffic.%I ADD CONSTRAINT %I FOREIGN KEY (eid) '
                'REFERENCES bkk_traffic.bronze_incidents (eid) '
                'ON UPDATE NO ACTION ON DELETE NO ACTION DEFERRABLE INITIALLY DEFERRED',
                child, child || '_eid_bronze_fk'
            );
        END IF;
    END LOOP;
END $$;

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('004_create_constraints')
ON CONFLICT (version) DO NOTHING;

COMMIT;
