-- Phase 9.2: least-privilege roles for bkk_traffic (D11).
--   bkk_traffic_owner    NOLOGIN; owns the schema and every object in it.
--                        Later migrations run as a superuser with SET ROLE bkk_traffic_owner.
--   bkk_traffic_app      NOLOGIN group for the pipeline: DML on the data tables,
--                        read-only on migration_history / load_history, no DDL.
--   bkk_traffic_readonly NOLOGIN group for analysts / backend: SELECT only.
-- No role gets any privilege on namtang, namtang_analysis or public.
-- Roles are cluster-wide. Login users and passwords are created out of band
-- (secret store), e.g. CREATE ROLE <user> LOGIN PASSWORD ... IN ROLE bkk_traffic_app;
-- passwords never appear in a migration.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

DO $$
DECLARE
    role_name text;
BEGIN
    FOREACH role_name IN ARRAY ARRAY['bkk_traffic_owner', 'bkk_traffic_app', 'bkk_traffic_readonly'] LOOP
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
            EXECUTE format('CREATE ROLE %I NOLOGIN', role_name);
        END IF;
    END LOOP;
END $$;

ALTER SCHEMA bkk_traffic OWNER TO bkk_traffic_owner;

DO $$
DECLARE
    table_name text;
BEGIN
    FOR table_name IN
        SELECT c.relname FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'bkk_traffic' AND c.relkind = 'r'
    LOOP
        EXECUTE format('ALTER TABLE bkk_traffic.%I OWNER TO bkk_traffic_owner', table_name);
    END LOOP;
END $$;

REVOKE ALL ON SCHEMA bkk_traffic FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA bkk_traffic FROM PUBLIC;
GRANT USAGE ON SCHEMA bkk_traffic TO bkk_traffic_app, bkk_traffic_readonly;

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA bkk_traffic TO bkk_traffic_app;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON bkk_traffic.migration_history, bkk_traffic.load_history
    FROM bkk_traffic_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA bkk_traffic TO bkk_traffic_app;
GRANT SELECT ON ALL TABLES IN SCHEMA bkk_traffic TO bkk_traffic_readonly;

ALTER DEFAULT PRIVILEGES FOR ROLE bkk_traffic_owner IN SCHEMA bkk_traffic
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO bkk_traffic_app;
ALTER DEFAULT PRIVILEGES FOR ROLE bkk_traffic_owner IN SCHEMA bkk_traffic
    GRANT USAGE, SELECT ON SEQUENCES TO bkk_traffic_app;
ALTER DEFAULT PRIVILEGES FOR ROLE bkk_traffic_owner IN SCHEMA bkk_traffic
    GRANT SELECT ON TABLES TO bkk_traffic_readonly;

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('005_create_roles_and_grants')
ON CONFLICT (version) DO NOTHING;

COMMIT;
