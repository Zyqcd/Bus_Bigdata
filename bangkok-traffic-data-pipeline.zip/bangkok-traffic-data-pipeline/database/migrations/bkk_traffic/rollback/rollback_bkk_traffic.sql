-- Phase 9.2: full rollback of database/migrations/bkk_traffic/001-005.
-- DESTRUCTIVE: drops the bkk_traffic schema with all its data, then the three
-- NOLOGIN roles. Touches nothing in namtang, namtang_analysis or public.
-- Same guard as the migrations; run only with explicit approval:
--   PGOPTIONS='-c bkk_traffic.expected_database=<target db>' \
--     psql -v ON_ERROR_STOP=1 -d <target db> -f rollback/rollback_bkk_traffic.sql
-- DROP ROLE fails (and the whole rollback is undone) if a login user is still a
-- member, or a role still owns objects / holds privileges in another database.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic rollback refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

DROP SCHEMA IF EXISTS bkk_traffic CASCADE;

DO $$
DECLARE
    role_name text;
BEGIN
    FOREACH role_name IN ARRAY ARRAY['bkk_traffic_readonly', 'bkk_traffic_app', 'bkk_traffic_owner'] LOOP
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = role_name) THEN
            EXECUTE format('DROP OWNED BY %I', role_name);
            EXECUTE format('DROP ROLE %I', role_name);
        END IF;
    END LOOP;
END $$;

COMMIT;
