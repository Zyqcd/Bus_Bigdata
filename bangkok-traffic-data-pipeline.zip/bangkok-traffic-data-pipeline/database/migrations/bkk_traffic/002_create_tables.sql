-- Phase 9.2: the 11 tables of the friend's SQLite storage.SCHEMA plus load_history.
-- Types and rules: docs/integration/bkk_traffic_phase9_2.md sections 6-9.
--   * timestamp (without time zone) = Asia/Bangkok wall-clock, the format the
--     pipeline writes ('YYYY-MM-DD HH:MM:SS' from datetime.now() / fromtimestamp()
--     with TZ=Asia/Bangkok). Our own audit tables use timestamptz.
--   * raw API payloads are json (verbatim text, accepts \u0000); checkpoint state is jsonb.
--   * 0/1 flags stay smallint, as the pipeline compares them with = 1 / = 0.
--   * Not migrated: incidents.raw_json (deprecated, raw lives in bronze) and probe_count.
BEGIN;

DO $$
BEGIN
    IF current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database() THEN
        RAISE EXCEPTION 'bkk_traffic migration refused: bkk_traffic.expected_database (%) does not match current_database() (%)',
            current_setting('bkk_traffic.expected_database', true), current_database();
    END IF;
END $$;
SET LOCAL lock_timeout = '5s';

-- BRONZE: raw incident JSON as fetched (Bangkok + traffic-relevant only).
CREATE TABLE IF NOT EXISTS bkk_traffic.bronze_incidents (
    eid bigint PRIMARY KEY,
    raw_json json NOT NULL,
    fetched_via text NOT NULL,
    first_fetched_at timestamp NOT NULL,
    last_fetched_at timestamp NOT NULL,
    cleaned_at timestamp                -- NULL = not cleaned yet
);

-- SILVER: cleaned incidents that passed the row rules.
CREATE TABLE IF NOT EXISTS bkk_traffic.incidents (
    eid bigint PRIMARY KEY,
    nid bigint,
    title text NOT NULL,
    title_en text,
    comment text,
    comment_en text,
    latitude double precision,
    longitude double precision,
    severity smallint CONSTRAINT incidents_severity_check CHECK (severity IN (1, 2, 3)),
    event_type_id integer,              -- API "severity" field = event type id (no FK, see D5)
    start_time timestamp NOT NULL,
    stop_time timestamp,
    createtime timestamp,
    updatedtime timestamp,
    contributor text,
    source text,
    status text,                        -- textual API value ('1', '0', '', NULL)
    event_type text,
    traffic_relevance text NOT NULL
        CONSTRAINT incidents_traffic_relevance_check CHECK (traffic_relevance IN ('direct', 'affects', 'keyword')),
    is_accident smallint NOT NULL CONSTRAINT incidents_is_accident_check CHECK (is_accident IN (0, 1)),
    is_bangkok smallint NOT NULL CONSTRAINT incidents_is_bangkok_check CHECK (is_bangkok IN (0, 1)),
    province_guess text,
    fetched_via text NOT NULL,
    first_seen_at timestamp NOT NULL,
    last_seen_at timestamp NOT NULL,
    dq_flags text,
    is_duplicate smallint NOT NULL DEFAULT 0
        CONSTRAINT incidents_is_duplicate_check CHECK (is_duplicate IN (0, 1))
);

-- QUARANTINE: rows that failed the row rules (never exported).
CREATE TABLE IF NOT EXISTS bkk_traffic.quarantine (
    eid bigint PRIMARY KEY,
    reasons text NOT NULL,
    raw_json json NOT NULL,
    detected_at timestamp NOT NULL
);

-- Every eid ever seen (no content), for gap detection.
CREATE TABLE IF NOT EXISTS bkk_traffic.seen_eids (
    eid bigint PRIMARY KEY,
    is_bangkok smallint NOT NULL CONSTRAINT seen_eids_is_bangkok_check CHECK (is_bangkok IN (0, 1)),
    seen_at timestamp NOT NULL
);

CREATE TABLE IF NOT EXISTS bkk_traffic.missing_eids (
    eid bigint PRIMARY KEY,
    detected_at timestamp NOT NULL,
    last_try_at timestamp,
    tries integer NOT NULL DEFAULT 0 CONSTRAINT missing_eids_tries_check CHECK (tries >= 0),
    status text NOT NULL
        CONSTRAINT missing_eids_status_check CHECK (status IN ('pending', 'recovered', 'not_available'))
);

-- Realtime traffic index samples (ts = epoch seconds from the API).
CREATE TABLE IF NOT EXISTS bkk_traffic.traffic_index (
    ts bigint PRIMARY KEY,
    ts_local timestamp NOT NULL,
    index_value double precision,
    fetched_at timestamp NOT NULL
);

-- 5-minute traffic index series (yearly Longdo files + realtime).
CREATE TABLE IF NOT EXISTS bkk_traffic.traffic_index_history (
    ts bigint PRIMARY KEY,
    ts_local timestamp NOT NULL,
    index_value double precision,
    source text NOT NULL                -- 'realtime' or 'history:<year>'
);

CREATE TABLE IF NOT EXISTS bkk_traffic.travel_times (
    route text NOT NULL,
    fetched_at timestamp NOT NULL,
    distance_m double precision,
    duration_s double precision,
    duration_min double precision,
    from_lat double precision,
    from_lon double precision,
    to_lat double precision,
    to_lon double precision,
    raw_json json,
    PRIMARY KEY (route, fetched_at)
);

CREATE TABLE IF NOT EXISTS bkk_traffic.event_types (
    id integer PRIMARY KEY,
    name text,
    name_en text,
    icon text,
    severity integer
);

CREATE TABLE IF NOT EXISTS bkk_traffic.checkpoints (
    job text PRIMARY KEY,
    state_json jsonb NOT NULL,
    updated_at timestamp NOT NULL
);

-- BY DEFAULT (not ALWAYS) so historical SQLite ids can be loaded once, followed by setval().
CREATE TABLE IF NOT EXISTS bkk_traffic.scrape_runs (
    id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,
    job text NOT NULL,
    started_at timestamp NOT NULL,
    finished_at timestamp,
    requests integer,
    items integer,
    new_items integer,
    status text NOT NULL,
    note text
);

-- One row per SQLite -> PostgreSQL load (or later sync) attempt.
CREATE TABLE IF NOT EXISTS bkk_traffic.load_history (
    load_id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    run_id text NOT NULL,
    source_db text NOT NULL,
    source_sha256 text,
    started_at timestamptz NOT NULL DEFAULT now(),
    finished_at timestamptz,
    status text NOT NULL CONSTRAINT load_history_status_check CHECK (status IN ('started', 'success', 'failed')),
    row_counts jsonb NOT NULL DEFAULT '{}'::jsonb,
    message text
);

INSERT INTO bkk_traffic.migration_history (version)
VALUES ('002_create_tables')
ON CONFLICT (version) DO NOTHING;

COMMIT;
