# Namtang GTFS data handoff

This is the complete Namtang GTFS dataset from the production PostgreSQL database. It is a snapshot of feed **20261001**, together with the analysis tables derived from it.

| | |
|---|---|
| Source | PostgreSQL 18.6, database `namtang_db`, schemas `namtang` and `namtang_analysis` |
| Snapshot | 2026-10-03 07:27:07 Asia/Bangkok (00:27:07 UTC) |
| Feed | `feed_version` 20261001, feed SHA-256 `e5d8b18ceb00bf7a4d02caa610db2fa565b49b17e872a4649a1531efbd4e5302` |
| Dump file | `payload/namtang_20261003T0027Z.dump` (PostgreSQL custom format, 79,706,558 bytes, about 76 MB) |
| Dump SHA-256 | `feb649d1c9e79a0835db213cbd9f7864fb42daf7eabb052b369e779d3bf7ecd9` |
| Restore test | PASS (2026-10-03, clean PostgreSQL 18 container) |

The dump is **not stored in Git**; `handoff/**/payload/` is ignored. Get it from the project owner through the shared drive, then put it in `handoff/namtang/payload/` before you start.

## Target layout

The project uses **one PostgreSQL database** with a separate schema for each source:

```
namtang_db
├── namtang            <- this handoff
├── namtang_analysis   <- this handoff
└── bkk_traffic        <- separate handoff: ../bkk_traffic/README.md
```

You can restore this dump and the BKK Traffic dump into the same database. They share no objects.

## What is included

**Contents:**
- Schemas `namtang` and `namtang_analysis`.
- 22 tables, with their data, primary keys, CHECK and NOT NULL constraints, indexes, and the sequence behind `namtang.load_history`.
- No views and no foreign keys. The production schemas have none either.

**Not included:**
- `bkk_traffic` and anything in `public`;
- Airflow metadata;
- PostgreSQL roles, owners and grants;
- passwords or other credentials;
- API keys, Airflow Variables and Airflow Connections.

The full dump was scanned and contains no credentials.

## Expected row counts

**Schema `namtang`** (clean GTFS, one row per source record):

| Table | Rows |
|---|---:|
| agency | 126 |
| calendar | 7 |
| calendar_dates | 105 |
| fare_attributes | 946,175 |
| fare_rules | 946,175 |
| feed_info | 1 |
| frequencies | 10,072 |
| routes | 2,069 |
| shapes | 3,873,114 |
| stop_times | 159,358 |
| stops | 17,081 |
| trips | 4,656 |
| **GTFS tables total** | **5,958,939** |
| migration_history | 5 |
| load_history | 1 |

**Schema `namtang_analysis`** (derived, analysis-ready):

| Table | Rows |
|---|---:|
| agencies_analysis | 126 |
| fare_analysis | 946,175 |
| frequencies_analysis | 10,072 |
| routes_analysis | 2,069 |
| shapes_analysis | 3,544 |
| stop_times_analysis | 159,358 |
| stops_analysis | 17,081 |
| trips_analysis | 4,656 |
| **Total** | **1,143,081** |

All tables together hold 7,102,026 rows. [manifest.json](manifest.json) also lists per-table sizes, the structure fingerprint and the migration and load history.

## Restore

You need **PostgreSQL 18**. Use `pg_restore` version 18 or newer; older versions can't read this archive. The commands below run from the repository root.

### 1. Verify the file

Run this from the package folder, because the checksum file uses paths relative to it.

Bash:
```bash
cd handoff/namtang && sha256sum -c checksums.sha256 && cd ../..
```

PowerShell:
```powershell
(Get-FileHash handoff/namtang/payload/namtang_20261003T0027Z.dump -Algorithm SHA256).Hash.ToLower()
# must print feb649d1c9e79a0835db213cbd9f7864fb42daf7eabb052b369e779d3bf7ecd9
```

### 2a. Restore into a new local container

This starts PostgreSQL on port **5440**. You can use any free port, but avoid ports used by other project databases.

```bash
docker run -d --name namtang_local -p 127.0.0.1:5440:5432 \
  -e POSTGRES_USER=namtang -e POSTGRES_PASSWORD=choose-a-password -e POSTGRES_DB=namtang_db \
  -v namtang_local_data:/var/lib/postgresql postgres:18

# wait a few seconds for the server to start, then:
docker cp handoff/namtang/payload/namtang_20261003T0027Z.dump namtang_local:/tmp/namtang.dump
docker exec namtang_local pg_restore -U namtang -d namtang_db \
  --no-owner --no-privileges --exit-on-error /tmp/namtang.dump
docker exec namtang_local rm /tmp/namtang.dump
```

In Git Bash on Windows, run `export MSYS_NO_PATHCONV=1` first. Otherwise Git Bash rewrites the `/tmp/...` container paths.

To build the full layout, restore the BKK Traffic dump into the same database afterwards; see `../bkk_traffic/README.md`.

### 2b. Restore into an existing PostgreSQL 18 database

The target database must not already contain the schemas `namtang` or `namtang_analysis`.

```bash
pg_restore -h <host> -p <port> -U <user> -d <database> \
  --no-owner --no-privileges --exit-on-error \
  handoff/namtang/payload/namtang_20261003T0027Z.dump
```

Every object will be owned by the user you restore as. No roles are needed. The restore takes about 20 seconds on a laptop.

### 3. Check the restore

```sql
SELECT 'shapes' AS t, count(*) FROM namtang.shapes
UNION ALL SELECT 'stop_times', count(*) FROM namtang.stop_times
UNION ALL SELECT 'fare_analysis', count(*) FROM namtang_analysis.fare_analysis
UNION ALL SELECT 'feed_info', count(*) FROM namtang.feed_info;
-- expected: 3873114, 159358, 946175, 1
SELECT feed_version, feed_sha256 FROM namtang.feed_info;
-- expected: 20261001, e5d8b18c...4e5302
```

## Notes

- **This is a snapshot.** Production loads a new feed only when the published Namtang ZIP changes. Ask for a new handoff if `feed_version` moves on.
- **Schema definitions.** The schemas match `database/migrations/namtang/001..005`, and `namtang.migration_history` records them. You don't need to run the migrations after a restore.
- **Not the old reference counts.** The row counts above are the current production values for feed 20261001. They are not the historical reference counts in older reports for feed 20260930.
