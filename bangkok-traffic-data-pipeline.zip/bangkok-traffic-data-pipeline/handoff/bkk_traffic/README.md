# BKK Traffic data handoff

This package holds the complete production `bkk_traffic` dataset, as a PostgreSQL dump you can restore on your own machine.

| | |
|---|---|
| Source | PostgreSQL 18.6, database `namtang_db`, schema `bkk_traffic` |
| Snapshot | 2026-10-03 07:07:49 Asia/Bangkok (00:07:49 UTC) |
| Dump file | `payload/bkk_traffic_20261003T0007Z.dump` (custom format, 54,077,831 bytes, about 52 MB) |
| SHA-256 | `79b63c79125206ce4d957564116117e42f0a76057f38e3c06a31edccfc2b985e` |
| Restore test | PASS (2026-10-03, clean PostgreSQL 18 container) |

The dump is **not stored in Git** (`*.dump` and `payload/` are ignored). Get it from the project owner through the shared drive. Then put it in `handoff/bkk_traffic/payload/` before you start.

## What is included

- **Included:** only schema `bkk_traffic`. That means 13 tables, 2 views (`incidents_bangkok`, `accidents_bangkok`), sequences, constraints and indexes.
- **Not included:**
  - Namtang schemas (`namtang`, `namtang_analysis`);
  - Airflow metadata;
  - roles, owners and grants;
  - Airflow Variables and Connections;
  - the Longdo API key.

  The full dump was scanned and contains no credentials.

**Row counts at snapshot time** (also in [manifest.json](manifest.json)):

| Table | Rows |
|---|---:|
| incidents | 484,840 |
| traffic_index_history | 1,414,008 |
| travel_times | 865 |
| seen_eids | 543 |
| bronze_incidents | 154 |
| event_types | 18 |
| scrape_runs | 11 |
| traffic_index | 6 |
| migration_history | 6 |
| checkpoints | 3 |
| load_history | 1 |
| quarantine | 0 |
| missing_eids | 0 |
| view `incidents_bangkok` | 484,829 |
| view `accidents_bangkok` | 223,729 |

**Timestamps** are `timestamp without time zone` in Bangkok wall-clock time (UTC+7). Do not convert them as if they were UTC.

## Restore

You need Docker, or PostgreSQL 18 client tools (`pg_restore` must be version 18 or newer). Run these commands from the repository root.

### 1. Verify the file

Bash:
```bash
cd handoff/bkk_traffic && sha256sum -c checksums.sha256 && cd ../..
```

PowerShell:
```powershell
(Get-FileHash handoff/bkk_traffic/payload/bkk_traffic_20261003T0007Z.dump -Algorithm SHA256).Hash.ToLower()
# must print 79b63c79125206ce4d957564116117e42f0a76057f38e3c06a31edccfc2b985e
```

### 2a. Restore into a new local container (simplest)

This starts PostgreSQL on port **5440**. Pick any free port, but don't use a port where another project database runs.

```bash
docker run -d --name bkk_traffic_local -p 127.0.0.1:5440:5432 \
  -e POSTGRES_USER=bkk -e POSTGRES_PASSWORD=choose-a-password -e POSTGRES_DB=bkk_traffic_local \
  -v bkk_traffic_local_data:/var/lib/postgresql postgres:18

# wait a few seconds for the server to start, then:
docker cp handoff/bkk_traffic/payload/bkk_traffic_20261003T0007Z.dump bkk_traffic_local:/tmp/bkk.dump
docker exec bkk_traffic_local pg_restore -U bkk -d bkk_traffic_local \
  --no-owner --no-privileges --exit-on-error /tmp/bkk.dump
docker exec bkk_traffic_local rm /tmp/bkk.dump
```

On Git Bash for Windows, run `export MSYS_NO_PATHCONV=1` first. Otherwise Git Bash rewrites the `/tmp/...` container paths.

### 2b. Restore into an existing PostgreSQL 18 database

The target database must not already have a `bkk_traffic` schema.

```bash
pg_restore -h <host> -p <port> -U <user> -d <database> \
  --no-owner --no-privileges --exit-on-error \
  handoff/bkk_traffic/payload/bkk_traffic_20261003T0007Z.dump
```

Every object is owned by the user you restore with. No roles are needed.

### 3. Check the restore

```sql
SELECT 'incidents' AS t, count(*) FROM bkk_traffic.incidents
UNION ALL SELECT 'traffic_index_history', count(*) FROM bkk_traffic.traffic_index_history
UNION ALL SELECT 'travel_times', count(*) FROM bkk_traffic.travel_times
UNION ALL SELECT 'accidents_bangkok', count(*) FROM bkk_traffic.accidents_bangkok;
-- expected: 484840, 1414008, 865, 223729
```

## Notes

- **This is a snapshot.** Production keeps collecting every 15 minutes, so later data is not in this dump. Ask for a new handoff when you need fresher data.
- **For read-only analysis, this restore is all you need.** You only need the role setup in `database/migrations/bkk_traffic/005_create_roles_and_grants.sql` if you want to run the BKK Airflow pipeline against your copy. That also needs your own Longdo API key, set as the Airflow Variable `longdo_api_key`. The key is never shared in this package.
- **Constraint text may differ slightly.** Two coordinate CHECK constraints can show different parentheses than the production definitions after restore. This is PostgreSQL re-printing the same expression; the checks are identical.
