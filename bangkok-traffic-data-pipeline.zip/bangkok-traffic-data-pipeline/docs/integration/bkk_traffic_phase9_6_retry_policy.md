# BKK Traffic Phase 9.6.2: bounded retry policy for transient connection failures

**Date:** 2026-10-03.

**Scope:** design, implementation and **offline / test-DB** verification of the travel-time collector's retry policy.
- No production DAG run.
- No real Longdo request.
- No production DB change.
- Schedule OFF; all DAGs paused.

**Phase 9.6 stays PARTIAL.**

Background: [bkk_traffic_phase9_6_connectivity.md](bkk_traffic_phase9_6_connectivity.md).

## 1. Previous retry behaviour (Phase 9.6, as implemented)

`RouteClient.route` (one call per route):

| Item | Value |
|---|---|
| Attempts | `REQUEST_ATTEMPTS = 2` (one retry), `RETRY_DELAY_SEC = 5` |
| Retried | `requests.Timeout` **and** `requests.ConnectionError`: every transport failure, including TLS (`SSLError` is a `ConnectionError` subclass) |
| Retried | HTTP 429 and 5xx |
| Not retried | other HTTP 4xx (route without a row); `throw …` body or non-JSON (`InvalidResponse`: the whole poll fails) |
| Timeout | `timeout=180` for **both** connect and read, so one unreachable address could block an attempt for minutes |
| Retry window | ≈ 5 s per route, about 13 s per failing route including the attempts |
| Quota guard | the poll runs if `quota_left ≥ len(pairs)` (8) |

## 2. Observed TCP outage

| Source | Window |
|---|---|
| Production run, 2026-10-03 (`collect_travel_times`) | connect failures from 21:33:29 to 21:35:08 UTC, **about 99 s** (6 routes × 2 attempts); routes 7–8 then worked |
| Key-free diagnostic | IPv4 connects refused for **about 105 s** (probe #1: 63 s, probe #2: 42 s), then 72/72 connects OK |
| Per failing attempt | about 3–8 s (production), up to about 21 s per address (diagnostic) |

**Conclusion:** a 5 s retry cannot cover a window of about 100 s. A bounded policy must allow roughly 100–125 s of waiting. It must also bound the duration of every individual attempt.

## 3. Failure classes (observed, not guessed)

Probed with the production libraries (requests 2.34.2, urllib3 2.7.0) inside the Airflow image, against local sockets only. The probes are also tests (`test_classification_of_real_library_exceptions`).

| Situation | Exception requests raises | Class | Action |
|---|---|---|---|
| Connection refused / network unreachable | `ConnectionError(MaxRetryError(reason=NewConnectionError))` | **connect** | bounded backoff |
| DNS failure | `ConnectionError(MaxRetryError(reason=NameResolutionError))` (a `NewConnectionError` subclass) | **connect** | bounded backoff |
| Connect timeout | `ConnectTimeout` (a `ConnectionError` and a `Timeout`) | **connect** | bounded backoff |
| Connection reset / closed (request may have been sent) | `ConnectionError(ProtocolError)` | **response** | one retry after 5 s |
| Read timeout (request was sent) | `ReadTimeout` | **response** | one retry after 5 s |
| HTTP 429 | response | **response** | one retry after 5 s |
| HTTP 5xx | response | **response** | one retry after 5 s |
| TLS failure | `SSLError` (a `ConnectionError` subclass) | **permanent** | not retried; route without a row (previously retried) |
| HTTP 4xx (401, 403, 404, …) | response | **permanent** | not retried; route without a row |
| Invalid API key (`throw 'Route Service API Key Error'`) | 200 + `throw` body | invalid | `InvalidResponse`: not retried, the whole poll fails and rolls back (unchanged) |
| Non-JSON / malformed body | 200 | invalid | `InvalidResponse` (unchanged) |
| Invalid travel-time value (missing, non-numeric, ≤ 0, implausible) | parsed body | invalid | `InvalidResponse` in `parse_route` (unchanged) |
| Any other `requests` exception (e.g. `InvalidURL`) | — | **permanent** | not retried |

Why the classes differ:
- **connect:** the request never reached the server. Waiting does not repeat any server work, and it is the failure seen in production.
- **response:** the server may have received the request (and may count it against quota), so the retry stays short, as before.
- **TLS and 4xx:** not transient, so they are no longer retried.

## 4. Chosen strategy

| Parameter | Value | Why |
|---|---|---|
| Connect-stage backoff | **5, 10, 20, 30, 30, 30 s** (up to 7 attempts per route) | Starts quickly (short blips recover in seconds), then grows; the 30 s cap avoids long idle gaps. The cumulative **125 s** covers the observed ~99–105 s window with margin. Pure exponential (5, 10, 20, 40, 80) would waste up to 80 s after a window ending at about 100 s. |
| Response-stage retry | **one retry after 5 s** (2 attempts) | Unchanged from Phase 9.6; protects quota when the server may have counted the request |
| Poll retry budget | **150 s of total backoff sleep per poll**, shared by all routes and both classes | Hard cap on waiting per poll. The connect schedule alone (125 s) fits inside it. |
| Circuit breaker | When a connect failure can no longer be retried (schedule or budget exhausted), **later routes of the poll are not requested** (`not requested: connection unavailable`) | An outage longer than about 2 min is not hammered route by route. Those routes get no row (a real gap). |
| Hard request cap | **3 × routes per poll = 24** (checked before every attempt) | Provable upper bound independent of the error mix |
| Connect timeout | **5 s per address** (`timeout=(5, 180)`) | Normal connects take 7–40 ms (diagnostic). Caps a connect-stage attempt at about 15 s (3 IPv4 addresses; IPv6 fails immediately: no route) |
| Read timeout | 180 s (unchanged) | Legacy value |
| Quota reservation | the poll runs only if `quota_left ≥ 24` (the worst case), was `≥ 8` | Retries can never overshoot the daily / monthly guard. Every attempt (even one that never connected) is counted in `traveltime_usage`. |

**Unchanged:**
- 8 routes, list and order;
- 1 s spacing between routes;
- sequential routes (no parallelism), one task, pool `longdo_api` = 1 slot;
- endpoint and parameters;
- `(route, fetched_at)` business key: one poll means one `fetched_at`, and a retried route still yields exactly one row;
- transaction per poll; invalid payloads roll back the poll; a failed route gets no row.

## 5. Bounds

| Quantity | Bound |
|---|---|
| Requests per poll (8 routes) | **≤ 24** (hard cap). Production-like outage: 13 (6 attempts on route 1 + 7) |
| Backoff sleep per poll | **≤ 150 s** |
| Backoff sleep per route (connect) | ≤ 125 s |
| Duration of one connect-stage attempt | ≈ ≤ 15 s (3 × 5 s connect timeout) |
| **Permanent connection outage** | ≤ 7 attempts × 15 s + 125 s = **≈ 230 s**, then the circuit opens (no further requests) + 7 s route spacing → below the task `execution_timeout` (300 s) |
| Read-timeout worst case | 180 s per attempt; with one retry a route can exceed 300 s (this exposure already existed with the legacy 180 s timeout) |
| **Absolute bound** | the Airflow task `execution_timeout` of **5 min**. A killed task never commits its poll transaction, so no partial data is written. |

**Quota:** at the */15 cadence (if it is ever enabled) the worst case is 96 polls × 24 = 2,304 calls/day, below the 4,500 guard. The typical load is 96 × 8 = 768.

## 6. Test scenarios and results

New file `tests/test_bkk_traffic_traveltime_retry.py` (32 tests; fake HTTP session + fake clock, no network). The 48 Phase 9.6 tests in `tests/test_bkk_traffic_traveltime.py` pass **unchanged**.

| Scenario | Result |
|---|---|
| Classification of shaped exceptions (refused, DNS, connect timeout, reset, read timeout, TLS, other) and of **real** library exceptions (local refused port, `.invalid` DNS, silent server, plain HTTP on TLS) | PASS |
| Outage of about 95 s (5 failing attempts, success on the 6th; backoff 5 / 10 / 20 / 30 / 30) | PASS |
| Outage of 150 s (6 failures, success on attempt 7, full schedule) | PASS |
| Permanent connection failure: stops after 7 attempts / 125 s, circuit opens, the next route is not requested | PASS |
| DNS failure and connect timeout use the same schedule | PASS |
| Budget shared across routes: a second outage gets only the remaining budget (130 s total), then the circuit opens | PASS |
| No retry for invalid key, malformed body, HTTP 401 / 403 / 404, TLS: exactly 1 request, no sleep, no key in messages | PASS |
| Reset and read timeout: exactly 2 attempts, one 5 s sleep; HTTP 503 → success | PASS |
| Hard request cap; adversarial mixes (always 503, always refused, refused then 503, flapping) stay ≤ 24 requests and ≤ 150 s sleep | PASS |
| Test DB: outage then success writes **one row per route** (8 rows, one `fetched_at`, 0 duplicate keys); 13 requests counted in the quota | PASS |
| Test DB: permanent outage writes nothing, records `failed` (7 requests, key-free note) | PASS |
| Test DB: a 4xx route gets no row, the other 7 are written | PASS |
| Test DB: a malformed response after retries elsewhere rolls back the whole poll | PASS |
| Test DB: quota reservation 23 left → skipped without requests; 24 left → runs | PASS |
| The default client receives the poll cap (3 × routes) | PASS |

**Full suites:**
- **Airflow 3.3.2 image (`airflow-cli`): 398 passed, 0 failed.** The DAG parses; task ids unchanged; dependency order unchanged (scrape → update_history → collect_travel_times → clean → validate → publish → verify_postgresql); `longdo_api` pool asserted; schedule `None`; Namtang DAG tests pass.
- **Windows:** 273 passed, 110 skipped (Airflow-only and DB tests without a DSN).

## 7. Production state during this phase (read-only checks)

- `bkk_traffic.travel_times`: 841 rows, 841 distinct keys, `sum(xmin)` unchanged, so no write of any kind.
- Namtang write counters 7,102,021 / 0 / 0; DAG runs: BKK 3, Namtang 4 (unchanged).
- Running Airflow: DAG parses (no import errors), all DAGs paused, timetable "Never", pool `longdo_api` = 1, `BKK_TRAFFIC_SCHEDULE_ENABLED=false`.
- `itproject_db`: not contacted. No real Longdo request and no quota used.

## 8. Intentional limitations

- **The real effect in production is unproven.** It needs a separate, explicitly authorized run.
- If an outage exceeds the budget, the remaining routes of that poll get no row (a real gap; nothing is fabricated).
- Read timeouts (180 s) can still reach the 5-minute task timeout. In that case Airflow kills the task, nothing from the poll is written, and that poll's quota counter update is lost (the 24-request reservation keeps the guard conservative).
- The circuit opens per poll only; the next poll starts fresh.
- No IPv6 route in the container (an infrastructure fact, not changed here).

## Files changed

- `data/scraper/bkk_traffic/traveltime.py`: classification, bounded backoff, poll budget, circuit breaker, request cap, `(5, 180)` timeouts, quota reservation. `TransientRouteError` is kept as an alias of `RouteRequestError`.
- `tests/test_bkk_traffic_traveltime_retry.py` (new).
- This document; a pointer from `bkk_traffic_traveltime_mapping.md` and `bkk_traffic_phase9_6.md`.
