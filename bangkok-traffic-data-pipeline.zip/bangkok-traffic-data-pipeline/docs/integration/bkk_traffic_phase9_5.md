# BKK Traffic Phase 9.5: history pipeline ported to PostgreSQL

**Date:** 2026-10-03 (Asia/Bangkok).

**Result: PASS.** Every item was executed, and the evidence is the command or query output captured during the work.

**Scope:** the friend's `history.py` (traffic-index yearly files) only. Not in scope:
- `traveltime.py` (Phase 9.6);
- CSV export;
- the quality report;
- `feed.py`;
- any change to the friend's SQLite pipeline.

Related:
- [bkk_traffic_history_mapping.md](bkk_traffic_history_mapping.md): design, written before the code;
- [bkk_traffic_history.md](bkk_traffic_history.md): the documented gap.

## A. Original `history.py` behaviour — PASS

Read in full, together with its only caller (DAG `bkk_traffic_history`, daily 02:30, pool `longdo_api`). It:
- downloads `api/raw/trafficindex/{year}` as CSV (`timestamp,datetime,index`) through the rate-limited client;
- overwrites a raw copy;
- skips unparseable rows silently;
- computes `ts_local` with `fromtimestamp` in the container TZ;
- upserts with `ON CONFLICT(ts) DO UPDATE` (a file value overrides a realtime sample);
- tracks a `years_done` checkpoint, with every year downloaded on the first run;
- writes no run log.

Real-data evidence comes from the friend's 15 files (1,413,831 rows):
- 0 invalid, duplicate, misaligned or wrong-year rows;
- the source `datetime` equals `ts` in UTC+7 for every row;
- real outages exist every year.

## B. PostgreSQL mapping — PASS

`timestamp` → `ts` (PK); `ts_local` = `bangkok_from_epoch(ts)`; `index` → `index_value`; `source` = `history:{year}`; `baseline_load_id = NULL` when the pipeline writes or updates a row.

The existing tables are sufficient: **no migration**. Decisions H1–H10 are in the mapping doc.

## C. Timestamp policy — PASS

- `ts_local` is computed explicitly in UTC+7; the container TZ is never used.
- The file's own `datetime` **must equal** `ts` in UTC+7, so any 7-hour shift is rejected.
- A stored row with a different `ts_local` for the same `ts` aborts the year.
- Tests cover UTC+7 for 5 epochs, a file labelled in UTC, a double-shifted file, and a shifted stored row.
- **Production after the run:** 0 `ts_local` mismatches in `traffic_index_history` and in `traffic_index`.

## D. History semantics — PASS

| | `traffic_index` (current) | `traffic_index_history` (history) |
|---|---|---|
| Meaning | log of realtime polls (`fetched_at`) | one row per observation time `ts`: the 5-minute series |
| Writers | `scrape.run_traffic_index` only | yearly files (authoritative) + realtime samples (provisional, insert-only) |
| Identity | `ts` | `ts` (PK); source identity `history:{year}` / `realtime` |
| Overlap | — | file value replaces a realtime value; realtime never overrides; an identical value is a no-op |
| Retention | never deleted | never deleted |

Tested: the realtime → file replacement; realtime does not override a file value; identical baseline rows stay baseline-owned while changed ones are taken over; `verify()` consistency checks.

## E. Gap handling — PASS

**Historical gap retained, no synthetic backfill** (details in [bkk_traffic_history.md](bkk_traffic_history.md)):
- 5-minute file data ends **2026-09-30 23:55**;
- no observations at all from **2026-10-02 18:55 to 2026-10-03 01:55** (0 rows, still 0 after the production run).

The realtime API has no history. Longdo's yearly file (downloaded twice today) has not yet published October. When it does, `update_history` inserts the real points automatically.

## F. New code — PASS

| File | Purpose |
|---|---|
| `data/scraper/bkk_traffic/history.py` (new) | `parse_year` (fail-closed validation); `years_to_refresh`; `write_year` (one transaction per year: TEMP table COPY, then an upsert that changes only differing rows, then shift and mismatch checks); `run` (throttle, raw copies named by SHA, checkpoint, `scrape_runs` success / failed); `verify` (history / current consistency) |
| `airflow/dags/bkk_traffic_pipeline.py` | New task `update_history` (pool = API pool, retries 0); the pipeline is now `scrape → update_history → clean → validate → publish → verify_postgresql` |

Not changed: migrations, loader, other package modules, Namtang.

## G. Tests — PASS

| Suite | Result |
|---|---|
| `tests/test_bkk_traffic_history.py` (new, 33 tests) | covers all 15 required areas + throttle / year selection / baseline ownership / raw copies |
| `tests/test_bkk_traffic_pipeline.py` | updated: exact task order and pool map now include `update_history`; FakeClient serves the yearly file (no network); the end-to-end `dag.test()` asserts history rows |
| Full suite, Airflow 3.3.2 image (`airflow-cli`, both throwaway test DBs) | **317 passed, 0 failed** |
| Full suite, Windows, no test DSNs | 218 passed, 84 skipped |
| History + pipeline modules, Windows, BKK test DB | 59 passed, 4 skipped (Airflow-only, passed in the image) |

## H. Test DB results — PASS

Every database test ran against `namtang_bkk_traffic_test_db` (127.0.0.1:5435) as a `bkk_traffic_app` member, under the guarded fixtures:
- valid insert;
- duplicate handling;
- rerun;
- the gap stays a gap (0 rows inside a 7-hour window);
- invalid-file rejection writes nothing and records `failed`;
- timezone-shift rollback;
- per-year atomicity;
- realtime vs file semantics;
- the client is used for every request;
- Namtang's 22 tables unchanged.

## I. Idempotency — PASS

- **Test DB:** the same file twice gives `inserted 0, updated 0, unchanged 30`. Rows and tuple versions (`xmin`) are identical, with one raw copy per content.
- **Production:** the real 2026 file (77,751 rows, identical to the baseline) gave **`2026: +0 ~0`**, unchanged 77,751. The file-era rows keep their baseline ownership (0 taken over).

## J. Rollback — PASS

Tested on the test DB:
- An invalid value rejects the whole file: no rows written, a `failed` row in `scrape_runs`, no checkpoint.
- A stored row with a 7-hour-shifted `ts_local` aborts the year transaction and leaves the existing data unchanged.
- With two years where the second is invalid, the first commits and the second rolls back completely (atomic per year, as documented).

## K. Pipeline integration — PASS

- **Placement:** `update_history` sits after `scrape`, sharing the API pool, so the two run one after the other in the 1-slot pool, and before `publish` / `verify_postgresql`, so the published `traffic_index` dataset and its check include the refreshed history.
- **Validated data only:** it writes only observations that passed `parse_year`.
- **Throttle:** it refreshes at most once per `bkk_history_refresh_hours` (default 24, the original daily cadence).
- **Run order:** it was tested end-to-end in `dag.test()` in the Airflow image.

## L. Airflow result — PASS

- **Parse:** the running Airflow 3.3.2 parsed the updated DAG with **no import errors**; its tasks are scrape, update_history, clean, validate, publish, verify_postgresql.
- **Pool and schedule:** pool `longdo_api` is unchanged at 1 slot; the schedule is still `None` (`BKK_TRAFFIC_SCHEDULE_ENABLED=false`).
- **State after the run:** `bkk_traffic_pipeline` was re-paused. Runs in total: `bkk_traffic_pipeline` 2 (Phase 9.4 + Phase 9.5), `namtang_gtfs_pipeline` 4 (unchanged).

## M. Production manual verification — PASS

**Pre-checks (read-only):**
- `current_database()` = `namtang_db`;
- the `bkk_traffic` schema exists;
- the DAG's connection is `namtang_db:5432` on the Docker network (production Namtang PostgreSQL), **not** host port 5432 / `itproject_db`;
- no import errors.

**Run** `phase9_5_manual_history_verification` (unpause → trigger once → re-pause):

| Task | State | Try | Pool | Seconds |
|---|---|---|---|---|
| scrape | success | 1 | longdo_api | 31 |
| update_history | success | 1 | longdo_api | 14 |
| clean | success | 1 | default_pool | 44 |
| validate | success | 1 | default_pool | 0 |
| publish | success | 1 | default_pool | 18 |
| verify_postgresql | success | 1 | default_pool | 1 |

**Evidence:**
- **History refresh:** `scrape_runs` row `traffic_index_history success, requests 1, items 77751, new 0, "2026: +0 ~0"`; checkpoint `latest_file_point 2026-09-30 23:55:00`, file SHA `9859ac32…`.
- **Real current observation:** **ts 1790971800 = 2026-10-03 03:10:00**, index 2.8, `fetched_at` 03:15:08. It is stored in `traffic_index` and in `traffic_index_history` (`realtime`) with the same `ts_local`.
- **Counts:** history 1,414,003 → **1,414,004** (+1 real sample); file rows 1,413,831 unchanged; duplicate `ts` 0; current rows missing from history 0; `ts_local` mismatches 0 / 0.
- **Gap:** rows between 2026-10-02 18:55 and 2026-10-03 01:55: **0** before and after.
- **Side effect:** incidents view 484,823 (+1 real new incident from the scrape); accidents 223,726.

## N. Namtang isolation — PASS

Read-only captures before and after the production run are identical:
- migration and load history;
- feed `20261001`;
- the table lists and row counts of all 22 tables;
- per-table write counters (7,102,021 / 0 / 0).

The Namtang DAG was not triggered: its latest run is still the Phase 8 one and it stays paused with the schedule off. `itproject_db` was never contacted.

## O. Remaining issues

| Issue | Status |
|---|---|
| 5-minute history after 2026-09-30 23:55, and the 7-hour hole on 2026-10-02/03 | **Retained gap.** Filled automatically only if and when Longdo publishes the real data |
| Recurring schedule | **OFF** (unchanged); enabling it is a separate decision |
| `traveltime.py` | Phase 9.6 (not started) |
| CSV export, full quality report, `feed.py`, missing-eid recovery scheduling | Future tasks |
| The friend's SQLite pipeline | Untouched; decision pending |
| The test DB container `namtang_bkk_traffic_test_db` | Still running (tmpfs); `docker stop` discards it |
