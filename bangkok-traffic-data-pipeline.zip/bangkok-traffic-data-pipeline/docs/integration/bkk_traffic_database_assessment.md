# BKK Traffic (Longdo) integration: database assessment (Phase 9.1)

> **Phase 9.2 follow-up:** the unknowns (U1–U8), decisions (D1–D11), final schema, migrations and test results are in [bkk_traffic_phase9_2.md](bkk_traffic_phase9_2.md). This Phase 9.1 document is kept as written.

**Status:** assessment and design only. Nothing has been created, migrated or changed: no PostgreSQL objects, no DAGs, no data.
**Source inspected:** `scrapping--main.zip` (GitHub `athiwat2626/scrapping-`), SHA-256 `b67baa1aa310154d7407867b8b24f7af12f0d3a54a86d2989fe31d4a8653ce77`, 6,676 entries, inspected read-only from an extracted copy outside this repository.
**Evidence:** all of the source code (16 plugin modules, 7 DAGs, 5 scripts, compose and env files), plus the data shipped in the ZIP (checkpoints, Parquet manifests and schemas, quality reports, raw file counts).
**Not available:** the SQLite warehouse `data/warehouse/bkk_traffic.db` is **not in the ZIP** (the friend's `.gitignore` excludes it; the comment there says about 1.5 GB). Every table definition below therefore comes from code (`storage.py` and the SQL in every module), and values were checked against the published Parquet subset. Anything that needs the real database is marked **UNKNOWN**.

---

## 1. Friend repository overview

**What it is:** a Bangkok traffic-incident, accident and traffic-index pipeline built on traffic.longdo.com (Longdo / iTIC).

| Item | Value (from code) |
|---|---|
| Orchestration | Airflow **2.10.5** (python 3.11), LocalExecutor, own Postgres 16 for Airflow metadata (`docker-compose.yaml`) |
| Code layout | `plugins/bkk_traffic/` (business logic), `dags/` (7 DAGs), `scripts/` (one-off migrations, status) |
| Storage | One **SQLite** file `data/warehouse/bkk_traffic.db` (WAL mode, `timeout=120`), created and altered on **every** `storage.connect()` (`executescript(SCHEMA)` + `_add_missing_columns`) |
| Files | `data/raw/<source>/dt=YYYY-MM-DD/HHMMSS_*.json.gz` (raw responses, Bangkok-only items), `data/processed/<dataset>/<year>.csv`, `data/parquet/<dataset>/part-*.parquet + _manifest.json`, `data/quality/dt=*/`, `data/checkpoints/*.json`, `data/checkpoints/.rate_limit.lock` |
| Sources | `incident.json?page=N[&limit]`, `event.json?eid=X`, `api/json/traffic/index`, `geteventtype`, `api/raw/trafficindex/{year}` (CSV), `event.longdo.com/feed/{year}` (CSV), `api.longdo.com/RouteService` (needs an API key) |
| Politeness | robots.txt `Crawl-delay: 10` enforced by a cross-process `fcntl` file lock (`client.py`) shared by all tasks |
| Scope rules | Only Bangkok (point-in-polygon on `bangkok_boundary.geojson`, otherwise the last province name in the text) **and** traffic-relevant (`direct` / `affects` / `keyword`). Out-of-scope events are stored only as an id in `seen_eids` |
| Layers (`storage.py` docstring) | BRONZE `bronze_incidents` → SILVER `incidents` (+ `quarantine`) → GOLD Parquet/CSV outside the DB, published only after the validation gate |
| Snapshot size (2026-10-02, `progress.json`) | seen eids 926,499; bronze 486,149; silver 486,141 (1,338 duplicates, 124 flagged); quarantine 8; missing eids pending 1,454 / not_available 303 / recovered 283; `traffic_index_history` 1,413,965 rows (checkpoint), `traffic_index` 213; `travel_times` 839 (Parquet) |
| Published Parquet | `incidents_bangkok` 484,803; `accidents_bangkok` 223,715; `traffic_index` 1,414,001; `travel_times` 839 rows (gate G1-G9 PASS) |

**Note on scope:** the dataset includes **accidents** (`is_accident`, the `accidents_bangkok` export). The main project README currently lists accident data as "out of scope (owned by another team member)". This integration *is* that teammate's pipeline, so accidents belong to `bkk_traffic`, never to `namtang`. The README wording must be updated deliberately when integration proceeds.

## 2. Existing SQLite architecture

- **Connection:** `storage.connect()` is a context manager. It opens SQLite with WAL, runs `executescript(SCHEMA)` (all `CREATE ... IF NOT EXISTS`) and `_add_missing_columns()` (`ALTER TABLE incidents ADD COLUMN` for `dq_flags`, `is_duplicate`, `event_type_id`, `traffic_relevance`), then yields and commits on exit. DDL therefore runs on every task.
- **Concurrency:** several DAGs write at the same time (`parquet` every minute, `realtime` and `backfill` every 15 min, `traveltime` every 5 min, plus the daily ones). SQLite serializes writers; the 120 s busy timeout absorbs contention.
- **Timestamps:** all are **TEXT** `YYYY-MM-DD HH:MM:SS`, naive local time. `storage.now_str()` uses `datetime.now()`, and compose sets `TZ=Asia/Bangkok`, so local means Bangkok. API times arrive as strings in the same format, and `ts_local` = `datetime.fromtimestamp(ts)` (container local time).
- **Flags:** stored as INTEGER 0/1 (`is_accident`, `is_bangkok`, `is_duplicate`). Lists are comma-separated TEXT (`dq_flags`, `quarantine.reasons`, `contributor`).
- **Upserts:** `INSERT ... ON CONFLICT(pk) DO UPDATE SET ...=excluded...`, `INSERT OR REPLACE`, `INSERT OR IGNORE`.
- **Clean and dedup:**
  - `clean.clean_eids` deletes from one of silver/quarantine and upserts the other, per eid, and sets `bronze.cleaned_at`.
  - `mark_duplicates` builds `temp.dups` with `ROW_NUMBER() OVER (PARTITION BY contributor, title, start_time, ROUND(lat,4), ROUND(lon,4) ORDER BY eid)` and updates `is_duplicate` on the whole table (every minute).
- **History of schema changes (scripts):**
  - `migrate_bangkok_only.py` (drops non-Bangkok rows, drops the table `probe_count`);
  - `migrate_v2_layers.py` (copies `incidents.raw_json` into `bronze_incidents`, re-cleans, then sets `incidents.raw_json = NULL`);
  - `migrate_v3_traffic_only.py` (deletes non-traffic events from bronze/silver/quarantine and rewrites raw files).

## 3. Existing tables (11 in `storage.SCHEMA`)

| SQLite table | Layer / role | Writers (function) | Readers |
|---|---|---|---|
| `bronze_incidents` | **Bronze** (raw JSON per Bangkok traffic event) | `storage.upsert_incidents`, `clean.clean_eids` (`cleaned_at`), scripts | `clean.*`, `feed.load_year`, `publish.gate_checks`, `quality`, `progress` |
| `incidents` | **Silver** (cleaned events) | `clean.clean_eids`, `clean.mark_duplicates`, `storage.upsert_incidents` (delete) | `publish`, `parquet_export`, `export`, `quality`, `progress`, `scrape` (max eid, gap detection) |
| `quarantine` | **Dead-letter** (rows failing R1/R2/R3/R5/R7/R8/R9) | `clean.clean_eids`, `storage.upsert_incidents` (delete) | `publish.gate_checks` (G6), `quality`, `progress` |
| `seen_eids` | **Operational**: every eid ever seen (scope + gap tracking; content not stored) | `storage.upsert_incidents` | `storage.known_eids`, `scrape.detect_missing_eids`, `progress` |
| `missing_eids` | **Operational**: queue of eid gaps (`pending` / `recovered` / `not_available`) | `scrape.detect_missing_eids`, `scrape.recover_missing_eids`, `storage.upsert_incidents` | `quality`, `progress` |
| `event_types` | **Reference** (`geteventtype`, 18 types) | `scrape.refresh_event_types` (`INSERT OR REPLACE`) | `clean.load_types` / `load_type_names` |
| `traffic_index` | **Source snapshot** (realtime index every 15 min, with `fetched_at`) | `scrape.run_traffic_index` (`INSERT OR IGNORE`) | `quality` (coverage), `progress` |
| `traffic_index_history` | **Source time series** (5-min index 2012→now; yearly CSV overwrites realtime values) | `history.load_year` (upsert), `scrape.run_traffic_index` (`INSERT OR IGNORE`, source `realtime`) | `parquet_export`, `export`, `quality`, `parquet_export._signature` |
| `travel_times` | **Source measurement** (RouteService A→B, compact raw kept) | `traveltime.collect` (`INSERT OR REPLACE`) | `parquet_export`, `export`, `quality` |
| `checkpoints` | **Operational state** (jobs `realtime`, `backfill`, `event_feed`, `traffic_index_history`, `traveltime_usage`; mirrored to `data/checkpoints/<job>.json`) | `storage.set_checkpoint` | `storage.get_checkpoint` everywhere |
| `scrape_runs` | **Run history** (jobs `realtime`, `backfill`, `recover`; status `success` / `failed`) | `storage.log_run` | `quality` (`failed_runs_24h`), `progress` |

Tables found only in **scripts or older databases**:
- `probe_count`: dropped by `migrate_bangkok_only.py`. Whether it still exists in the real DB is **UNKNOWN**.
- `temp.dups`: a per-connection temporary table, not persistent.

**Parquet and CSV are not tables.** They are gold *artifacts* exported from silver (see section 7).

## 4. Table-by-table schema mapping

**Conventions in this section:**
- *Declared* = the SQLite DDL in `storage.SCHEMA`. SQLite only enforces the PRIMARY KEY, so "nullable" below combines the DDL, what the code guarantees, and what the 2026-10-02 Parquet showed.
- **Timestamps:** "`timestamp`" means PostgreSQL `timestamp without time zone` holding Asia/Bangkok wall-clock time, the same meaning as the SQLite text. Decision **D1** in section 15 covers the alternative.
- **Flags:** stay `smallint` 0/1 to preserve behaviour (exports write `int8`, quality code sums and compares integers). Decision **D2**.

### 4.1 `bronze_incidents` (bronze)
| Column | SQLite | Proposed PG | Null | Key / constraint | Evidence |
|---|---|---|---|---|---|
| eid | INTEGER PK | bigint | NO | **PK** | always set by `upsert_incidents` |
| raw_json | TEXT | `json` (verbatim, validated; D3) | NO | | `json.dumps(item)` always provided |
| fetched_via | TEXT | text | NO | CHECK in (`realtime`, `backfill`, `recover`, `feed`) | values observed and produced by code |
| first_fetched_at | TEXT | timestamp | NO | | set on insert, kept on conflict |
| last_fetched_at | TEXT | timestamp | NO | | updated on every upsert |
| cleaned_at | TEXT | timestamp | YES | NULL = waiting for clean | reset to NULL on every upsert |
| Indexes | `ix_bronze_pending(cleaned_at)` | **partial** `(eid) WHERE cleaned_at IS NULL` | | | `clean_pending`, gate G8 query `WHERE cleaned_at IS NULL` |

### 4.2 `incidents` (silver)
| Column | SQLite | Proposed PG | Null | Constraint | Evidence (code / Parquet) |
|---|---|---|---|---|---|
| eid | INTEGER PK | bigint | NO | **PK**; FK → `bronze_incidents(eid)` DEFERRABLE INITIALLY DEFERRED (D4) | every silver row comes from a bronze row; bronze 486,149 = silver 486,141 + quarantine 8 |
| nid | INTEGER | bigint | YES | | 824 nulls (feed rows) |
| title / title_en | TEXT | text | title NO (R5) / YES | | R5 quarantines rows without a title |
| comment / comment_en | TEXT | text | YES | | comment up to 9,385 characters |
| latitude / longitude | REAL | double precision | YES | | `R2_no_coords` rows are allowed (167 text-only Bangkok rows) |
| severity | INTEGER | smallint | YES | CHECK 1..3 | R6 sets it NULL when out of range (839 nulls; 1/2/3 observed) |
| event_type_id | INTEGER | integer | YES | **no FK** (D5) | API field `severity` = type id; feed rows carry a `type` |
| start_time | TEXT | timestamp | NO | | R3 guarantees it parses and is ≥ 2008 (0 unparseable) |
| stop_time | TEXT | timestamp | YES | | R4 sets NULL if unparseable or before start (109 nulls) |
| createtime | TEXT | timestamp | YES | | not validated by clean; 0 unparseable in published data; **UNKNOWN in full DB** |
| updatedtime | TEXT | timestamp | YES | | 12 non-null; same caveat |
| contributor | TEXT | text | YES | | a list joined with "," |
| source | TEXT | text | YES | | `longdo_event_feed` or NULL |
| status | TEXT | **text** | YES | | values `'1'`, `'0'`, `''`, NULL: textual, **not** numeric |
| event_type | TEXT | text | NO | | `classify_type` falls back to `'Unknown'` |
| traffic_relevance | TEXT | text | NO | CHECK in (`direct`, `affects`, `keyword`) | R8 quarantines NULL; gate G9 also checks it |
| is_accident | INTEGER | smallint | NO | CHECK in (0, 1) | `int(...)` always |
| is_bangkok | INTEGER | smallint | NO | CHECK in (0, 1); deliberately **not** `= 1` | R2 quarantines 0; gate G3 and quality check `!= 1` (keeps them meaningful) |
| province_guess | TEXT | text | YES | | `bangkok`, `bangkok(text)` |
| fetched_via | TEXT | text | YES | | copied from bronze |
| first_seen_at / last_seen_at | TEXT | timestamp | NO | | set by `clean_eids` |
| raw_json | TEXT | **not migrated** (D6) | | | "เลิกใช้" (deprecated); v2 migration set it NULL; not read by any current code; all-NULL in the real DB is **UNKNOWN** |
| dq_flags | TEXT | text | YES | | e.g. `R2_no_coords,R4_stop_before_start` |
| is_duplicate | INTEGER DEFAULT 0 | smallint DEFAULT 0 | NO | CHECK in (0, 1) | `mark_duplicates` |
| Indexes | `ix_incidents_start(start_time)`, `ix_incidents_bkk(is_bangkok, is_accident)` | same two, plus `ix_incidents_createtime(createtime)` (quality `MAX(createtime)`) and partial `(eid) WHERE is_bangkok=1 AND is_duplicate=0` (exports and gate) | | | |

### 4.3 `quarantine` (dead-letter)
| Column | SQLite | PG | Null | Constraint |
|---|---|---|---|---|
| eid | INTEGER PK | bigint | NO | **PK**; FK → `bronze_incidents(eid)` DEFERRABLE INITIALLY DEFERRED (D4) |
| reasons | TEXT | text | NO | comma-separated rule codes (`R1_no_eid` ... `R9_start_long_before_create`) |
| raw_json | TEXT | json | NO | the bronze raw for that eid |
| detected_at | TEXT | timestamp | NO | not updated on conflict (keeps the first detection) |

### 4.4 Operational tables
| Table | Column | SQLite | PG | Null | Constraint / note |
|---|---|---|---|---|---|
| `seen_eids` | eid | INTEGER PK | bigint | NO | PK |
| | is_bangkok | INTEGER | smallint | NO | CHECK (0, 1); updated on conflict |
| | seen_at | TEXT | timestamp | NO | first-seen time (not updated on conflict) |
| `missing_eids` | eid | INTEGER PK | bigint | NO | PK |
| | detected_at | TEXT | timestamp | NO | |
| | last_try_at | TEXT | timestamp | YES | |
| | tries | INTEGER DEFAULT 0 | integer DEFAULT 0 | NO | |
| | status | TEXT | text | NO | CHECK in (`pending`, `recovered`, `not_available`) |
| | *index* | | `(status, eid DESC)` | | the recover queue reads `WHERE status='pending' ORDER BY eid DESC LIMIT n` |
| `checkpoints` | job | TEXT PK | text | NO | PK (5 known jobs; no CHECK, so new jobs stay possible) |
| | state_json | TEXT | **jsonb** | NO | internal state, not raw source |
| | updated_at | TEXT | timestamp | NO | |
| `scrape_runs` | id | INTEGER PK AUTOINCREMENT | bigint GENERATED ALWAYS AS IDENTITY | NO | PK |
| | job | TEXT | text | NO | `realtime`, `backfill`, `recover` |
| | started_at / finished_at | TEXT | timestamp | started NO / finished YES | |
| | requests / items / new_items | INTEGER | integer | YES | |
| | status | TEXT | text | NO | CHECK in (`success`, `failed`) |
| | note | TEXT | text | YES | error text truncated to 500 characters |
| | *indexes* | | `(status, started_at)`, `(job, started_at)` | | `failed_runs_24h` and `runs_last_24h` |

### 4.5 Reference and source time series
| Table | Column | SQLite | PG | Null | Constraint / note |
|---|---|---|---|---|---|
| `event_types` | id | INTEGER PK | integer | NO | PK |
| | name / name_en / icon | TEXT | text | YES | Thai / English / icon key |
| | severity | INTEGER | smallint | YES | 1 or 3 in the source |
| `traffic_index` | ts | INTEGER PK | bigint | NO | PK, epoch seconds from the API |
| | ts_local | TEXT | timestamp | YES | `fromtimestamp(ts)` (Bangkok) |
| | index_value | REAL | double precision | YES | `to_float` may give NULL |
| | fetched_at | TEXT | timestamp | NO | *index* `(fetched_at)` for the coverage query |
| `traffic_index_history` | ts | INTEGER PK | bigint | NO | PK |
| | ts_local | TEXT | timestamp | YES | |
| | index_value | REAL | double precision | YES | the history loader skips NULL; the realtime insert may not |
| | source | TEXT | text | NO | `realtime` or `history:<year>` |
| `travel_times` | route | TEXT | text | NO | **PK** (route, fetched_at) |
| | fetched_at | TEXT | timestamp | NO | one timestamp per collect run; *index* `(fetched_at)` |
| | distance_m / duration_s / duration_min | REAL | double precision | YES | |
| | from_lat / from_lon / to_lat / to_lon | REAL | double precision | YES | |
| | raw_json | TEXT | json | YES | compact response (no `guide`) |

## 5. Table relationships

```
API / yearly CSV ──► seen_eids (every eid, scope flag)
                 └─► bronze_incidents (Bangkok + traffic only) ──clean──► incidents (silver)  ──► Parquet/CSV (gold)
                                                           └──clean──► quarantine (dead-letter)
      incidents.eid ⊂ bronze_incidents.eid ;  quarantine.eid ⊂ bronze_incidents.eid ;  incidents ∩ quarantine = ∅
missing_eids (gap queue) ──recover──► bronze/incidents ; status 'recovered' set by upsert_incidents
event_types ──(lookup by id / name prefix)──► incidents.event_type, event_type_id (soft link, no FK)
traffic_index (realtime 15-min) ──INSERT OR IGNORE──► traffic_index_history ◄── yearly CSV (overwrites)
travel_times (independent) ; checkpoints / scrape_runs (operational, keyed by job name)
```

**Invariants used by the code:**
- An eid is in **either** `incidents` or `quarantine`, never both (`clean_eids` deletes from the other table).
- Out-of-scope eids are deleted from all three content tables and kept only in `seen_eids`.

## 6. DAG → table dependency

R = read, W = insert/update, D = delete. "files" are artifacts on disk.

| DAG (schedule, Bangkok) | Task → function | bronze | incidents | quarantine | seen | missing | event_types | t_index | t_index_hist | travel | checkpoints | scrape_runs | files |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `bkk_traffic_realtime` (*/15) | `traffic_index` → `scrape.run_traffic_index` | | | | | | | W | W | | | | raw `traffic_index/` |
| | `incidents` → `run_realtime_incidents` | RWD | RWD | WD | RW | W | R (W if empty) | | | | W realtime | W | raw `incidents_realtime/` |
| | `update_progress` → `progress.write_progress_file` | R | R | R | R | R | | R | | | R | R | `progress.json` |
| `bkk_traffic_backfill` (*/15) | `backfill_batch` → `run_backfill_batch` | RWD | RWD | WD | RW | W | R (W) | | | | RW backfill | W | raw `incidents_backfill/` |
| | *when the target is reached:* `parquet_export.export_all()` and `export.export_all()` **without the gate** (D10) | | R | | | | | | R | R | | | Parquet, CSV |
| | `update_progress` | R | R | R | R | R | | R | | | R | R | `progress.json` |
| `bkk_traffic_quality` (01:00) | `refresh_event_types` | | | | | | W | | | | | | raw `event_types/` |
| | `detect_missing_eids` | | R | | R | RW | | | | | R backfill | | |
| | `recover_missing_eids` | RWD | RWD | WD | RW | RW | R | | | | | W | raw `incidents_recover/` |
| | `quality_checks` → `quality.run_quality_checks` | R | R | R | | R | | R | R | R | R | R | `quality/dt=*/`, reads Parquet |
| | `export_csv` → `publish.publish_csv` (gate, then CSV) | R | R | R | R | R | | R | R | R | R | R | `processed/*.csv`, `gate_last.json` |
| `bkk_traffic_parquet` (every minute) | `clean` → `run_clean_stage` (`clean_pending` + `mark_duplicates`) | RW | RWD | WD | | | R | | | | | | |
| | `validate_gate` → `gate_checks` | R | R | R | | | | | | | | | `gate_last.json` |
| | `publish_parquet` → `parquet_export.export_all` | | R | | | | | | R | R | | | Parquet + manifests |
| `bkk_traffic_history` (02:30) | `load_traffic_index_history` → `history.run` | | | | | | | | W | | RW t_i_h | | raw `traffic_index_history/*.csv` |
| | `load_event_feed` → `feed.run` | RW | RWD | WD | RW | W | R | | | | RW event_feed | | raw `event_feed/` |
| `bkk_traffic_traveltime` (*/5) | `collect_travel_times` → `traveltime.collect` | | | | | | | | | W | RW traveltime_usage | | |
| `bkk_traffic_maintenance` (03:30) | `delete_old_logs`, `clean_airflow_db` | none of the warehouse tables. Affects **Airflow logs and the Airflow metadata DB** (see section 13) |

**Airflow-level dependencies:**
- Pool `longdo_api` (3 slots, created in compose `airflow-init`).
- Variables: `bkk_scrape_stopped`, `bkk_backfill_start_date`, `bkk_backfill_pages_per_run`, `bkk_backfill_page_size`, `bkk_backfill_target_rows`, `bkk_realtime_max_pages`, `bkk_recover_per_run`, `longdo_api_key` (secret), `bkk_od_pairs`.

## 7. SQLite → PostgreSQL migration mapping

| Existing SQLite | PostgreSQL schema | PostgreSQL table | Type (layer) | Used by (DAGs) |
|---|---|---|---|---|
| `bronze_incidents` | bkk_traffic | `bronze_incidents` | source / bronze | realtime, backfill, quality, parquet, history |
| `incidents` | bkk_traffic | `incidents` | clean / silver | all except traveltime, maintenance |
| `quarantine` | bkk_traffic | `quarantine` | clean / dead-letter | realtime, backfill, quality, parquet, history |
| `seen_eids` | bkk_traffic | `seen_eids` | operational metadata | realtime, backfill, quality, history |
| `missing_eids` | bkk_traffic | `missing_eids` | operational metadata (work queue) | realtime, backfill, quality, history |
| `event_types` | bkk_traffic | `event_types` | reference / dimension | realtime, backfill, quality, parquet, history |
| `traffic_index` | bkk_traffic | `traffic_index` | source snapshot | realtime, quality |
| `traffic_index_history` | bkk_traffic | `traffic_index_history` | source time series | realtime, history, parquet, quality |
| `travel_times` | bkk_traffic | `travel_times` | source measurement | traveltime, parquet, quality |
| `checkpoints` | bkk_traffic | `checkpoints` | operational metadata (state) | all scraping DAGs |
| `scrape_runs` | bkk_traffic | `scrape_runs` | operational metadata (run history) | realtime, backfill, quality |
| `probe_count` (legacy) | none | **not migrated** | obsolete | none (dropped by script) |
| `incidents.raw_json` (column) | none | **not migrated** (D6) | deprecated | none |
| *(new)* | bkk_traffic | `migration_history` | operational (schema versions) | migrations only |
| *(new)* | bkk_traffic | `load_history` | operational (historical SQLite → PG loads) | one-off migration loader |
| Parquet `data/parquet/*` | none (files) | none | **gold artifact** (rebuildable from silver) | parquet, backfill |
| CSV `data/processed/*` | none (files) | none | gold artifact | quality, backfill |
| raw `data/raw/**.json.gz/.csv` | none (files) | none | raw archive (bronze per request) | all scrapers |
| `data/checkpoints/*.json` | none (files) | none | human-readable mirror of `checkpoints` (DB stays authoritative) | all scrapers |
| `progress.json`, `quality/dt=*/`, `gate_last.json` | none (files) | none | derived reports | realtime, backfill, quality, parquet |
| `.rate_limit.lock` | none | none | must stay a file lock (or become a PG advisory lock later; D9) | client |

**Should not be stored in PostgreSQL:**
- raw response files (already represented per row by `bronze_incidents.raw_json`; files remain the archive);
- Parquet and CSV exports (artifacts, fully regenerated from silver);
- quality and progress report files;
- the rate-limit lock;
- the Longdo API key (Airflow Variable or Connection, never a table).

**Source of truth:**
- **PostgreSQL** for bronze, silver, quarantine and operational state.
- **Parquet / CSV** are published gold artifacts. Each is written only after gate G1-G9 passes (except decision D10), and each is fully rebuildable from silver.

## 8. Proposed `bkk_traffic` PostgreSQL schema

- **Where:** one schema, `bkk_traffic`, in the existing database `namtang_db` (port 5433). Nothing goes in `public`, `namtang` or `namtang_analysis`.
- **Table names:** kept identical to the friend's names, so the business logic is ported, not redesigned.
- **Layer labels:** shown with `COMMENT ON TABLE`.

```sql
-- PROPOSAL ONLY (Phase 9.2 would turn this into database/migrations/bkk_traffic/00x_*.sql)
CREATE SCHEMA IF NOT EXISTS bkk_traffic;

CREATE TABLE bkk_traffic.migration_history (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now());

-- bronze
CREATE TABLE bkk_traffic.bronze_incidents (
  eid bigint PRIMARY KEY, raw_json json NOT NULL,
  fetched_via text NOT NULL CHECK (fetched_via IN ('realtime','backfill','recover','feed')),
  first_fetched_at timestamp NOT NULL, last_fetched_at timestamp NOT NULL, cleaned_at timestamp);
-- silver
CREATE TABLE bkk_traffic.incidents (
  eid bigint PRIMARY KEY REFERENCES bkk_traffic.bronze_incidents(eid) DEFERRABLE INITIALLY DEFERRED,
  nid bigint, title text NOT NULL, title_en text, comment text, comment_en text,
  latitude double precision, longitude double precision,
  severity smallint CHECK (severity BETWEEN 1 AND 3), event_type_id integer,
  start_time timestamp NOT NULL, stop_time timestamp, createtime timestamp, updatedtime timestamp,
  contributor text, source text, status text, event_type text NOT NULL,
  traffic_relevance text NOT NULL CHECK (traffic_relevance IN ('direct','affects','keyword')),
  is_accident smallint NOT NULL CHECK (is_accident IN (0,1)),
  is_bangkok smallint NOT NULL CHECK (is_bangkok IN (0,1)),
  province_guess text, fetched_via text,
  first_seen_at timestamp NOT NULL, last_seen_at timestamp NOT NULL,
  dq_flags text, is_duplicate smallint NOT NULL DEFAULT 0 CHECK (is_duplicate IN (0,1)));
CREATE TABLE bkk_traffic.quarantine (
  eid bigint PRIMARY KEY REFERENCES bkk_traffic.bronze_incidents(eid) DEFERRABLE INITIALLY DEFERRED,
  reasons text NOT NULL, raw_json json NOT NULL, detected_at timestamp NOT NULL);
-- operational / reference / time series: as in section 4.4-4.5
-- (seen_eids, missing_eids, checkpoints, scrape_runs, event_types, traffic_index,
--  traffic_index_history, travel_times, load_history)
```

`load_history` (new, for the one-off historical migration and any later re-loads):
- `load_id` (identity PK);
- `run_id`;
- `source_db` (path) and `source_sha256` (of the SQLite file);
- `started_at`, `finished_at` (`timestamptz`);
- `status` CHECK in (`success`, `failed`);
- `row_counts` `jsonb` (per table: source vs loaded);
- `message`.

## 9. Index proposal

| Table | Index | Serves |
|---|---|---|
| bronze_incidents | PK (eid); **partial** `(eid) WHERE cleaned_at IS NULL` | `clean_pending`, gate G8, quality |
| incidents | PK; `(start_time)`; `(is_bangkok, is_accident)`; `(createtime)`; partial `(eid) WHERE is_bangkok=1 AND is_duplicate=0` | quality daily counts and anomaly, progress, gate G2/G4/G5, exports ordered by eid |
| quarantine | PK | |
| seen_eids | PK (range scans `eid BETWEEN` use the PK) | gap detection, `known_eids` |
| missing_eids | PK; `(status, eid DESC)` | recover queue |
| scrape_runs | `(status, started_at)`, `(job, started_at)` | `failed_runs_24h`, `runs_last_24h` |
| traffic_index | PK (ts); `(fetched_at)` | coverage per day |
| traffic_index_history | PK (ts); optional `(ts_local)` | export order by ts (PK); daily grouping |
| travel_times | PK (route, fetched_at); `(fetched_at)` | export order, coverage |

`mark_duplicates` scans the whole silver table every minute. A composite index cannot remove that scan, because the partition key includes rounding.

## 10. Constraint proposal

- **Primary keys:** exactly the SQLite PKs. Upsert semantics depend on them.
- **Foreign keys:** `incidents.eid` and `quarantine.eid` → `bronze_incidents(eid)`, **DEFERRABLE INITIALLY DEFERRED** (D4).
  - The friend code deletes in the order incidents → bronze → quarantine inside one transaction (`upsert_incidents`). An immediate FK would fail on the `quarantine` delete; a deferred one is checked at commit, when all three rows are gone.
- **No other FKs:**
  - `event_type_id` → `event_types` stays soft (D5);
  - there's no FK from `missing_eids` / `seen_eids`, since gaps are by definition missing.
- **CHECKs:** only for values the code itself guarantees (enums and 0/1 flags above).
  - `is_bangkok` is **not** constrained to 1. Rule R2 quarantines non-Bangkok rows, and gate G3 / quality must stay able to detect a regression.
- **NOT NULL:** only where a clean rule or the writer guarantees a value (`title` R5, `start_time` R3, `traffic_relevance` R8, `event_type`, flags, operational timestamps).

## 11. Lineage proposal

- **Per row (already in the friend design):**
  - `fetched_via` and first/last fetched/seen times;
  - `bronze_incidents.raw_json` is the exact source record;
  - `quarantine.raw_json` and `reasons` explain every rejection;
  - `dq_flags` records every value the clean rules changed.
- **Gold:** each Parquet `_manifest.json` stores `signature`, `total_rows` and the gate result that allowed the publish (`validation`). Keep this.
- **Historical migration:** `load_history` records the SQLite file SHA-256 and per-table source vs loaded counts. Validation compares row counts and content checksums table by table, the same approach as Namtang Phase 5.
- **Not available:** a link from a bronze row to the raw `.json.gz` file that held it is **not stored** (`client.save_raw` names files by time and page). Adding a `raw_file` column would be a new feature and is out of scope unless approved.

## 12. Load and history proposal

Unlike Namtang (a latest-snapshot model with transactional replace), Longdo is **incremental**: continuous upserts by key, with no feed snapshots.

1. **One-off historical load** (Phase 9.3 or later):
   - copy the real `bkk_traffic.db` read-only;
   - load each table into `bkk_traffic` in a **single transaction**, in FK order: `event_types`, `bronze_incidents`, `incidents`, `quarantine`, operational tables, time series;
   - verify counts and checksums before commit;
   - record the run in `load_history`;
   - **never TRUNCATE or replace** once live pipelines write to PostgreSQL.
2. **After cut-over:** friend tasks write to PostgreSQL directly, with the same upsert semantics. `scrape_runs` stays their run history. Airflow keeps task history.
3. **Never `--replace`-style loads into `bkk_traffic`.** It holds accumulated history that can't be re-scraped quickly: 926k pages' worth at a 10 s crawl delay.

**SQLite → PostgreSQL code changes needed later.** The business logic doesn't change, only the SQL dialect:

| SQLite | PostgreSQL |
|---|---|
| `INSERT OR REPLACE` / `OR IGNORE` | `INSERT ... ON CONFLICT ... DO UPDATE / DO NOTHING` |
| `?` placeholders | `%s` |
| `PRAGMA table_info` (gate G1, `_add_missing_columns`) | `information_schema.columns` |
| `date('now','localtime',...)` / `datetime(...)` | `now() AT TIME ZONE 'Asia/Bangkok'` |
| `substr(<timestamp>,…)` | `to_char` / `::date` (if D1 = typed timestamps) |
| `IS NOT 1` | `IS DISTINCT FROM 1` |
| `ROUND(real, 4)` | `round(x::numeric, 4)` (both round half away from zero) |
| `temp.dups` | a CTE or temporary table |
| `VACUUM` in scripts | not needed |
| `sqlite3.Row` | psycopg `dict_row` |

Two more changes: remove DDL-on-connect (use migrations), and replace `executescript`.

## 13. Potential conflicts with Namtang

| # | Conflict | Impact | Proposed handling |
|---|---|---|---|
| C1 | **`bkk_traffic_maintenance` runs `airflow db clean`** (all DAGs, older than 14 days) and deletes `/opt/airflow/logs/**.log` older than 7 days | It would erase Namtang DAG run history and task logs in a shared Airflow | Don't enable it as-is in the shared stack. Scope it to `bkk_traffic_*` DAG IDs and BKK log folders, or keep maintenance manual (decision D7) |
| C2 | Airflow **2.10** code (`airflow.decorators`, `airflow.models.Variable`, `airflow.operators.bash.BashOperator`, `airflow.exceptions`) vs our **3.3.2** | Import, deprecation or runtime errors | Port the imports to `airflow.sdk` / `airflow.providers.standard` in Phase 9.x (DAG layer only, not business logic) |
| C3 | Friend compose: Airflow on **8080**, its own Postgres, `DAGS_ARE_PAUSED_AT_CREATION=false` | Port clash with our Airflow (127.0.0.1:8080); auto-running DAGs | Don't run the friend compose. Integrate the DAGs into the existing `namtang-airflow` stack (new DAGs are paused at creation there) |
| C4 | Paths: `BKK_DATA_DIR=/opt/airflow/data`, `data/raw/<source>` layout | Mixing with `data/raw/namtang/` | Use a separate root, e.g. `BKK_DATA_DIR=/opt/namtang/data/bkk_traffic` (raw, processed, parquet, quality, checkpoints under it) |
| C5 | Load on the shared scheduler and database: `parquet` every minute (full dedup UPDATE + exports), traveltime every 5 min, realtime and backfill every 15 min | May delay Namtang tasks; WAL / vacuum churn in `namtang_db` | Size LocalExecutor parallelism; consider `max_active_tasks` per BKK DAG and a slower `parquet` schedule (decision D8) |
| C6 | Database permissions | A shared `postgres` superuser could touch `namtang*` | Recommend a separate role (e.g. `bkk_traffic_app`) owning only `bkk_traffic`, with no rights on `namtang` / `namtang_analysis`, and a separate Airflow connection `bkk_traffic_postgres` (decision D11) |
| C7 | Locks | Namtang uses `data/metadata/namtang_pipeline.lock`; BKK uses `checkpoints/.rate_limit.lock` (`fcntl`, Linux only) | Independent, no clash if the paths stay separate. `fcntl` works because tasks run in the Linux scheduler container |
| C8 | Git / data volume | The friend repo commits about 680 MB of data (processed CSV 474 MB, Parquet 78 MB, raw 132 MB) | Add ignore rules for the new BKK data root, and don't commit datasets (project rule §10) |
| C9 | Tests | `tests/test_database_migration.py` scans `database/migrations/namtang/*.sql` and `database/load/*.py` for `create schema accident`, `create table accident`, `traffic_accident` | Put BKK migrations under `database/migrations/bkk_traffic/` and its loader under `database/load/bkk_traffic/`. Proposed names contain none of those strings. The existing test must not be weakened |
| C10 | Docs | The README says accident data is out of scope for this module | Update the wording to "out of scope for Namtang; provided by the `bkk_traffic` pipeline" when integrating |
| C11 | Secrets | `longdo_api_key` | An Airflow Variable or Connection set at runtime; never in compose, `.env.example` or the repo |

**No schema, table, migration or DAG of Namtang needs to change for this integration.** None was found.

## 14. Things that must NOT be changed

- **Namtang** (protected; unchanged by Phase 9.1, verified by SHA-256 snapshot):
  - `data/scraper/namtang_scraper.py`, `data/scraper/run_pipeline.py`;
  - `data/scraper/processing/{clean_gtfs,validate_gtfs,build_analysis}.py`;
  - `database/load/load_namtang.py`, `database/migrations/namtang/001-005*.sql`;
  - `airflow/dags/namtang_gtfs_pipeline.py`;
  - DQ policies, the Namtang data under `data/{raw,clean,analysis}/namtang/`, and the schemas `namtang` / `namtang_analysis` with their tables.
- **Friend business behaviour:**
  - scope rules (Bangkok polygon, text fallback, `traffic_relevance` sets and keywords, `ACCIDENT_WORDS`);
  - clean rules R1-R9 and `dq_flags`;
  - the duplicate rule (contributor + title + start_time + coordinates rounded to 4 places; the lowest eid wins);
  - gate G1-G9 thresholds; quality thresholds;
  - export filters (`is_bangkok=1 AND is_duplicate=0`, accidents additionally `is_accident=1`);
  - the Parquet schemas, `ROWS_PER_FILE` and manifest format;
  - checkpoint semantics (`page`, `anchor_time`, `done`, ...);
  - the 10 s crawl delay and the travel-time quotas;
  - the API field semantics (`severity` → `event_type_id`, `severity_level` → `severity`).
- **`itproject_db`** (port 5432): never touched.

## 15. Open questions / UNKNOWN items

| # | Item | Where to check |
|---|---|---|
| U1 | The **real SQLite schema** (columns added by `ALTER`, column order, SQLite type affinity: any value can be in any column) | `PRAGMA table_info(<t>)` and `SELECT typeof(col), count(*) ... GROUP BY 1` on the real `bkk_traffic.db` (needed from the friend) |
| U2 | Are `createtime`, `updatedtime`, `stop_time`, `ts_local` and `fetched_at` parseable in **all** rows (only the published subset was checked: 0 failures)? | Same DB; any failure decides between `timestamp` and text (D1) |
| U3 | Is `incidents.raw_json` all NULL after the v2 migration? | `SELECT count(*) FROM incidents WHERE raw_json IS NOT NULL` |
| U4 | Does `probe_count` still exist? | `sqlite_master` |
| U5 | Row counts of `event_types`, `scrape_runs`, `checkpoints`, and the exact `traffic_index` / `travel_times` / `quarantine` counts at migration time | Real DB |
| U6 | Container timezone when rows were written (compose sets `TZ=Asia/Bangkok`; any period without it?) | Friend / deployment history |
| U7 | Who consumes the Parquet/CSV (backend, analysis team)? Does PostgreSQL replace them or complement them? | Team decision |
| U8 | Should the backfill DAG's **ungated** final export (D10) stay as-is? | Friend / team |

**Decisions to confirm before Phase 9.2:**
- **D1:** typed `timestamp` (recommended; needs dialect changes in the friend's SQL and in string handling in Python) vs keeping `text` (zero code change, weaker typing).
- **D2:** flags as `smallint` 0/1 (recommended, preserves behaviour) vs `boolean`.
- **D3:** raw JSON as `json` (verbatim; recommended) vs `jsonb` (queryable, but re-formats).
- **D4:** deferred FKs from silver/quarantine to bronze.
- **D5:** no FK from `event_type_id`.
- **D6:** drop the deprecated `incidents.raw_json`.
- **D7:** maintenance DAG scope.
- **D8:** scheduler load and `parquet` cadence.
- **D9:** keep the `fcntl` rate lock.
- **D10:** ungated backfill export.
- **D11:** dedicated database role and connection.

## 16. Recommended next phase

**Phase 9.2: `bkk_traffic` schema migrations in an isolated test database only.**
1. Get the real SQLite file (read-only copy) and close U1-U5.
2. Write `database/migrations/bkk_traffic/001_create_schema.sql` … (own `bkk_traffic.migration_history`), following the conventions and decisions above.
3. Apply them only to the isolated test DB (`namtang-test-db`). Test idempotency, constraints and deferred FKs with the friend's delete order, and test that nothing touches `namtang` / `namtang_analysis`.
4. Add tests that assert schema isolation (no BKK object outside `bkk_traffic`, no change to `namtang*`).

Later phases, each separately approved:
- **9.3:** the storage layer port (SQLite → psycopg) inside the friend's package, with business logic unchanged and tests against the test DB.
- **9.4:** the historical SQLite → PostgreSQL load with `load_history` and count/checksum verification.
- **9.5:** porting the DAGs to Airflow 3.3.2 in the shared stack, paused, with C1/C5 resolved.
- **9.6:** cut-over and operations docs.
