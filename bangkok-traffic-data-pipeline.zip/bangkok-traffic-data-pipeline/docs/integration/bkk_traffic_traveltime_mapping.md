# BKK Traffic: travel-time mapping (Phase 9.6)

**Purpose:** describe the friend's `traveltime.py` and its PostgreSQL port **before** implementation.
**Port:** `data/scraper/bkk_traffic/traveltime.py`.
**Storage:** PostgreSQL `bkk_traffic.travel_times` only; no SQLite.

## 1. Call graph (legacy)

```
DAG bkk_traffic_traveltime (*/5, retries 1, timeout 10 min; no pool)
  has_api_key (short_circuit): skip the run if bkk_scrape_stopped or Variable longdo_api_key is empty
  collect_travel_times → traveltime.collect(Variable longdo_api_key, Variable bkk_od_pairs or DEFAULT_OD_PAIRS)
        ├─ storage.get_checkpoint/set_checkpoint("traveltime_usage")   (quota counters)
        ├─ storage.now_str()                                           (fetched_at, day/month keys)
        ├─ requests.Session().get(ROUTE_URL, params)                   (own session: NOT LongdoClient)
        ├─ _parse(body), compact_raw(body)
        └─ INSERT OR REPLACE INTO travel_times
Readers: parquet_export / export (travel_times dataset), quality.py (15-minute coverage)
```

No other legacy module is involved; there is no dependency on `history.py`, `scrape.py` or `clean.py`.

## 2. Legacy behaviour (the 19 points)

| # | Aspect | Legacy SQLite behaviour |
|---|---|---|
| 1 | Endpoint | `GET https://api.longdo.com/RouteService/json/route/guide` (a different host from traffic.longdo.com) |
| 2 | Parameters | `flat, flon, tlat, tlon` (origin / destination), `mode=t` (route with current traffic), `type=25`, `locale=th`, `key` |
| 3 | API key | Personal Longdo Map key (free tier) in Airflow Variable `longdo_api_key`; the DAG skips when it is empty |
| 4 | Frequency | Every 5 minutes × 8 routes, with 1 s between routes. Quota guard: ≤ 4,500 calls/day and ≤ 95,000/month (Longdo free tier 5,000 / 100,000), counted in checkpoint `traveltime_usage` |
| 5 | Response | JSON `{"meta": …, "data": [{"distance": m, "interval" \| "time" \| "duration": s, "guide": [...] …}]}` or the object without a list; an API error comes back as text starting with `throw` (e.g. "Route Service API Key Error") |
| 6 | Timestamps | The source has **no observation timestamp**. `fetched_at = storage.now_str()` (container local time, Bangkok only because the friend's compose set `TZ`), taken once per run, so all routes of one poll share it |
| 7 | Identifiers | Route **name** (e.g. `อนุสาวรีย์ชัยฯ -> สยาม`) plus origin / destination coordinates from the OD-pair list; Variable `bkk_od_pairs` (JSON) overrides `DEFAULT_OD_PAIRS` (8 routes) |
| 8 | Fields | `distance` → `distance_m`; `interval` (fallback `time`, `duration`) → `duration_s` |
| 9 | Units | metres, seconds; `duration_min = duration_s / 60` |
| 10 | Rounding | `round(duration / 60, 2)` (Python) |
| 11 | Duplicates | PK `(route, fetched_at)`; a second write in the same second replaces the row |
| 12 | Update | `INSERT OR REPLACE` (rewrites every column) |
| 13 | Errors | Per route: any exception is logged as a warning (**the message can contain the request URL, including `key=`**) and the next route continues; successful routes are committed; the run raises only if **no** route succeeded |
| 14 | Retries | None per request (one attempt); the DAG task retried once after 2 min |
| 15 | SQLite write | `conn.execute(INSERT OR REPLACE …)` per route, then one commit at the end |
| 16 | Overwrite | Only the same `(route, fetched_at)`, in practice never (a new poll means a new second) |
| 17 | Current or history | **Both, as a time series:** every poll appends one observation per route (the latest poll is "current") |
| 18 | Local time | Yes: `now_str()` relies on the container TZ |
| 19 | Other modules | `config`, `storage` only |

**Evidence in production** (the 839 baseline rows):
- 8 routes = `DEFAULT_OD_PAIRS`; 105 polls from 2026-10-02 09:43:45 to 19:00:02, almost all 5 min apart.
- One poll (13:25:02) has **7 routes**: a failed route left a real gap and nothing was filled in.
- Distance and duration are integers; `duration_min = round(duration_s/60, 2)` holds for all 839 rows.
- `raw_json` is NULL (not exported in the Parquet baseline).

## 3. What one row means

**One real observation:** Longdo's estimated travel time and distance for one named origin → destination route, *with traffic at the moment of the request*, recorded at the poll's start time `fetched_at` (Asia/Bangkok).
- It is **not** a measured trip.
- It is **not** a historical value: the API returns only the present estimate, so past times can never be requested and a missing poll stays missing.

## 4. PostgreSQL mapping

| Source | Validation | `bkk_traffic.travel_times` |
|---|---|---|
| OD-pair name | non-empty, unique in the run | `route text` (PK part) |
| poll start | `config.bangkok_now()` (explicit UTC+7), once per run | `fetched_at timestamp` (PK part, Bangkok wall-clock, seconds) |
| `data[0].distance` | number, finite, 0 < x ≤ 200,000 m | `distance_m double precision` |
| `data[0].interval` (`time`, `duration`) | number, finite, 0 < x ≤ 86,400 s | `duration_s double precision` |
| — | computed in SQL: `round((duration_s / 60)::numeric, 2)` | `duration_min double precision` |
| OD-pair coordinates | numbers; lat −90..90, lon −180..180 (also a DB CHECK) | `from_lat, from_lon, to_lat, to_lon` |
| body without `guide` (`compact_raw`) | valid JSON | `raw_json json` |
| — | written / updated by the pipeline | `baseline_load_id = NULL` |

- **Business key:** `(route, fetched_at)`, the existing PK and the legacy key. No new uniqueness rule is invented.
- **Schema:** the existing table is sufficient. No migration, and no second table.

## 5. PostgreSQL behaviour and intentional differences

| # | Legacy | PostgreSQL port | Why |
|---|---|---|---|
| T1 | `fetched_at` from the container TZ | `bangkok_now()` explicitly | Our containers run in UTC (the Phase 9.3 bug) |
| T2 | `INSERT OR REPLACE` | `ON CONFLICT (route, fetched_at) DO UPDATE … WHERE (values) IS DISTINCT FROM (excluded)`, comparing `raw_json` as text | Same key; identical data is not rewritten (idempotent); a legitimate change for the same key is applied |
| T3 | Each route committed as it goes; malformed payloads skipped like network errors | **One transaction for the whole poll.** A *malformed or implausible* payload (missing fields, non-numeric, out-of-range, a `throw` API error) is unsafe: the task fails and **nothing** from the poll is written. A *transport* failure (timeout, connection error, HTTP 429/5xx after a retry, other HTTP errors) on some routes leaves those routes without a row: a real gap, as the legacy did. | No partially corrupted data; transient failures keep the legacy per-route resilience |
| T4 | One attempt per request | One retry after 5 s for timeouts, connection errors, 429 and 5xx; each attempt counts toward the quota | Bounded resilience; quota stays honest |
| T4b | — | **Phase 9.6.2:** connect-stage failures back off 5/10/20/30/30/30 s within a 150 s poll budget (circuit breaker after); response-stage failures retry once; TLS / 4xx not retried; ≤ 3 requests per route per poll; connect timeout 5 s; quota reservation = worst case. See [bkk_traffic_phase9_6_retry_policy.md](bkk_traffic_phase9_6_retry_policy.md) | Observed ~100 s TCP outage; bounded and quota-safe |
| T5 | Exception text logged (it may contain `key=`) | Messages are built from the status / exception type only, and every message is also redacted (`key` → `***`). The key is read from Airflow Variable `longdo_api_key` (masked by Airflow because the name contains `api_key`) and is never logged or stored. | Credential safety |
| T6 | No key: the DAG run skips | No key: the task records `scrape_runs(status='skipped', note='no longdo_api_key')`, makes **no request**, writes no data, and lets the incident pipeline continue | A missing travel-time credential must not stop incidents / history |
| T7 | `round(duration/60, 2)` in Python | `round((duration_s/60)::numeric, 2)` in SQL | Project rule (numeric semantics). Identical for integer seconds, as all 839 existing rows show. |
| T8 | Own DAG every 5 min | Task `collect_travel_times` inside `bkk_traffic_pipeline`, pool `longdo_api` (1 slot), so it never overlaps `scrape` / `update_history`. It runs when the pipeline runs (*/15 if the schedule is ever enabled; now **off**). | One BKK DAG; the pool guarantees serial Longdo requests |
| T9 | No run log | `scrape_runs` row (`job='travel_times'`: success / failed / skipped, counts, failed route names) | Auditability |

**Unchanged:** endpoint, parameters, OD pairs and their names, field choice (`interval` → `time` → `duration`), `compact_raw`, the quota limits and checkpoint `traveltime_usage`, the 1 s spacing between routes, and "raise when no route succeeded".

## 6. Existing 839 rows

They are production observations (baseline load 1). The port never deletes, truncates or rebuilds them. A new poll adds rows with a new `fetched_at`. A row is updated only if the same `(route, fetched_at)` reappears with a different value, which a real poll does not produce.
