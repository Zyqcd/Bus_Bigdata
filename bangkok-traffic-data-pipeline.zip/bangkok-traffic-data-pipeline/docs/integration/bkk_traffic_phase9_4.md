# BKK Traffic Phase 9.4: production cutover

**Date:** 2026-10-03, about 01:30–02:45 Asia/Bangkok.

**Approval:** production cutover was explicitly approved by the user. The steps followed [bkk_traffic_phase9_3.md](bkk_traffic_phase9_3.md) section 11.

**Result: PASS.** All items below were executed, and the evidence is the query or command output captured during the cutover.

**Final production state:**
- `namtang_db` has the schema `bkk_traffic` loaded from a fresh, gate-passed Parquet snapshot.
- The BKK DAGs are registered and **paused**, with the schedule **off**.
- One manual production run succeeded.
- Namtang is unchanged.
- `itproject_db` was never contacted.

## A. Fresh snapshot identity — PASS

| Item | Value |
|---|---|
| How it was built | The ported pipeline's own functions (`run_traffic_index`, `run_realtime_incidents(150 pages)`, `run_clean_stage`, `gate_checks`, `publish_parquet`, `verify_postgresql`). They ran inside the Airflow image (Linux `fcntl` rate lock, 10 s crawl delay) against the **test DB**, which held the 2026-10-02 baseline. The real traffic.longdo.com API was used; nothing was fabricated. Build time 1,615 s. |
| Location | `data/bkk_traffic/snapshot_builds/fresh_20261002T1858Z/parquet/` (219 files, read-only; `snapshot.source.json` records every file's SHA-256) |
| Snapshot SHA-256 | `0f91949e07eb05e7118c29523516af38b39e610184fdb6ed2822e3e29831828a` |
| Signature | `accidents_bangkok=223726\|2026-10-03 02:22:19\|10000; incidents_bangkok=484822\|2026-10-03 02:23:28\|10000; traffic_index=1414002\|1790967300-4722027.1999997925\|10000; travel_times=839\|2026-10-02 19:00:02\|10000` |
| generated_at | 2026-10-03 02:24:44 – 02:25:11 (Asia/Bangkok); gate passed 02:24:13 |
| Quality gate | G1–G9 all **PASS**. Loader validation (manifest, schema, timestamps, keys, flags, coordinates, `ts`/`ts_local`) **PASS** |
| Gap coverage (incidents) | Realtime read 1,705 items. The lowest eid seen, 785,140, is inside the old snapshot's range (max eid 978,727), so the pages overlapped the snapshot and no window between them was skipped. 19 incidents are newer than the old snapshot; 646 Bangkok incidents were re-fetched. |
| Duplicates | 13 re-fetched reports that the friend's pipeline had already excluded as duplicates were flagged `is_duplicate=1` again, so they are not in the published datasets |

## B. Source row counts — PASS

| Dataset | Manifest | Parquet | Δ vs the 2026-10-02 snapshot |
|---|---:|---:|---:|
| `incidents_bangkok` | 484,822 | 484,822 | +19 |
| `accidents_bangkok` | 223,726 | 223,726 | +11 |
| `traffic_index` | 1,414,002 | 1,414,002 | +1 (realtime sample) |
| `travel_times` | 839 | 839 | 0 (`traveltime.py` not ported) |

## C. Production PostgreSQL row counts — PASS

Counts after the initial load; read-only queries on `namtang_db` (port 5433).

| Object | Rows | = manifest |
|---|---:|---|
| `bkk_traffic.incidents` | 484,822 | yes |
| view `incidents_bangkok` | 484,822 | yes |
| `bkk_traffic.traffic_index_history` | 1,414,002 | yes |
| `bkk_traffic.travel_times` | 839 | yes |
| view `accidents_bangkok` | 223,726 | yes (accidents Parquet) |

State after the manual run (section M):

| Object | Rows | Notes |
|---|---:|---|
| `incidents` | 484,833 | 147 rows now owned by the pipeline; 11 re-fetched duplicates flagged `is_duplicate=1` |
| `incidents_bangkok` | 484,822 | unchanged |
| `accidents_bangkok` | 223,726 | unchanged |
| `traffic_index_history` | 1,414,003 | +1 sample |
| `bronze_incidents` | 147 | |
| `seen_eids` | 511 | |
| `quarantine` | 0 | |

## D. Migration result — PASS

- **Backup first:** `pg_dump -Fc` of `namtang_db` → `data/bkk_traffic/cutover_backups/namtang_db_before_phase9_4_20261002T1927Z.dump` (82 MB, 22 table-data entries, SHA-256 `3a5e233f…88df`).
- **Applied:** `database/migrations/bkk_traffic/001–006`, unmodified, with `psql -v ON_ERROR_STOP=1` and `PGOPTIONS='-c bkk_traffic.expected_database=namtang_db'`. Pass 1: all exit 0. **Pass 2 (rerun): all exit 0.**
- **`bkk_traffic.migration_history`:** 001–006 (6 rows).
- **Objects:**
  - 13 tables (owner `bkk_traffic_owner`);
  - views `incidents_bangkok` and `accidents_bangkok`;
  - 13 PKs;
  - 5 FKs: `incidents_bronze_eid_fk` and `quarantine_eid_bronze_fk` deferred, plus 3 `baseline_load` FKs;
  - 11 CHECKs;
  - 8 `ix_*` indexes;
  - 0 constraints left unvalidated (79 constraints in total).
- **`public`:** 0 tables, 0 views.

## E. Role result — PASS

| Role | Login | Membership / rights (verified with `has_*_privilege`) |
|---|---|---|
| `bkk_traffic_owner` | no | owns schema `bkk_traffic` and all its objects |
| `bkk_traffic_app` | no | USAGE on `bkk_traffic`; DML on data tables; **no** INSERT on `migration_history` / `load_history`; no CREATE |
| `bkk_traffic_readonly` | no | SELECT only (incl. views); no INSERT |
| `bkk_traffic_airflow` | **yes** | member of `bkk_traffic_app` only; not superuser, createdb or createrole |

- **Namtang:** all four roles have **no** USAGE on `namtang` / `namtang_analysis`. A live login as `bkk_traffic_airflow` was denied on `namtang.feed_info`.
- **`public`:** USAGE comes only from the PostgreSQL default PUBLIC grant; CREATE false; `public` has no tables.
- **Password:** random, never printed, stored only in the Airflow connection. The temporary file was deleted.
- **Note:** the psql helper script reported a syntax error on its final `\endif` (a shell-quoting slip) **after** every role statement had run. The resulting state was verified directly: role attributes, membership, and a password login. Nothing was half-applied.
- **`itproject_db`:** no grants; never contacted.

## F. Airflow connection result — PASS

- **Created:** `bkk_traffic_postgres` with `airflow connections add`, stored encrypted in the Airflow metadata DB. Values: type postgres, host `namtang_db`, port 5432, schema (= database) `namtang_db`, login `bkk_traffic_airflow`, password set.
- **Namtang connection unchanged:** `namtang_postgres` is still defined by `AIRFLOW_CONN_NAMTANG_POSTGRES`, with host `namtang_db`, database `namtang_db` and login `postgres` as before.

## G. Airflow pool result — PASS

- **Pool:** `longdo_api`, 1 slot, "BKK Traffic: traffic.longdo.com requests (crawl delay 10 s)".
- **`default_pool`:** unchanged (128).
- **Usage in the run:** `scrape` ran in `longdo_api`; the other tasks ran in `default_pool`.
- **Configuration:** `airflow/docker-compose.yml` passes `BKK_TRAFFIC_SCHEDULE_ENABLED` (default `false`) and `BKK_TRAFFIC_API_POOL` (default `longdo_api`). The Airflow services were recreated once with the same image and no rebuild; the Namtang env, connection and paused state survived.

## H. Loader result — PASS

- **Guard:** without `--production-approved`, the run was `refused` (exit 2).
- **Dry run with approval:** `would_load`, no pipeline rows.
- **Load:**
  - `python database/load/load_bkk_traffic.py --source-dir data/bkk_traffic/snapshot_builds/fresh_20261002T1858Z/parquet --expected-database namtang_db --production-approved --run-id phase9_4-production-initial-load`;
  - result **success**, load_id 1, 1 min 46 s;
  - one transaction: validate → COPY → accidents comparison → reconciliation → constraints immediate → commit;
  - rejected rows 0 in every dataset.

## I. Constraint result — PASS

- 79 constraints, 0 left unvalidated.
- `SET CONSTRAINTS ALL IMMEDIATE` passed inside the load.
- Independent checks:
  - incidents without a bronze parent (pipeline rows): 0;
  - quarantine without bronze: 0;
  - baseline rows pointing to an unknown load: 0;
  - invalid coordinates: 0;
  - `ts_local` vs `ts` mismatches: 0.
- 167 incidents carry the source's `(0, 0)` "no coordinates" placeholder, which is within range and kept as published.

## J. Duplicate result — PASS

- **Duplicate PKs:** 0 for `eid`, `ts` and `(route, fetched_at)`, both after the load and after the run.
- **Business-key duplicates after the load:** 0.
- **After the run:** 11 re-fetched duplicate reports are stored with `is_duplicate=1`, which is the friend's dedup rule, and are excluded from both views.

## K. Accident-view reconciliation — PASS

`bkk_traffic.accidents_bangkok` vs the accidents Parquet, every column (timestamps as text), compared as multisets:
- source → view: 0 rows missing;
- view → source: 0 rows extra;
- 223,726 = 223,726.

No physical accidents table exists (0 `bkk_traffic` tables named `%accident%`).

## L. load_history — PASS

| load_id | run_id | status | source_sha256 | finished |
|---|---|---|---|---|
| 1 | `phase9_4-production-initial-load` | success | `0f91949e07eb…828a` (= snapshot A) | yes |

`source_signature` and `source_manifests` are recorded. Namtang's `namtang.load_history` is unchanged (1 row).

## M. Manual DAG run — PASS

| Item | Value |
|---|---|
| Registration | `bkk_traffic_pipeline` and `bkk_traffic_maintenance` moved to `airflow/dags/`; registered **paused**; import errors: none; timetable "Never, external triggers only" |
| Run | unpaused → `airflow dags trigger bkk_traffic_pipeline --run-id phase9_4_manual_production_verification` → re-paused afterwards. Exactly **one** BKK run exists. |
| Duration | 19:36:05 → 19:42:24 UTC (02:36–02:42 Bangkok) |
| Tasks | scrape ✔ (5 min 15 s, `longdo_api`), clean ✔, validate ✔ (G1–G9 PASS), publish ✔, verify_postgresql ✔; every task **try 1**, no retries |
| PostgreSQL after | `scrape_runs`: realtime success, 511 items, 147 new bronze; checkpoint `realtime`; 0 PK duplicates; 0 FK orphans; views unchanged (484,822 / 223,726) |
| Published | `data/bkk_traffic/parquet/`: incidents 484,822, accidents 223,726, traffic_index 1,414,003, travel_times 839, all gates PASS; manifests equal PostgreSQL (`verify_postgresql`) |
| load_history | unchanged (the pipeline writes PostgreSQL directly; no Parquet reload) |
| Namtang DAG | not triggered; latest run still `phase8_final_multiprocess_lock_verification`; still 4 runs |

## N. Namtang isolation — PASS

The read-only state was captured before any write, after the load and after the run.

All of the following are identical in all three captures:
- `namtang.migration_history` (001–005);
- `namtang.load_history` (1 row, feed `e5d8b18c…`);
- feed identity `20261001`;
- the table lists of `namtang` (14) and `namtang_analysis` (8);
- the row counts of all 22 tables (source total 5,958,939);
- per-table write counters (totals 7,102,021 / 0 / 0).

The Namtang DAG stayed paused with `NAMTANG_SCHEDULE_ENABLED=false`.

## O. itproject_db isolation — PASS

No command targeted `itproject_db` or port 5432 at any point: all production SQL used `namtang_db` on 5433, or `namtang_db:5432` on the Docker network. Its container was neither restarted nor touched (still "Up 7 hours"). Its contents were deliberately not queried, per the rule never to connect.

## P. Schedule state — PASS

| DAG | Paused | Schedule | Last run |
|---|---|---|---|
| `bkk_traffic_pipeline` | **yes** | `None` (`BKK_TRAFFIC_SCHEDULE_ENABLED=false`; when true: */15 Asia/Bangkok, per Phase 9.2 D8) | `phase9_4_manual_production_verification`, **success** |
| `bkk_traffic_maintenance` | **yes** | `None` (when enabled: daily 03:30) | never run |
| `namtang_gtfs_pipeline` | yes | `None` (`NAMTANG_SCHEDULE_ENABLED=false`) | `phase8_final_multiprocess_lock_verification` (unchanged) |

No recurring schedule was enabled. To activate later (explicit decision):
1. Set `BKK_TRAFFIC_SCHEDULE_ENABLED=true` in `airflow/.env`.
2. `docker compose -f airflow/docker-compose.yml up -d`
3. `airflow dags unpause bkk_traffic_pipeline` (and `bkk_traffic_maintenance`).

## Q. Files changed — PASS

| File | Change |
|---|---|
| `airflow/dags/bkk_traffic_pipeline.py`, `airflow/dags/bkk_traffic_maintenance.py` | Moved from `airflow/bkk_traffic_dags/` (folder removed); docstrings now say "registered"; code unchanged |
| `airflow/docker-compose.yml` | +2 env lines, `BKK_TRAFFIC_SCHEDULE_ENABLED` and `BKK_TRAFFIC_API_POOL`, with a comment |
| `airflow/.env.example` | The same two keys, documented (no secrets) |
| `tests/test_bkk_traffic_pipeline.py` | Paths for the registered location; the live-folder check now expects all 3 DAGs; the scrape-pool expectation follows `BKK_TRAFFIC_API_POOL`; the staged-folder workaround was removed. Not weakened. |
| `docs/integration/bkk_traffic_phase9_4.md` | This report |
| `docs/architecture/project_architecture.md`, `docs/integration/bkk_traffic_phase9_3.md` | Phase 9.4 status banner |

**Not changed:**
- the migrations (identical SHA-256);
- the loader;
- the pipeline package;
- every Namtang file;
- `airflow/.env` (the compose defaults are used).

**Tests after the move:**
- Airflow image (`airflow-cli`): **283 passed, 0 failed**;
- Windows: 196 passed / 72 skipped.

## R. Production objects created — PASS

| Where | Objects |
|---|---|
| `namtang_db` | schema `bkk_traffic`; 13 tables, 2 views, 13 PKs, 5 FKs, 11 CHECKs, 8 indexes; roles `bkk_traffic_owner`, `bkk_traffic_app`, `bkk_traffic_readonly`, `bkk_traffic_airflow` (login); data from load 1 + the manual run |
| Airflow metadata | connection `bkk_traffic_postgres`; pool `longdo_api`; DAGs `bkk_traffic_pipeline`, `bkk_traffic_maintenance` (paused); 1 DAG run |
| Files (git-ignored `data/bkk_traffic/`) | fresh snapshot build; pre-cutover backup dump; published Parquet `data/bkk_traffic/parquet/`; raw pages / checkpoints of the manual run |

## S. Remaining issues

| Issue | Status |
|---|---|
| `traffic_index_history` has no 5-minute points between 2026-10-02 18:55 and the realtime samples: `history.py` (yearly file) is not ported | Open (not fabricated; port `history.py` to backfill from Longdo's yearly file) |
| `travel_times` stays at 839 rows: `traveltime.py` and the `longdo_api_key` secret are not set up | Open |
| Quality report, CSV export, yearly event feed and missing-eid recovery are not scheduled | Open (functions partly ported) |
| The Parquet loader now refuses new snapshots, because pipeline rows exist (by design: PostgreSQL is the source of truth) | Expected |
| Recurring schedule | Off until explicitly approved |
| The friend's SQLite pipeline still runs in the friend's environment | Keep until the team decides; do not delete yet |
| The pre-cutover backup lives on the local disk only (`data/bkk_traffic/cutover_backups/`) | Copy it to durable storage if required |
| The test DB container `namtang_bkk_traffic_test_db` is still running (tmpfs) | `docker stop namtang_bkk_traffic_test_db` discards it |
