# BKK Traffic: Parquet → PostgreSQL mapping (Phase 9.3)

**Source:** the friend's published, gate-passed Parquet snapshot, copied read-only to `data/bkk_traffic/source_snapshots/friend_parquet_2026-10-02/` from `scrapping--main.zip`. SQLite is **not** a source (it is intentionally excluded).

**Target:** schema `bkk_traffic` (migrations `database/migrations/bkk_traffic/001–006`).

**Loader:** `database/load/load_bkk_traffic.py`.

Where the schemas come from:
- **Source schema:** the friend's `plugins/bkk_traffic/parquet_export.py`, checked against the actual files with pyarrow. All 215 parts read; one schema per dataset, identical to the code.
- **Target schema:** the migrations.

## 1. Dataset → table

| Parquet dataset | Parts | `total_rows` | Defined in the friend's code as | PostgreSQL target |
|---|---:|---:|---|---|
| `incidents_bangkok` | 49 | 484,803 | `SELECT … FROM incidents WHERE is_bangkok=1 AND is_duplicate=0 ORDER BY eid` | **`bkk_traffic.incidents`** (canonical incidents) |
| `accidents_bangkok` | 23 | 223,715 | `… WHERE is_bangkok=1 AND is_accident=1 AND is_duplicate=0` | **No table.** View `bkk_traffic.accidents_bangkok` over `incidents`. The dataset is loaded into a temporary table only to *verify* that it equals the view row for row. |
| `traffic_index` | 142 | 1,414,001 | `SELECT ts, ts_local, index_value, source FROM traffic_index_history ORDER BY ts` | **`bkk_traffic.traffic_index_history`**. Note the name: the friend's realtime table `traffic_index` has a `fetched_at` column and is *not* exported. |
| `travel_times` | 1 | 839 | `SELECT route, fetched_at, … FROM travel_times` (no `raw_json`) | **`bkk_traffic.travel_times`** |

Tables with no Parquet source stay empty after the initial load. The pipeline fills them from its first run onward:
- `bronze_incidents`, `quarantine`, `seen_eids`, `missing_eids`;
- `traffic_index` (realtime samples), `event_types`, `checkpoints`, `scrape_runs`.

Nothing is synthesized for them.

## 2. `incidents_bangkok` → `bkk_traffic.incidents`

| Parquet column | Arrow type | PG column | PG type | Nullable | Transformation | Validation |
|---|---|---|---|---|---|---|
| `eid` | int64 | `eid` | bigint **PK** | NO | none | Not null, unique across all parts |
| `nid` | int64 | `nid` | bigint | yes | none | |
| `start_time` | string | `start_time` | timestamp | NO | Text `YYYY-MM-DD HH:MM:SS` parsed by PG as Bangkok wall-clock, no TZ conversion | Exact format + real calendar date; not null |
| `stop_time` | string | `stop_time` | timestamp | yes | same | Format when not null; `''` would be rejected (none expected) |
| `createtime` | string | `createtime` | timestamp | yes | same | same |
| `updatedtime` | string | `updatedtime` | timestamp | yes | same | same |
| `event_type_id` | int16 | `event_type_id` | integer | yes | widen | no FK (D5) |
| `event_type` | string | `event_type` | text | yes | none | |
| `traffic_relevance` | string | `traffic_relevance` | text | NO | none | ∈ {direct, affects, keyword} (DB CHECK) |
| `is_accident` | int8 | `is_accident` | smallint | NO | widen | ∈ {0,1} |
| `is_bangkok` | int8 | `is_bangkok` | smallint | NO | widen | ∈ {0,1}; must be 1 (export filter, gate G3) |
| `severity` | int16 | `severity` | smallint | yes | none | ∈ {1,2,3} when not null |
| `title` | string | `title` | text | NO | none | Not null, not empty (R5) |
| `title_en`, `comment`, `comment_en` | string | same | text | yes | none | |
| `latitude`, `longitude` | double | same | double precision | yes | none (exact repr) | −90..90 / −180..180 (DB CHECK); count outside a Bangkok bounding box reported |
| `province_guess`, `contributor`, `source`, `status` | string | same | text | yes | none; `status` keeps `''` distinct from NULL | |
| `fetched_via` | string | `fetched_via` | text | NO | none | Not null |
| `first_seen_at`, `last_seen_at` | string | same | timestamp | NO | as `start_time` | Format, not null |
| `dq_flags` | string | `dq_flags` | text | yes | none | |
| — | — | `is_duplicate` | smallint NOT NULL | — | **0**, the dataset's definition (`WHERE is_duplicate=0`), not a guess | Business-key duplicate count after load (round(x::numeric,4)) is reported |
| — | — | `baseline_load_id` | bigint FK → `load_history` | — | The `load_id` of this load | — |
| — | — | `bronze_eid` | generated | — | NULL for baseline rows, so no bronze parent is required | Deferred FK checked at commit (`SET CONSTRAINTS ALL IMMEDIATE`) |
| — | — | `raw_json` | not in schema (D6) | — | — | — |

**Text sentinel:** the CSV stream uses `\N` for NULL, so a literal string `\N` in any text column fails validation instead of silently becoming NULL.

## 3. `accidents_bangkok` → view `bkk_traffic.accidents_bangkok` (no physical rows)

The schema is identical to `incidents_bangkok`. Checks:
- the schema is identical;
- the manifest count equals the row count;
- the eids are unique;
- every row has `is_accident = 1` and `is_bangkok = 1`;
- **set equality, row for row, on every column:**
  - `(temp accidents) EXCEPT ALL (view accidents_bangkok)` = 0 rows;
  - the reverse `EXCEPT ALL` = 0 rows;
  - the view count equals 223,715.

Storing it again would duplicate 223,715 physical rows.

## 4. `traffic_index` → `bkk_traffic.traffic_index_history`

| Parquet | Arrow | PG | Type | Nullable | Transformation | Validation |
|---|---|---|---|---|---|---|
| `ts` | int64 | `ts` | bigint **PK** | NO | none | Not null, unique |
| `ts_local` | string | `ts_local` | timestamp | NO | Bangkok wall-clock text | Format, and `ts_local == ts` as Asia/Bangkok local time (UTC+7, no DST) for **every** row |
| `index_value` | double | `index_value` | double precision | yes | none | |
| `source` | string | `source` | text | NO | none | Not null |
| — | — | `baseline_load_id` | bigint FK | — | `load_id` | — |

## 5. `travel_times` → `bkk_traffic.travel_times`

| Parquet | Arrow | PG | Type | Nullable | Transformation | Validation |
|---|---|---|---|---|---|---|
| `route` | string | `route` | text | NO | none | **PK `(route, fetched_at)`** unique |
| `fetched_at` | string | `fetched_at` | timestamp | NO | Bangkok wall-clock text | Format |
| `distance_m`, `duration_s`, `duration_min` | double | same | double precision | yes | none | |
| `from_lat`, `from_lon`, `to_lat`, `to_lon` | double | same | double precision | yes | none | Geographic range (DB CHECK) |
| — | — | `raw_json` | json | yes | **NULL** (not exported by the friend; never invented) | — |
| — | — | `baseline_load_id` | bigint FK | — | `load_id` | — |

## 6. Snapshot-level checks

| Check | Rule |
|---|---|
| Manifest | `dataset` = folder; `rows_per_file` = 10,000; `files` list = the part files on disk (none missing, none extra); per-file `rows` = Parquet metadata `num_rows`; Σ = `total_rows`; every gate check G1–G9 = `PASS` |
| Schema | Exact field names, order and Arrow types per dataset |
| Identity | SHA-256 of every part + manifest → one snapshot SHA-256 (`load_history.source_sha256`); manifest signatures + generated_at → `source_signature` / `source_manifests` |
| Reconciliation | Per dataset: manifest rows = Parquet rows = PostgreSQL rows; rejected = 0 (any invalid row fails the whole load; no partial load, no quarantine because Parquet rows have no raw JSON); per-column fingerprints (non-null count, numeric sums, min/max timestamps) Parquet vs PostgreSQL |
| Atomicity | All three tables, the accidents verification and the `load_history` row are written in **one transaction**; any error rolls everything back |
| Idempotency | The same snapshot SHA-256 with matching row counts → `unchanged` (data untouched; an audit row is written) |
| Replacement | A new snapshot replaces the previous **baseline** rows (`baseline_load_id IS NOT NULL`). The loader refuses if pipeline-written rows exist (`baseline_load_id IS NULL`): after cutover PostgreSQL is the source of truth and a Parquet import must not overwrite it. |
