# BKK Traffic Phase 9.6: travel-time connectivity diagnostic

**Date:** 2026-10-03, about 04:45–05:05 Asia/Bangkok.

**Scope:** read-only diagnosis of `Airflow task environment → api.longdo.com`, explaining the production run `phase9_6_manual_traveltime_verification` (2 of 8 routes OK, 6 `ConnectionError`). It was *not* another production run:
- no `collect_travel_times` run;
- no route request;
- no key used;
- no data, code, retry, pool or schedule change.

**Phase 9.6 stays PARTIAL.**

## Diagnostic Status

**INCONCLUSIVE.** The failure is localized to the **TCP connection stage** and reproduced once without the application and without a key, but its origin cannot be proven from the evidence.

## Execution Environment

| Item | Value |
|---|---|
| Airflow container | `namtang-airflow-airflow-scheduler-1` (hostname `0c93209185cc`, Compose project `namtang-airflow`, service `airflow-scheduler`, image `namtang-airflow:3.3.2`). The metadata `task_instance.hostname` for all 7 tasks of the run, incl. `collect_travel_times` (pid 602), is `0c93209185cc`. The executor is LocalExecutor, so tasks run inside the scheduler container. |
| Airflow version | 3.3.2 (Python requests 2.34.2, urllib3 2.7.0, OpenSSL 3.0.20) |
| Network | `namtang-airflow_default` (172.28.0.5) and `bangkok-traffic-project_default` (172.27.0.3); outbound through Docker Desktop |
| DNS resolver | Docker embedded DNS `127.0.0.11`, forwarding to the Docker Desktop host resolver `192.168.65.7`; `ndots:0`; no custom DNS, no `/etc/hosts` entry |
| Proxy | none (`HTTP(S)_PROXY`, `NO_PROXY`, `ALL_PROXY` not set) |
| IPv6 | **no IPv6 route in the container** (every IPv6 connect: `Errno 101 Network is unreachable`) |

## DNS

- **`api.longdo.com` resolution:** 10/10 successful (10.7–47.0 ms).
- **Order returned:** `104.26.3.141`, `104.26.2.141`, `172.67.70.46` (IPv4, Cloudflare), then `2606:4700:20::681a:38d`, `2606:4700:20::ac43:462e`, `2606:4700:20::681a:28d` (IPv6).
- **Result: PASS.** DNS is not the cause. urllib3 got the addresses and tried every one of them (see HTTP).

## TCP/TLS

- **Port 443, IPv4 (series 1, raw socket):** 15/15 TCP connects OK (7–39 ms), 15/15 TLS 1.3 handshakes OK (11–44 ms). The certificate CN is `longdo.com`, valid until 2026-11-12.
- **Port 443, IPv4 (series 2, raw socket, about 10 min later):** 36/36 OK from the container **and** 36/36 OK from the Windows host; none took longer than 1 s.
- **Port 443, IPv6:** 15/15 `OSError [Errno 101] Network is unreachable` (container has no IPv6 route).
- **TLS:** always OK whenever TCP was established.
- **Result:** intermittent. See the HTTP probe, which caught a TCP refusal window.

## HTTP

- **Request performed:** 8 × `GET https://api.longdo.com/RouteService/json/route/guide` with **no parameters and no key**. This computes no route, uses no quota, and writes nothing. It ran from the same container through `requests.Session`, 1 s apart (the production cadence), with every `socket.connect` traced.
- **Results:**

| # | Connection attempts (in order) | Outcome |
|---|---|---|
| 1 | `104.26.3.141` **ConnectionRefusedError**, `104.26.2.141` **ConnectionRefusedError**, `172.67.70.46` **ConnectionRefusedError** (about 21 s each), then 3 × IPv6 `OSError` (unreachable) | **`requests.ConnectionError`** after 63 s. Chain: `ConnectionError ← MaxRetryError ← NewConnectionError ← OSError` |
| 2 | `104.26.3.141` refused, `104.26.2.141` refused, `172.67.70.46` **ok** | HTTP 200 after 42 s; body `throw 'Route Service API Key Error';` (expected without a key) |
| 3–8 | none (reused the open keep-alive connection) | HTTP 200, 70–72 ms each, same body |

- **Status / error:** a `ConnectionError` at the **TCP connect stage** (refused on every IPv4 address; IPv6 unreachable), then success once a TCP connection was established.
- **Credential exposed: NO.** No key was sent or read in any diagnostic. The production-log scan was done without printing the key.

## Existing production logs

`collect_travel_times` task log (16 lines; the key is not present, see the Phase 9.6 report):
- **All six failures are identical:** `route <name>: ConnectionError after 2 attempts (no observation stored)`, in list order from 21:33:50 to 21:35:08 UTC.
- No HTTP status, no `throw` body, no timeout, no TLS error. The collector deliberately logs only the exception type, so the inner cause (refused vs unreachable) was not recorded.
- **Failure stage:** before any HTTP response, i.e. connection establishment, the same stage as diagnostic probe #1.
- **Timing:** about 3–8 s per failed attempt; the failure window lasted about 1.5 min.
- **After the window:** route 7 succeeded on its retry (15 requests in total = 6 × 2 + 2 + 1); route 8 then succeeded straight away, consistent with keep-alive reuse as in probes #3–8.

## Production Evidence

- successful routes: 2 (บางแค → ปิ่นเกล้า, มีนบุรี → รามคำแหง; `meta.status` 200)
- failed routes: 6 (อนุสาวรีย์ชัยฯ → สยาม, สีลม → อโศก, ห้าแยกลาดพร้าว → อนุสาวรีย์ชัยฯ, บางนา → พระราม 9, ดอนเมือง → หมอชิต, สาทร → วงเวียนใหญ่)
- production travel_times before: 839
- production travel_times after: 841

## Failure classification

| Candidate | Evidence | Verdict |
|---|---|---|
| A. DNS | 10/10 resolutions; urllib3 attempted all 6 resolved addresses | **Excluded** |
| B. TCP connectivity | Diagnostic probe #1: TCP connect refused on all 3 IPv4 addresses, IPv6 unreachable → `NewConnectionError` → `ConnectionError`, the same stage and type as production | **Confirmed as the failing layer** (intermittent) |
| C. TLS | 15/15 handshakes OK; no TLS error anywhere | **Excluded** |
| D. HTTP / API | the failure happens before any HTTP exchange; the API answers normally once connected (200, key error without a key; real `meta.status` 200 with the key) | **Excluded** |
| E. Longdo throttling | no HTTP 429 or rate-limit body; the diagnostic was refused *without* any key or route request. HTTP-level throttling is excluded. A Cloudflare connection-level refusal cannot be excluded **or** proven. | **Not proven** |
| F. Route-specific behaviour | reproduced with no route parameters at all; the failure precedes the request | **Excluded** |
| G. Transient external network failure | refusals come in windows (production about 1.5 min; diagnostic about 1.5 min), then 72/72 connects OK and identical results from the Windows host. Consistent with G, but the origin (Docker Desktop network path, Windows host / local network, ISP, Cloudflare edge) is not identified. | **Consistent, not proven** |
| H. Unknown | the exact origin of the refusals | **Remaining** |

**Contributing condition (not a cause):** the container has no IPv6 route, so when the IPv4 connects are refused there is no working alternative path. Every IPv6 attempt fails immediately.

## Root Cause

**INCONCLUSIVE — additional controlled observation required.**

**Proven:**
- The six production failures were TCP connection-establishment failures from the Airflow scheduler container to every `api.longdo.com` address.
- They were intermittent, lasting about 1.5 min, and were reproduced once by a key-free diagnostic, where the IPv4 connects were actively refused.
- They are not DNS, TLS, HTTP / API, credential or route problems.

**Not proven:** *who* refuses the connections. Docker Desktop's outbound proxy, the Windows host or local network, the ISP and the Cloudflare edge all remain possible. The diagnostic's ~21 s per refusal resembles a host-side TCP connect timeout surfacing as a refusal inside the container, but production attempts failed faster (about 3–8 s), so this is not treated as proof.

**No application defect was found:**
- the collector used one session, the configured endpoint and parameters, and handled the failures as designed (no row, failure recorded, nothing fabricated);
- `traveltime.py` was not changed.
- An observation for the team, not a fix: the 2-attempt / 5 s retry cannot ride out a connection-refusal window of about 1.5 min. Whether to change retries is a separate decision.

## Database Safety

- travel_times changed during diagnostic: **NO** (841 rows, 841 distinct `(route, fetched_at)`, `sum(xmin)` identical before and after, so no inserts, updates or deletes)
- duplicates: 0
- `scrape_runs` (travel_times): still 1; quota counters unchanged (15 / 15), since the diagnostic used no key

## Isolation

- Namtang unchanged: **YES** (migration and load history, feed `20261001`, all 22 table row counts, write counters 7,102,021 / 0 / 0; DAG not triggered; DAG runs: BKK 3, Namtang 4, unchanged)
- itproject_db contacted: **NO**
- Airflow: all DAGs paused; schedule OFF; pool `longdo_api` = 1 slot; no DAG run triggered by the diagnostic

## What remains to be decided (not done)

1. Another controlled observation, possibly with the connect-error inner cause temporarily logged (key-free), to identify the refusing hop.
2. Whether connection-level retry / backoff in the collector should change (business-logic decision).
3. The next production run, which is a separate explicit decision. Phase 9.6 stays **PARTIAL**, and Phase 9.7 has not started.
