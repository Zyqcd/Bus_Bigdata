# BKK Traffic: traffic-index history and the documented gap

**As of 2026-10-03 03:15 (Asia/Bangkok).** These are measurements on production `namtang_db`, `bkk_traffic.traffic_index_history`. Design: [bkk_traffic_history_mapping.md](bkk_traffic_history_mapping.md).

## 1. What the history contains

| Part | Range (Asia/Bangkok) | Source | Resolution |
|---|---|---|---|
| Longdo yearly files | 2012-01-01 00:00 → **2026-09-30 23:55** | `history:{year}` (1,413,831 rows; Parquet baseline, re-validated by `update_history` with 0 changes) | 5 minutes, with the source's own outages |
| Realtime samples (friend's pipeline, in the Parquet baseline) | 2026-10-01 00:10 → 2026-10-02 18:55 | `realtime` | about 15 minutes |
| Realtime samples (our pipeline) | 2026-10-03 01:55, 02:35, 03:10 | `realtime` | one per manual run (schedule off) |

## 2. Observed gaps (exact)

| Gap | Start (last point before) | End (first point after) | Length | Rows inside |
|---|---|---|---|---|
| **No 5-minute file data** | 2026-09-30 23:55 | (not yet published) | open | Only realtime samples exist after it |
| **No observations at all** | **2026-10-02 18:55** (ts 1790942100) | **2026-10-03 01:55** (ts 1790967300) | 7 h | **0** |
| Between manual runs | 2026-10-03 01:55 | 2026-10-03 02:35 | 40 min | 0 |
| Between manual runs | 2026-10-03 02:35 | 2026-10-03 03:10 | 35 min | 0 |

## 3. Why the gaps exist

- **The friend's snapshot ends 2026-10-02 18:55** (the source of the Phase 9.4 baseline).
- **The production pipeline is not scheduled.** Samples exist only for the manual runs: the fresh-snapshot build at 01:55 and the two production verification runs.
- **Longdo has not yet published October 2026** in its yearly download. Our own downloads on 2026-10-03, one at inspection and one in the production run, both returned 77,751 rows ending at 2026-09-30 23:55 (file SHA-256 `9859ac32…`). The friend's file of 2026-10-02 ended at the same point. Longdo's publishing cadence is not documented; it is *not* assumed here.

## 4. Can it be backfilled?

| Question | Answer |
|---|---|
| Does the realtime API provide past observations? | **No.** `api/json/traffic/index` returns only the current value. |
| Does the yearly file provide them? | **Not yet.** It ends at 2026-09-30 23:55. |
| What happens when Longdo publishes October? | `update_history` (inside `bkk_traffic_pipeline`, at most once per `bkk_history_refresh_hours`, default 24 h) validates the new file and **inserts the real 5-minute points**. A realtime sample at the same `ts` is replaced by the file value (the original rule). Reruns are idempotent. |
| Will every 5-minute point then exist? | Only those Longdo publishes. Its files have real outages every year (e.g. 2026 already has 28 gaps > 5 min), and they stay gaps. |

## 5. What was intentionally NOT done

**Historical gap retained: no synthetic backfill.** None of the following was done:
- interpolation;
- generated or "expected" 5-minute timestamps;
- copying neighbouring or old values;
- fabricated API responses;
- shifting realtime samples onto 5-minute marks;
- treating missing points as zero.

Interval figures (`gaps_over_5min`, `largest_gap_minutes`, `misaligned_ts`, `source_freshness_hours`) are **quality metrics** in the `update_history` result. They never trigger data generation.

## 6. How to check the gap

```sql
SELECT to_char(to_timestamp(ts - d) AT TIME ZONE 'Asia/Bangkok', 'YYYY-MM-DD HH24:MI') AS gap_start,
       to_char(to_timestamp(ts) AT TIME ZONE 'Asia/Bangkok', 'YYYY-MM-DD HH24:MI') AS gap_end, d / 60 AS minutes
FROM (SELECT ts, ts - lag(ts) OVER (ORDER BY ts) AS d FROM bkk_traffic.traffic_index_history) s
WHERE d > 300 AND ts >= extract(epoch FROM timestamptz '2026-10-01 00:00+07')
ORDER BY ts;
```
