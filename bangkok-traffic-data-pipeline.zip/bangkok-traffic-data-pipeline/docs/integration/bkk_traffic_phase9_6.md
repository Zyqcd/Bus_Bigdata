# BKK Traffic Phase 9.6: travel-time pipeline ported to PostgreSQL

**Date:** 2026-10-03 (Asia/Bangkok).

**Status: PASS** (final controlled production verification #2, 2026-10-03 05:14 Asia/Bangkok: 8 / 8 routes from the real RouteService, 849 rows, 0 duplicates; section 14b).
- **Caveat:** no transient outage occurred during that run, so the retry policy's outage-recovery branch is verified by deterministic tests, not yet observed in production.
- **History:** production verification #1 (section 13) was PARTIAL, with 6 / 8 routes failing on a TCP connection outage.

Design: [bkk_traffic_traveltime_mapping.md](bkk_traffic_traveltime_mapping.md).

> **Follow-ups:** [connectivity diagnostic](bkk_traffic_phase9_6_connectivity.md) (TCP-connect-stage outages of about 100 s, cause inconclusive) and [Phase 9.6.2 retry policy](bkk_traffic_phase9_6_retry_policy.md) (bounded connect backoff implemented and tested offline; **production not run**).

## 1. Objective

Port the friend's `traveltime.py` (Longdo RouteService travel times) to the PostgreSQL BKK architecture, writing to the existing `bkk_traffic.travel_times`, with:
- no SQLite;
- no fabricated observations;
- explicit Asia/Bangkok time;
- serial Longdo requests through pool `longdo_api`.

## 2. Legacy `traveltime.py` behaviour — PASS (documented)

- **Call graph:** DAG `bkk_traffic_traveltime` (*/5) → `collect(Variable longdo_api_key, Variable bkk_od_pairs)` → its own `requests.Session` (not `LongdoClient`), `storage` checkpoints and `INSERT OR REPLACE`.
- **Behaviour:**
  - one request per OD pair (8 routes), 1 s apart, with a daily / monthly quota guard;
  - `fetched_at = now_str()` (container TZ);
  - `duration_min = round(duration/60, 2)`;
  - per-route exceptions are logged (possibly with the key in the URL) and skipped;
  - the run raises only if every route failed.
- **The 839 production rows confirm this:** 8 routes = `DEFAULT_OD_PAIRS`; 105 polls about 5 min apart; one poll with 7 routes (a real per-route gap); integer metres / seconds; the rounding rule holds for all rows.

Details (the 19 points) are in the mapping doc.

## 3. PostgreSQL mapping — PASS

| Field | Mapping |
|---|---|
| `route` | OD-pair name (PK part) |
| `fetched_at` | poll start in explicit Bangkok time (PK part) |
| `distance_m` | `data[0].distance` |
| `duration_s` | `data[0].interval` → `time` → `duration` |
| `duration_min` | computed in SQL: `round((duration_s/60)::numeric, 2)` |
| coordinates | from the OD pair |
| `raw_json` | `compact_raw(body)` (no `guide`) |
| `baseline_load_id` | `NULL` for pipeline rows |

No migration and no new table: the existing schema is sufficient.

## 4. API endpoint and credential mechanism

| Item | Value |
|---|---|
| Endpoint | `GET https://api.longdo.com/RouteService/json/route/guide` with `flat, flon, tlat, tlon, mode=t, type=25, locale=th, key` (unchanged) |
| Credential | Airflow Variable **`longdo_api_key`**, the legacy mechanism. Read only inside the task; Airflow masks it in logs because the name contains `api_key`. Never in code, compose, `.env`, tests or docs. |
| Availability | **Not available.** Production Airflow has no Variables; no key exists in the container env or `airflow/.env`; the friend's archive contains only `.env.example`. No public or foreign key was used. |
| Network during tests | **None.** Fake route clients and fake HTTP sessions only. |

## 5. Timestamp / timezone behaviour — PASS

- **Source:** the API returns **no observation timestamp**. An observation is "the estimate at request time".
- **`fetched_at`:** `storage.now_str()` = `config.bangkok_now()`, an explicit UTC+7 wall-clock, taken once per poll. Every row of a poll shares it, as in the legacy.
- **Explicit `fetched_at`** (reruns / tests) must match `YYYY-MM-DD HH:MM:SS` and is rejected **before any request** otherwise. PostgreSQL alone would have accepted `03/10/2026 04:00`, which a test exposed.
- **Representation:** stored as `timestamp without time zone` (Bangkok wall-clock), the same convention as Phases 9.3–9.5.
- **Test:** the stored `fetched_at` is within 10 s of UTC + 7 h.

## 6. Business key — PASS

`(route, fetched_at)`: the existing primary key and the legacy key. No new uniqueness rule.

## 7. Insert / update / upsert semantics — PASS

```
ON CONFLICT (route, fetched_at) DO UPDATE SET …, baseline_load_id = NULL
WHERE (all values incl. raw_json::text) IS DISTINCT FROM (excluded …)
```

- A new poll means a new `fetched_at`, so rows are appended.
- An identical observation is a no-op.
- A changed value for the same key is updated (tested).
- The 839 baseline rows are never deleted, truncated or rewritten (tested: same `xmin`).

## 8. Error handling — PASS (tested)

| Case | Behaviour |
|---|---|
| Timeout, connection error, HTTP 429 / 5xx | one retry after 5 s; still failing → that route gets **no row** (real gap), recorded in `scrape_runs.note` |
| Other HTTP 4xx | route failure (no row), as above |
| `throw …` API error (e.g. key error), non-JSON body, missing / non-numeric / non-finite / ≤ 0 / implausible values (> 200 km, > 24 h), empty data | **unsafe:** the whole poll fails, nothing is written, `scrape_runs` = failed, the task fails |
| Every route failed | task fails, nothing written (legacy rule) |
| DB constraint failure (e.g. coordinate CHECK) | transaction rolled back, **no** row of the poll kept |
| Missing key | no client, no request, no write; `scrape_runs` = skipped "no longdo_api_key"; the pipeline continues |
| Quota exhausted | no request; `scrape_runs` = skipped |
| Error messages | built from status / exception type only, plus key redaction; tests inject the key into exception URLs and API error text and prove it reaches neither logs, `scrape_runs`, `travel_times`, checkpoints nor the result |

## 9. Transaction behaviour — PASS

All observations of a poll are written in **one** transaction, with a count check before commit. Any failure rolls back the whole poll.

The quota counters (`traveltime_usage`) still count the real requests made, even on failure, as in the legacy. They are kept in a separate commit.

## 10. Idempotency — PASS

Running the same `(route, fetched_at)` observations twice gives `inserted 0, updated 0, unchanged 8`, with identical rows and tuple versions and 0 duplicate keys.

A retried or rerun task polls again at a new time, giving new real observations. That is not a duplicate.

## 11. Airflow integration — PASS (tests) / not run in production

- **Pipeline:**
  ```
  scrape → update_history → collect_travel_times → clean → validate → publish → verify_postgresql
  ```
- **Task:** `collect_travel_times` (the legacy task id), pool `longdo_api` (1 slot, unchanged), so it never overlaps `scrape` / `update_history`. `retries=0`, timeout 5 min.
- **Placement:** before `publish` / `verify_postgresql`, so the published `travel_times` dataset and its check include the new rows.
- **Frequency:** it runs when the pipeline runs; there is no separate 5-minute DAG. The schedule is still **off**.
- **Running Airflow 3.3.2:** the updated DAG parsed with no import errors; the tasks are clean, collect_travel_times, publish, scrape, update_history, validate, verify_postgresql. DAG **paused**, timetable "Never". No run was triggered.

## 12. Test results — PASS

| Suite | Result |
|---|---|
| `tests/test_bkk_traffic_traveltime.py` (new, 48 tests) | parsing (valid, empty, malformed, missing field, invalid numbers), OD pairs, mapping, numeric rounding (4.5 s → 0.08, not Python's 0.07), Bangkok `fetched_at`, invalid timestamps, insert / update / idempotency / append, invalid payload rollback, constraint rollback, zero observations, real gap on transport failure, 839-style baseline preserved, quota, missing key, key never leaked, other tables + Namtang untouched, DAG position / pool / schedule |
| `tests/test_bkk_traffic_pipeline.py`, `tests/test_bkk_traffic_history.py` | exact task order / pool map / `update_history` downstream updated for the new task (still exact); the end-to-end `dag.test()` now also asserts the travel task's safe "skipped" record |
| Full suite, **Airflow 3.3.2 image** (`airflow-cli`, throwaway test DBs) | **366 passed, 0 failed** |
| Full suite, Windows, no test DSNs | 247 passed, 104 skipped |
| BKK traveltime + history + pipeline, Windows, BKK test DB | 107 passed, 5 skipped (Airflow-only; passed in the image) |

## 13. Production test results — PARTIAL (executed 2026-10-03 04:32 Asia/Bangkok)

**Authorization:** the user configured the Airflow Variable `longdo_api_key` (encrypted, has a value; its value was never read into output or printed) and authorized one controlled run.

**Pre-checks** (read-only):
- target `namtang_db` (connection `bkk_traffic_postgres` → `namtang_db:5432` on the Docker network, never `itproject_db` / host port 5432);
- pool `longdo_api` = 1 slot;
- all DAGs paused, timetable "Never", no import errors;
- `travel_times` 839 rows, 0 travel-time runs.

**Run:** `phase9_6_manual_traveltime_verification`, exactly one (unpause → trigger 21:32:51 UTC → re-pause). DAG runs: `bkk_traffic_pipeline` 2 → 3, `namtang_gtfs_pipeline` 4 (unchanged).

| Task | State | Try | Pool | Seconds |
|---|---|---|---|---|
| scrape | success | 1 | longdo_api | 31 |
| update_history | success (throttled: last refresh 1.3 h ago; verify checks 0) | 1 | longdo_api | 1 |
| collect_travel_times | success | 1 | longdo_api | 109 |
| clean / validate / publish / verify_postgresql | success | 1 | default_pool | 45 / 0 / 15 / 1 |

**`collect_travel_times` result** (XCom + `scrape_runs`):

| Item | Value |
|---|---|
| Routes requested | 8 (`DEFAULT_OD_PAIRS`) |
| HTTP requests | 15: 6 routes × 2 failed attempts, plus 2 successes (one after a retry) |
| Successful responses | **2**: `บางแค -> ปิ่นเกล้า` (19,497 m, 1,333 s → 22.22 min) and `มีนบุรี -> รามคำแหง` (16,584 m, 1,235 s → 20.58 min). Raw `meta.status` 200; real RouteService fields (`fdistance`, `tdistance`, …); `guide` dropped. |
| Failed routes | **6**, each `ConnectionError after 2 attempts`: อนุสาวรีย์ชัยฯ -> สยาม, สีลม -> อโศก, ห้าแยกลาดพร้าว -> อนุสาวรีย์ชัยฯ, บางนา -> พระราม 9, ดอนเมือง -> หมอชิต, สาทร -> วงเวียนใหญ่ |
| Inserted / updated / unchanged / rejected | 2 / 0 / 0 / 0 |
| `fetched_at` | `2026-10-03 04:33:29` = task start 21:33:29 UTC + 7 h (explicit Asia/Bangkok) |
| Quota checkpoint `traveltime_usage` | created: day 15, month 15 calls |

**Exact failure.**
- The first six routes (in list order) each failed both attempts with a `requests` `ConnectionError`, i.e. no HTTP response was received. The last two routes then succeeded.
- A key problem would have produced Longdo's `throw … Key Error` body, which is classified as an invalid response and fails the whole poll. That did not happen.
- So the failure was at the connection level between the Airflow container and `api.longdo.com`. Its root cause (network, DNS, TLS, or rate limiting on the remote side) cannot be determined from this single run.
- **Per the instruction, the run was not repeated** and nothing was retried manually.

**Verification after the run:**
- `travel_times` 839 → **841**; 841 distinct `(route, fetched_at)` = **0 duplicates**.
- The 839 baseline rows are intact (same count, all `baseline_load_id = 1`, last 2026-10-02 19:00:02).
- New rows: `duration_min = round((duration_s/60)::numeric, 2)` holds; coordinates valid; no NULL / ≤ 0 / NaN values.
- The six failed routes have **no row** at 04:33:29 (a real gap, nothing fabricated).
- **API key in logs:** scanning all 7 task log files of the run inside the container found **0 occurrences of the key value** and **0 `key=`**. The key length is maskable (≥ 5 characters). The log's "Skipping masking for a secret as it's too short" warning concerns another value, not the key.
- **Transaction:** the poll committed as one transaction with the count check (2 = 2). The quota counters and the run log were written.
- **Other BKK tables:** changed only by the pipeline's documented steps.
  - `scrape`: incidents +1, `traffic_index` +1, `traffic_index_history` +1, `seen_eids` +7, `scrape_runs` +1 realtime.
  - `collect_travel_times`: `scrape_runs` +1 travel_times; new checkpoint `traveltime_usage`.
  - quarantine and `missing_eids` unchanged; 0 incident key duplicates; 0 `ts_local` mismatches; 0 unvalidated constraints.
- **Namtang:** before / after identical (migration and load history, feed `20261001`, the table lists and row counts of all 22 tables, write counters 7,102,021 / 0 / 0); its DAG was not triggered (latest run still Phase 8).
- **`itproject_db`:** never contacted.
- **Airflow:** the schedule stayed **OFF**; every DAG paused at the end; pool `longdo_api` still 1 slot.

## 14. Row counts before / after

| | Before the production run | After |
|---|---:|---:|
| `bkk_traffic.travel_times` | 839 (baseline load 1) | **841** (+2 real observations at 2026-10-03 04:33:29; 0 updated, 0 deleted) |
| `scrape_runs` (job `travel_times`) | 0 | 1 (success, 15 requests, 2 received, 2 inserted, 6 failed routes listed) |
| Duplicate `(route, fetched_at)` | 0 | 0 |

## 14b. Production Verification #2 (final, with the Phase 9.6.2 retry policy) — PASS

| Item | Evidence |
|---|---|
| Trigger time | 2026-10-02 22:14:35 UTC = **2026-10-03 05:14:35 Asia/Bangkok**; run `phase9_6_final_retry_verification`, the **only** run of this step (unpause → trigger → re-pause). DAG runs: BKK 3 → 4, Namtang 4 → 4 |
| Target DB | `namtang_db` (connection `bkk_traffic_postgres` → `namtang_db:5432` on the Docker network); **not** `itproject_db` / host port 5432 |
| Pre-run state | DAG paused, timetable "Never", no import errors; pool `longdo_api` = 1; the mounted code holds `CONNECT_RETRY_DELAYS = (5, 10, 20, 30, 30, 30)`; `travel_times` 841 rows, `sum(xmin)` 747,843 |
| Tasks | scrape 21 s, update_history 0 s (throttled), **collect_travel_times 8 s**, clean 44 s, validate 0 s, publish 14 s, verify_postgresql 1 s; **all success, try 1**; Longdo tasks in pool `longdo_api` |
| Routes requested | 8 |
| Total HTTP requests | **8** (= routes, so 0 retries) |
| Successful routes | **8 / 8**: real RouteService responses (`raw_json` `meta.status` 200) |
| Failed routes | **0** |
| Retry behaviour | No connection failure, no HTTP 429 / 5xx, no read timeout: the policy issued **no retry and no backoff sleep**, as designed (no unnecessary retries; request cap 24 not approached). **The outage-recovery branch (5 / 10 / 20 / 30 / 30 / 30 s backoff, 150 s budget, circuit breaker) was not exercised in production, because no outage occurred.** It is verified by the 32 deterministic tests (outages of 95 s and 150 s recover; a permanent outage stops after 7 attempts / 125 s). |
| Rows inserted / updated / unchanged / rejected | **8 / 0 / 0 / 0** (`scrape_runs`: `success, requests 8, items 8, new 8, "+8 ~0; failed routes: none"`) |
| Final `travel_times` count | **849** (841 + 8); the 841 earlier rows are intact (`sum(xmin)` still 747,843) |
| Duplicate count | **0** (849 rows = 849 distinct `(route, fetched_at)`) |
| Values | All 8 new rows: `duration_min = round((duration_s/60)::numeric, 2)`; 0 invalid coordinates; 0 NULL / ≤ 0 / NaN distances or durations in the whole table; `baseline_load_id NULL` (pipeline rows) |
| Timezone verification | `fetched_at = 2026-10-03 05:15:05`, which is the task start 22:15:04 UTC + 7 h (explicit Asia/Bangkok); one `fetched_at` shared by the 8 routes of the poll |
| Transaction | Committed as one poll transaction (8 = 8 count check); quota counters `traveltime_usage` 15 → 23 (= +8 requests). Failure / rollback semantics are evidenced by the test-DB rollback tests (no failure was induced in production). |
| API-key log scan | 7 task log files of the run scanned inside the container (value never printed): **0** occurrences of the key value, **0** `key=`, **0** `api.longdo.com` URLs. The key was accepted (8 real responses). |
| Other BKK tables | Expected pipeline changes only: `traffic_index` +1, `traffic_index_history` +1 (realtime sample), `scrape_runs` +2 (realtime with 0 new incidents; travel_times); incidents, quarantine, `seen_eids`, `missing_eids` and checkpoint count unchanged; 0 incident key duplicates, 0 `ts_local` mismatches, 0 unvalidated constraints |
| Namtang verification | Before / after identical: migration and load history, feed **20261001**, table lists and row counts of all 22 tables, write counters **7,102,021 / 0 / 0**; Namtang DAG not triggered (latest run still the Phase 8 one; 4 runs) |
| `itproject_db` verification | Not contacted: the only DB connection used is `bkk_traffic_postgres` → `namtang_db`; production checks used `namtang_db` (5433) only |
| Final Airflow state | `bkk_traffic_pipeline` **paused**, schedule **OFF** (`BKK_TRAFFIC_SCHEDULE_ENABLED=false`), pool `longdo_api` = 1 slot |

**Did the new policy improve behaviour?** This run cannot show it: there was no transient outage, so nothing needed recovering. The run shows that the policy changed nothing on the healthy path (8 requests, no extra quota, no waiting) and that the collector works fully in production.

## 15. Source-data limitations

- RouteService returns only the **current** estimate, so no past travel time can be obtained. The production series stops at 2026-10-02 19:00:02 and **stays that way** until real polls run with a valid key; that gap will not be filled.
- Free-tier quota: 5,000 calls/day; the guard allows 4,500. 8 routes every 15 min = 768 calls/day.

## 16. Intentionally NOT implemented

- A separate 5-minute travel-time DAG (the task runs with the pipeline).
- Schedule activation.
- CSV export and the full quality report.
- SQLite shutdown.
- Any Namtang or `itproject_db` change.
- Any migration.

## 17. Final status

| Item | Status |
|---|---|
| Legacy behaviour + mapping | PASS |
| Implementation (`traveltime.py`, DAG task) | PASS |
| Offline / test-DB tests | PASS |
| Airflow 3.3.2 image suite | PASS |
| Credential handling (missing key, no leakage) | PASS |
| Real API test | **PARTIAL**: real RouteService responses for 2 / 8 routes; 6 routes `ConnectionError after 2 attempts` |
| Production manual run | **PARTIAL**: run `phase9_6_manual_traveltime_verification` succeeded (all 7 tasks try 1); 2 real observations stored; 6 routes without a row (real gap, nothing fabricated) |
| Key never in logs | PASS (0 occurrences of the key value and 0 `key=` in the 7 task logs) |
| Transaction / integrity | PASS (841 rows = 841 distinct keys; 839 baseline rows intact; rounding, coordinates, values valid) |
| Namtang / `itproject_db` isolation | PASS (before / after identical; `itproject_db` never contacted) |
| Schedule off / DAG paused | PASS |
| Production verification #2 (retry policy deployed) | **PASS**: 8 / 8 routes, 8 requests, 0 retries needed, 849 rows, 0 duplicates, key not in logs (section 14b) |
| Retry outage-recovery branch in production | **NOT EXERCISED** (no outage occurred; covered by 32 deterministic tests) |
| **Phase 9.6 overall** | **PASS** (with the caveat above) |
