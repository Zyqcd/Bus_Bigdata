# BKK Traffic Phase 9.7: quality pipeline (test DB only)

**Date:** 2026-10-03.

**Status:** implemented and **tested on the isolated test DB and in the Airflow 3.3.2 image only**. **Not run in production.**

Design: [bkk_traffic_quality_mapping.md](bkk_traffic_quality_mapping.md), written before implementation.

## 1. Scope

Port of the friend's `quality.py` and its daily quality DAG to PostgreSQL, as a separate DAG `bkk_traffic_quality`:

```
refresh_event_types → detect_missing_eids → recover_missing_eids → quality_checks → gate
```

**Not included** (separate decisions):
- CSV export (the friend's `export_csv` task);
- `feed.py`, `progress.py`, backfill scheduling;
- schedule activation, SQLite shutdown, production execution;
- docs / `.gitignore` cleanup, TCP-outage root cause.

## 2. Implementation

| File | Change |
|---|---|
| `data/scraper/bkk_traffic/quality.py` (new) | All friend checks with unchanged names, thresholds, statuses and report files, written to `data/bkk_traffic/quality/dt=<day>/`. SQLite constructs replaced: explicit Bangkok `now`, half-open timestamp ranges, `extract()` 15-min slots, `ts_local::date`, type-aware NULL checks, `to_char` text. Coverage start: backfill anchor if present, else the documented `2015-12-29`. |
| `data/scraper/bkk_traffic/scrape.py` | `refresh_event_types`: validated (non-empty list, integer unique ids, text / integer fields), one transaction, upsert rewrites only changed rows, never deletes. `detect_missing_eids`: persisted coverage floor (checkpoint `missing_eid_detection`, initialised to the highest Parquet-baseline eid), window `(floor, MAX(seen_eids)]`, excludes seen / tracked / stored eids, ≤ 2,000 new per run. `recover_missing_eids(limit=30, max_seconds=360)`: deadline-bounded, one request at a time, a mismatched / malformed item is not stored. It reports `attempted, recovered, recovered_bangkok, not_available, failed, remaining_pending, stop_reason` and records a `scrape_runs` row (job `recover`). |
| `data/scraper/bkk_traffic/client.py` | Optional `deadline`: no crawl-delay wait, request or retry backoff may pass it, and the request timeout is capped at the remaining time; raises `DeadlineExceeded`. **No deadline gives byte-for-byte the previous behaviour** (main pipeline unchanged; tested). |
| `data/scraper/bkk_traffic/config.py` | `DEFAULT_RECOVER_PER_RUN = 30` (friend 150), new `DEFAULT_RECOVER_MAX_SECONDS = 360` |
| `airflow/dags/bkk_traffic_quality.py` (new) | Airflow 3.3.2 (`airflow.sdk`). Report day = `dag_run.run_after` in Asia/Bangkok − 1 day. Pool `longdo_api` for `refresh_event_types` and `recover_missing_eids`. `recover_missing_eids` has an `execution_timeout` of 8 min (backstop above the 6-min deadline). Variables `bkk_recover_per_run` / `bkk_recover_max_seconds` / `bkk_scrape_stopped`. Schedule `None` unless `BKK_TRAFFIC_SCHEDULE_ENABLED=true` (then 01:00 Asia/Bangkok). `max_active_runs=1`. |
| `tests/test_bkk_traffic_quality.py` (new, 44 tests) | Section 3 |
| `tests/test_bkk_traffic_pipeline.py` | `FakeClient` accepts `deadline`. The exact live-DAG-folder and DagBag sets now include `bkk_traffic_quality` (still exact). The detect / recover test was rewritten for the coverage-floor rule (intentional behaviour change D1) and is stricter (exact counts and stop reason). |
| `docs/integration/bkk_traffic_quality_mapping.md`, this report | documentation |

**Not changed:**
- the database schema (migrations still 001–006, no new table);
- `bkk_traffic_pipeline`, `traveltime.py`, `history.py`, the loader;
- anything in Namtang.

**Recovery limit — clean enforcement:**
- The friend's client could spend more than 5 minutes on one eid: 4 retries with 30–120 s backoff and 180 s timeouts.
- The friend's time check ran only between eids.
- The deadline-aware client makes the 360 s bound hold *inside* each request, so no workaround was needed.
- The Airflow `execution_timeout` (8 min) is a second, independent bound.

## 3. Tests

| Area | Tests (test DB unless noted) | Result |
|---|---|---|
| Quality SQL and checks | empty tables (`has_data` FAIL, all 5 files written); type-aware NULL / empty checks; validity, quarantine reasons, dq flags, duplicates, sources, bronze backlog, quarantine CSV; freshness with Bangkok `now` and future `createtime` ignored; default `now` = UTC + 7; day boundaries (00:00:00 / 23:59:59 / next day) and the 7-day window; missing and low days + CSV; documented coverage start; 15-min slots + first-day rule + "not started"; 5-min history days; 24 h failed-run window (01:29 vs 01:31); pending eids CSV; Parquet check FAIL without manifests, OK after publish; `report.md` format; overall status; no SQLite constructs or key references in code | PASS |
| Event types | upsert (3 inserted, rerun unchanged with identical `xmin`, 1 changed, nothing deleted on a shorter list); 9 malformed payloads (dict, empty, non-object, string / bool / missing id, duplicate id, bad severity, bad name) change nothing; API failure changes nothing | PASS |
| Missing-eid detection | no baseline → no floor, nothing added; floor from the baseline, persisted, stable after the row is taken over; seen / tracked / bronze eids excluded; nothing missing; cap keeps the newest | PASS |
| Recovery | success, not_available, failure, malformed / mismatched item, partial mix (exact states, tries, run log); **30-eid limit** (40 pending → 30 newest attempted, `stop_reason=limit`, 10 remaining); **time limit** (12 s per request, 60 s → 5 attempted, `stop_reason=time`, deadline passed to the client); defaults 30 / 360; API failure keeps everything pending; no API key needed; empty queue is a no-op | PASS |
| Client deadline (fake session / time / lock, no network) | no deadline gives the original retries (30 / 60 / 90 s, 180 s timeout); the deadline stops a retry it cannot afford; it blocks an unaffordable crawl-delay wait **before** sending; timeout capped at the remaining time | PASS |
| DAG (Airflow image) | task ids and order, pools (`longdo_api` for refresh / recover), recover `execution_timeout` 8 min, schedule `None` / 01:00 when enabled, `max_active_runs` 1, no `multiple_outputs`; report day from `run_after` in Bangkok (18:30 UTC → 2026-10-02; 16:59 UTC → 2026-10-01); **end-to-end `dag.test()`** against the test DB as a `bkk_traffic_app` member: all upstream tasks succeed, an eid is detected and recovered, the report is written; the gate **succeeds on WARN and fails on FAIL** | PASS |

**Suite totals:**

| Suite | Result |
|---|---|
| **Airflow 3.3.2 image** (`airflow-cli`, throwaway test DBs, all suites incl. Namtang) | **443 passed, 0 failed** |
| Windows, no test DSNs | 280 passed, 148 skipped (DB and Airflow-only tests) |
| Windows, BKK test DB (quality + pipeline modules) | 69 passed, 7 skipped (Airflow-only; passed in the image) |

The test-DB pass in the Airflow image includes every quality test above.

## 4. Test DB verification

- **Target:** `namtang_bkk_traffic_test_db` (127.0.0.1:5435; from containers `host.docker.internal:5435`). The guarded fixtures refuse ports 5432 / 5433 and the production names, and check `current_database()`.
- **Role:** pipeline code ran as a login user in `bkk_traffic_app`. No new privilege was needed: `event_types`, `missing_eids`, `checkpoints` and `scrape_runs` DML already exists.
- **Network:** no real Longdo request in any test.

## 5. Airflow verification (production Airflow, read-only)

- `bkk_traffic_quality` is registered from `/opt/namtang/airflow/dags/bkk_traffic_quality.py`, **paused**, timetable "Never, external triggers only", `max_active_runs` 1, tasks as designed, **no import errors**.
- It has never run (0 runs).
- Other DAGs: all paused. DAG runs unchanged (`bkk_traffic_pipeline` 4, `namtang_gtfs_pipeline` 4).
- Pool `longdo_api` = 1 slot; `BKK_TRAFFIC_SCHEDULE_ENABLED=false`, `NAMTANG_SCHEDULE_ENABLED=false`.

## 6. Production safety verification (read-only)

- **BKK production counts** are identical to the end of Phase 9.6:

  | Table | Rows |
  |---|---:|
  | incidents | 484,835 |
  | traffic_index | 4 |
  | traffic_index_history | 1,414,006 |
  | quarantine | 0 |
  | seen_eids | 525 |
  | missing_eids | 0 |
  | checkpoints | 3 (no `missing_eid_detection`) |
  | scrape_runs | 7 |
  | travel_times | 849 |
  | event_types | 18 |

- No production DAG was triggered; no production schedule enabled.
- **Namtang:** migration and load history, feed `20261001`, the table lists and row counts of all 22 tables and the write counters (7,102,021 / 0 / 0) are unchanged.
- **`itproject_db`:** not contacted.
- No `airflow db clean`. The legacy SQLite pipeline was not touched. No key appears in code, logs or documents; this DAG never reads `longdo_api_key`.

## 7. Known limitations

| Limitation | Note |
|---|---|
| Coverage floor | Eids at or below the Parquet baseline's highest eid (978,543 in production) are not checked; the friend's pipeline covered them. The floor is fixed at first detection. |
| Coverage start for missing days | `2015-12-29` (the friend's last reported window) unless a backfill anchor exists |
| Gate behaviour in production | The checks reflect real data health. With the pipeline unscheduled, freshness checks (`realtime_last_success_hours`, coverage) would report FAIL / WARN, so the gate would fail, correctly. |
| Event-type refresh failure | As in the friend's DAG, a failed refresh stops the downstream tasks of that run (linear chain) |
| Recovery throughput | ≤ 30 eids per run (about 10–12 s per eid at the 10 s crawl delay); a larger backlog drains over several runs |
| Report content in production | Not observed (no production run) |

## 8. Status

| Component | Status |
|---|---|
| Mapping documentation | PASS |
| `quality.py` port | PASS (test DB) |
| `refresh_event_types` (daily, validated) | PASS (test DB) |
| `detect_missing_eids` (coverage floor) | PASS (test DB) |
| `recover_missing_eids` (30 eids / 360 s, deadline) | PASS (test DB) |
| Client deadline | PASS (offline) |
| DAG `bkk_traffic_quality` (parse, structure, end-to-end, gate) | PASS (Airflow 3.3.2 image + test DB) |
| Registration in production Airflow (paused, schedule off) | PASS (read-only check) |
| Production execution of the quality DAG | **NOT TESTED** (not authorized in this phase) |
| Real Longdo API behaviour of refresh / recovery | **NOT TESTED** (fake clients only) |
| Namtang / `itproject_db` / BKK production untouched | PASS |
| **Phase 9.7 overall** | **PASS for implementation and testing; production verification NOT TESTED** |
