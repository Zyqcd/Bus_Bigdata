# BKK Traffic: traffic-index history mapping (Phase 9.5)

**Purpose:** document the friend's `history.py` and its PostgreSQL port **before** implementation.
**Port:** `data/scraper/bkk_traffic/history.py`.
**Storage:** PostgreSQL `bkk_traffic` only. There is no SQLite.

## 1. Original behaviour (friend's `plugins/bkk_traffic/history.py`, 58 lines)

| Aspect | Original (SQLite) |
|---|---|
| Source | `GET https://traffic.longdo.com/api/raw/trafficindex/{year}`: one CSV per calendar year, published by Longdo for download. Attribution: "Longdo Traffic (https://traffic.longdo.com)". |
| Format | Header `timestamp,datetime,index`. `timestamp` = epoch seconds; `datetime` = local time `YYYY-MM-DDTHH:MM`; `index` = 0–10 congestion index (Bangkok + vicinity), computed every 5 minutes. |
| API calls | `LongdoClient.get_text` (shared `fcntl` rate lock with a 10 s crawl delay, 4 retries with 30/60/90/120 s backoff) |
| Raw copy | `RAW_DIR/traffic_index_history/{year}.csv`, **overwritten** on every download |
| Timestamp generation | `ts_local = datetime.fromtimestamp(ts)` (**container local time**; correct only because the friend's compose set `TZ=Asia/Bangkok`) |
| Row filter | Rows whose `timestamp` or `index` does not parse are **skipped silently**. The `datetime` column is ignored. |
| Write | `executemany INSERT … ON CONFLICT(ts) DO UPDATE SET index_value, source`. A file value **overrides** an earlier realtime sample for the same `ts` (comment in `scrape.py`: "values from the yearly file overwrite later"). Rerunning rewrites every row. |
| Dedup | `ts` primary key |
| Retention | Never deletes |
| Checkpoint | `traffic_index_history`: `years_done` (completed past years are never downloaded again), `last_run`, `last_result`, `rows_total`, `range` |
| Years | First run: every year from 2012 to the current one. Later: the current year only (plus any year not yet done). |
| Errors / retries | Client retries; no run log (`scrape_runs` was not written); the DAG task retried 2× with a 5 min delay |
| Schedule | DAG `bkk_traffic_history`, daily 02:30, pool `longdo_api`, 30 min timeout; followed by `load_event_feed` (`feed.py`, yearly incident files, **not in scope**) |
| Callers | Only that DAG. `traffic_index_history` is also written by `scrape.run_traffic_index` (realtime sample, `INSERT OR IGNORE`, `source='realtime'`) and read by the Parquet / CSV exports and `quality.py`. |

## 2. Real-source evidence (measured, not assumed)

| Evidence | Result |
|---|---|
| The friend's 15 downloaded files (2012–2026, 1,413,831 rows) | Header always `timestamp,datetime,index`. 0 blank, unparseable or non-finite values. 0 duplicate `ts`. 0 points outside their file's (Bangkok) year. Every `ts` is a multiple of 300 s. Values 0.0–9.9. |
| `datetime` vs `ts` | **`datetime` = `ts` in UTC+7 for all 1,413,831 rows.** The source itself states Bangkok wall-clock time. |
| Real outages | Every year has gaps > 5 min (e.g. 2018: 5,870; 2026: 28). The source does **not** guarantee every 5-minute point. |
| Live download (2026-10-03, one request through the rate-limited client) | 77,751 rows; last point **2026-09-30 23:55**. Longdo has not published anything after September yet. |

## 3. PostgreSQL mapping

| CSV field | Validation | PostgreSQL `bkk_traffic.traffic_index_history` |
|---|---|---|
| `timestamp` | integer; 2012-01-01 ≤ local time; ≤ now + 10 min; local year = requested year | `ts bigint` **PK** (observation identity) |
| `datetime` | must equal `ts` formatted in UTC+7 (`%Y-%m-%dT%H:%M`); any 7-hour shift is rejected | not stored (redundant) |
| — | computed explicitly: `config.bangkok_from_epoch(ts)` (never the container TZ) | `ts_local timestamp` (Bangkok wall-clock, seconds included) |
| `index` | float, finite, 0 ≤ x ≤ 10 | `index_value double precision` |
| — | `history:{year}` (source identity, as in the original) | `source text` |
| — | a row written or updated by the pipeline is owned by it | `baseline_load_id = NULL` (Phase 9.3 provenance) |

The existing schema is sufficient. **No migration is needed.**

### Current vs history

| Table | Meaning | Written by |
|---|---|---|
| `bkk_traffic.traffic_index` (**current**) | Log of realtime API polls: one row per distinct API `time`, with `fetched_at` | `scrape.run_traffic_index` only (`ON CONFLICT DO NOTHING`); history never touches it |
| `bkk_traffic.traffic_index_history` (**history**) | One row per observation time `ts`: the 5-minute series | the yearly files (`history:{year}`, authoritative) and realtime samples (`realtime`, provisional; inserted only when the `ts` is new) |

**Overlap rule (kept from the original, made idempotent):**
- A file value for a `ts` replaces a provisional realtime value.
- A realtime sample never overrides an existing value.
- An identical file value is a no-op: `ON CONFLICT … DO UPDATE … WHERE (index_value, source) IS DISTINCT FROM (excluded…)`. A rerun therefore rewrites nothing.

## 4. Decisions that differ from the original (and why)

| # | Original | Port | Reason |
|---|---|---|---|
| H1 | `fromtimestamp(ts)` (container TZ) | `bangkok_from_epoch(ts)` + `datetime` column check | Our containers run in UTC (the Phase 9.3 bug) |
| H2 | Invalid rows skipped silently | **The whole year file is rejected** (rollback), the failure goes to `scrape_runs`, and the task fails | Project policy: fail closed, never drop silently. Real files contain 0 such rows. |
| H3 | Exact duplicate `ts` handled by the PK | Identical duplicates collapsed and counted; conflicting duplicates reject the file | Unambiguous observation identity |
| H4 | `DO UPDATE` on every row | `DO UPDATE … WHERE IS DISTINCT FROM` | Idempotent rerun (same input → same state, no rewritten tuples) |
| H5 | `executemany` | `COPY` into a session TEMP table, then one `INSERT … SELECT … ON CONFLICT`, in **one transaction per year** | Atomic per year; fast (≈78k rows) |
| H6 | Raw copy overwritten | Raw copy kept immutable as `{year}_{sha256[:12]}.csv`, written only when the content changed | Provenance without unbounded growth |
| H7 | `years_done` checkpoint; the first run downloads 2012–2026 | Years = the current Bangkok year, the previous year during the first 7 days of January, and any year with **0 rows** in PostgreSQL | Production already holds 2012–2026 from the Parquet baseline; avoids 15 needless downloads |
| H8 | No run log | `scrape_runs` row (`job = 'traffic_index_history'`, success / failed) + checkpoint (file SHA per year, last success, latest point) | Auditability |
| H9 | Separate daily DAG | Task `update_history` inside `bkk_traffic_pipeline`, throttled to one refresh per `bkk_history_refresh_hours` (default **24**, the original daily cadence) | One BKK pipeline; the pool `longdo_api` (1 slot) serializes it with `scrape`; publish / verify then include the refreshed history |
| H10 | No interval logic | Interval figures (gaps > 5 min, misaligned `ts`, source freshness) are **quality metrics only**. Nothing is ever generated. | Real outages exist (section 2) |

## 5. Not in scope

- `feed.py` (yearly incident files), `traveltime.py` (Phase 9.6), CSV export, the full quality report.
- Changes to the friend's SQLite pipeline.
