# BKK Traffic (Longdo) integration: Phase 9.2 design closure and migration test

> **Phase 9.3 follow-up:** the initial load now comes from the friend's published Parquet (SQLite excluded); see [bkk_traffic_phase9_3.md](bkk_traffic_phase9_3.md). This Phase 9.2 record is kept as written.

**Status:** design finalized and migrations tested **only** in an isolated throwaway database. **Integration is NOT complete.** Nothing is in production:
- no `bkk_traffic` schema or roles in `namtang_db`;
- no friend data loaded;
- no DAG added or changed;
- no Namtang file changed.

**Baseline:** [bkk_traffic_database_assessment.md](bkk_traffic_database_assessment.md) (Phase 9.1). It is preserved unchanged, except for one cross-reference line.
**Date:** 2026-10-02/03 (Asia/Bangkok).

---

## 1. Phase 9.2 objective

1. Close the Phase 9.1 unknowns, using real evidence only.
2. Decide or defer D1–D11.
3. Finalize the `bkk_traffic` PostgreSQL design: tables, types, constraints, indexes and roles.
4. Assess compatibility with Airflow 3.3.2.
5. Make the maintenance DAG safe for the shared Airflow metadata.
6. Analyse the per-minute Parquet schedule.
7. Write numbered migrations.
8. Test the migrations in an isolated test database only.
9. Map every SQLite operation to PostgreSQL.
10. Verify that Namtang is untouched.

Out of scope:
- loading friend data;
- production DDL;
- porting the friend's code;
- changing any production schedule.

## 2. Phase 9.1 baseline

Phase 9.1 produced:
- the 11-table inventory;
- the type mapping;
- proposed indexes and constraints;
- `migration_history` / `load_history`;
- conflicts C1–C11, unknowns U1–U8 and decisions D1–D11.

All of it was carried forward. Where Phase 9.2 changes a 9.1 proposal, the change is listed with its evidence (D-table in section 5, indexes in section 8).

## 3. SQLite availability

**The real SQLite warehouse `data/warehouse/bkk_traffic.db` was NOT found.**

| Location searched | Result |
|---|---|
| Project root (`bangkok-traffic-project/`, recursive) | No `.db` / `.sqlite` / `.sqlite3` / `bkk_traffic*` |
| `scrapping--main.zip` (project root) and `Downloads/scrapping--main.zip` | Byte-identical (SHA-256 `b67baa1a…ce77`); 6,676 entries, **no** `.db` / `sqlite` / `warehouse` entry |
| Session scratchpad (extracted friend repo) | No database |
| Desktop, Downloads, Documents, OneDrive (recursive) | Only unrelated DBs (Chrome profile, Grafana) |
| Mounted drives / Docker volumes | No other drives; no friend volume |

The friend's `.gitignore` excludes `data/warehouse/` ("SQLite (~1.5 GB) exceeds GitHub's 100 MB limit, rebuildable from code").

**No SQLite fact in this document is invented.** Everything is either:
- **code** (`storage.py` and all SQL in the friend's modules), or
- **data shipped in the ZIP**: Parquet exports, checkpoint JSON copies, quality reports.

Each item says which. Step 2 (DB vs code comparison) could not run.

Secondary evidence used:

| Evidence | What it covers |
|---|---|
| `data/parquet/incidents_bangkok` (484,803 rows) | Every non-duplicate silver incident at export time |
| `data/parquet/traffic_index` (1,414,001 rows) | The **whole** `traffic_index_history` table (the export query has no WHERE) |
| `data/parquet/travel_times` (839 rows) | The **whole** `travel_times` table |
| `data/checkpoints/*.json` | Copies written by `set_checkpoint` right after each DB upsert |
| `data/quality/dt=*/report.md` | Counts computed by the friend's quality DAG |

## 4. U1–U8 resolution

| ID | Question | Status | Evidence | Impact |
|---|---|---|---|---|
| U1 | Real SQLite schema, columns added by `ALTER`, and type affinity | **REMAINS_UNKNOWN** | No DB. Code defines the schema plus `_NEW_COLUMNS` (`dq_flags`, `is_duplicate`, `event_type_id`, `traffic_relevance`). Parquet types match the code. | The Phase 9.3 loader must run `PRAGMA table_info` and a `typeof()` profile per column **before** copying. Any value that does not fit the target type aborts the load (no silent coercion). |
| U2 | Are the timestamps parseable in **all** rows? | **REMAINS_UNKNOWN** (partly evidenced) | **Data**, 100% exact `YYYY-MM-DD HH:MM:SS`, 0 unparseable:<br>• 484,803 published incidents: `start_time`, `stop_time`, `createtime`, `updatedtime`, `first_seen_at`, `last_seen_at`;<br>• all 1,414,001 `traffic_index_history.ts_local`;<br>• all 839 `travel_times.fetched_at`.<br>**Code** guarantees:<br>• `start_time`: R3 rejects unparseable values;<br>• `stop_time`: R4 sets unparseable values to NULL;<br>• internal times come from fixed `strftime` formats.<br>**Still unverified:**<br>• `createtime` / `updatedtime` in the ~1,338 unpublished duplicate rows;<br>• any value written after the export. | The loader pre-flight counts unparseable values per column; any count > 0 stops the load. `''` → NULL is applied only to the timestamp columns (section 14, A7). |
| U3 | Is `incidents.raw_json` all NULL? | **REMAINS_UNKNOWN** | **Code:**<br>• `migrate_v2_layers.py` runs `UPDATE incidents SET raw_json=NULL`;<br>• `clean_eids` never writes `raw_json` (not in `SILVER_COLS`).<br>So all NULL is expected, but not verified. | The column is not created in PostgreSQL. The loader asserts `count(raw_json IS NOT NULL) = 0`; otherwise it STOPs, so nothing is dropped silently. |
| U4 | Does `probe_count` still exist? | **REMAINS_UNKNOWN** | **Code:** `migrate_bangkok_only.py` drops it, and `storage.SCHEMA` never creates it. Whether that script ran is unknown. | None on the design (it is not migrated). The pre-flight lists all tables and reports any table it does not expect. |
| U5 | Row counts of the small tables at migration time | **REMAINS_UNKNOWN** (partly evidenced) | **Code:** `set_checkpoint` is called for exactly 5 jobs (`realtime`, `backfill`, `event_feed`, `traffic_index_history`, `traveltime_usage`), and a JSON copy exists for each. `progress.json` is file-only.<br>**Data:**<br>• bronze 486,149 = silver 486,141 + quarantine 8 (Phase 9.1 snapshot);<br>• quarantine 1 on 2026-10-01 (later report);<br>• `missing_eids` pending 1,454 / not_available 303 / recovered 283. | Counts change over time anyway. The loader records the source counts in `load_history.row_counts` and reconciles source against target per table. |
| U6 | Container timezone when rows were written | **RESOLVED** | **Data:** in all 1,414,001 `traffic_index_history` rows (sources `history` and `realtime`), `ts_local − UTC(ts)` = exactly **+7 h**. `ts_local` is `datetime.fromtimestamp(ts)`, so every writer ran with `TZ=Asia/Bangkok` (compose sets it).<br>Other tables have no epoch to compare against; they are written by the same containers and code. | Timestamps are Bangkok wall-clock. Store them as `timestamp without time zone` (D1, section 6). |
| U7 | Who consumes the Parquet/CSV? | **REMAINS_UNKNOWN** (team decision) | The friend README describes the files as the "gold" deliverable but names no consumer. | Keep the Parquet/CSV exports **byte-compatible** (same string timestamp format, section 14 A3). PostgreSQL complements them until the team decides. |
| U8 | Should the backfill DAG's ungated final export stay as-is? | **RESOLVED** (technical; team may override) | **Code:** the path runs only when `done_reason` contains "target", which needs `bkk_backfill_target_rows` > 0. The default is 0. **Data:** the latest checkpoint says `done=true, done_reason="end_of_list"`. So the path is dormant, and gated equivalents exist (`publish.publish_parquet`, `publish.publish_csv` → `_require_gate`). | When ported, call the gated `publish.*` functions instead of `parquet_export.export_all()` / `export.export_all()` (D10). |

**Additional findings (new in 9.2):**
- **N1** — rounding semantics of `mark_duplicates`. Measured on 497,047 distinct published coordinates:
  - SQLite **3.49.1** (and Python `round`) differs from PostgreSQL `round(x::numeric, 4)` on **123** values.
  - SQLite **3.40.1**, which ships in the Airflow 2.10.x images and in our image, differs on **0** values.
  - The published pair eid 313525 / 313529 (lat 13.802938 / 13.80295) is *not* marked duplicate in the friend's output. That matches 3.40.1 and PostgreSQL, but not 3.49.1.
  - **Decision:** port with `round(latitude::numeric, 4)`. The Phase 9.3 load must check that recomputed `is_duplicate` equals the SQLite values.
- **N2** — `INSERT … VALUES (NULL, …)` into SQLite `INTEGER PRIMARY KEY` silently creates a rowid. PostgreSQL rejects it. `run_traffic_index` can pass `ts = None`, so the port must skip that row (test `test_null_primary_key_is_rejected_unlike_sqlite_rowid`).
- **N3** — the README says "50,000 rows per Parquet file", but `parquet_export.ROWS_PER_FILE = 10_000`. The code is authoritative.

## 5. D1–D11 decisions

| ID | Decision | Status | Evidence | Final Choice |
|---|---|---|---|---|
| D1 | Typed timestamps vs text | **PRESERVE** (gated by the U2 pre-flight) | Every timestamp in the published, history and travel data uses exactly one format. Code guarantees `start_time` and `stop_time`. U6: Bangkok wall-clock. | `timestamp without time zone` holding Asia/Bangkok wall-clock; `timestamptz` only for our audit tables. The port formats values back to `'YYYY-MM-DD HH24:MI:SS'` wherever the code expects strings (section 14). |
| D2 | `smallint` 0/1 flags vs `boolean` | **PRESERVE** | Code compares with `=1`, `!=1`, `=0` and `IS NOT 1`. Parquet types are `int8`. `guess_province` and `normalize` always return int 0/1. | `smallint` + `CHECK (x IN (0,1))`. `NOT NULL` where the code always sets a value. |
| D3 | Raw JSON as `json` vs `jsonb` | **PRESERVE** | `json` keeps text verbatim (key order, spacing, Thai). `json.dumps(ensure_ascii=False)` can emit `\u0000`, which `jsonb` rejects; tested (`test_raw_json_is_stored_verbatim_and_validated`). | `json` for `bronze_incidents.raw_json`, `quarantine.raw_json` and `travel_times.raw_json`; `jsonb` for `checkpoints.state_json` (our own dicts). |
| D4 | Deferred FKs silver/quarantine → bronze | **PRESERVE** (now evidenced) | `migrate_v3_traffic_only.py` deletes `bronze_incidents` **before** `incidents` and `quarantine` in one transaction, which would fail with immediate FKs. Bronze 486,149 = silver + quarantine (every child has a parent). Tested both ways. | `DEFERRABLE INITIALLY DEFERRED`, `ON DELETE/UPDATE NO ACTION` (the code always deletes children explicitly; a cascade would hide a missed delete). |
| D5 | No FK on `event_type_id` | **PRESERVE** | `event_types` is refreshed from the API by `INSERT OR REPLACE`. `feed.py` maps the CSV `type` into `severity`, which becomes `event_type_id`. Code handles unknown ids (`event_type='Unknown'`, quality check `event_type_unknown`). | No FK. |
| D6 | Drop deprecated `incidents.raw_json` | **PRESERVE** (gated by the U3 pre-flight) | The code never writes it after v2, and raw lives in bronze. | Not created in PostgreSQL. The load STOPs if any non-NULL value exists. |
| D7 | Maintenance DAG scope | **MODIFY** | Verified in Airflow 3.3.2:<br>• `airflow db clean` without `--dag-ids` cleans every DAG;<br>• even *with* `--dag-ids`, the tables that have no `dag_id` column are cleaned globally (`callback`, `import_error`, `trigger`, `revoked_token`, `connection_test_request`, `partitioned_asset_key_log`, `celery_*`).<br>Our compose mounts one shared `./logs:/opt/airflow/logs`, so `delete_old_logs` would delete Namtang logs. | `airflow db clean` is removed from the DAG. Log cleanup is limited to `dag_id=bkk_traffic_*` directories. Metadata retention becomes a manual, scoped, dry-run-first ops procedure (section 12). |
| D8 | Scheduler load / Parquet cadence | **DEFER** (recommendation made) | 1,440 runs/day × 3 tasks; incidents change at most every 15 min; a full-table window runs every minute (section 13). | Recommend every 15 min after realtime, or asset-triggered. Production schedule unchanged; the user / team decides in Phase 9.4. |
| D9 | Keep the `fcntl` rate lock | **PRESERVE** | Our Airflow image is Linux (Debian bookworm). The lock file sits under the BKK data root (`checkpoints/.rate_limit.lock`), independent of `data/metadata/namtang_pipeline.lock`. | Keep, with the path under `BKK_DATA_DIR=/opt/namtang/data/bkk_traffic` (C4). |
| D10 | Ungated backfill final export | **MODIFY** | U8: the path is dormant (target_rows=0, done_reason=end_of_list); gated functions already exist. | Port it as `publish.publish_parquet()` + `publish.publish_csv()`, which run the gate. |
| D11 | Dedicated role and connection | **PRESERVE** (refined) | Runtime DDL in `storage.connect()` (`executescript(SCHEMA)`, `ALTER TABLE ADD COLUMN`) must not run under a DML-only role, so migrations own the schema. | Roles `bkk_traffic_owner` / `bkk_traffic_app` / `bkk_traffic_readonly` (migration 005); Airflow Connection `bkk_traffic_postgres` uses a login user that is a member of `bkk_traffic_app` (section 10). |

## 6. Final PostgreSQL schema

Schema `bkk_traffic`, 13 tables:
- 11 from `storage.SCHEMA`;
- `migration_history`;
- `load_history`.

It has no objects in `public` and no reference to `namtang*`.

Migrations (`database/migrations/bkk_traffic/`):

| File | Content |
|---|---|
| `001_create_schema.sql` | Schema + `migration_history` |
| `002_create_tables.sql` | 12 data/audit tables with types, NOT NULL and CHECKs |
| `003_create_indexes.sql` | 8 secondary indexes (section 8) |
| `004_create_constraints.sql` | 2 deferred FKs (idempotent `DO` block, the Namtang 004 pattern) |
| `005_create_roles_and_grants.sql` | 3 NOLOGIN roles, ownership, grants, default privileges |
| `rollback/rollback_bkk_traffic.sql` | Destructive full rollback (not numbered, never applied automatically) |

Properties of every file:
- one transaction (`BEGIN … COMMIT`);
- idempotent (`IF NOT EXISTS`, catalog checks, `ON CONFLICT DO NOTHING`);
- records itself in `bkk_traffic.migration_history`;
- sets `lock_timeout = 5s`;
- **refuses to run** unless the session sets `bkk_traffic.expected_database` to the connected database name (a guard against running in the wrong DB by accident).

How to run (Phase 9.2: test DB only):

```bash
PGOPTIONS='-c bkk_traffic.expected_database=namtang_bkk_traffic_test_db' \
  psql -v ON_ERROR_STOP=1 -d namtang_bkk_traffic_test_db -f 001_create_schema.sql   # then 002 … 005
```

**Timestamp policy:**
- Pipeline columns are `timestamp without time zone`, holding Asia/Bangkok wall-clock (U6). Bangkok has had no DST since 1920, so values are unambiguous.
- Values are not shifted by the session `TimeZone` (tested).
- "Now" is written as `now() AT TIME ZONE 'Asia/Bangkok'`, or passed from Python. Never use `localtimestamp`: the container default is UTC.
- Our own audit tables (`migration_history.applied_at`, `load_history.started_at`/`finished_at`) are `timestamptz`.

**JSON policy:**
- Raw payloads are `json` (verbatim, validated).
- Checkpoint state is `jsonb` (structured, our own data).
- `load_history.row_counts` is `jsonb`.

## 7. Table-by-table design

NN = NOT NULL. "Code" means the rule is guaranteed by the friend's write path.

| Table | Columns (type, nullability) | PK / constraints | Notes |
|---|---|---|---|
| `bronze_incidents` | `eid bigint`, `raw_json json NN`, `fetched_via text NN`, `first_fetched_at timestamp NN`, `last_fetched_at timestamp NN`, `cleaned_at timestamp` | PK `eid` | Upsert resets `cleaned_at` to NULL (code) |
| `incidents` | `eid bigint`, `nid bigint`, `title text NN` (R5), `title_en`, `comment`, `comment_en text`, `latitude`/`longitude double precision`, `severity smallint` CHECK 1–3 (R6), `event_type_id integer`, `start_time timestamp NN` (R3), `stop_time`, `createtime`, `updatedtime timestamp`, `contributor`, `source`, `status text` (`'1'`, `'0'`, `''`, NULL), `event_type text`, `traffic_relevance text NN` CHECK direct/affects/keyword (R8, G9), `is_accident smallint NN` 0/1, `is_bangkok smallint NN` 0/1, `province_guess text`, `fetched_via text NN`, `first_seen_at`, `last_seen_at timestamp NN`, `dq_flags text`, `is_duplicate smallint NN DEFAULT 0` 0/1 | PK `eid`; FK `eid` → bronze (deferred) | `raw_json` not migrated (D6) |
| `quarantine` | `eid bigint`, `reasons text NN`, `raw_json json NN`, `detected_at timestamp NN` | PK `eid`; FK → bronze (deferred) | |
| `seen_eids` | `eid bigint`, `is_bangkok smallint NN` 0/1, `seen_at timestamp NN` | PK `eid` | Upsert updates only `is_bangkok` (code) |
| `missing_eids` | `eid bigint`, `detected_at timestamp NN`, `last_try_at timestamp`, `tries integer NN DEFAULT 0` CHECK ≥ 0, `status text NN` CHECK pending/recovered/not_available | PK `eid` | |
| `traffic_index` | `ts bigint`, `ts_local timestamp NN`, `index_value double precision`, `fetched_at timestamp NN` | PK `ts` | N2: the port must skip `ts = None` |
| `traffic_index_history` | `ts bigint`, `ts_local timestamp NN`, `index_value double precision`, `source text NN` | PK `ts` | 1.41 M rows |
| `travel_times` | `route text NN`, `fetched_at timestamp NN`, 7 × `double precision`, `raw_json json` | PK `(route, fetched_at)` | |
| `event_types` | `id integer`, `name`, `name_en`, `icon text`, `severity integer` | PK `id` | No FK from incidents (D5) |
| `checkpoints` | `job text`, `state_json jsonb NN`, `updated_at timestamp NN` | PK `job` | |
| `scrape_runs` | `id bigint GENERATED BY DEFAULT AS IDENTITY`, `job text NN`, `started_at timestamp NN`, `finished_at timestamp`, `requests`, `items`, `new_items integer`, `status text NN`, `note text` | PK `id` | BY DEFAULT so historical ids load once, then `setval` (tested). No CHECK on `status`/`job`: older code versions are unknown (U1). |
| `load_history` | `load_id bigint ALWAYS IDENTITY`, `run_id text NN`, `source_db text NN`, `source_sha256 text`, `started_at timestamptz NN DEFAULT now()`, `finished_at timestamptz`, `status text NN` CHECK started/success/failed, `row_counts jsonb NN DEFAULT '{}'`, `message text` | PK `load_id` | New |
| `migration_history` | `version text`, `applied_at timestamptz NN DEFAULT now()` | PK `version` | Same as `namtang.migration_history` |

## 8. Indexes

Each index is tied to a query in the friend's code. PKs already serve:
- eid / ts lookups;
- `MAX(eid)`;
- `eid BETWEEN`;
- `ORDER BY eid` (exports, samples).

| Index | Query it serves |
|---|---|
| `ix_bronze_incidents_pending (eid) WHERE cleaned_at IS NULL` | `clean_pending`, gate G8, quality/progress backlog counts. Partial: nearly all rows are cleaned, so the index stays tiny. Replaces SQLite's full `ix_bronze_pending(cleaned_at)`. |
| `ix_incidents_start_time (start_time)` | `detect_missing_eids` (`start_time >= anchor ORDER BY eid`); quality daily counts (date ranges, after the A4 rewrite); `MAX/MIN(start_time)` in realtime/progress |
| `ix_incidents_createtime (createtime)` | Quality `MAX(createtime) WHERE createtime <= now` |
| `ix_missing_eids_status_eid (status, eid DESC)` | `recover_missing_eids` / quality sample: `status='pending' ORDER BY eid DESC LIMIT n`; status counts |
| `ix_scrape_runs_started_at (started_at)` | Quality `failed_runs_24h`, progress `runs_last_24h` (both: last 24 h) |
| `ix_traffic_index_fetched_at (fetched_at)` | Quality coverage for one day plus `MIN(fetched_at)` |
| `ix_travel_times_fetched_at_route (fetched_at, route)` | The same coverage query plus the export `ORDER BY fetched_at, route` |
| `ix_load_history_source_sha256 (source_sha256, started_at DESC)` | Loader: "already loaded this snapshot?" |

**Dropped from the 9.1 proposal, with evidence:**
- `(is_bangkok, is_accident)` and partial `(eid) WHERE is_bangkok=1 AND is_duplicate=0` are dropped:
  - `is_bangkok` is 1 in 100% of rows;
  - `is_duplicate=0` covers about 99.7% of rows;
  - `is_accident=1` is about 46%.
  The queries that would use them (exports, counts) read nearly the whole table, so a sequential scan or the PK order is cheaper. They would only add write cost.
- `scrape_runs (status, started_at)` and `(job, started_at)` are merged into one `(started_at)`: both queries filter on the last 24 h.

Not indexed: the `mark_duplicates` partition key. It is a whole-table window, so a sort is needed either way. This is revisited if the cadence stays per-minute (section 13).

## 9. Constraints

- **PKs:** as in SQLite (11 tables) plus the 2 audit tables.
- **FKs:** `incidents.eid` and `quarantine.eid` → `bronze_incidents.eid`, `DEFERRABLE INITIALLY DEFERRED`, `NO ACTION` (D4). `SET CONSTRAINTS ALL IMMEDIATE` remains available for debugging (tested).
- **CHECKs**, only where the friend's code is the only writer and the value set is closed:
  - the flags 0/1;
  - `severity` 1–3 (R6);
  - `traffic_relevance` (R8 and the `traffic_relevance()` return values; data: direct 443,110 / affects 38,591 / keyword 3,102);
  - `missing_eids.status` and `tries ≥ 0`;
  - `load_history.status`.
- **NOT NULL:** where the write path always supplies a value (R3/R5/R8, `now_str()` timestamps, `json.dumps` raw). If a historical row violates one, the Phase 9.3 load fails loudly. That is intended; it is not coerced.
- **Not enforceable declaratively:** "an eid is never in both `incidents` and `quarantine`". The code ensures it by deleting from the other table. The loader checks it with a query.

## 10. Role / privilege design

| Role | Login | Rights |
|---|---|---|
| `bkk_traffic_owner` | NOLOGIN | Owns schema `bkk_traffic` and all objects. Later migrations run as a superuser with `SET ROLE bkk_traffic_owner`. |
| `bkk_traffic_app` | NOLOGIN (group) | `USAGE` on schema; `SELECT/INSERT/UPDATE/DELETE` on data tables; `USAGE, SELECT` on sequences; **read-only** on `migration_history` and `load_history`; no DDL |
| `bkk_traffic_readonly` | NOLOGIN (group) | `USAGE` + `SELECT` only |

Further rules:
- `PUBLIC` loses all rights on the schema. Default privileges cover future owner-created tables and sequences.
- No role gets any right on `namtang`, `namtang_analysis` or `public`.
- Tested: `SELECT namtang.feed_info` and `CREATE TABLE public.zz` → InsufficientPrivilege.
- Login users and passwords are created **out of band** (secret store), e.g. `CREATE ROLE bkk_traffic_airflow LOGIN PASSWORD … IN ROLE bkk_traffic_app`, and exposed to Airflow as Connection `bkk_traffic_postgres`. Passwords never go in migrations, compose or the repo (C11 also applies to `longdo_api_key`).
- Roles are cluster-wide: creating them in the `namtang_db` cluster is a production change and needs approval (Phase 9.4).
- `mark_duplicates` creates a TEMP table in SQLite. The port uses one `UPDATE … FROM (window)` statement instead (section 14), so no TEMP privilege is needed.

## 11. Airflow 3.3 compatibility findings

How this was verified: in our running Airflow 3.3.2 image (Python 3.13.15), using import and `--help` checks only. Nothing was triggered.
- `airflow.decorators.dag/task`, `airflow.models.Variable`, `airflow.exceptions.AirflowSkipException/AirflowFailException` and `airflow.operators.bash.BashOperator` all still import, with `DeprecatedImportWarning`. Their replacements are `airflow.sdk.dag/task/Variable`, `airflow.sdk.exceptions.*` and `airflow.providers.standard.operators.bash.BashOperator`.
- `airflow.sdk.Variable.get(key, default=…)` accepts the friend's positional default.
- `@task.short_circuit` exists.
- `[scheduler] create_cron_data_intervals = False`, so cron strings use `CronTriggerTimetable`.
- `dags_are_paused_at_creation = True` (the friend's compose had false, C3).
- Pool `longdo_api` does **not** exist (only `default_pool`).
- `plugins_folder = /opt/airflow/plugins` is on `sys.path`, but our compose does not mount the friend's `plugins/bkk_traffic` there.
- Plugin dependencies are the stdlib plus `requests` and `pyarrow` (both already used by Namtang in the image).

| DAG | Airflow 3.3 compatibility | Required changes | Risk |
|---|---|---|---|
| `bkk_traffic_realtime` (*/15) | Parses and runs with deprecation warnings | Switch imports to `airflow.sdk`; create pool `longdo_api`; make `bkk_traffic` importable (mount under plugins, or package it); PostgreSQL storage port | Medium (pool missing → tasks never queue) |
| `bkk_traffic_backfill` (*/15) | Same | Same + D10 gated export; backfill is `done` (end_of_list), so each run skips almost immediately | Medium |
| `bkk_traffic_quality` (01:00) | Runs; **breaks on manual runs** | `quality_checks(data_interval_end)`: Airflow 3 manual runs can have no logical date / data interval (our own run `phase8_final_multiprocess_lock_verification` has an empty `logical_date`), so `.in_timezone()` on None raises. Use `dag_run.run_after` (or `logical_date or run_after`). Scheduled runs with `CronTriggerTimetable` give the same "yesterday" as 2.10. | Medium |
| `bkk_traffic_parquet` (every minute) | Runs | Imports; cadence (D8); signature/export SQL port (section 14) | High (scheduler and DB load, section 13) |
| `bkk_traffic_history` (02:30) | Runs | Imports; pool | Low |
| `bkk_traffic_traveltime` (*/5) | Runs; skips without key | Imports; `longdo_api_key` as a secret Variable or Connection set at runtime (C11) | Low–Medium (quota, secret handling) |
| `bkk_traffic_maintenance` (03:30) | Runs, and is **destructive** | `BashOperator` path deprecated. `airflow db clean` without `--dag-ids` cleans every DAG's metadata. `delete_old_logs` walks the shared `/opt/airflow/logs`. Airflow 3 also discourages task processes from touching the metadata DB. **Do not port as-is** (section 12). | **Critical** |

Cross-cutting items:
- XCom return values are plain dicts with no return annotations, so `multiple_outputs` is not inferred (unlike the Namtang fix).
- No top-level `Variable.get` (all calls are inside tasks).
- `catchup=False` and `max_active_runs=1` are set explicitly.

## 12. Maintenance DAG safety (C1, final decision)

Facts, verified in Airflow 3.3.2 (`airflow.utils.db_cleanup.config_dict`):
- `airflow db clean` supports `--dag-ids`, `--exclude-dag-ids`, `--tables` and `--dry-run`.
- 7 table groups have **no** `dag_id` column: `callback`, `import_error`, `trigger`, `revoked_token`, `connection_test_request`, `partitioned_asset_key_log`, `celery_taskmeta/tasksetmeta`. The DAG filter is ignored for them, so they are cleaned globally.
- Our Airflow writes every DAG's logs to the single mount `airflow/logs` → `/opt/airflow/logs`.

**Decision:**
1. **Remove** the `clean_airflow_db` task from the ported maintenance DAG. No DAG in this project may run `airflow db clean`.
2. Restrict `delete_old_logs` to an allow-list:
   - only directories `/opt/airflow/logs/dag_id=bkk_traffic_*`;
   - check with `Path.resolve()` that each path stays inside them;
   - never touch `dag_id=namtang_*`, `dag_processor*` or `scheduler*` logs;
   - keep the 7-day retention.
3. Airflow metadata retention for the BKK DAGs is a **manual, documented ops procedure** run by an operator, never automated. Always both filters, always a dry run first:

   ```bash
   airflow db clean --clean-before-timestamp '<YYYY-MM-DD>' \
     --dag-ids bkk_traffic_realtime,bkk_traffic_backfill,bkk_traffic_quality,bkk_traffic_parquet,bkk_traffic_history,bkk_traffic_traveltime,bkk_traffic_maintenance \
     --tables dag_run,task_instance,task_instance_history,task_reschedule,xcom,log \
     --dry-run          # review, then re-run without --dry-run; no --skip-archive
   ```

   Before and after, count `namtang_gtfs_pipeline` rows in `dag_run` / `task_instance`; they must not change.
4. Reducing the Parquet cadence (section 13) removes about 93% of the run, log and XCom volume that motivated the cleanup in the first place.

## 13. Parquet schedule analysis (C5)

| Question | Finding |
|---|---|
| Why every minute | The DAG docstring and README want fresh gold files right after each clean. The DAG also mops up the clean backlog. |
| What each run does, even when nothing changed | `clean_pending` (usually 0 rows); `mark_duplicates` (a window and sort over **all** ~486k silver rows); 9 gate count queries; 4 export *signature* aggregates (one sums `index_value` over 1.41 M history rows); file rewrite only when a signature changes |
| How often the inputs change | Incidents: realtime every 15 min (last run: 2 new items); recover and feed daily; backfill finished (`end_of_list`). `travel_times`: every 5 min. `traffic_index_history`: daily, plus realtime samples every 15 min. |
| Scheduler load | 1,440 DAG runs and 4,320 task instances per day for this DAG alone. The friend's own maintenance docstring estimates ~4,000 log files per day. The whole BKK set is about 5,500 TIs/day, against Namtang's 6. |
| Database load (PostgreSQL) | A full-table window UPDATE and several sequential scans every minute, plus WAL from the rows whose flag flips. All of it lands on the shared `namtang_db` instance. |
| Is PostgreSQL the source of truth? | After integration, yes for silver. Readers can query `bkk_traffic` directly (`bkk_traffic_readonly`). Parquet/CSV become snapshot deliverables (U7 still open). |
| Are minute-level exports needed? | No evidence of it: inputs change every 5–15 min at most, and no consumer is documented (U7). |

**Recommendation** (not applied; production schedule unchanged):
1. Run `clean_pending` + `mark_duplicates` at the end of the realtime / recover / feed tasks, where the data changes.
2. Publish Parquet every 15 minutes, offset after realtime (e.g. `7-59/15 * * * *`), or as an Airflow asset triggered by realtime success.
3. Keep the daily CSV in the quality DAG.

This cuts parquet runs from 1,440 to 96 per day (−93%). The decision belongs to the user or team, at the DAG port (Phase 9.4).

## 14. SQLite → PostgreSQL adaptation requirements (operation mapping)

### General adaptations (A-list)

| ID | SQLite behaviour | PostgreSQL requirement |
|---|---|---|
| A1 | `sqlite3.connect(file, timeout=120)`, `PRAGMA journal_mode=WAL`, `executescript(SCHEMA)`, `_add_missing_columns` (ALTER on every connect) | psycopg connection from Connection `bkk_traffic_postgres` (role `bkk_traffic_app`), `search_path=bkk_traffic`, `row_factory=dict_row`, `lock_timeout` / `statement_timeout`. **No DDL at runtime**: the migrations own the schema, and the app role cannot ALTER. |
| A2 | `?` placeholders; `IN (?,?,…)` built from a list | `%s` placeholders; `= ANY(%s)` with a list |
| A3 | Timestamps come back as `str` | psycopg returns `datetime`. Every place that uses them as strings must format them: checkpoint JSON (`max_start_time`, history `range`), progress JSON, quality `first[:10]` and `fromisoformat(newest)`, quarantine samples, and the Parquet/CSV string columns. Use `to_char(col, 'YYYY-MM-DD HH24:MI:SS')` in the SELECTs so the gold files stay byte-compatible (U7). |
| A4 | `substr(ts,1,10)=?`, `substr(fetched_at,12,2)*4 + substr(fetched_at,15,2)/15`, `datetime('now','localtime','-1 day')` | Half-open ranges `col >= d AND col < d + 1`; `extract(hour …)::int*4 + extract(minute …)::int/15`; `(now() AT TIME ZONE 'Asia/Bangkok') - interval '1 day'`, or pass the cutoff from Python. Never `localtimestamp` (session TZ is UTC; tested). |
| A5 | `INSERT OR IGNORE` | `ON CONFLICT (pk) DO NOTHING` |
| A6 | `INSERT OR REPLACE` (delete + insert) | `ON CONFLICT (pk) DO UPDATE SET` every column. Equivalent because no FK references `event_types` or `travel_times`. |
| A7 | TEXT affinity accepts `''` in time columns | `''` → NULL for timestamp columns only. The friend already treats both alike (quality: `IS NULL OR = ''`). Any other unparseable value raises (pre-flight, U2). |
| A8 | `json` column text read back with `json.loads` | psycopg parses `json`/`jsonb` automatically. Select `raw_json::text` where the verbatim text is copied (`clean_eids` → quarantine), and drop `json.loads` for `state_json`. |
| A9 | `ROUND(x, 4)` on REAL; `IS NOT 1` | `round(x::numeric, 4)` (equals SQLite 3.40.1 on all 497,047 published values; N1); `IS DISTINCT FROM 1` |
| A10 | `INTEGER PRIMARY KEY` + NULL → auto rowid | NOT NULL violation, so skip rows with `ts IS NULL` (N2) |
| A11 | Writers serialized by the DB file lock | Row locks. Concurrent upserts of the same eids (realtime / backfill / recover / feed) can deadlock, so: sort batches by eid, keep transactions short (the code already commits per page or batch), and retry on `DeadlockDetected` / `SerializationFailure`. |
| A12 | `cur = conn.execute(sql)` then iterating lazily over 486k–1.4M rows | Server-side (named) cursor with `itersize` for the Parquet/CSV exports, so the full result never sits in memory |
| A13 | `PRAGMA table_info(incidents)` (gate G1) | `information_schema.columns WHERE table_schema='bkk_traffic' AND table_name='incidents'` |
| A14 | `{f} IS NULL OR {f} = ''` on numeric/time fields (quality `field_null_pct`) | Type error in PostgreSQL, so use `IS NULL` for non-text columns and `IS NULL OR = ''` for text columns |
| A15 | `ORDER BY length(name) DESC` (event type matching) has no tie-breaker | Add `, id` for a deterministic first match. SQLite tie order is unspecified too; record the choice. |
| A16 | `SUM(index_value)` text in the signature (`MAX(ts) || '-' || SUM(…)`) | Works (PG ≥ 16 also allows the alias-less subquery). Float text may differ from SQLite, so expect one extra rewrite after cutover; harmless. |
| A17 | `VACUUM`, `DROP TABLE probe_count`, `migrate_*.py` | Obsolete one-off SQLite scripts; not ported |

### Per-operation mapping

| Module / function | SQLite operation | PostgreSQL operation | Adaptation |
|---|---|---|---|
| **storage.connect** | PRAGMA, `executescript`, ALTER | none (migrations) | A1 |
| **checkpoint** `get_checkpoint` | `SELECT state_json FROM checkpoints WHERE job=?` + `json.loads` | `SELECT state_json … WHERE job=%s` → dict | A8 |
| **checkpoint** `set_checkpoint` | `INSERT … ON CONFLICT(job) DO UPDATE SET state_json=excluded…, updated_at=excluded…` | Same statement; `Jsonb(state)`, `now_str()` | Tested; the file copy stays under `BKK_DATA_DIR/checkpoints` |
| **scrape_run** `log_run` | `INSERT INTO scrape_runs(job, started_at, finished_at, requests, items, new_items, status, note)` | Same | Identity `id`; tested |
| **seen_eid** `upsert_incidents` | `INSERT INTO seen_eids … ON CONFLICT(eid) DO UPDATE SET is_bangkok=excluded.is_bangkok` | Same | Tested (`seen_at` keeps its first value) |
| **seen_eid** `known_eids` | `SELECT eid FROM seen_eids WHERE eid IN (…)` | `… WHERE eid = ANY(%s)` | A2 |
| `upsert_incidents` | `UPDATE missing_eids SET status='recovered' WHERE eid=? AND status!='recovered'` | Same | Tested |
| `upsert_incidents` (out of scope) | `DELETE FROM incidents/bronze_incidents/quarantine WHERE eid=?` | Same | Deferred FK makes the order irrelevant |
| `upsert_incidents` | `SELECT 1 FROM bronze_incidents WHERE eid=?` | Same | |
| **bronze** upsert | `INSERT … ON CONFLICT(eid) DO UPDATE SET raw_json, last_fetched_at, fetched_via, cleaned_at=NULL` | Same | Tested; A11 |
| clean `load_type_names` / `load_types` | `SELECT name, name_en … ORDER BY length(name) DESC`; `SELECT id, name_en` | Same | A15 |
| clean `clean_eids` | `SELECT raw_json, fetched_via FROM bronze_incidents WHERE eid=?` | `SELECT raw_json::text, fetched_via …` | A8 |
| **quarantine** `clean_eids` | `DELETE FROM incidents WHERE eid=?`; `INSERT INTO quarantine … ON CONFLICT(eid) DO UPDATE SET reasons, raw_json` | Same | Tested (FK) |
| `clean_eids` (silver) | `DELETE FROM quarantine WHERE eid=?`; dynamic `INSERT INTO incidents(SILVER_COLS…) ON CONFLICT(eid) DO UPDATE SET …` | Same | A7 (`''` timestamps); ints for flags |
| `clean_eids` | `UPDATE bronze_incidents SET cleaned_at=? WHERE eid=?` | Same | |
| `clean_pending` / `reclean_all` | `SELECT eid … WHERE cleaned_at IS NULL` / `ORDER BY eid` | Same | Partial index |
| `mark_duplicates` | `CREATE TEMP TABLE dups` (ROW_NUMBER, ROUND) + 2 UPDATEs with `IS NOT` + count | One `WITH ranked … UPDATE … FROM ranked WHERE is_duplicate IS DISTINCT FROM dup`, plus `count(*) FILTER (WHERE dup=1)` | A9; tested, idempotent |
| scrape `refresh_event_types` | `INSERT OR REPLACE INTO event_types` | `ON CONFLICT(id) DO UPDATE` (all columns) | A6; tested |
| `_ensure_event_types` / backfill `bkk_rows` | `SELECT COUNT(*) …` | Same | |
| realtime checkpoint | `SELECT MAX(eid), MAX(start_time) FROM incidents` | Same, with `to_char` on `MAX(start_time)` | A3 |
| `run_traffic_index` | `INSERT OR IGNORE INTO traffic_index`, `INSERT OR IGNORE INTO traffic_index_history` | `ON CONFLICT(ts) DO NOTHING` (both) | A5, A10; tested |
| `detect_missing_eids` | `SELECT eid FROM incidents WHERE start_time >= ? ORDER BY eid`; `MAX(eid)`; `BETWEEN`; `INSERT OR IGNORE INTO missing_eids` (executemany) | Same / `ON CONFLICT DO NOTHING` | A5; tested |
| `recover_missing_eids` | `SELECT … status='pending' ORDER BY eid DESC LIMIT ?`; `UPDATE … tries=tries+1, last_try_at=?`; `UPDATE … status='not_available'` | Same | Tested |
| publish `gate_checks` | `PRAGMA table_info`; 9 COUNT queries | `information_schema`; same COUNTs | A13 |
| parquet / CSV export | `SELECT {cols} FROM incidents WHERE is_bangkok=1 AND is_duplicate=0 ORDER BY eid` (+ accidents, traffic_index_history, travel_times); signature aggregates | Same with `to_char` on time columns; named cursor | A3, A12, A16 |
| quality | `MAX(createtime) …`, null %, counts, `substr` day / slot queries, `datetime('now','localtime')`, samples | See A3, A4, A14; counts unchanged | A3/A4/A14 |
| history `load_year` | `executemany INSERT … ON CONFLICT(ts) DO UPDATE SET index_value, source`; COUNT; `MIN/MAX(ts_local)` | Same (or COPY into a temp table + merge for 1.4M rows); `to_char` for checkpoint | A3; tested |
| traveltime `collect` | `INSERT OR REPLACE INTO travel_times` | `ON CONFLICT(route, fetched_at) DO UPDATE` | A6; tested |
| feed `load_year` | `SELECT eid FROM bronze_incidents WHERE eid IN (…)` | `= ANY(%s)` | A2 |
| progress | COUNTs, `MIN/MAX(start_time)`, `MIN/MAX(eid)`, `GROUP BY event_type`, `SUM(requests)`, `runs_last_24h` with `datetime('now','localtime','-1 day')` | Same; `to_char`; A4 for the 24 h cutoff | A3/A4 |
| scripts `status.py` / `watch.py` | Read-only monitors | Point at PostgreSQL (readonly role) at cutover | |

**Conclusion:** the storage layer can target PostgreSQL **without changing business semantics**, provided A1–A17 are implemented. Every statement shape in this table was executed against the test schema (section 16). The port itself is Phase 9.3 work.

## 15. Test DB setup

A dedicated, throwaway container, separate from both `namtang_db` and the Namtang lifecycle test DB:

```bash
docker run -d --rm --name namtang_bkk_traffic_test_db --label purpose=bkk_traffic_phase9_2_test \
  -e POSTGRES_DB=namtang_bkk_traffic_test_db -e POSTGRES_USER=bkk_test -e POSTGRES_PASSWORD=bkk_test \
  --tmpfs /var/lib/postgresql:rw -p 127.0.0.1:5435:5432 postgres:18
```

| Property | Value |
|---|---|
| Container / database | `namtang_bkk_traffic_test_db` / `namtang_bkk_traffic_test_db` |
| Port | 127.0.0.1:**5435** (`namtang_db` 5433, `itproject_db` 5432, Namtang test DB 5434 all untouched) |
| Storage | tmpfs; `Mounts: []` (no volume); `--rm` deletes everything on stop |
| Credentials | Throwaway local `bkk_test` (not a secret, not in the repo) |
| Identity check | `SELECT current_database()` = `namtang_bkk_traffic_test_db` before any write (psql run and every pytest connection). The pytest guard also refuses dbname ≠ test DB, port 5432/5433 and hosts `namtang_db` / `itproject_db`. |

Running the tests:

```bash
BKK_TRAFFIC_TEST_DATABASE_URL="host=127.0.0.1 port=5435 dbname=namtang_bkk_traffic_test_db user=bkk_test password=bkk_test" \
  .venv/Scripts/python.exe -m pytest tests/test_bkk_traffic_migrations.py
```

Without the variable, the 36 database tests skip and the 12 static tests run.

## 16. Migration test result

**psql run** (container `psql`, `ON_ERROR_STOP=1`):
- `001` without `bkk_traffic.expected_database` was **refused** (exit 3), and the schema was not created.
- 001–005 were applied twice: all exit 0.
- Result: 5 `migration_history` rows, 13 tables, 0 tables in `public`, 3 roles.

**pytest** `tests/test_bkk_traffic_migrations.py`: **48 passed**.

| Area | Tests |
|---|---|
| Static | Files numbered 001–005; each is one guarded transaction with `lock_timeout`; each records its own version; no `namtang` / `public.` / `itproject` reference; no DROP/TRUNCATE statements; every CREATE is schema-qualified |
| Shape | 13 tables exactly; no `public` tables; the Namtang schema (14 tables, applied from its own migrations) coexists; idempotency (re-apply leaves history, object and constraint counts identical) |
| Keys / indexes | PKs per table (incl. the composite `travel_times`); 2 FKs deferrable, initially deferred, NO ACTION; 8 indexes incl. the partial predicate and `(status, eid DESC)` |
| Checks / NOT NULL | 9 incident violations; `missing_eids` status / tries; `seen_eids` flag; `load_history` status; a NULL PK is rejected (N2) |
| Deferrable behaviour | Child-first insert commits; an orphan child is accepted at INSERT and fails at COMMIT; parent-first delete (migrate_v3 order) commits; deleting only the parent fails and rolls back; `SET CONSTRAINTS ALL IMMEDIATE` fails at the statement |
| Timestamps | Column types; wall-clock unchanged across session TZ UTC / Bangkok / New York; half-open day range; `0000-00-00` rejected; `now() AT TIME ZONE 'Asia/Bangkok'` independent of session TZ |
| JSON | `raw_json` verbatim (key order, spacing, Thai, `\u0000`); the `::jsonb` cast fails on `\u0000` (proves D3); invalid JSON rejected; checkpoint `jsonb` upsert round-trip |
| Operation ports | Bronze/seen upserts; `mark_duplicates` port (13.802938 vs 13.80295 are not duplicates, NULL coordinates group together, second run updates 0); `INSERT OR IGNORE`/`REPLACE` ports; `missing_eids` flow; `scrape_runs` identity after a historical id load + `setval` |
| Roles | App: DML OK; CREATE / ALTER / write to `migration_history` / `load_history` / read `namtang.*` / `namtang_analysis.*` / create in `public` all denied. Readonly: SELECT only. No role can log in. Owned objects only in `bkk_traffic` (+ its TOAST). |
| Guard / rollback | Guard refuses a missing target and the targets `namtang_db` / `itproject_db`; an injected failure leaves no table and no history row; out-of-order 002 fails atomically; the rollback script removes only `bkk_traffic` and its roles (Namtang's 22 tables intact), is idempotent, and re-applying works afterwards |

Two failures on the first run were bugs in the tests themselves, not in the migrations, and were fixed:
- the word "truncate" in `REVOKE … TRUNCATE` tripped a too-broad check;
- TOAST tables showed up in the ownership check.

## 17. Namtang isolation verification

Production `namtang_db` was queried **read-only** (`default_transaction_read_only=on`), before and after:

| Check | Result |
|---|---|
| Schemas | `namtang`, `namtang_analysis`, `public` (**no `bkk_traffic`**) |
| Tables | `namtang` 14, `namtang_analysis` 8, `public` 0 |
| Roles `bkk*` | 0 |
| Feed identity | `20261001` / `e5d8b18ceb00bf7a4d02caa610db2fa565b49b17e872a4649a1531efbd4e5302` |
| `load_history` | 1 row (success, e5d8b18c…) |
| `migration_history` | 001–005 (unchanged) |
| Write counters (`n_tup_ins/upd/del`, both schemas) | 7,102,021 / 0 / 0 (unchanged since Phase 8) |
| Exact rows | agency 126, calendar 7, calendar_dates 105, fare_attributes 946,175, fare_rules 946,175, feed_info 1, frequencies 10,072, routes 2,069, shapes 3,873,114, stops 17,081, stop_times 159,358, trips 4,656; `namtang_analysis` total 1,143,081 |
| DAG | `namtang_gtfs_pipeline` paused = True; `NAMTANG_SCHEDULE_ENABLED=false`; newest run is still the Phase 8 verification; no lock file |
| Files | Project snapshot at start = Phase 9.1 end state (113 files, identical SHA-256). Phase 9.2 only **added** files (5 migrations, the rollback script, `tests/test_bkk_traffic_migrations.py`, this document) plus the cross-reference line in the 9.1 doc. No Namtang source, migration, DAG, data or test changed. |
| Tests | Full suite: 140 passed / 44 skipped without the BKK DSN (= the Phase 9.1 baseline of 128/8 + 12 new static + 36 skipped DB tests); 176 passed / 8 skipped with it |
| `itproject_db` | Never connected to |

## 18. Remaining unknowns

| Item | Why it is open | Resolved by |
|---|---|---|
| U1 | No SQLite file | Pre-flight on a real copy |
| U2 | Same: unpublished rows and values written after the export | Pre-flight on a real copy |
| U3 | Same | Pre-flight on a real copy |
| U4 | Same | Pre-flight on a real copy |
| U5 | Same | Pre-flight on a real copy |
| U7 Parquet/CSV consumers | Team decision | Team |
| Exact SQLite version in the friend's runtime (`apache/airflow:2.10.5-python3.11`) | Inferred 3.40.1 from the sibling 2.10.x images and the published duplicate flags; that image is not local and was not pulled | `sqlite3.sqlite_version` inside the friend's container, or the is_duplicate parity check |
| Whether the API ever returns `''` for `stop_time` / `createtime` / `updatedtime` | 0 cases in published data | Pre-flight |
| Event-type tie order (A15) | SQLite order unspecified | Parity check on `event_type` after the load |

## 19. Remaining risks

| Risk | Mitigation |
|---|---|
| Real data violates a NOT NULL / CHECK / type (U1/U2) | Pre-flight profile; the load aborts and reports. Never coerce silently. |
| Duplicate flags differ after the port (N1) | `round(::numeric,4)`; parity check of `is_duplicate` against SQLite during the load |
| Deadlocks between concurrent writers (A11) | Sorted batches, short transactions, retry |
| Scheduler and DB load on the shared stack (per-minute parquet, ~5,500 TIs/day) | Section 13 cadence change before enabling |
| Destructive maintenance (C1) | Section 12: no `db clean` in DAGs; logs allow-listed |
| Shared `namtang_db` instance: ~1.5 GB SQLite → several GB in PostgreSQL; backups/WAL/vacuum now include BKK | Size check after the test-DB load; backup plan before production |
| Secrets (`longdo_api_key`, DB login) | Out-of-band secret store; never in repo / compose |
| Airflow deprecations become removals | Port to `airflow.sdk` / providers imports at the DAG port |
| Data drift during dual-run (SQLite still live while PostgreSQL loads) | Snapshot SHA-256 in `load_history`; one-time load, then cut over or sync with a defined freeze window |

## 20. Phase 9.3 recommendation

**Phase 9.3 — "Real-data pre-flight and SQLite → PostgreSQL loader, test DB only".**

**Blocker:** a read-only copy of the real `bkk_traffic.db` from the friend, with its SHA-256. It goes outside the repo, or under a git-ignored path. Without it, U1–U5 stay open and no load may be written.

1. Verify the copy's SHA-256 and open it read-only (`mode=ro` URI). Never modify or delete the friend's SQLite or pipeline.
2. Pre-flight script (read-only) to close U1–U5:
   - `sqlite_master`;
   - `PRAGMA table_info`;
   - `typeof()` profile per column;
   - unparseable / `''` timestamps per column;
   - `incidents.raw_json` non-NULL count;
   - `probe_count`;
   - exact row counts;
   - incidents ∩ quarantine;
   - orphan children;
   - `sqlite_version()` recorded.
3. Loader `database/load/bkk_traffic/load_sqlite_to_pg.py`:
   - COPY-based, all tables, in one transaction;
   - `load_history` row with source SHA-256 and counts;
   - pre-flight abort rules;
   - target `setval` for `scrape_runs`;
   - post-load reconciliation: counts per table, `is_duplicate` parity via the ported `mark_duplicates`, sample-row equality.
   - Run it **only** against `namtang_bkk_traffic_test_db` (plus the size measurement).
4. Start the storage port (`storage` adapter implementing A1–A17), with unit tests against the test DB. Keep it in a separate directory; the friend's SQLite pipeline keeps running unchanged.
5. Stop and report before any production step. These need explicit approval in Phase 9.4 or later:
   - creating schema/roles in `namtang_db`;
   - creating the login user;
   - creating the Airflow Connection and pool;
   - porting the DAGs (paused, maintenance without `db clean`, parquet cadence decision).
