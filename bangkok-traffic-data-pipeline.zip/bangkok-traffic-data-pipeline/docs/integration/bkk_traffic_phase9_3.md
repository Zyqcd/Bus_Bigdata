# BKK Traffic Phase 9.3: Parquet → PostgreSQL and pipeline integration

> **Update 2026-10-03, Phase 9.4: production cutover done.** `bkk_traffic` exists in production `namtang_db` (loaded from a fresh gate-passed snapshot), roles / connection `bkk_traffic_postgres` / pool `longdo_api` exist, and the BKK DAGs are registered in `airflow/dags/`, **paused, schedule off**; one manual run succeeded. Details: [bkk_traffic_phase9_4.md](bkk_traffic_phase9_4.md).

**Date:** 2026-10-03.

**Status:**
- Implemented and tested **only in the isolated test database** `namtang_bkk_traffic_test_db`.
- **Stopped before production cutover.** Nothing exists in production yet: no `bkk_traffic` schema, roles, Airflow connection, pool or DAG, and no data load.

Related documents:
- Mapping: [bkk_traffic_parquet_mapping.md](bkk_traffic_parquet_mapping.md)
- Earlier phases: [bkk_traffic_database_assessment.md](bkk_traffic_database_assessment.md) (9.1), [bkk_traffic_phase9_2.md](bkk_traffic_phase9_2.md) (9.2)

## 1. Decisions that frame this phase

| Decision | Detail |
|---|---|
| **SQLite intentionally excluded** | The friend's SQLite warehouse is a legacy implementation. There is no SQLite → PostgreSQL migration and no parity proof against SQLite. The ported pipeline does not import `sqlite3` (checked by a test). The replaced `scrapping--main.zip` (2026-10-03 00:43, 6,681 entries) now *contains* `data/warehouse/bkk_traffic.db` and a `.db` snapshot. They were **not extracted and not opened**; only `data/parquet/` was taken. |
| **Parquet = source artifact for the initial load** | The friend's published, gate-passed Parquet snapshot (generated 2026-10-02 19:03, gate passed 19:02:08, all G1–G9 PASS). Read-only copy: `data/bkk_traffic/source_snapshots/friend_parquet_2026-10-02/` (219 files, 78 MB). `friend_parquet_2026-10-02.source.json` records the archive SHA-256 and each file's SHA-256. The data root is git-ignored (`data/bkk_traffic/**`). |
| **PostgreSQL = persistent source of truth** | After the initial load, the pipeline writes PostgreSQL directly (bronze → silver / quarantine). Parquet becomes a *published export* of PostgreSQL. |
| **Namtang untouched** | No Namtang code, schema, migration, DQ policy, DAG or data changed. BKK code lives in its own folders: `data/scraper/bkk_traffic/`, `database/load/load_bkk_traffic.py`, `database/migrations/bkk_traffic/`, `airflow/bkk_traffic_dags/`. |

## 2. Source datasets and row counts

| Dataset | Parts | Manifest `total_rows` | Actual Parquet rows | Target |
|---|---:|---:|---:|---|
| `incidents_bangkok` | 49 | 484,803 | 484,803 | `bkk_traffic.incidents` |
| `accidents_bangkok` | 23 | 223,715 | 223,715 | view `bkk_traffic.accidents_bangkok` (subset; **no physical copy**) |
| `traffic_index` | 142 | 1,414,001 | 1,414,001 | `bkk_traffic.traffic_index_history` |
| `travel_times` | 1 | 839 | 839 | `bkk_traffic.travel_times` |

Snapshot identity (SHA-256 over every part and manifest): `f7e90c8882ef09f5a3cb524a464694657c111cf76c8395df4a01c6d154149511`.

The actual Arrow schemas were read from all 215 parts. There is one schema per dataset, identical to the friend's `parquet_export.py`.

## 3. Target tables and migration 006

Schema `bkk_traffic` has:
- 13 tables (unchanged from Phase 9.2);
- 2 new views;
- migrations 001–006.

**`006_parquet_baseline.sql`** (additive, one transaction, idempotent, guarded):

| Change | Why |
|---|---|
| `baseline_load_id` on `incidents`, `traffic_index_history`, `travel_times` (FK → `load_history`) | Row provenance: which snapshot load wrote the row. NULL means the pipeline wrote it. |
| `incidents.bronze_eid` generated (`eid` for pipeline rows, NULL for baseline rows); the deferred bronze FK moves from `eid` to `bronze_eid` | Parquet carries no raw JSON, so baseline incidents have no bronze parent, and **no raw is invented**. Pipeline rows still require a bronze parent (tested). |
| `load_history.source_signature`, `source_manifests`; status adds `unchanged` | Snapshot identity, and audit rows for reruns |
| CHECK on coordinates (−90..90, −180..180) for `incidents` and `travel_times` | Geographic validity |
| Views `incidents_bangkok`, `accidents_bangkok` (owner `bkk_traffic_owner`, SELECT for app / readonly) | The published dataset definitions; accidents are queryable without duplicate rows |

Also changed: one condition in **004**. Re-running 004 after 006 no longer restores the replaced FK. This was found when 001–006 were re-applied; 004 had never been applied outside throwaway DBs.

## 4. Mapping and transformations

Full column tables are in [bkk_traffic_parquet_mapping.md](bkk_traffic_parquet_mapping.md).

**Transformations:**
- Timestamp strings are loaded as `timestamp` holding Bangkok wall-clock: no UTC conversion, verified unchanged under session TZ UTC.
- int8 / int16 are widened.
- `is_duplicate = 0`: this is the dataset's own `WHERE is_duplicate=0`.
- `travel_times.raw_json = NULL`: it is not exported, so it is not invented.
- `baseline_load_id` is set to the load's id.

Nothing else is transformed:
- `status` keeps `''` distinct from NULL;
- text and floats are stored exactly (checked).

## 5. Validation (before anything is written)

| Check | Rule (any violation fails the whole load; rejected rows are always 0) |
|---|---|
| Manifest | dataset name, `rows_per_file` = 10,000, gate = exactly G1–G9 all PASS, file list = files on disk, per-file rows = Parquet metadata, Σ = `total_rows` |
| Schema | Exact names, order and Arrow types |
| Row counts | manifest = Parquet = PostgreSQL |
| Keys | `eid` unique, `ts` unique, `(route, fetched_at)` unique |
| NULL rules | Required columns per the target schema; empty `title` rejected; nothing filled in |
| Timestamps | `YYYY-MM-DD HH:MM:SS` **and** an exact round trip (pyarrow `strptime` silently normalizes `2026-02-30` / `0000-00-00`; the round trip rejects them, found by a test) |
| `ts` vs `ts_local` | `ts_local` = `ts` in Asia/Bangkok (UTC+7) for every row |
| Flags | `is_accident`, `is_bangkok` ∈ {0,1}; `is_bangkok = 1` (export filter); accidents all `is_accident = 1` |
| Domains | `severity` ∈ {1,2,3} or NULL; `traffic_relevance` ∈ {direct, affects, keyword} |
| Coordinates | Numeric and within the geographic range. Rows outside a Bangkok bounding box are *reported*: **167**, all `(0.0, 0.0)` with `province_guess='bangkok(text)'`. That is the API's "no coordinates" placeholder, kept as published. |
| NULL token | A literal `\N` text value is rejected (it is the COPY NULL marker) |
| accidents subset | In the load transaction: `file EXCEPT ALL view` = 0, `view EXCEPT ALL file` = 0, counts equal |
| Reconciliation | Per column: non-null count, integer sums, float sums (rel. 1e-9), timestamp min/max, text character totals: Parquet vs PostgreSQL |
| Constraints | `SET CONSTRAINTS ALL IMMEDIATE` before commit (deferred FKs checked inside the load) |
| Business-key duplicates | `contributor, title, start_time, round(lat::numeric,4), round(lon::numeric,4)` counted and reported (real snapshot: **0**) |

## 6. Load strategy, idempotency, rollback

`database/load/load_bkk_traffic.py` (standalone; `load_namtang.py` is not touched):

```
validate snapshot (streaming, 50k-row batches; only key columns kept)
  → guard target → read state
  → same snapshot SHA + matching counts → "unchanged" (audit row; data untouched)
  → pipeline rows exist (baseline_load_id IS NULL) → refuse
  → ONE transaction: LOCK 3 tables (EXCLUSIVE) → load_history 'started' → delete previous baseline rows
      → COPY incidents / traffic_index_history / travel_times → COPY accidents to a TEMP table and compare
      → counts + fingerprints → constraints immediate → load_history 'success' → COMMIT
  → any error: ROLLBACK, then a separate 'failed' load_history row
```

**Replacement:** a newer snapshot replaces the previous baseline atomically. This is allowed only while no pipeline rows exist. After cutover, PostgreSQL is the source of truth and a Parquet import must not overwrite it.

**Target guard:**
- `--expected-database` must equal the DSN and `current_database()`;
- `namtang_db` or port 5433 needs `--production-approved`;
- `itproject_db` and host port 5432 are always refused, before connecting.

**CLI:**

```bash
BKK_TRAFFIC_DATABASE_URL="host=127.0.0.1 port=5435 dbname=namtang_bkk_traffic_test_db user=... password=..." \
  .venv/Scripts/python.exe database/load/load_bkk_traffic.py \
  --source-dir data/bkk_traffic/source_snapshots/friend_parquet_2026-10-02 \
  --expected-database namtang_bkk_traffic_test_db [--dry-run]
```

Exit codes: `0` success / unchanged / dry run, `1` failed, `2` refused by the guard.

## 7. Pipeline integration (ported, PostgreSQL storage)

```
BKK Traffic (DAG bkk_traffic_pipeline)                          Namtang (DAG namtang_gtfs_pipeline, unchanged)
scrape → clean → validate → publish → verify_postgresql         scrape → clean → validate → dq_policy_gate → analysis → load_postgresql
  │        │        │          │            │
  │  bronze/silver/quarantine in PostgreSQL bkk_traffic (source of truth)
  └ Longdo API, crawl delay 10 s                 └ manifests == PostgreSQL counts
```

- **Package `data/scraper/bkk_traffic/`.** Ported from the friend's `plugins/bkk_traffic`:
  - `config`, `client`, `geo` (unchanged, plus its boundary file);
  - `clean`, `storage`, `scrape`, `publish`, `parquet_export`;
  - new `maintenance`.
  - `clean.py` and `scrape.py` are the friend's files with asserted, minimal replacements, so business rules R1–R9, the gate G1–G9 and the scraping logic are unchanged.
- **Adaptations** (Phase 9.2 A-list, plus what this phase found):
  - **Storage:** psycopg, `search_path=bkk_traffic`, no runtime DDL, `ON CONFLICT` instead of `INSERT OR REPLACE/IGNORE`, jsonb checkpoints, `raw_json::text`, information_schema instead of PRAGMA, server-side export cursor, `to_char` timestamps (Parquet stays byte-compatible), `round(::numeric,4)` duplicates, a deterministic event-type order.
  - **Timestamp rules:** `''` → NULL; an unparseable `createtime` / `updatedtime` → quarantine `R10_bad_*` (never stored as garbage).
  - **NULL key:** a traffic-index sample without `time` is skipped instead of creating a fake key.
  - **Baseline takeover:** a pipeline upsert takes over a Parquet baseline row (`baseline_load_id = NULL`; its bronze parent now exists).
  - **Explicit Asia/Bangkok time:** found in this phase. Our Airflow containers run in **UTC** (the friend's compose set `TZ=Asia/Bangkok`), so `datetime.now()` / `fromtimestamp()` would have written `ts_local` and every "now" 7 h off. The loader validator caught it in the end-to-end test. All times now use a fixed UTC+7 (`config.bangkok_now()`); no compose change was needed.
- **DAGs (Airflow 3.3.2, `airflow.sdk`)** are **staged** in `airflow/bkk_traffic_dags/`, which the running Airflow does not parse:
  - **`bkk_traffic_pipeline`:**
    - schedule `None` unless `BKK_TRAFFIC_SCHEDULE_ENABLED=true` (then */15, Asia/Bangkok); `max_active_runs=1`; `catchup=False`; `multiple_outputs=False`;
    - API pool from `BKK_TRAFFIC_API_POOL` (default `default_pool` until the `longdo_api` pool is approved);
    - Variables `bkk_scrape_stopped`, `bkk_realtime_max_pages`;
    - connection `bkk_traffic_postgres`.
  - **`bkk_traffic_maintenance`:** deletes logs older than 7 days only inside `dag_id=bkk_traffic_*` folders (resolved paths, no symlink escape). **No `airflow db clean`.** Metadata retention stays the manual procedure of Phase 9.2 section 12: `--dag-ids bkk_traffic_* --tables dag_run,task_instance,task_instance_history,task_reschedule,xcom,log --dry-run` first, with Namtang counts checked before and after.
- **Ported but not scheduled:** `run_backfill_batch`, `detect_missing_eids`, `recover_missing_eids` (functions ported and tested; no DAG).
- **Not ported in this phase:** `quality.py` (daily report), `export.py` (CSV), `history.py` (yearly traffic-index files), `feed.py` (yearly event files), `traveltime.py` (needs the `longdo_api_key` secret), `progress.py`, and their DAGs.

## 8. Test database

A throwaway container (the Phase 9.2 setup), recreated for this phase:

```bash
docker run -d --rm --name namtang_bkk_traffic_test_db -e POSTGRES_DB=namtang_bkk_traffic_test_db \
  -e POSTGRES_USER=bkk_test -e POSTGRES_PASSWORD=bkk_test --tmpfs /var/lib/postgresql:rw \
  -p 127.0.0.1:5435:5432 postgres:18
```

| Property | Value |
|---|---|
| Storage | tmpfs, no volume, removed on stop |
| Port | 127.0.0.1:5435 (5432 `itproject_db`, 5433 `namtang_db`, 5434 Namtang test DB: untouched) |
| Guards | `current_database()` checked before writes; DSN refused by name / host / port |
| Applied | Namtang migrations 001–005 (to prove coexistence and isolation) + bkk_traffic 001–006 |
| From Airflow | Tests reach it as `host.docker.internal:5435` |

## 9. Test results (executed)

| Suite | Result |
|---|---|
| `tests/test_bkk_traffic_migrations.py` (incl. 006) | **PASS**: 50 passed. The exact file list, FK list and history count were updated for 006, just as strictly. |
| `tests/test_bkk_traffic_parquet_loader.py` | **PASS**: 53 passed (the 20 required areas + guards + real snapshot) |
| `tests/test_bkk_traffic_pipeline.py` | **PASS**: 29 passed in the Airflow image (`dag.test()` end-to-end as a `bkk_traffic_app` login user); locally 26 passed + 3 Airflow-only skips |
| Full suite, Windows, no test DSNs | **PASS**: 196 passed, 72 skipped |
| Full suite, Windows, BKK test DB | **PASS**: 257 passed, 11 skipped (Airflow-only and Namtang lifecycle DB tests) |
| Full suite in the Airflow 3.3.2 image (`airflow-cli`, throwaway SQLite metadata, Namtang test DB + BKK test DB) | **PASS**: 283 passed, 0 failed, 0 skipped |

**Real snapshot load (test DB, CLI):**

| Step | Result |
|---|---|
| dry run | `would_load` |
| load | `success`, load_id 1, 1 min 29 s |
| rerun | `unchanged` (audit row 2) |
| Production DSN | `refused`, exit 2 |

| Table / view | Source rows | Loaded | Rejected |
|---|---:|---:|---:|
| `incidents` | 484,803 | 484,803 | 0 |
| `traffic_index_history` | 1,414,001 | 1,414,001 | 0 |
| `travel_times` | 839 | 839 | 0 |
| view `accidents_bangkok` | 223,715 | 223,715 rows in the view (0 physical copies) | 0 |

Other measured results:
- **Duplicates:** PK duplicates 0; business-key duplicates 0.
- **Integrity:** `ts_local` mismatches 0; constraints not valid 0; 0 tables in `public`.
- **Pipeline tables:** bronze, quarantine, seen and checkpoints are empty, as designed.
- **Size:** test DB 487 MB.
- **Fingerprint reconciliation:** passed for every column.
- **Rollback:** failures injected after each table rolled back completely and left the previous snapshot intact, plus a `failed` audit row (tested).
- **Replacement:** atomic (tested).

## 10. Namtang isolation (verified)

**Production `namtang_db`** (read-only queries):
- schemas `namtang`, `namtang_analysis`, `public` only;
- no `bkk_traffic` schema, 0 `bkk*` roles;
- tables 14 + 8; feed `20261001` / `e5d8b18ceb00`;
- `load_history` 1 row; migrations 001–005;
- write counters 7,102,021 / 0 / 0, unchanged since Phase 8.

**Airflow:**
- only `namtang_gtfs_pipeline`, paused;
- its newest run is still the Phase 8 verification;
- pools: `default_pool` only; no `bkk` connection.

**Test DB:** the Namtang schemas (22 tables) were unchanged by every load (tested).

**Files:** no Namtang file changed (SHA-256 comparison; see the final report).

**`itproject_db`:** never connected to.

## 11. Production safety and cutover plan (NOT executed; each step needs explicit approval)

1. Back up `namtang_db` (`pg_dump`) and record the Namtang row counts and feed identity.
2. Apply `database/migrations/bkk_traffic/001–006` with `PGOPTIONS='-c bkk_traffic.expected_database=namtang_db'` (`psql -v ON_ERROR_STOP=1`).
3. Create a login user out of band (secret store): `CREATE ROLE bkk_traffic_airflow LOGIN PASSWORD … IN ROLE bkk_traffic_app`.
4. Airflow: Connection `bkk_traffic_postgres` (secret); pool `longdo_api` (1 slot) and `BKK_TRAFFIC_API_POOL=longdo_api`; Variables. Pass `BKK_TRAFFIC_*` in compose; `TZ` is not needed.
5. Optionally take a **fresh** friend Parquet snapshot just before cutover, to shorten the gap (section 12). Load it: `load_bkk_traffic.py --expected-database namtang_db --production-approved` (dry run first).
6. Reconcile the counts. Verify the Namtang tables and identity are unchanged and `itproject_db` was not touched.
7. Move `airflow/bkk_traffic_dags/*.py` into `airflow/dags/` (they arrive paused). Run `bkk_traffic_pipeline` **manually once**, then verify PostgreSQL, the Parquet output and `verify_postgresql`.
8. Enable `BKK_TRAFFIC_SCHEDULE_ENABLED` only on explicit approval (D8: */15).
9. Stop the friend's SQLite pipeline only after the team agrees. Do not delete it yet.

## 12. Remaining risks

| Risk | Status / mitigation |
|---|---|
| **Data gap**: the snapshot ends 2026-10-02 19:00 (incidents up to 18:31:54). Realtime only reads the current pages (≤ 30). | Load a fresh snapshot right before cutover; the missing-eid detect/recover functions are ported (not scheduled yet) |
| First runs: `seen_eids` is empty, so realtime reads up to `bkk_realtime_max_pages` (30 × 10 s) until pages are known | Within the 10-min task timeout; expected |
| Quality report, CSV export, yearly history / feed loads, travel times are **not ported** | Future work. `traffic_index_history` grows only from realtime samples until `history.py` is ported. |
| 167 incidents with `(0,0)` coordinates (a source placeholder) | Kept as published; consumers should treat `(0,0)` as missing |
| `namtang_db` grows by ~0.5 GB (test DB 487 MB) | Backup / retention planning before cutover |
| Shared Airflow metadata / logs | No `db clean` anywhere; allow-listed log cleanup; manual filtered metadata procedure |
| Concurrency | One writer DAG (`max_active_runs=1`); backfill / recover not scheduled alongside it. Revisit (sorted batches, retries) if they are scheduled. |
| Event-type tie order (`ORDER BY length(name) DESC, id`) may classify a few title-only events differently from SQLite's unspecified order | Accepted (deterministic now) |
| U7 (consumers of Parquet/CSV) still open | Parquet kept byte-compatible; CSV not ported |
