# BKK Traffic: quality pipeline mapping (Phase 9.7)

**Purpose:** document the friend's `quality.py` and its daily DAG, and their PostgreSQL port, **before** implementation.

**Port:**
- `data/scraper/bkk_traffic/quality.py` (new);
- `data/scraper/bkk_traffic/scrape.py` (`refresh_event_types`, `detect_missing_eids`, `recover_missing_eids`);
- `data/scraper/bkk_traffic/client.py` (optional deadline);
- DAG `airflow/dags/bkk_traffic_quality.py`.

**Storage:** PostgreSQL `bkk_traffic` only. No migration, no new table, no SQLite.

## 1. Original behaviour

### 1.1 DAG `bkk_traffic_quality` (friend, Airflow 2.10, daily 01:00)

```
refresh_event_types (pool longdo_api) → detect_missing_eids → recover_missing_eids (pool longdo_api, 150 eids, 35 min)
   → quality_checks(data_interval_end) → export_csv (all_done)
quality_checks → gate (FAIL if overall == FAIL)
```

- `refresh_event_types` and `recover_missing_eids` are skipped when Variable `bkk_scrape_stopped=true`.
- `quality_checks` reports on *yesterday* = `data_interval_end` (Bangkok) − 1 day.
- **`export_csv` is out of scope (CSV export is not part of Phase 9.7).**

### 1.2 `quality.py` (friend, SQLite)

`run_quality_checks(report_day)` writes `data/quality/dt=<day>/` containing `report.json`, `report.md`, `quarantine_rows.csv`, `missing_days.csv` and `missing_eids_pending.csv`.

| # | Check | Rule (OK / WARN / FAIL) | SQLite specifics |
|---|---|---|---|
| 0 | `has_data` | FAIL if `incidents` is empty (report ends) | — |
| 1 | `realtime_last_success_hours` | < 1 h OK, < 3 h WARN, else FAIL (from checkpoint `realtime.last_success`) | `datetime.now()` (container TZ) |
| 1 | `newest_event_age_hours` | MAX(createtime) ≤ now: < 3 h OK, < 12 h WARN, else FAIL | text compare with `now` string |
| 2 | `field_null_pct` | % NULL or `''` for title, latitude, longitude, start_time, stop_time, severity, event_type, + `event_type_unknown`; worst of lat / lon / start_time < 1 % OK, < 5 % WARN, else FAIL | `{f} IS NULL OR {f}=''` on numeric / time columns |
| 3 | `non_bangkok_rows` | 0 OK, else FAIL | — |
| 3 | `bangkok_by_text_only` | `province_guess='bangkok(text)'` < 5 % of total OK, else WARN | — |
| 3 | `clean_rule_flags` | OK; counts of each `dq_flags` name | — |
| 3 | `quarantine_rows` | 0 OK, < 5 % WARN, else FAIL; counts per reason | — |
| 3 | `duplicate_reports_removed` | OK; count `is_duplicate=1` | — |
| 3 | `rows_by_source` | OK; count per `fetched_via` | — |
| 3 | `bronze_not_cleaned` | < 1000 OK, else WARN | — |
| 4 | `days_without_incidents` | days with 0 incidents in (coverage start, yesterday]: 0 OK, else FAIL | `substr(start_time,1,10)`, `date('now','localtime','+1 day')` |
| 4 | `days_abnormally_low` | days with 0 < n < 30 % of the median: none OK, else WARN | — |
| 5 | `traffic_index_coverage_pct`, `travel_times_coverage_pct` | 15-min slots (96 / day) with ≥ 1 sample on the report day, counted from the first sample if collection started that day: ≥ 95 % OK, ≥ 80 % WARN, else FAIL; "not started yet" → OK | `substr(fetched_at,12,2)*4 + substr(fetched_at,15,2)/15` |
| 5.5 | `traffic_index_5min_incomplete_days` | days (except the last) with < 90 % of 288 points: ≤ 2 % of days OK, else WARN | `substr(ts_local,1,10)` |
| 6 | `missing_eids_pending` | pending < 500 OK, else WARN | — |
| 6.5 | `accident_share_vs_7d`, `volume_vs_7d` | report day vs the 7 previous days: share within 0.5–2× OK; volume within 0.3–5× OK; else WARN (only when both days have data) | `substr(start_time,1,10) IN (…)` |
| 6.6 | `parquet_files_valid` | each published dataset: manifest present, schema equal, ≤ 10,000 rows per file, Σ rows = manifest → 0 problems OK, else FAIL | — |
| 7 | `failed_runs_24h` | `scrape_runs` failed in the last 24 h: 0 OK, < 5 WARN, else FAIL | `datetime('now','localtime','-1 day')` |

The overall result is the worst check status.

### 1.3 Missing incidents and event types (friend `scrape.py`, already ported in Phase 9.3)

**`refresh_event_types`**
- Real response: a JSON list of 18 `{id:int, name, name_en, icon, severity}`, no duplicates.
- Written with `INSERT OR REPLACE`, without validation.
- The PostgreSQL pipeline calls it only when `event_types` is empty (`_ensure_event_types`), so after cutover **it is never refreshed** (the gap the review found).

**`detect_missing_eids`**
- Floor = the 1st-percentile eid of incidents whose `start_time ≥` backfill checkpoint `anchor_time`.
- Every eid from that floor to `MAX(seen_eids)` that is neither in `seen_eids` nor in `missing_eids` is added as `pending`. There is no cap.
- **It requires a `backfill` checkpoint.** Production has none (checkpoints: realtime, traffic_index_history, traveltime_usage), and the friend's own final checkpoint has `anchor_time = None`.

**`recover_missing_eids(limit=150, max_seconds=35*60)`**
- Takes pending eids newest first and calls `event.json?eid=` via `LongdoClient`, which shares the rate lock: ≥ 10 s between requests, and **4 retries with 30/60/90/120 s backoff, 180 s timeout**.
- The time limit is checked **only between eids**, so one eid can take more than 5 minutes.
- On an item: `_store` (bronze → clean) and the eid is marked recovered. On an empty response: `not_available`. On an error: `tries+1`, the eid stays pending.

## 2. PostgreSQL port

### 2.1 SQL adaptations (from Phase 9.2 A-list)

| SQLite | PostgreSQL |
|---|---|
| `datetime.now()` / `date.today()` | `config.bangkok_now()` (explicit UTC+7; never the container TZ) |
| `{f} IS NULL OR {f} = ''` on every key field (A14) | `IS NULL OR = ''` for text fields (title, event_type); `IS NULL` for numeric / time fields (latitude, longitude, start_time, stop_time, severity) |
| `substr(start_time,1,10) = ?` / `IN (…)` (A4) | half-open ranges: `start_time >= day AND start_time < day + 1`; 7 previous days: `>= day - 7 AND < day` |
| `date('now','localtime','+1 day')` | `start_time < (Bangkok today + 1 day)` as a parameter |
| `substr(fetched_at,12,2)*4 + substr(fetched_at,15,2)/15` | `extract(hour FROM fetched_at)::int * 4 + extract(minute FROM fetched_at)::int / 15` with `fetched_at` in `[day, day + 1)` |
| `substr(ts_local,1,10)` grouping | `ts_local::date` grouping |
| `datetime('now','localtime','-1 day')` | `started_at >= (Bangkok now − 1 day)` as a parameter |
| `MIN(fetched_at)`, `MAX(createtime)` returned as text (A3) | `to_char(…, 'YYYY-MM-DD HH24:MI:SS')` |
| `dict(row)` for samples (A3) | explicit columns, `detected_at` via `to_char` |
| `?` placeholders | `%s` |

Check names, thresholds, statuses, the report files and their columns are **unchanged**. The output folder is `data/bkk_traffic/quality/dt=<day>/` (`config.QUALITY_DIR`).

### 2.2 Intentional differences

| # | Friend | Port | Why |
|---|---|---|---|
| Q1 | Report day from `data_interval_end` | From `dag_run.run_after` (Asia/Bangkok) − 1 day | Airflow 3 manual runs can have no data interval (Phase 9.2) |
| Q2 | Coverage start for the missing-days check = backfill `anchor_time` or `last_seen` | Backfill `anchor_time` if present, else **2015-12-29**: the friend's last reported coverage window (`dt=2026-10-01` report: "2015-12-30..2026-10-01"). Configurable (`coverage_start`). | Production has no backfill checkpoint; `last_seen` would silently disable the check |
| Q3 | `export_csv` task | Not ported | CSV export is out of scope (U7 open) |
| E1 | Event types written unvalidated, refreshed only when empty | **Daily** task `refresh_event_types`. The response must be a non-empty list of objects with an integer `id`, unique ids. **One transaction**; upsert that rewrites only changed rows; types never deleted. Invalid → fail, no change. | Correctness; fixes the stale-types gap |
| D1 | Floor = percentile over the backfill window | **Coverage floor**: checkpoint `missing_eid_detection.floor_eid`. Initialised once to the highest eid still owned by the Parquet baseline (`baseline_load_id IS NOT NULL`); production now 978,543. Window `(floor, MAX(seen_eids)]`. | The baseline came from the friend's pipeline (their `seen_eids` are not ours). Our realtime pipeline is responsible only for eids above it. The friend's anchor rule needs a backfill, which is not part of this architecture. |
| D2 | Excludes `seen_eids` and `missing_eids` | Also excludes eids already in `incidents`, `bronze_incidents`, `quarantine` | They are not missing |
| D3 | No cap | At most **2,000** new pending eids per run (the highest first); the rest are reported as `truncated` and found by later runs | Bounded writes and recovery backlog |
| R1 | 150 eids, 35 min, between-eid time check only | **30 eids, 360 s** (Airflow Variables `bkk_recover_per_run`, `bkk_recover_max_seconds`; defaults 30 / 360). A **deadline-aware client**: before every request, crawl-delay wait and retry backoff the remaining time is checked, and each request's timeout is capped at the remaining time; when it is exhausted, recovery stops. | Enforce the ~6 min bound cleanly while holding the 1-slot pool |
| R2 | Errors: `tries+1`, logged with `str(err)` | Same state change; logs carry only the exception type and status. Result: `attempted, recovered, recovered_bangkok, not_available, failed, remaining_pending, stop_reason (done / limit / time)` in `scrape_runs` (job `recover`) and the task result | Auditability, no URL / secret text in logs |
| R3 | An item whose `eid` differs from the requested one is stored anyway | Treated as malformed: `failed`, eid stays pending, nothing stored | Correctness |
| T1 | The task-level time check was the only bound | Airflow `execution_timeout` = 8 min on `recover_missing_eids` as a last-resort backstop above the 6 min deadline | Defence in depth |

`LongdoClient` keeps its exact behaviour when no deadline is set, so the main pipeline is unchanged.

## 3. Airflow task mapping (`bkk_traffic_quality`, Airflow 3.3.2)

| Task | Pool | What it does |
|---|---|---|
| `refresh_event_types` | `longdo_api` | daily event-type refresh (skipped when `bkk_scrape_stopped`) |
| `detect_missing_eids` | default | coverage-floor detection (DB only) |
| `recover_missing_eids` | `longdo_api` | ≤ 30 eids, ≤ 360 s, one request at a time through the shared rate lock (skipped when `bkk_scrape_stopped`) |
| `quality_checks` | default | report for `run_after` (Bangkok) − 1 day |
| `gate` | default | fails the run if overall = FAIL |

- **Order:** `refresh_event_types → detect_missing_eids → recover_missing_eids → quality_checks → gate`.
- **Settings:** paused at creation; schedule `None` unless `BKK_TRAFFIC_SCHEDULE_ENABLED=true` (then 01:00 Asia/Bangkok, as the friend's); `max_active_runs=1`; `catchup=False`; `multiple_outputs=False`.
- **Independent** of `bkk_traffic_pipeline`. The 1-slot pool serializes their Longdo requests.

## 4. Tables used

| Access | Tables |
|---|---|
| Read | `incidents`, `quarantine`, `bronze_incidents`, `seen_eids`, `missing_eids`, `traffic_index`, `traffic_index_history`, `travel_times`, `scrape_runs`, `checkpoints` |
| Write | `event_types` (upsert); `missing_eids` (insert pending, status / tries updates); recovered items via the existing `_store` path (`seen_eids`, `bronze_incidents`, `incidents` / `quarantine`); `scrape_runs` (`recover` runs); `checkpoints` (`missing_eid_detection`) |
| Never | `namtang*`, `itproject_db` |

The app role `bkk_traffic_app` already has the needed DML.

## 5. Error handling and security

| Area | Behaviour |
|---|---|
| Event types | API failure (after client retries) → task fails, no change. Malformed → fail before any write. |
| Detection | DB only; capped |
| Recovery | Per-eid errors are counted and the eid stays pending. A deadline stop is reported. Unexpected errors fail the task after logging the run. |
| Quality | Empty tables handled (`has_data` FAIL ends the report; other empty sets give 0 / "not started"). The gate fails on FAIL. |
| Credentials | traffic.longdo.com `event.json` / `geteventtype` need **no API key**. The quality DAG never reads `longdo_api_key`, and messages never contain URLs or exception text with query strings. |
