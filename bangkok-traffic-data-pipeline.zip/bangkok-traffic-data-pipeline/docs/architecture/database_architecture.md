# Database architecture

> **Current state (2026-10-03, final):** BKK Traffic is **in production** in PostgreSQL schema `bkk_traffic` (`namtang_db`, the only store and source of truth; no SQLite dependency). `bkk_traffic_pipeline` runs every 15 min and `bkk_traffic_maintenance` at 03:30 (Asia/Bangkok, Airflow 3.3.2, pool `longdo_api` = 1 slot); `bkk_traffic_quality` (01:00) is intentionally paused until the first full production day. The Longdo API key is an external secret (encrypted Airflow Variable `longdo_api_key`), never committed. Statements below that say "planned", "not integrated", "paused" or "schedule off" for BKK are point-in-time history. See [README section 12](../../README.md#12-bkk-traffic-pipeline-production).

**As of:** 2026-10-03 (verified with read-only queries). Status labels: **CURRENT**, **FUTURE / NOT CREATED YET**.

## 1. Current production (CURRENT)

```
PostgreSQL 18 · container namtang_db · host port 5433 · volume bangkok-traffic-project_namtang_pgdata
namtang_db
│
├── namtang            12 GTFS source tables + migration_history + load_history   (14 tables)
│                      migrations 001–005 applied; feed 20261001 (SHA e5d8b18c…5302); load_history 1 row
├── namtang_analysis   8 derived analysis tables
└── public             no tables
```

| Item | Value |
|---|---|
| Migrations | `database/migrations/namtang/001_create_schema` … `005_create_load_history` (recorded in `namtang.migration_history`) |
| Loader | `database/load/load_namtang.py`: COPY, latest-snapshot replace in one transaction, `load_history` row |
| Roles | `postgres` (local development credentials in the root `docker-compose.yml`) |
| Clients | `run_pipeline.py` / `load_namtang.py` (`DATABASE_URL`, host port 5433); Airflow scheduler via Connection `namtang_postgres` (`namtang_db:5432` on the Docker network) |
| Row counts | 5,958,939 source rows across 12 tables; 1,143,081 analysis rows (README section 7) |

## 2. Future (FUTURE / NOT CREATED YET)

```
namtang_db
│
├── namtang
├── namtang_analysis
├── public
└── bkk_traffic   ← NOT CREATED YET
      13 tables (designed): bronze_incidents, incidents, quarantine, seen_eids, missing_eids,
      traffic_index, traffic_index_history, travel_times, event_types, checkpoints,
      scrape_runs, load_history, migration_history
      roles (designed, NOT CREATED): bkk_traffic_owner, bkk_traffic_app, bkk_traffic_readonly
```

| Artifact | Status |
|---|---|
| Design (types, constraints, indexes, roles, timestamp / JSON policy) | Final for now: [bkk_traffic_phase9_2.md](../integration/bkk_traffic_phase9_2.md) sections 6–10 |
| Migrations `database/migrations/bkk_traffic/001–005` + `rollback/rollback_bkk_traffic.sql` | Exist in the repo; **tested only** on throwaway `namtang_bkk_traffic_test_db` (48 tests passed); **never applied** to `namtang_db` |
| Migration guard | Each file refuses to run unless the session sets `bkk_traffic.expected_database` = the connected database |
| Applying to production | Requires explicit approval. Phase 9.3 added `006_parquet_baseline` (provenance columns, generated `bronze_eid` FK, views `incidents_bangkok` / `accidents_bangkok`) and loaded the real Parquet snapshot **into the test DB only**. |

## 3. Why the schemas are separated

| Reason | Effect |
|---|---|
| **Ownership** | Each source pipeline owns its schema(s), migrations and loader. `namtang` / `namtang_analysis` belong to Namtang; `bkk_traffic` will belong to the BKK Traffic pipeline. |
| **Different data models** | Namtang is a versioned latest-snapshot of a static feed (replace per SHA). BKK Traffic is a continuously appended event store (upserts every few minutes). Mixing them would couple incompatible write patterns. |
| **Independent lifecycle** | Each schema has its own `migration_history`, so migrations are numbered and applied per source; a BKK change never renumbers or blocks Namtang migrations. |
| **Least privilege** | Planned `bkk_traffic_*` roles get rights on `bkk_traffic` only; tested: no access to `namtang*` or `public`. |
| **Safe rollback** | `bkk_traffic` can be dropped (`rollback_bkk_traffic.sql`) without touching Namtang; tested in the throwaway DB, where Namtang's 22 tables stayed intact. |
| **Source vs derived separation** | `namtang` (source records) and `namtang_analysis` (derived) are already split for the same reason inside Namtang. |

## 4. Dependency rules

1. **Namtang must not depend on BKK Traffic tables.** There are no joins, views, FKs or loader reads across the schemas, and the Namtang migrations stay unchanged.
2. **BKK Traffic must not modify Namtang schemas.** The BKK migrations contain no `namtang` reference (checked by a static test), and the planned app role has no privilege there.
3. **Cross-source analysis** (e.g. incidents near bus routes), if ever needed, belongs to a shared read-only analysis / backend layer that reads both schemas. It must not be built inside either pipeline. This is **not planned yet**.
4. **`itproject_db` is a completely separate database** (container `itproject_db`, port **5432**, volumes `it_project_pgdata*`, network `it_project_default`). It must never be connected to, queried, migrated or used for tests.

## 5. Other databases in the environment

| Database | Purpose | Status |
|---|---|---|
| `airflow` on `airflow-metadata-db` (postgres:16, not published) | Airflow metadata (shared by all DAGs) | **CURRENT** |
| `namtang_test_db` (127.0.0.1:5434, tmpfs) | Namtang Phase 7/8 lifecycle tests | **TEST**, stopped |
| `namtang_bkk_traffic_test_db` (127.0.0.1:5435, tmpfs, `--rm`) | BKK migration, loader and pipeline tests | **TEMPORARY** (running at the end of Phase 9.3; discarded on stop) |

Details: [environment_boundaries.md](environment_boundaries.md).
