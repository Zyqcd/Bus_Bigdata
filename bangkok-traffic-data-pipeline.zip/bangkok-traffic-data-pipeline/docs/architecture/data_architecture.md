# Data architecture

> **Current state (2026-10-03, final):** BKK Traffic is **in production** in PostgreSQL schema `bkk_traffic` (`namtang_db`, the only store and source of truth; no SQLite dependency). `bkk_traffic_pipeline` runs every 15 min and `bkk_traffic_maintenance` at 03:30 (Asia/Bangkok, Airflow 3.3.2, pool `longdo_api` = 1 slot); `bkk_traffic_quality` (01:00) is intentionally paused until the first full production day. The Longdo API key is an external secret (encrypted Airflow Variable `longdo_api_key`), never committed. Statements below that say "planned", "not integrated", "paused" or "schedule off" for BKK are point-in-time history. See [README section 12](../../README.md#12-bkk-traffic-pipeline-production).

> **Update 2026-10-03, Phase 9.3:** the BKK Traffic Parquet → PostgreSQL loader, migration 006 and the ported pipeline exist and are tested **on the throwaway test DB only**; production cutover has not happened. Details: [bkk_traffic_phase9_3.md](../integration/bkk_traffic_phase9_3.md). SQLite is no longer a dependency or a blocker.

**As of:** 2026-10-03. Status labels: **CURRENT**, **PLANNED / FUTURE / NOT IMPLEMENTED**, **ON HOLD**. See [project_architecture.md](project_architecture.md).

## 1. Ownership summary

| Dataset | Owner (pipeline) | Storage | Status |
|---|---|---|---|
| Namtang static GTFS: raw, clean, analysis | Namtang pipeline (this repository) | `data/raw|clean|analysis/namtang/` + PostgreSQL `namtang`, `namtang_analysis` | **CURRENT** |
| Namtang run metadata, validation reports, DQ policies | Namtang pipeline + human reviewers (policies) | `data/metadata/` | **CURRENT** |
| Longdo incidents, traffic index, travel times | The friend's BKK Traffic pipeline (friend's repository and deployment) | Friend's SQLite `data/warehouse/bkk_traffic.db` + friend's Parquet/CSV | **NOT INTEGRATED** with this repository |
| `bkk_traffic` PostgreSQL schema | Future BKK Traffic pipeline | `namtang_db` → `bkk_traffic` | **FUTURE / NOT IMPLEMENTED** |

Each source owns its own folders, schema(s), DQ rules and DAG(s). Shared code is limited to generic infrastructure (README section 10, "Integrating another source later").

## 2. Namtang data flow (CURRENT)

```
OTP static GTFS ZIP (single HTTPS download per run; unchanged SHA-256 → nothing stored)
    │
    ▼
data/raw/namtang/<YYYY-MM-DD>[/HHMMSS]/gtfs.zip + manifest.json      RAW (immutable, read-only)
    │  clean_gtfs.py (100k-row chunks, hash re-checked against manifest)
    ▼
data/clean/namtang/<feed>/<table>.parquet, rejected/, metadata.json, _SUCCESS   CLEAN (source records, typed)
    │  validate_gtfs.py → data/metadata/validation_<feed>.json/.md (read-only report)
    │  policy gate: approved data_quality_policy_<feed>.json for this exact SHA
    ▼
data/analysis/namtang/<feed>/<dataset>_analysis.parquet, metadata.json, _SUCCESS   ANALYSIS (derived)
    │  load_namtang.py (COPY, one transaction, latest snapshot)
    ▼
PostgreSQL namtang_db
    ├── namtang            12 source tables + migration_history + load_history
    └── namtang_analysis   8 derived tables
```

| Layer | Meaning | Rules |
|---|---|---|
| Raw | Original bytes of the published ZIP | Immutable; SHA-256 is the feed identity; never edited or deleted automatically |
| Clean | Same records, typed and normalized (`source_row` lineage, `feed_sha256`, `feed_version` on every row) | clean + rejected = raw (validated); never repaired |
| Validation | Read-only PASS / WARNING / ERROR report | Never modifies data |
| DQ policy | Human-approved decision per finding (DQ-001…DQ-012) | Bound to the feed SHA; `approval.approved` must be true; never auto-generated |
| Analysis | Derived counts, segments, speeds, estimates; DQ flag columns | No rows excluded; derived counts are never presented as source counts |
| PostgreSQL | Latest snapshot of clean + analysis | One feed at a time; unchanged SHA → no write; replace → one transaction + `load_history` row |

Current snapshots on disk:
- `2026-10-01` (feed 20260930);
- `2026-10-02` (feed 20261001, which is in production).

Policies: `data_quality_policy_2026-10-01.json` and `2026-10-02.json` are approved; the `2026-10-02.DRAFT.*` files are kept as history.

## 3. BKK Traffic data flow

### 3.1 Today (CURRENT): not integrated

```
Longdo Traffic API / yearly files
    │  friend's Airflow 2.10.5 (friend's deployment)
    ▼
friend SQLite data/warehouse/bkk_traffic.db   (bronze → silver / quarantine, ~1.5 GB, not in any repo)
    │
    ▼
friend Parquet / CSV (friend's repository)

        ✗  CURRENTLY NOT INTEGRATED with this repository or with namtang_db
```

What this repository holds:
- a read-only copy of the friend's **source code** (`scrapping--main.zip`, used for the assessment);
- design documents;
- the untested-in-production migrations.

*(Superseded by Phase 9.3.)* The repository now holds a read-only copy of the friend's published Parquet snapshot (`data/bkk_traffic/source_snapshots/`, git-ignored). It is loaded into PostgreSQL **on the test DB only**; SQLite is excluded.

### 3.2 Proposed future flow (FUTURE / NOT IMPLEMENTED)

```
friend scraper (Longdo API)                                   ── FUTURE / NOT IMPLEMENTED ──
    ▼
bkk_traffic pipeline (ported storage layer, Airflow 3.3.2 DAGs, paused until approved)
    ├── raw / checkpoints / exports under a separate data root (planned: data/bkk_traffic/)
    ▼
PostgreSQL namtang_db
    └── bkk_traffic   bronze_incidents → incidents / quarantine, seen_eids, missing_eids,
                      traffic_index, traffic_index_history, travel_times, event_types,
                      checkpoints, scrape_runs, load_history, migration_history
    ▼
Parquet / CSV exports (kept byte-compatible while U7 "who consumes them" is open)
```

One-time history transfer: *originally planned from SQLite; replaced in Phase 9.3 by the Parquet loader (section 5)*:

```
real bkk_traffic.db (read-only copy + SHA-256) → pre-flight profile → loader (COPY, one transaction,
reconciliation, is_duplicate parity) → namtang_bkk_traffic_test_db ONLY
```

A production load is a later phase that needs explicit approval.

Designed rules for the future flow (Phase 9.2 sections 6–9):
- Timestamps are Asia/Bangkok wall-clock (`timestamp without time zone`).
- Raw JSON stays verbatim (`json`).
- Silver and quarantine rows require a bronze parent (deferred FKs).
- Duplicates use `round(x::numeric, 4)`, which matches the friend's SQLite 3.40.1 behaviour.
- `incidents.raw_json` and `probe_count` are not migrated.
- The load aborts instead of coercing values that don't fit.

## 4. Boundaries between the two sources

| Rule | Status |
|---|---|
| Namtang tables never reference or read BKK tables | **CURRENT** (no BKK tables exist) and a design rule for the future |
| BKK code never writes `data/raw|clean|analysis/namtang` or the `namtang*` schemas | Design rule (enforced by roles in migration 005 once applied) |
| Separate data roots: Namtang `data/*/namtang/`, BKK `data/bkk_traffic/` (`BKK_DATA_DIR`, git-ignored) | Both **CURRENT** (BKK holds the source snapshot; pipeline output only in tests so far) |
| Separate locks: `data/metadata/namtang_pipeline.lock` vs the friend's `checkpoints/.rate_limit.lock` | Namtang **CURRENT**; BKK **PLANNED** |
| Datasets are never committed (raw, clean, analysis, and the future BKK data root) | Namtang **CURRENT** (`.gitignore`); BKK ignore rule **PLANNED** (C8) |

## 5. Phase 9.3 flow (implemented, test DB only)

```
friend Parquet snapshot (gate-passed) ─► load_bkk_traffic.py (validate, COPY, one transaction, reconcile)
    ─► bkk_traffic.incidents / traffic_index_history / travel_times  (accidents = view, no copy)
Longdo API ─► bkk_traffic_pipeline: scrape ─► bronze ─► clean ─► silver/quarantine ─► gate ─► Parquet ─► verify
```

PostgreSQL is the source of truth after the initial load. Production cutover requires approval ([bkk_traffic_phase9_3.md](../integration/bkk_traffic_phase9_3.md)).
