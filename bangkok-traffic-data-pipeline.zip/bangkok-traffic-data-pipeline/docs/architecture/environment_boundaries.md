# Environment boundaries

> **Current state (2026-10-03, final):** BKK Traffic is **in production** in PostgreSQL schema `bkk_traffic` (`namtang_db`, the only store and source of truth; no SQLite dependency). `bkk_traffic_pipeline` runs every 15 min and `bkk_traffic_maintenance` at 03:30 (Asia/Bangkok, Airflow 3.3.2, pool `longdo_api` = 1 slot); `bkk_traffic_quality` (01:00) is intentionally paused until the first full production day. The Longdo API key is an external secret (encrypted Airflow Variable `longdo_api_key`), never committed. Statements below that say "planned", "not integrated", "paused" or "schedule off" for BKK are point-in-time history. See [README section 12](../../README.md#12-bkk-traffic-pipeline-production).

**As of:** 2026-10-03, from `docker ps -a`, `docker volume ls` and `docker network ls`.

| Class | Meaning |
|---|---|
| **PRODUCTION** | Holds real project data, or runs the real pipeline |
| **TEST** | Reusable, isolated test resource |
| **TEMPORARY** | Created for one task, then destroyed |
| **NOT YET CREATED** | Designed or named, does not exist |
| **NEVER TOUCH** | Belongs to another project |

## 1. Resource inventory

| Resource | Class | Location / port | Storage | Current state | Notes |
|---|---|---|---|---|---|
| `namtang_db` (container) / database `namtang_db` | **PRODUCTION** | Host **5433** → 5432; root `docker-compose.yml` | Volume `bangkok-traffic-project_namtang_pgdata` | Running | Schemas `namtang`, `namtang_analysis`. Writes only by the Namtang loader. |
| `itproject_db` | **NEVER TOUCH** | Host **5432** | Volumes `it_project_pgdata`, `it_project_pgdata18`; network `it_project_default` | Running (not ours) | Never connect, query, migrate or test against it |
| Airflow stack `namtang-airflow` (apiserver, scheduler, dag-processor, init) | **PRODUCTION** (orchestration, local) | UI `127.0.0.1:8080` | Repo mounted at `/opt/namtang`; logs in `airflow/logs` | Running; DAG paused, schedule off | Scheduler joins `bangkok-traffic-project_default` to reach `namtang_db` |
| `airflow-metadata-db` | **PRODUCTION** (Airflow internal) | Not published | Volume `namtang-airflow_airflow_metadata_pgdata` | Running | Shared by every DAG in this Airflow; never globally cleaned |
| `data/raw|clean|analysis/namtang`, `data/metadata` | **PRODUCTION** data | Repository | Local disk (datasets git-ignored) | Present | Raw is immutable |
| `namtang-test-db` / `namtang_test_db` | **TEST** | `127.0.0.1:5434`; profiles `cli` / `testdb` in `airflow/docker-compose.yml` | tmpfs (discarded on stop) | Stopped (exited) | Namtang Phase 7/8 tests via `NAMTANG_TEST_DATABASE_URL`; refuses `namtang_db` / port 5433 |
| `airflow-cli` | **TEST** | Profile `cli` | Throwaway SQLite metadata in `/tmp/airflow-test` | Run on demand (`--rm`) | Unsets `AIRFLOW_CONN_NAMTANG_POSTGRES`, so it cannot reach production |
| pytest temporary directories | **TEST** | OS temp | Temporary | Per run | Pipeline roots for lifecycle tests |
| `namtang_bkk_traffic_test_db` | **TEMPORARY** | `127.0.0.1:5435` **when created** | tmpfs, **no persistent volume**, `docker run --rm` | Running at the end of Phase 9.3 (holds the test load; removed on stop) | BKK migration tests via `BKK_TRAFFIC_TEST_DATABASE_URL`. The recreate command is in [bkk_traffic_phase9_2.md](../integration/bkk_traffic_phase9_2.md) section 15. |
| Extracted friend repository | **TEMPORARY** | Session scratchpad (outside the repository) | Temporary | May be cleaned at any time | Read-only assessment copy |
| `scrapping--main.zip` | Reference input | Project root (237 MB) | Local file | Present | Friend's source code only; no SQLite DB inside. Git-ignored (exceeds GitHub's 100 MB limit). |
| `bkk_traffic` schema in `namtang_db` | **NOT YET CREATED** | — | — | — | Needs approval (Phase 9.4+) |
| Roles `bkk_traffic_owner` / `_app` / `_readonly` + login user | **NOT YET CREATED** | — | — | — | Needs approval; passwords out of band |
| Airflow Connection `bkk_traffic_postgres`, pool `longdo_api`, Variable `longdo_api_key` | **NOT YET CREATED** | — | — | — | Needs approval |
| BKK DAGs in `airflow/dags/` | **NOT YET CREATED** | Staged in `airflow/bkk_traffic_dags/` (not parsed by the running Airflow) | — | — | Moving them is a cutover step |
| BKK data root `data/bkk_traffic/` (`BKK_DATA_DIR`) | Source snapshot (read-only) | Repository | Local disk, git-ignored (`data/bkk_traffic/**`) | Created in Phase 9.3 | Holds the friend's Parquet snapshot copy; pipeline output only in tests so far |
| Friend's SQLite `data/warehouse/bkk_traffic.db` | **Excluded** (legacy) | Inside the replaced `scrapping--main.zip` | ~1.5 GB | Not extracted, not opened | Not a source since Phase 9.3 |

## 2. Port map

| Port | Resource | Class |
|---|---|---|
| 5432 | `itproject_db` | **NEVER TOUCH** |
| 5433 | `namtang_db` | **PRODUCTION** |
| 5434 (127.0.0.1) | `namtang_test_db` | **TEST** |
| 5435 (127.0.0.1) | `namtang_bkk_traffic_test_db` (only while it exists) | **TEMPORARY** |
| 8080 (127.0.0.1) | Airflow UI / API | **PRODUCTION** (local) |

On Windows, use `127.0.0.1` rather than `localhost` for these ports: `localhost` tries IPv6 first and adds about 5 s per connection.

## 3. Guard rules in code (CURRENT)

| Guard | Where |
|---|---|
| Namtang test DSN must be `namtang_test_db`; refuses host `namtang_db` and port 5433; checks `current_database()` | `tests/phase7_support.py` |
| BKK test DSN must be `namtang_bkk_traffic_test_db`; refuses ports 5432 / 5433 and hosts `namtang_db` / `itproject_db`; checks `current_database()` | `tests/test_bkk_traffic_migrations.py` |
| BKK migrations refuse unless `bkk_traffic.expected_database` = `current_database()` | `database/migrations/bkk_traffic/*.sql` |
| Airflow test runs unset the production connection and use SQLite metadata | `airflow/run_dag_tests.sh` |
| Lifecycle tests assert the real `data/` tree is unchanged | Phase 7 tests |

## 4. Rules

- Never use a PRODUCTION resource as a test target, and never touch `itproject_db`.
- Production database checks are read-only (`PGOPTIONS='-c default_transaction_read_only=on'`).
- Creating any NOT YET CREATED resource is a production change and needs explicit approval.
