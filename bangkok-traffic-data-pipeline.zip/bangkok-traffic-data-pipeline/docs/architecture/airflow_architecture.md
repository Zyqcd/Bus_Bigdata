# Airflow architecture

> **Current state (2026-10-03, final):** BKK Traffic is **in production** in PostgreSQL schema `bkk_traffic` (`namtang_db`, the only store and source of truth; no SQLite dependency). `bkk_traffic_pipeline` runs every 15 min and `bkk_traffic_maintenance` at 03:30 (Asia/Bangkok, Airflow 3.3.2, pool `longdo_api` = 1 slot); `bkk_traffic_quality` (01:00) is intentionally paused until the first full production day. The Longdo API key is an external secret (encrypted Airflow Variable `longdo_api_key`), never committed. Statements below that say "planned", "not integrated", "paused" or "schedule off" for BKK are point-in-time history. See [README section 12](../../README.md#12-bkk-traffic-pipeline-production).

> **Update 2026-10-03, Phase 9.3:** the BKK Traffic Parquet → PostgreSQL loader, migration 006 and the ported pipeline exist and are tested **on the throwaway test DB only**; production cutover has not happened. Details: [bkk_traffic_phase9_3.md](../integration/bkk_traffic_phase9_3.md). SQLite is no longer a dependency or a blocker.

**As of:** 2026-10-03. Status labels: **CURRENT**, **PLANNED / NOT ACTIVE**. Nothing in section 3 is implemented. Source of the findings: [bkk_traffic_phase9_2.md](../integration/bkk_traffic_phase9_2.md) sections 11–13.

## 1. Current deployment (CURRENT)

```
Compose project "namtang-airflow"  (airflow/docker-compose.yml, image namtang-airflow:3.3.2)
  Airflow 3.3.2 · Python 3.13 · LocalExecutor · default timezone Asia/Bangkok
  │
  ├── airflow-apiserver      UI + REST + execution API, 127.0.0.1:8080 only
  ├── airflow-scheduler      runs tasks; also joins network bangkok-traffic-project_default → namtang_db:5432
  ├── airflow-dag-processor  parses /opt/namtang/airflow/dags
  ├── airflow-metadata-db    postgres:16, Airflow's own metadata (volume namtang-airflow_airflow_metadata_pgdata)
  ├── airflow-init           one-off "db migrate"
  ├── airflow-cli            profile "cli": runs the test suite (throwaway SQLite metadata, real connection unset)
  └── namtang-test-db        profiles "cli"/"testdb": namtang_test_db, tmpfs, 127.0.0.1:5434
  │
  └── DAG: namtang_gtfs_pipeline     (the only DAG)
        scrape → clean → validate → dq_policy_gate → analysis → load_postgresql
```

| Setting | Value |
|---|---|
| Mounts | Repository at `/opt/namtang`; **one shared log directory** `airflow/logs` at `/opt/airflow/logs` |
| DAG state | **Paused**; `NAMTANG_SCHEDULE_ENABLED=false`, so `schedule=None` (manual trigger only) |
| Schedule when enabled | `CronTriggerTimetable("0 6 * * *", timezone="Asia/Bangkok")`, `catchup=False`, `max_active_runs=1` |
| Connection | `namtang_postgres` from `AIRFLOW_CONN_NAMTANG_POSTGRES` in `airflow/.env` (git-ignored) |
| Pools | `default_pool` only |
| New DAGs | `DAGS_ARE_PAUSED_AT_CREATION=true` |
| Concurrency | DAG-run lease on `data/metadata/namtang_pipeline.lock` (6 h TTL), shared with manual `run_pipeline.py` runs |
| Last run | Phase 8 verification on 2026-10-02 (unchanged feed, nothing written) |

The DAG only orchestrates: each task calls a step function in `data/scraper/run_pipeline.py`. Operating procedures are in README sections 8 and 10.

## 2. BKK Traffic DAGs (NOT ACTIVE)

The friend's 7 DAGs exist only inside the friend's repository. Phase 9.3 ported two replacement DAGs, `bkk_traffic_pipeline` and `bkk_traffic_maintenance`, staged in `airflow/bkk_traffic_dags/`. They are **not** in `airflow/dags/` and not registered in the running Airflow (tested end-to-end with `dag.test()` in the `airflow-cli` image only).

| Friend DAG | Friend schedule | In our Airflow |
|---|---|---|
| `bkk_traffic_realtime` | */15 | **NOT ACTIVE** |
| `bkk_traffic_backfill` | */15 | **NOT ACTIVE** |
| `bkk_traffic_quality` | 01:00 | **NOT ACTIVE** |
| `bkk_traffic_parquet` | every minute | **NOT ACTIVE** |
| `bkk_traffic_history` | 02:30 | **NOT ACTIVE** |
| `bkk_traffic_traveltime` | */5 | **NOT ACTIVE** |
| `bkk_traffic_maintenance` | 03:30 | **NOT ACTIVE**; must not be ported as-is |

## 3. Constraints for a future integration (PLANNED, not implemented)

All of these were verified read-only in our Airflow 3.3.2 image during Phase 9.2.

| # | Constraint | Finding | Planned handling |
|---|---|---|---|
| 1 | **Airflow 2.10.5 → 3.3.2** | `airflow.decorators`, `airflow.models.Variable`, `airflow.exceptions.*` and `airflow.operators.bash.BashOperator` still import, but with `DeprecatedImportWarning` | Port to `airflow.sdk` (`dag`, `task`, `Variable`), `airflow.sdk.exceptions`, `airflow.providers.standard.operators.bash` |
| 2 | **`longdo_api` pool** | Does not exist; tasks assigned to a missing pool never get queued | Create the pool (slot count to be decided) when the DAGs are ported; needs approval |
| 3 | **Quality DAG manual-run data interval** | Airflow 3 manual runs can have no logical date or data interval (our own Phase 8 run has an empty `logical_date`). `data_interval_end.in_timezone()` then fails. Scheduled runs (CronTriggerTimetable, `create_cron_data_intervals=False`) behave like 2.10. | Use `dag_run.run_after` (or `logical_date or run_after`) |
| 4 | **Plugin mounting** | The friend's code is imported as package `bkk_traffic` from `plugins/`. Our `plugins_folder=/opt/airflow/plugins` is on `sys.path` but nothing is mounted there. | Mount the ported package there, or install it into the image; decided at the port |
| 5 | **Maintenance DAG safety** | `airflow db clean` without `--dag-ids` cleans every DAG's metadata. Even with `--dag-ids`, 7 tables without a `dag_id` column are cleaned globally (`callback`, `import_error`, `trigger`, `revoked_token`, `connection_test_request`, `partitioned_asset_key_log`, `celery_*`). | Remove `clean_airflow_db` from the DAG. Metadata retention becomes a manual, `--dag-ids` + `--tables` + `--dry-run`-first ops procedure (Phase 9.2 section 12). |
| 6 | **Shared Airflow metadata** | One metadata DB holds Namtang and future BKK run history | Never automate global cleanup; before and after any manual clean, count `namtang_gtfs_pipeline` rows in `dag_run` / `task_instance`, which must be unchanged |
| 7 | **Shared log directory** | The friend's `delete_old_logs` walks all of `/opt/airflow/logs`, which would delete Namtang task logs | Allow-list `dag_id=bkk_traffic_*` directories only, with a `Path.resolve()` containment check |
| 8 | **BKK Traffic schedule decision** | The Parquet DAG runs every minute: 1,440 runs and 4,320 task instances per day, plus a full-table duplicate pass each minute. All BKK DAGs together make about 5,500 task instances/day, against Namtang's 6. Inputs change every 5–15 min at most. | Recommendation: publish every 15 min after realtime, or asset-triggered (−93% runs). **Decision deferred** to the user / team (D8); the friend's production schedule is unchanged. |
| 9 | Secrets | `longdo_api_key` Variable | Set at runtime from a secret store; never in compose, `.env.example` or the repo |
| 10 | Ungated backfill export (D10) | Dormant path that bypasses the gate | Call the gated `publish.*` functions |

Also verified: XCom returns are plain dicts without return annotations (so `multiple_outputs` is not inferred), there is no top-level `Variable.get`, and `catchup=False` / `max_active_runs=1` are explicit.

## 4. Rules that apply now

- Do not add, copy or mount BKK DAGs into `airflow/dags/` or `plugins/` until the port phase is approved.
- Do not create the `longdo_api` pool, the `bkk_traffic_postgres` connection or BKK Variables yet.
- Do not trigger or unpause `namtang_gtfs_pipeline` without a reason. Schedule activation is the user's decision (README section 10).
- No DAG may run `airflow db clean`.
