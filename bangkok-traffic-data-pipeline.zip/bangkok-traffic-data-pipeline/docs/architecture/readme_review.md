# README review (2026-10-03)

> Point-in-time review written before Phase 9.3. Since then Phase 9.3 ran on the test DB and `.gitignore` gained `data/bkk_traffic/**`; see [bkk_traffic_phase9_3.md](../integration/bkk_traffic_phase9_3.md).

**Scope:** [README.md](../../README.md), checked against the current state:
- Namtang Phases 1–8 complete;
- BKK Traffic Phases 9.1–9.2 complete;
- Phase 9.3 ON HOLD;
- BKK integration not complete.

Related problems found in [database/README.md](../../database/README.md) and `.gitignore` are listed in sections 2–3.

**Policy:** do not rewrite the README broadly. Only statements that were clearly false were corrected. Everything else is a suggestion for the maintainers.

## 1. README.md

Line numbers refer to the README **before** this review.

| Location | Current statement | Problem | Suggested update |
|---|---|---|---|
| §1 Python environment, line 62 | "105 pass; Airflow + Phase 7 DB tests skip" | Obsolete count: today's result on plain Windows Python is 140 passed / 44 skipped | **Corrected:** "140 pass, 44 skip: Airflow, Phase 7 DB and bkk_traffic DB tests skip" |
| §7 PostgreSQL, line 202 | "`namtang` (12 source tables + `migration_history`)" | Migration 005 added `load_history`; production has 14 tables in `namtang` | **Corrected:** "+ `migration_history` + `load_history`" |
| §7 PostgreSQL, line 208 | "(005_create_load_history is not yet applied to the running namtang_db; see database/README.md.)" | False since Phase 5/8: 005 is applied (`migration_history` lists 001–005) and `load_history` has 1 row | **Corrected:** "(All five, including 005_create_load_history, are applied to the running namtang_db.)" |
| §8 Environment, line 274 | "It never modifies `namtang_db` or `itproject_db`." | Inaccurate: the `load_postgresql` task in this Compose project writes to `namtang_db` (through the loader). What is true is that the project does not manage that container. | **Corrected:** "It does not manage the `namtang_db` container and never touches `itproject_db`; its only writes to `namtang_db` are made by the `load_postgresql` task through the existing loader." The same wording appears in the header comment of `airflow/docker-compose.yml`, which was left unchanged (production Docker config is out of scope). |
| Status table, Phase 8 row | "Implemented. Daily schedule configured but **off**" | Phase 8 passed its verification on 2026-10-02 (real new-feed transition to 20261001, multi-process lease run). The wording undersells this but is not false. | Suggest: "Complete (verified 2026-10-02). Daily schedule configured but **off**" |
| Status table | Ends at Phase 8 | Phases 9.1–9.2 (BKK Traffic assessment and design) are not mentioned; a reader can't find `docs/integration/` | Suggest one row: "9.1–9.2 \| BKK Traffic (Longdo) integration assessment and design, migrations tested on a throwaway DB \| Complete; integration **not** implemented, 9.3 ON HOLD (needs the friend's `bkk_traffic.db`)", linking `docs/integration/bkk_traffic_phase9_2.md` |
| Status table, Phase 6 row | "manual trigger only (`schedule=None`)" | Since Phase 8 the schedule is controlled by `NAMTANG_SCHEDULE_ENABLED`; `schedule=None` holds only while it is false (the current default) | Suggest: "manual trigger only while `NAMTANG_SCHEDULE_ENABLED=false` (see section 10)" |
| Header, line 6 | "Out of scope: … accident data (owned by another team member)" | Still true for the Namtang module, but the friend's accident / incident pipeline is now being assessed for a separate `bkk_traffic` schema (Phase 9.1 conflict C10) | Suggest: "accident / incident data (owned by another team member; integration as a separate `bkk_traffic` pipeline is being designed, see `docs/integration/`)" |
| Project structure block, lines 27–53 | Lists only Namtang paths | Missing `docs/` (architecture + integration), `database/migrations/bkk_traffic/` (tested only on a throwaway DB, not applied), `tests/test_bkk_traffic_migrations.py`, `scrapping--main.zip` | Suggest adding those entries with their status, or one line pointing to [project_architecture.md](project_architecture.md) section 8 |
| §2 Daily pipeline, line 103 | "the gate requires a reviewed `data/metadata/data_quality_policy_<feed>.json` written for that exact SHA-256" | Incomplete: since Phase 8 the gate also requires `approval.approved == true` (a DRAFT is refused, `run_pipeline.py` `policy_gate`). The README never states this explicitly. | Suggest adding: "…and marked approved (`approval.approved: true`); drafts never pass" |
| §5 Validation, line 172 | "The DQ policy (`data/metadata/data_quality_policy_2026-10-01.*`) decides…" | Only the first feed's policy is named; production now runs feed 20261001 with the approved `data_quality_policy_2026-10-02.*` | Suggest: "The DQ policy of each feed (`data_quality_policy_<feed>.*`; currently `2026-10-01` and `2026-10-02`)…" |
| §6 heading | "Known DQ findings (feed 20260930)" | Production feed is 20261001. Its validation and analysis outputs were verified identical (same counts), so the table is still correct. | Suggest: "(feeds 20260930 and 20261001; identical counts)" |
| §2 / §10 DSN examples | `localhost:5433` | Works, but section 9 itself warns that `localhost` adds about 5 s per connection on Windows | Optional: use `127.0.0.1:5433` |
| §10 "Integrating another source later" | Generic guidance only | Accurate; it could point to the concrete BKK design | Optional: add "First application: BKK Traffic, see `docs/integration/`" |
| §11 Git and data rules | Lists the ignored paths | Accurate for current files, but see section 3 (`scrapping--main.zip` and the future BKK data root are not ignored) | Update when `.gitignore` is changed |

## 2. database/README.md (not modified)

| Location | Current statement | Problem | Suggested update |
|---|---|---|---|
| "Status: Phase 5 complete" list | `migration_history` has 001–004; feed SHA `6b1a6a2d…`, `feed_version` 20260930 | Obsolete: 005 is applied, and production holds feed 20261001 (`e5d8b18c…5302`) since 2026-10-02 | Update the snapshot: 001–005, 14 `namtang` tables, feed 20261001, `load_history` 1 row (date the check) |
| Bold paragraph after the migration loop | "**Migration 005 (`namtang.load_history`) is new and not yet applied to the running `namtang_db`.**" | False today | Replace with "Migration 005 is applied (2026-10-02)." |
| Intro and last paragraph | "No accident data … part of this workflow" / "must not be extended with accident-related objects" | Still correct for the Namtang workflow, but readers may not know that `database/migrations/bkk_traffic/` now exists as a separate, unapplied workflow | Add one sentence: "BKK Traffic migrations live separately in `database/migrations/bkk_traffic/` (not applied; see `docs/integration/bkk_traffic_phase9_2.md`)." |
| DSN | `localhost:5433` | Same Windows latency note | Optional: `127.0.0.1` |

## 3. Repository hygiene observations (not modified)

| Item | Problem | Suggested update |
|---|---|---|
| `scrapping--main.zip` (237 MB) in the project root | Not covered by `.gitignore`. It exceeds GitHub's 100 MB file limit and holds about 680 MB of friend data once extracted (Phase 9.1 C8). | Add `/scrapping--main.zip` to `.gitignore`, or move the file outside the repository once it is no longer needed for reference |
| Future BKK data root (`data/bkk_traffic/`) | No ignore rule yet | Add one before the first BKK run (Phase 9.1 C4/C8) |
| `AGENTS.md` | The task list mentions it, but it does not exist; rules are in `.ai/PROJECT_RULES.md` (referenced by `.claude/CLAUDE.md`) | None required. Create it only if another agent tool needs it, as a pointer to `.ai/PROJECT_RULES.md`. |
| `.ai/PROJECT_RULES.md` §1 / §3 | Describes the scope as Namtang only, and the structure without `database/`, `airflow/`, `tests/`, `docs/` | Out of date but not wrong for its purpose; update when BKK integration is approved |

## 4. Conclusion

- Four README statements were clearly false or obsolete and were corrected with minimal wording changes. No other README content was changed.
- The remaining items are suggestions: mostly the missing Phase 9 status and the undocumented approval requirement.
- `database/README.md` has two clearly obsolete statements (005 "not yet applied", old feed snapshot). It was **not** modified in this task because it was outside the README-only correction scope; correcting it is recommended.
