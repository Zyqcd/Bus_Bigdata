# Project architecture (current state)

> **Current state (2026-10-03, final):** BKK Traffic is **in production** in PostgreSQL schema `bkk_traffic` (`namtang_db`, the only store and source of truth; no SQLite dependency). `bkk_traffic_pipeline` runs every 15 min and `bkk_traffic_maintenance` at 03:30 (Asia/Bangkok, Airflow 3.3.2, pool `longdo_api` = 1 slot); `bkk_traffic_quality` (01:00) is intentionally paused until the first full production day. The Longdo API key is an external secret (encrypted Airflow Variable `longdo_api_key`), never committed. Statements below that say "planned", "not integrated", "paused" or "schedule off" for BKK are point-in-time history. See [README section 12](../../README.md#12-bkk-traffic-pipeline-production).

> **Update 2026-10-03, Phase 9.4: production cutover done.** `bkk_traffic` exists in production `namtang_db` (loaded from a fresh gate-passed snapshot), roles / connection `bkk_traffic_postgres` / pool `longdo_api` exist, and the BKK DAGs are registered in `airflow/dags/`, **paused, schedule off**; one manual run succeeded. Details: [bkk_traffic_phase9_4.md](../integration/bkk_traffic_phase9_4.md).

> **Update 2026-10-03, Phase 9.3:** the BKK Traffic Parquet → PostgreSQL loader, migration 006 and the ported pipeline exist and are tested **on the throwaway test DB only**; production cutover has not happened. Details: [bkk_traffic_phase9_3.md](../integration/bkk_traffic_phase9_3.md). SQLite is no longer a dependency or a blocker.

**As of:** 2026-10-03. This document describes what exists **now**.

Every statement is labelled with one of these statuses:

| Label | Meaning |
|---|---|
| **CURRENT** | Exists and works today |
| **PLANNED** | Designed or documented, but not built in production |
| **ON HOLD** | Blocked, waiting for an external input |
| **NOT YET CREATED** | A named resource that does not exist yet |

Companion documents:
- [data_architecture.md](data_architecture.md)
- [database_architecture.md](database_architecture.md)
- [airflow_architecture.md](airflow_architecture.md)
- [environment_boundaries.md](environment_boundaries.md)
- [readme_review.md](readme_review.md)

Detailed sources:
- [README.md](../../README.md)
- [database/README.md](../../database/README.md)
- [bkk_traffic_database_assessment.md](../integration/bkk_traffic_database_assessment.md) (Phase 9.1)
- [bkk_traffic_phase9_2.md](../integration/bkk_traffic_phase9_2.md) (Phase 9.2)
- [.ai/PROJECT_RULES.md](../../.ai/PROJECT_RULES.md) (the project rules)

---

## 1. Project Overview

The Bangkok Traffic Project analyses traffic, accidents and public transport in Bangkok. This repository is its **data-engineering module**: it collects and prepares data for the analysis / ML team.

| Area | Status |
|---|---|
| **Namtang GTFS pipeline** (public transport, static GTFS ZIP from OTP): Phases 1–8 | **CURRENT**, stable in production |
| **BKK Traffic (Longdo) integration**: the friend's incident / traffic-index / travel-time pipeline | Phases 9.1–9.2 complete. Phase 9.3 (Parquet → PostgreSQL loader, migration 006, ported pipeline, staged DAGs) implemented and tested **on the test DB only**; stopped before production cutover. Production integration **PLANNED**, not built. |
| `backend/`, `frontend/` | **NOT YET CREATED** (only `.gitkeep`) |
| ML models | Out of scope for this module |

## 2. System Boundaries

```
                  ┌────────────────────────── this repository ──────────────────────────┐
 OTP static GTFS  │  Namtang pipeline (Python) ──► data/ (raw, clean, analysis, metadata)│
 ZIP (HTTPS) ────►│        ▲ orchestrated by Airflow 3.3.2 (namtang-airflow)             │
                  │        └──────────────► PostgreSQL namtang_db (5433)                 │
                  │                           schemas: namtang, namtang_analysis         │
                  └──────────────────────────────────────────────────────────────────────┘

 Friend's Longdo pipeline (own repo, Airflow 2.10.5 + SQLite) ── NOT CONNECTED to this system
   (only a read-only source ZIP, scrapping--main.zip, sits in the project root)

 itproject_db (5432): a different project's database. Outside this system, never touched.
```

| External input | Use | Status |
|---|---|---|
| `https://namtang-api.otp.go.th/download/namtang-gtfs.zip` | The only network endpoint the Namtang pipeline contacts | **CURRENT** |
| Longdo Traffic API (`traffic.longdo.com`) | Used only by the friend's pipeline, in the friend's own deployment | Not used by this repository |
| Friend's published Parquet snapshot (from `scrapping--main.zip`) | Source of the initial BKK load (Phase 9.3); read-only copy in `data/bkk_traffic/source_snapshots/` | **CURRENT** (test DB only). The friend's SQLite is intentionally excluded. |

## 3. Namtang Pipeline

**CURRENT**, Phases 1–8 complete.

```
scrape ─► clean ─► validate ─► dq_policy_gate ─► analysis ─► load_postgresql
```

| Step | Code | Output |
|---|---|---|
| Scrape (Phase 1) | `data/scraper/namtang_scraper.py` | `data/raw/namtang/<date>/gtfs.zip` + `manifest.json` (immutable, SHA-256 identity) |
| Clean (Phase 2) | `data/scraper/processing/clean_gtfs.py` | `data/clean/namtang/<feed>/` (12 Parquet tables, 100k-row chunks) |
| Validate (Phase 3) | `data/scraper/processing/validate_gtfs.py` | `data/metadata/validation_<feed>.json/.md` (PASS / WARNING / ERROR) |
| DQ policy gate (3.5, 8) | `run_pipeline.py` (`policy_gate`) | Passes only with an **approved** policy (`approval.approved == true`) written for that exact feed SHA; otherwise `awaiting_policy` |
| Analysis (Phase 4) | `data/scraper/processing/build_analysis.py` | `data/analysis/namtang/<feed>/` (8 derived Parquet datasets, DQ flag columns, no rows excluded) |
| Load (Phase 5) | `database/load/load_namtang.py` | Latest-snapshot replace in one transaction; `namtang.load_history` row |
| Runner | `data/scraper/run_pipeline.py` | Step functions shared by the CLI and Airflow; lease lock `data/metadata/namtang_pipeline.lock` |
| Orchestration (Phases 6–8) | `airflow/dags/namtang_gtfs_pipeline.py` | One task per step; no data logic in the DAG |

Production state:
- feed `20261001` (SHA `e5d8b18c…5302`), loaded 2026-10-02;
- `load_history` has 1 row;
- DAG **paused**, with `NAMTANG_SCHEDULE_ENABLED=false`, so it runs on manual trigger only.

Activating the daily 06:00 schedule is an explicit user decision (README section 10).

## 4. BKK Traffic Integration Status

| Item | Status |
|---|---|
| Phase 9.1: assessment of the friend's repository (11 SQLite tables, 7 DAGs, conflicts C1–C11) | **Complete** (document only) |
| Phase 9.2: unknowns, decisions, final `bkk_traffic` design, migrations `database/migrations/bkk_traffic/001–005` + rollback, tested on throwaway DB `namtang_bkk_traffic_test_db` | **Complete** (test DB only) |
| Phase 9.3: Parquet → PostgreSQL loader `database/load/load_bkk_traffic.py`, migration 006, pipeline package `data/scraper/bkk_traffic/`, staged DAGs `airflow/bkk_traffic_dags/` | **Complete on the test DB** (real snapshot loaded and reconciled there); production cutover **not done** |
| `bkk_traffic` schema in production `namtang_db` | **NOT YET CREATED** |
| Roles `bkk_traffic_owner` / `bkk_traffic_app` / `bkk_traffic_readonly` in production | **NOT YET CREATED** |
| Airflow Connection `bkk_traffic_postgres`, pool `longdo_api` | **NOT YET CREATED** |
| BKK Traffic DAGs in our Airflow | **NOT YET CREATED**: not copied, not ported, not active |
| Storage-layer port (SQLite → PostgreSQL code) | **PLANNED**: mapping documented (Phase 9.2 section 14); no code written |
| BKK data in this repository | None. The friend's data lives in the friend's own deployment. |

**BKK Traffic integration is not complete.**

## 5. PostgreSQL Architecture

Detail: [database_architecture.md](database_architecture.md).

| Database | Port | Schemas | Status |
|---|---|---|---|
| `namtang_db` (container `namtang_db`, postgres:18) | 5433 | `namtang` (14 tables), `namtang_analysis` (8), `public` (0 tables) | **CURRENT**, production |
| `namtang_db` → schema `bkk_traffic` | 5433 | 13 tables as designed | **PLANNED / NOT YET CREATED** |
| Airflow metadata DB (`airflow-metadata-db`, postgres:16) | not published | Airflow internal | **CURRENT** |
| `namtang_test_db` (Namtang lifecycle tests) | 127.0.0.1:5434 | Test only | **TEST**, currently stopped |
| `namtang_bkk_traffic_test_db` (Phases 9.2–9.3) | 127.0.0.1:5435 | Test only | **TEMPORARY** (tmpfs; running at the end of Phase 9.3, discarded when stopped) |
| `itproject_db` | 5432 | Another project | **Never touched** |

## 6. Airflow Architecture

Detail: [airflow_architecture.md](airflow_architecture.md).

**CURRENT**:
- Compose project `namtang-airflow` (Airflow 3.3.2, Python 3.13, LocalExecutor);
- UI on `127.0.0.1:8080`;
- one DAG, `namtang_gtfs_pipeline`, which is paused and has its schedule switched off.

The BKK Traffic DAGs are **not active**. Their integration constraints (pool, imports, manual-run data interval, plugin mount, unsafe maintenance DAG, shared metadata and logs, schedule) are recorded as **PLANNED** work.

## 7. Data Lifecycle

Detail: [data_architecture.md](data_architecture.md).

**Namtang (CURRENT)**:

```
raw ZIP (immutable) → clean Parquet → analysis Parquet → PostgreSQL namtang / namtang_analysis
```

- A new feed SHA stops at the policy gate until a human approves a policy.
- An unchanged SHA writes nothing.

**BKK Traffic**: friend SQLite → **NOT INTEGRATED**. The PostgreSQL flow into `bkk_traffic` is **FUTURE / NOT IMPLEMENTED**.

## 8. Directory Structure

| Path | Category | Status / notes |
|---|---|---|
| `data/scraper/namtang_scraper.py`, `run_pipeline.py` | Production code (ingestion, runner, gate, lock) | **CURRENT** |
| `data/scraper/processing/` (`clean_gtfs.py`, `validate_gtfs.py`, `build_analysis.py`) | Data-processing code | **CURRENT** |
| `database/load/load_namtang.py` | Production loader | **CURRENT** |
| `database/migrations/namtang/001–005` | Database migrations (applied in production) | **CURRENT** |
| `database/migrations/bkk_traffic/001–005`, `rollback/` | Database migrations, **tested only on the throwaway DB** | **PLANNED** for production; must not be run against `namtang_db` without approval (they refuse unless `bkk_traffic.expected_database` is set) |
| `airflow/dags/namtang_gtfs_pipeline.py` | Airflow orchestration | **CURRENT** |
| `airflow/docker-compose.yml`, `Dockerfile`, `.env.example`, `run_dag_tests.sh` | Orchestration infrastructure (+ the Namtang test DB service) | **CURRENT** |
| `airflow/.env` | Local secrets | Git-ignored, never committed |
| `airflow/logs/` | Generated task logs | Git-ignored |
| `docker-compose.yml` (root) | Production DB container `namtang_db` | **CURRENT** |
| `data/raw/namtang/` | Immutable source snapshots | Generated, git-ignored |
| `data/clean/namtang/`, `data/analysis/namtang/` | Generated artifacts | Git-ignored; rebuildable |
| `data/metadata/` | Run log (`scrape_log.csv`), validation reports, DQ policies (approved + historical DRAFT) | Committed; policies are human-reviewed artifacts |
| `tests/` (+ `tests/fixtures/phase7/`) | Tests and TEST-ONLY fixtures | **CURRENT** |
| `docs/integration/` | BKK Traffic assessment (9.1) and design / test record (9.2) | **CURRENT** documentation of **PLANNED** work |
| `docs/architecture/` | This document set | **CURRENT** |
| `README.md`, `database/README.md`, `.ai/PROJECT_RULES.md`, `.claude/CLAUDE.md` | Documentation and rules | **CURRENT** (see [readme_review.md](readme_review.md)) |
| `scrapping--main.zip` (237 MB) | Read-only copy of the friend's source repository, used for assessment | Reference input, not production; **not covered by `.gitignore`** (see readme_review) |
| `backend/`, `frontend/` | Placeholders | **NOT YET CREATED** |

There is no `AGENTS.md` in the repository. The shared AI rules live in `.ai/PROJECT_RULES.md`, which `.claude/CLAUDE.md` points to.

## 9. Test Architecture

| Layer | Files | Needs | Status |
|---|---|---|---|
| Unit / component (synthetic data, no network) | `test_namtang_scraper.py`, `test_clean_gtfs.py`, `test_validate_gtfs.py`, `test_build_analysis.py`, `test_run_pipeline.py`, `test_database_migration.py`, `test_phase8_operations.py` | Python only | **CURRENT** |
| Airflow DAG tests | `test_airflow_dag.py`, `test_phase8_airflow_operations.py`, `test_phase7_airflow_lifecycle.py` | The Airflow image (`airflow-cli`), throwaway SQLite metadata DB; skipped on plain Windows Python | **CURRENT** |
| New-feed lifecycle (Phase 7) | `test_phase7_new_feed_lifecycle.py`, `phase7_support.py`, `fixtures/phase7/` | `NAMTANG_TEST_DATABASE_URL` → `namtang_test_db` (5434); refuses `namtang_db` / port 5433 | **CURRENT** (skips without the DSN) |
| BKK Traffic migrations (Phase 9.2) | `test_bkk_traffic_migrations.py` | 12 static tests always run; 36 DB tests need `BKK_TRAFFIC_TEST_DATABASE_URL` → `namtang_bkk_traffic_test_db` (5435); refuses ports 5432 / 5433 | **CURRENT** (DB tests skip without the DSN) |

Last full results (2026-10-03):
- 140 passed / 44 skipped on Windows Python without the test DSNs;
- 176 passed / 8 skipped with the BKK test DB running.

Tests never contact the real feed URL and never write to `namtang_db`.

## 10. Production vs Test Resources

Detail: [environment_boundaries.md](environment_boundaries.md).

| Category | Resources |
|---|---|
| **PRODUCTION** | `namtang_db` (5433); the Airflow stack `namtang-airflow` and its metadata DB; `data/raw|clean|analysis/namtang`; `data/metadata` |
| **TEST** | `namtang-test-db` / `namtang_test_db` (5434, tmpfs, profiles `cli` / `testdb`); throwaway SQLite Airflow metadata inside `airflow-cli`; pytest temporary directories |
| **TEMPORARY** | `namtang_bkk_traffic_test_db` (5435, `docker run --rm`, tmpfs; created for migration / loader / pipeline tests, discarded when stopped); the extracted friend repository in the session scratchpad (outside the repo) |
| **NOT YET CREATED** | `bkk_traffic` schema and roles in production; `bkk_traffic_postgres` connection; `longdo_api` pool; BKK DAGs in the live `airflow/dags/` (they are staged in `airflow/bkk_traffic_dags/`) |
| **NEVER TOUCH** | `itproject_db` (5432) and its volumes / network |

## 11. Current Integration Boundary

What exists for BKK Traffic **inside this repository** today:
- design documents (`docs/integration/`);
- SQL migrations and their rollback (`database/migrations/bkk_traffic/`);
- one test module (`tests/test_bkk_traffic_migrations.py`).

Nothing BKK-related is wired into any running component:

| Boundary | Status |
|---|---|
| No BKK code is imported by the Namtang modules, DAG, loader or migrations | **CURRENT**, verified |
| No BKK object exists in `namtang_db` (no schema, no roles) | **CURRENT**, verified read-only on 2026-10-03 |
| No BKK DAG, connection, pool or variable exists in Airflow | **CURRENT** |
| The friend's pipeline still runs in the friend's own environment (SQLite) | Outside this system |
| The `test_database_migration.py` check (no accident objects) scans only `database/migrations/namtang/` and `database/load/*.py` | **CURRENT**. BKK files live in `bkk_traffic/` sub-folders, so that check is unaffected. |

## 12. Pending Work

| Work | Status | Blocked by |
|---|---|---|
| Phase 9.3: Parquet loader + pipeline port, test DB only | **Done (test DB)** | — |
| Production cutover (schema, roles, connection, pool, initial load, DAGs; plan in the Phase 9.3 doc, section 11) | **PLANNED** | Explicit user approval |
| Not yet ported: quality report, CSV export, yearly history / feed loads, travel times | **PLANNED** | Future phase |
| Production `bkk_traffic` schema, roles, login user, Connection, pool | **PLANNED** (Phase 9.4+) | Explicit user approval |
| BKK DAG port to Airflow 3.3.2 (imports, pool, maintenance without `db clean`, Parquet cadence) | **PLANNED** (Phase 9.4+) | Phase 9.3 + approval + team decision on the schedule (D8) |
| U7: who consumes the BKK Parquet / CSV | Open | Team decision |
| Activate the Namtang daily schedule | Available, **off** | User decision |
| Documentation fixes listed in [readme_review.md](readme_review.md) | Proposed | Review |

## 13. Safety/Isolation Rules

These summarize the existing rules; they are not new ones.

1. **Raw data is immutable**; records are never fabricated or duplicated to reach a row count (PROJECT_RULES).
2. **Namtang stays independent:**
   - its schemas, migrations, scraper, runner and DAG are not changed for BKK Traffic;
   - Namtang never depends on `bkk_traffic` tables;
   - BKK Traffic never writes to `namtang` / `namtang_analysis`.
3. **`itproject_db` (5432) is never touched.**
4. **Tests never use production:**
   - test DSNs are guarded by name and port, and `SELECT current_database()` is checked before any write;
   - BKK migrations refuse to run unless `bkk_traffic.expected_database` matches the connected database.
5. **No production change without explicit approval:**
   - this covers schema or role creation, data loads, DAG activation, connections and pools;
   - `load_namtang.py --replace` is not a normal workflow.
6. **DQ policies are human-approved for the exact feed SHA**, never generated or auto-approved.
7. **No secrets in the repository:**
   - `.env` files are git-ignored;
   - future `longdo_api_key` and DB passwords go to a secret store / Airflow at runtime.
8. **Shared Airflow metadata and logs are protected:** no DAG may run `airflow db clean`, and BKK log cleanup must be allow-listed to `dag_id=bkk_traffic_*` (Phase 9.2 section 12).
9. **No invented data:** the BKK initial load uses only the friend's published Parquet; SQLite is excluded and nothing is fabricated (no bronze raw for baseline rows, no `travel_times.raw_json`).
