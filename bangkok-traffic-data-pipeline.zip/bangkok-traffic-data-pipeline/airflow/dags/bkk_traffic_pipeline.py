"""BKK Traffic pipeline DAG (Airflow 3.3.2), independent of namtang_gtfs_pipeline.

Registered in airflow/dags/ at the Phase 9.4 production cutover
(docs/integration/bkk_traffic_phase9_4.md); created paused, schedule off by default.

    scrape -> update_history -> collect_travel_times -> clean -> validate -> publish -> verify_postgresql

* scrape: event types (when empty), the realtime traffic index sample and realtime
  incidents from traffic.longdo.com into PostgreSQL bronze (Bangkok + traffic only;
  crawl delay 10 s through the shared rate-limit lock).
* update_history (Phase 9.5): Longdo's yearly 5-minute traffic-index file -> validated ->
  traffic_index_history in one transaction per year (idempotent; never generates missing
  points); at most once per Variable bkk_history_refresh_hours (default 24, the original
  daily cadence); same API pool as scrape. Then history/current consistency is checked.
* collect_travel_times (Phase 9.6): one Longdo RouteService poll of the OD pairs -> travel_times
  in one transaction (key: route, fetched_at; nothing fabricated). Needs Airflow Variable
  longdo_api_key (masked); without it the task records a 'skipped' run and makes no request.
  Same API pool as scrape / update_history, so Longdo requests never overlap.
* clean: bronze rows not cleaned yet -> incidents / quarantine, then duplicate flags.
* validate: the friend's gate G1-G9; FAIL stops the run, nothing is published.
* publish: Parquet under data/bkk_traffic/parquet (same datasets and manifest format).
* verify_postgresql: the published manifests must equal PostgreSQL's row counts.
  PostgreSQL is the persistent source of truth (written by scrape/clean); nothing is
  re-loaded from Parquet, which would be circular. The one-off initial load from the
  friend's Parquet snapshot is database/load/load_bkk_traffic.py.

Schedule: None (manual) unless BKK_TRAFFIC_SCHEDULE_ENABLED=true, then every 15 minutes
(Asia/Bangkok). Ported from the friend's Airflow 2.10 realtime + parquet DAGs: airflow.sdk
imports, run_after instead of a data interval, configurable API pool (default_pool
until the longdo_api pool is approved), connection bkk_traffic_postgres.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import timedelta
from pathlib import Path

import pendulum
from airflow.sdk import Variable, dag, task

try:  # Airflow 3 Task SDK
    from airflow.sdk.exceptions import AirflowFailException, AirflowSkipException
except ImportError:  # pragma: no cover - older layouts
    from airflow.exceptions import AirflowFailException, AirflowSkipException

PROJECT_ROOT = Path(os.environ.get("NAMTANG_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(PROJECT_ROOT / "data" / "scraper"))

DAG_ID = "bkk_traffic_pipeline"
CONN_ID = "bkk_traffic_postgres"
SCHEDULE_ENV = "BKK_TRAFFIC_SCHEDULE_ENABLED"
SCHEDULE_CRON = "*/15 * * * *"
SCHEDULE_TIMEZONE = "Asia/Bangkok"
API_POOL = os.environ.get("BKK_TRAFFIC_API_POOL", "default_pool")

log = logging.getLogger(__name__)


def pipeline_schedule():
    if os.environ.get(SCHEDULE_ENV, "false").strip().lower() not in ("1", "true", "yes"):
        return None
    from airflow.timetables.trigger import CronTriggerTimetable

    return CronTriggerTimetable(SCHEDULE_CRON, timezone=SCHEDULE_TIMEZONE)


# ---- configuration hooks (overridden in tests) -------------------------------

def bkk_dsn() -> str:
    """libpq conninfo for the Airflow connection bkk_traffic_postgres (schema field = database)."""
    from airflow.sdk import Connection
    from psycopg.conninfo import make_conninfo

    conn = Connection.get(CONN_ID)
    return make_conninfo(host=conn.host, port=conn.port or 5432, dbname=conn.schema,
                         user=conn.login, password=conn.password)


def _configure() -> None:
    from bkk_traffic import storage

    storage.configure(bkk_dsn())


def _scraping_stopped() -> bool:
    return str(Variable.get("bkk_scrape_stopped", "false")).lower() == "true"


# ---- DAG -----------------------------------------------------------------------

@dag(
    dag_id=DAG_ID,
    schedule=pipeline_schedule(),
    start_date=pendulum.datetime(2026, 10, 1, tz=SCHEDULE_TIMEZONE),
    catchup=False,
    max_active_runs=1,
    dagrun_timeout=timedelta(minutes=14),
    default_args={"owner": "bkk_traffic", "retries": 0},
    tags=["bkk_traffic"],
)
def bkk_traffic_pipeline():
    @task(multiple_outputs=False, pool=API_POOL, retries=2, retry_delay=timedelta(minutes=2),
          execution_timeout=timedelta(minutes=10))
    def scrape() -> dict:
        from bkk_traffic import config, scrape as scr

        if _scraping_stopped():
            raise AirflowSkipException("scraping stopped (Variable bkk_scrape_stopped=true)")
        _configure()
        max_pages = int(Variable.get("bkk_realtime_max_pages", config.DEFAULT_REALTIME_MAX_PAGES))
        index = scr.run_traffic_index()
        incidents = scr.run_realtime_incidents(max_pages)
        return {"traffic_index_time": index.get("time"), "incidents": incidents}

    @task(multiple_outputs=False, pool=API_POOL, retries=0, execution_timeout=timedelta(minutes=10))
    def update_history(scraped: dict) -> dict:
        from bkk_traffic import history, storage

        if _scraping_stopped():
            raise AirflowSkipException("scraping stopped (Variable bkk_scrape_stopped=true)")
        _configure()
        hours = float(Variable.get("bkk_history_refresh_hours", history.DEFAULT_REFRESH_HOURS))
        result = history.run(refresh_hours=hours)
        with storage.connect() as conn:
            result["verify"] = history.verify(conn)
        return result

    @task(multiple_outputs=False, pool=API_POOL, retries=0, execution_timeout=timedelta(minutes=5))
    def collect_travel_times(previous: dict) -> dict:
        import json

        from bkk_traffic import traveltime

        if _scraping_stopped():
            raise AirflowSkipException("scraping stopped (Variable bkk_scrape_stopped=true)")
        _configure()
        api_key = Variable.get("longdo_api_key", None)   # masked in logs by Airflow (name contains api_key)
        pairs = json.loads(Variable.get("bkk_od_pairs", "null") or "null")
        return traveltime.collect(api_key, pairs)

    @task(multiple_outputs=False)
    def clean(previous: dict) -> dict:
        from bkk_traffic import publish

        _configure()
        return publish.run_clean_stage()

    @task(multiple_outputs=False)
    def validate(cleaned: dict) -> dict:
        from bkk_traffic import publish

        _configure()
        gate = publish.gate_checks()
        for c in gate["checks"]:
            log.info("[%s] %s: %s %s", c["status"], c["check"], c["value"], c["detail"])
        if not gate["passed"]:
            raise AirflowFailException("validation gate FAIL - nothing published (see data/bkk_traffic/quality)")
        return gate

    @task(multiple_outputs=False)
    def publish(gate: dict) -> dict:
        from bkk_traffic import publish as pub

        _configure()
        return pub.publish_parquet(gate)

    @task(multiple_outputs=False)
    def verify_postgresql(published: dict) -> dict:
        from bkk_traffic import parquet_export

        _configure()
        return parquet_export.verify_postgresql()

    verify_postgresql(publish(validate(clean(collect_travel_times(update_history(scrape()))))))


pipeline_dag = bkk_traffic_pipeline()
