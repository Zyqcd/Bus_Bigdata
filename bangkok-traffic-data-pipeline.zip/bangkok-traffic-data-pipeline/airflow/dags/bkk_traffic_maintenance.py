"""BKK Traffic maintenance DAG (Airflow 3.3.2): BKK Traffic task logs only.

Registered in airflow/dags/ at the Phase 9.4 production cutover
(docs/integration/bkk_traffic_phase9_4.md); created paused, schedule off by default.

Replaces the friend's bkk_traffic_maintenance, which ran `airflow db clean` on every
DAG and deleted all logs under /opt/airflow/logs. Here:
  * no Airflow metadata cleanup at all (the metadata DB is shared with Namtang);
  * logs older than 7 days are deleted only inside dag_id=bkk_traffic_* folders.
Schedule: None unless BKK_TRAFFIC_SCHEDULE_ENABLED=true, then daily 03:30 Asia/Bangkok.
"""

from __future__ import annotations

import os
import sys
from datetime import timedelta
from pathlib import Path

import pendulum
from airflow.sdk import dag, task

PROJECT_ROOT = Path(os.environ.get("NAMTANG_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(PROJECT_ROOT / "data" / "scraper"))

DAG_ID = "bkk_traffic_maintenance"
SCHEDULE_ENV = "BKK_TRAFFIC_SCHEDULE_ENABLED"
LOG_ROOT = Path(os.environ.get("BKK_TRAFFIC_LOG_ROOT", "/opt/airflow/logs"))


def maintenance_schedule():
    if os.environ.get(SCHEDULE_ENV, "false").strip().lower() not in ("1", "true", "yes"):
        return None
    from airflow.timetables.trigger import CronTriggerTimetable

    return CronTriggerTimetable("30 3 * * *", timezone="Asia/Bangkok")


@dag(
    dag_id=DAG_ID,
    schedule=maintenance_schedule(),
    start_date=pendulum.datetime(2026, 10, 1, tz="Asia/Bangkok"),
    catchup=False,
    max_active_runs=1,
    default_args={"owner": "bkk_traffic", "retries": 1, "retry_delay": timedelta(minutes=10)},
    tags=["bkk_traffic", "maintenance"],
)
def bkk_traffic_maintenance():
    @task(multiple_outputs=False)
    def delete_old_bkk_logs() -> dict:
        from bkk_traffic import maintenance

        return maintenance.delete_old_bkk_logs(LOG_ROOT)

    delete_old_bkk_logs()


maintenance_dag = bkk_traffic_maintenance()
