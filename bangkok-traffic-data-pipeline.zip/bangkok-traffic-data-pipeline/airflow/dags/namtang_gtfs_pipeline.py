"""Namtang GTFS pipeline: one Airflow task per stage.

    scrape >> clean >> validate >> dq_policy_gate >> analysis >> load_postgresql

Airflow only orchestrates. Every task calls one step function of
``data/scraper/run_pipeline.py`` (the same steps the manual runner uses), which in
turn calls the existing scraper, cleaner, validator, policy gate, analysis builder
and PostgreSQL loader. No data processing happens in this file.

* Feed identity: ``scrape`` pins the feed to the raw_path returned by the scraper.
  Every later task receives a small JSON context through XCom (paths, SHA-256,
  feed_version, run ids, statuses). Datasets stay on disk; no rows go into XCom.
  Each task pushes exactly one XCom (return_value): ``multiple_outputs=False`` is
  explicit because a ``dict`` return annotation would otherwise make Airflow store
  every key as an extra XCom row.
* ``dq_policy_gate``: known errors covered by the reviewed policy pass. A missing
  or mismatched policy, or an unexpected ERROR, fails the task as
  ``awaiting_policy`` (no retries), so analysis and load never run.
* ``load_postgresql``: SHA-256 based - an unchanged feed writes nothing, a new
  feed replaces the snapshot in one transaction (rolled back on failure).
* PostgreSQL credentials come from the Airflow connection ``namtang_postgres``.
* Schedule: a daily *polling* run at 06:00 Asia/Bangkok
  (``CronTriggerTimetable("0 6 * * *", timezone="Asia/Bangkok")``), enabled only
  when ``NAMTANG_SCHEDULE_ENABLED=true``; otherwise ``schedule=None`` (manual).
  06:00 is an operational choice, not the publisher's update time. An unchanged
  feed is a successful no-op. ``catchup=False``, ``max_active_runs=1``.
* Concurrency: the DAG run holds the shared pipeline lock as a *lease* from
  ``scrape`` until the run ends, so a manual run_pipeline.py cannot start between
  tasks. Failed runs release it (task failure or the DAG failure callback); a
  crashed run's lease expires after ``rp.AIRFLOW_LEASE_TTL``.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import timedelta
from pathlib import Path
from typing import Any, Callable

import pendulum
from airflow.sdk import dag, get_current_context, task

try:  # Airflow 3 Task SDK
    from airflow.sdk.exceptions import AirflowFailException
except ImportError:  # pragma: no cover - older layouts
    from airflow.exceptions import AirflowFailException

PROJECT_ROOT = Path(os.environ.get("NAMTANG_PROJECT_ROOT",
                                   Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(PROJECT_ROOT / "data" / "scraper"))

import run_pipeline as rp  # noqa: E402  (import only defines functions and constants)

DAG_ID = "namtang_gtfs_pipeline"
CONN_ID = "namtang_postgres"
SCHEDULE_TIMEZONE = "Asia/Bangkok"
SCHEDULE_CRON = "0 6 * * *"        # daily polling time (operational choice; see README)
SCHEDULE_ENV = "NAMTANG_SCHEDULE_ENABLED"

log = logging.getLogger(__name__)


def pipeline_schedule():
    """None (manual only) unless NAMTANG_SCHEDULE_ENABLED is true.

    The timezone is explicit on the timetable, so the run time does not depend on
    the machine's or Airflow's default timezone."""
    if os.environ.get(SCHEDULE_ENV, "false").strip().lower() not in ("1", "true", "yes"):
        return None
    from airflow.timetables.trigger import CronTriggerTimetable

    return CronTriggerTimetable(SCHEDULE_CRON, timezone=SCHEDULE_TIMEZONE)


# ---- configuration hooks (overridden in tests) -------------------------------

def pipeline_paths() -> rp.Paths:
    return rp.Paths()


def namtang_dsn() -> str:
    """libpq conninfo for the Airflow connection ``namtang_postgres``.

    The connection's *schema* field holds the database name (namtang_db); the
    tables live in the PostgreSQL schemas namtang / namtang_analysis."""
    from airflow.sdk import Connection
    from psycopg.conninfo import make_conninfo

    conn = Connection.get(CONN_ID)
    return make_conninfo(host=conn.host, port=conn.port or 5432, dbname=conn.schema,
                         user=conn.login, password=conn.password)


def pipeline_stages(paths: rp.Paths, run_id: str, dsn: str | None = None) -> rp.Stages:
    return rp.default_stages(paths, dsn, run_id)


# ---- helpers -------------------------------------------------------------------

def _run_id() -> str:
    return f"airflow-{get_current_context()['run_id']}"


def _lease(paths: rp.Paths, run_id: str, stage: str | None = None) -> rp.PipelineLock:
    """The DAG run's lease on the shared pipeline lock (owner = pipeline run id)."""
    return rp.PipelineLock(paths.lock_path, run_id, kind="airflow",
                           ttl=rp.AIRFLOW_LEASE_TTL, stage=stage)


def _guarded(stage: str, ctx: dict[str, Any] | None, fn: Callable[[], Any],
             final: bool = False) -> Any:
    """Run one step under the DAG run's lease and make failures visible.

    ``scrape`` creates the lease and later tasks of the same run re-enter it, so
    a manual run cannot start between tasks. It is released after the final task
    or as soon as any task fails (a retry re-acquires it). A lock held by a manual
    run raises PipelineLocked, so the task fails instead of overlapping."""
    paths = pipeline_paths()
    run_id = (ctx or {}).get("run_id") or _run_id()
    lease = _lease(paths, run_id, stage)
    lease.acquire()
    try:
        result = fn()
    except rp.AwaitingPolicy as exc:
        message = exc.gate.get("operator_message", exc.gate["reason"])
        rp.log_event(paths, run_id, "pipeline", "awaiting_policy", message,
                     rp.feed_fields(exc.ctx))
        lease.release()
        raise AirflowFailException(f"awaiting_policy: {message}") from exc
    except rp.StageFailure as exc:
        rp.log_event(paths, run_id, "pipeline", "failed",
                     f"failed at {exc.stage}: {exc.message}", rp.feed_fields(ctx))
        lease.release()
        raise
    except BaseException:
        lease.release()
        raise
    if final:
        lease.release()
    return result


def on_dag_run_failure(context: dict[str, Any]) -> None:
    """DAG-level failure callback: release this run's lease and log a summary.

    This is the single place to add an operator notification (e-mail, chat, ...)
    once the team has configured one; none is configured in this project."""
    dag_run = context.get("dag_run")
    run_id = f"airflow-{getattr(dag_run, 'run_id', '')}"
    released = _lease(pipeline_paths(), run_id).release_if_owner()
    log.warning("Namtang DAG run %s failed (lease released: %s). Inspect the failed task's "
                "log in the Airflow UI and the stage=pipeline rows in scrape_log.csv.",
                run_id, released)


# ---- DAG -----------------------------------------------------------------------

@dag(
    dag_id=DAG_ID,
    description="Namtang static GTFS: scrape, clean, validate, DQ gate, analysis, load",
    schedule=pipeline_schedule(),       # None unless NAMTANG_SCHEDULE_ENABLED=true
    start_date=pendulum.datetime(2026, 10, 1, tz=SCHEDULE_TIMEZONE),
    catchup=False,
    max_active_runs=1,
    on_failure_callback=on_dag_run_failure,
    default_args={"owner": "namtang", "retries": 0},
    tags=["namtang", "gtfs"],
    doc_md=__doc__,
)
def namtang_gtfs_pipeline():

    @task(multiple_outputs=False, retries=2, retry_delay=timedelta(minutes=10))
    def scrape() -> dict[str, Any]:
        def run() -> dict[str, Any]:
            paths, run_id = pipeline_paths(), _run_id()
            rp.log_event(paths, run_id, "pipeline", "started", f"Airflow DAG {DAG_ID}")
            rp.clean_stale_temp_dirs(paths)
            return rp.step_scrape(paths, pipeline_stages(paths, run_id), run_id)
        return _guarded("scrape", None, run)

    @task(multiple_outputs=False)
    def clean(ctx: dict[str, Any]) -> dict[str, Any]:
        paths = pipeline_paths()
        return _guarded("clean", ctx, lambda: rp.step_clean(
            paths, pipeline_stages(paths, ctx["run_id"]), ctx))

    @task(multiple_outputs=False)
    def validate(ctx: dict[str, Any]) -> dict[str, Any]:
        paths = pipeline_paths()
        return _guarded("validate", ctx, lambda: rp.step_validate(
            paths, pipeline_stages(paths, ctx["run_id"]), ctx)[0])

    @task(multiple_outputs=False, retries=0)
    def dq_policy_gate(ctx: dict[str, Any]) -> dict[str, Any]:
        paths = pipeline_paths()
        return _guarded("dq_policy_gate", ctx, lambda: rp.step_policy_gate(paths, ctx)[0])

    @task(multiple_outputs=False)
    def analysis(ctx: dict[str, Any]) -> dict[str, Any]:
        paths = pipeline_paths()
        return _guarded("analysis", ctx, lambda: rp.step_analysis(
            paths, pipeline_stages(paths, ctx["run_id"]), ctx))

    @task(multiple_outputs=False, retries=1, retry_delay=timedelta(minutes=5))
    def load_postgresql(ctx: dict[str, Any]) -> dict[str, Any]:
        def run() -> dict[str, Any]:
            paths = pipeline_paths()
            stages = pipeline_stages(paths, ctx["run_id"], namtang_dsn())
            new = rp.step_load(paths, stages, ctx)
            rp.log_event(paths, ctx["run_id"], "pipeline", rp.final_status(new),
                         rp.summary_message(new), rp.feed_fields(new))
            return new
        return _guarded("load_postgresql", ctx, run, final=True)

    load_postgresql(analysis(dq_policy_gate(validate(clean(scrape())))))


namtang_dag = namtang_gtfs_pipeline()
