"""BKK Traffic daily quality DAG (Airflow 3.3.2), independent of bkk_traffic_pipeline.

Phase 9.7: ported from the friend's bkk_traffic_quality (Airflow 2.10, daily 01:00)
(docs/integration/bkk_traffic_quality_mapping.md).

    refresh_event_types -> detect_missing_eids -> recover_missing_eids -> quality_checks -> gate

* refresh_event_types: daily geteventtype refresh (validated, one transaction) - pool longdo_api.
* detect_missing_eids: eids above the coverage floor that realtime never saw -> missing_eids.
* recover_missing_eids: at most bkk_recover_per_run (30) eids and bkk_recover_max_seconds (360)
  per run, one request at a time through the shared rate lock - pool longdo_api.
* quality_checks: report for (run_after in Asia/Bangkok) - 1 day -> data/bkk_traffic/quality/dt=<day>/.
* gate: fails the run when the report's overall status is FAIL.
The friend's export_csv task is not ported (CSV export is out of scope). The traffic.longdo.com
endpoints used here need no API key; longdo_api_key is never read by this DAG.

Created paused; schedule None unless BKK_TRAFFIC_SCHEDULE_ENABLED=true (then 01:00 Asia/Bangkok).
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import timedelta
from pathlib import Path

import pendulum
from airflow.sdk import Variable, dag, get_current_context, task

try:  # Airflow 3 Task SDK
    from airflow.sdk.exceptions import AirflowFailException, AirflowSkipException
except ImportError:  # pragma: no cover - older layouts
    from airflow.exceptions import AirflowFailException, AirflowSkipException

PROJECT_ROOT = Path(os.environ.get("NAMTANG_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
sys.path.insert(0, str(PROJECT_ROOT / "data" / "scraper"))

DAG_ID = "bkk_traffic_quality"
CONN_ID = "bkk_traffic_postgres"
SCHEDULE_ENV = "BKK_TRAFFIC_SCHEDULE_ENABLED"
SCHEDULE_CRON = "0 1 * * *"
SCHEDULE_TIMEZONE = "Asia/Bangkok"
API_POOL = os.environ.get("BKK_TRAFFIC_API_POOL", "default_pool")

log = logging.getLogger(__name__)


def quality_schedule():
    if os.environ.get(SCHEDULE_ENV, "false").strip().lower() not in ("1", "true", "yes"):
        return None
    from airflow.timetables.trigger import CronTriggerTimetable

    return CronTriggerTimetable(SCHEDULE_CRON, timezone=SCHEDULE_TIMEZONE)


# ---- configuration hooks (overridden in tests) -------------------------------

def bkk_dsn() -> str:
    from airflow.sdk import Connection
    from psycopg.conninfo import make_conninfo

    conn = Connection.get(CONN_ID)
    return make_conninfo(host=conn.host, port=conn.port or 5432, dbname=conn.schema,
                         user=conn.login, password=conn.password)


def _configure() -> None:
    from bkk_traffic import storage

    storage.configure(bkk_dsn())


def _scraping_stopped() -> bool:
    return str(Variable.get("bkk_scrape_stopped", "false")).lower() == "true"


def report_day_for(run_after) -> "pendulum.Date":
    """The day being reported: the run's run_after in Asia/Bangkok, minus one day."""
    return pendulum.instance(run_after).in_timezone(SCHEDULE_TIMEZONE).date() - timedelta(days=1)


@dag(
    dag_id=DAG_ID,
    schedule=quality_schedule(),
    start_date=pendulum.datetime(2026, 10, 1, tz=SCHEDULE_TIMEZONE),
    catchup=False,
    max_active_runs=1,
    default_args={"owner": "bkk_traffic", "retries": 0},
    tags=["bkk_traffic", "quality"],
)
def bkk_traffic_quality():
    @task(multiple_outputs=False, pool=API_POOL, execution_timeout=timedelta(minutes=10))
    def refresh_event_types() -> dict:
        from bkk_traffic import scrape

        if _scraping_stopped():
            raise AirflowSkipException("scraping stopped (Variable bkk_scrape_stopped=true)")
        _configure()
        return scrape.refresh_event_types()

    @task(multiple_outputs=False)
    def detect_missing_eids(previous: dict) -> dict:
        from bkk_traffic import scrape

        _configure()
        return scrape.detect_missing_eids()

    @task(multiple_outputs=False, pool=API_POOL, execution_timeout=timedelta(minutes=8))
    def recover_missing_eids(detected: dict) -> dict:
        from bkk_traffic import config, scrape

        if _scraping_stopped():
            raise AirflowSkipException("scraping stopped (Variable bkk_scrape_stopped=true)")
        _configure()
        limit = int(Variable.get("bkk_recover_per_run", config.DEFAULT_RECOVER_PER_RUN))
        max_seconds = int(Variable.get("bkk_recover_max_seconds", config.DEFAULT_RECOVER_MAX_SECONDS))
        return scrape.recover_missing_eids(limit, max_seconds)

    @task(multiple_outputs=False)
    def quality_checks(recovered: dict) -> dict:
        from bkk_traffic import quality

        _configure()
        day = report_day_for(get_current_context()["dag_run"].run_after)
        report = quality.run_quality_checks(day)
        return {"report_day": report["report_day"], "overall": report["overall"],
                "problems": [c for c in report["checks"] if c["status"] != "OK"]}

    @task(multiple_outputs=False)
    def gate(result: dict) -> dict:
        for p in result["problems"]:
            log.info("[%s] %s: %s %s", p["status"], p["check"], p["value"], p["detail"])
        if result["overall"] == "FAIL":
            raise AirflowFailException(f"data quality FAIL for {result['report_day']} - see "
                                       f"data/bkk_traffic/quality/dt={result['report_day']}/report.md")
        return result

    gate(quality_checks(recover_missing_eids(detect_missing_eids(refresh_event_types()))))


quality_dag = bkk_traffic_quality()
