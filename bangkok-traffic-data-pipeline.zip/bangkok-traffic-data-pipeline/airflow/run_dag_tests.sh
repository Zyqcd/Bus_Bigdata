#!/usr/bin/env bash
# Runs the whole test suite (including tests/test_airflow_dag.py) inside the
# Airflow image. Uses a throwaway SQLite metadata database under /tmp so test DAG
# runs never appear in the real Airflow UI, and unsets the real database
# connection so no test can reach namtang_db.
#
#   docker compose -f airflow/docker-compose.yml run --rm airflow-cli
set -euo pipefail

export AIRFLOW_HOME=/tmp/airflow-test
export PYTHONDONTWRITEBYTECODE=1   # no Linux .pyc files in the mounted Windows checkout
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN="sqlite:///${AIRFLOW_HOME}/airflow.db"
unset AIRFLOW_CONN_NAMTANG_POSTGRES
mkdir -p "${AIRFLOW_HOME}"
airflow db migrate > "${AIRFLOW_HOME}/migrate.log" 2>&1 || { cat "${AIRFLOW_HOME}/migrate.log"; exit 1; }

cd /opt/namtang
python -m pytest -q -p no:cacheprovider "${@:-tests}"   # default: the whole suite
