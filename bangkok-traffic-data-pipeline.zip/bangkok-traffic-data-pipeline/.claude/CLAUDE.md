# Claude Code Instructions

This project has shared AI development rules.

Before working on the project, read:

.ai/PROJECT_RULES.md

The rules in PROJECT_RULES.md are the primary project
rules and must be followed for all development tasks.

Do not create conflicting rules unless explicitly requested
by the user.