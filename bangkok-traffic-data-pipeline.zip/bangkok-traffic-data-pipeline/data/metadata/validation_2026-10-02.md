# GTFS validation — data/clean/namtang/2026-10-02

- **Overall status:** ERROR (3 errors, 10 warnings)
- **feed_version:** 20261001
- **feed_sha256:** `e5d8b18ceb00bf7a4d02caa610db2fa565b49b17e872a4649a1531efbd4e5302`
- **Validated at (UTC):** 2026-10-02T13:15:31+00:00
- **Data modified:** none; raw and clean data were only read

## Sections

| Section | Status |
|---|---|
| lineage | PASS |
| exact_duplicates | WARNING |
| logical_keys | ERROR |
| foreign_keys | ERROR |
| stop_times | WARNING |
| trips_routes_stops | WARNING |
| shapes | WARNING |
| frequencies | WARNING |
| calendar | WARNING |
| fares | ERROR |
| row_counts | PASS |

## Row counts

| Table | Raw | Clean | Rejected | Exact duplicates |
|---|---:|---:|---:|---:|
| agency | 126 | 126 | 0 | 0 |
| calendar | 7 | 7 | 0 | 0 |
| calendar_dates | 105 | 105 | 0 | 0 |
| fare_attributes | 946,175 | 946,175 | 0 | 0 |
| fare_rules | 946,175 | 946,175 | 0 | 0 |
| feed_info | 1 | 1 | 0 | 0 |
| frequencies | 10,072 | 10,072 | 0 | 1 |
| routes | 2,069 | 2,069 | 0 | 0 |
| shapes | 3,873,114 | 3,873,114 | 0 | 0 |
| stop_times | 159,358 | 159,358 | 0 | 0 |
| stops | 17,081 | 17,081 | 0 | 0 |
| trips | 4,656 | 4,656 | 0 | 0 |
| **total** | 5,958,939 | 5,958,939 | 0 | |

_Totals add rows from different GTFS tables; they are not trip counts._

## ERROR findings (3)

- **logical_keys / agency logical key ['agency_id']**: 2 repeated keys over 4 rows (2 conflicting, 0 identical)
- **foreign_keys / fare_rules.origin_id -> stops.zone_id**: 61 rows reference 1 values missing from stops.zone_id
- **foreign_keys / fare_rules.destination_id -> stops.zone_id**: 59 rows reference 1 values missing from stops.zone_id

## WARNING findings (10)

- **exact_duplicates / frequencies exact duplicate rows**: 1 extra copies in 1 groups (compared on all 4 source columns)
- **logical_keys / frequencies logical key ['trip_id', 'start_time', 'end_time']**: 1 repeated keys over 2 rows (0 conflicting, 1 identical)
- **stop_times / same stop_id on consecutive stops**: 3 rows repeat the previous stop_id within a trip
- **trips_routes_stops / routes without trips**: 4 routes are never referenced
- **trips_routes_stops / stops not used by stop_times**: 219 stops are never referenced
- **shapes / repeated consecutive coordinates**: 815348 points repeat the previous point's coordinates within the same shape (valid but redundant; not an error)
- **shapes / shapes not used by trips**: 7 shapes are never referenced
- **frequencies / single_departure rows**: 555 rows encode a single departure (headway_secs = 0, start_time == end_time); accepted, not expanded
- **frequencies / duplicate (trip_id, start_time, end_time)**: 1 repeated keys
- **calendar / calendar_dates consistent with calendar**: 6 additions on days the service already runs; 27 removals on days it does not run
