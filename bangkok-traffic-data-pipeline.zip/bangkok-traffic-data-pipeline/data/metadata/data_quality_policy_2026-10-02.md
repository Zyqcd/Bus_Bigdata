# Data quality policy: Namtang GTFS 2026-10-02 (feed 20261001) - APPROVED

> **APPROVED** by tatphong.t@ku.th (6621600861-Tatphong) at 2026-10-02T20:54:57+07:00 (Asia/Bangkok). Active policy file: `data_quality_policy_2026-10-02.json`.

**Feed:** `feed_version` 20261001 · SHA-256 `e5d8b18ceb00bf7a4d02caa610db2fa565b49b17e872a4649a1531efbd4e5302`
**Clean data:** `data/clean/namtang/2026-10-02/` (5,958,939 rows, 0 rejected; clean run `20261002T131454Z-64affac4`)
**Based on:** [validation_2026-10-02.json](validation_2026-10-02.json): overall ERROR, 3 errors, 10 warnings
**Derived from:** the approved policy for feed 20260930 ([data_quality_policy_2026-10-01.md](data_quality_policy_2026-10-01.md)). The DQ issues and decisions below are copied **verbatim**.

## Why the 20260930 decisions apply unchanged

- **Raw:** 11 of 12 GTFS files are byte-identical (same CRC-32 and size). Only `feed_info.txt` differs: `feed_version` 20260930 → 20261001.
- **Clean:** all 5,958,939 rows in the 12 tables are identical in content, schema and `source_row`.
- **Validation:** every check, count, status and example is identical: DQ-001 4 agency rows (CCT/SBT, source rows 22, 23, 87, 88), DQ-002 61 + 59 = 120 zone-221 fare rules, the same 10 warnings. The only difference is the scrape date in one summary text.
- **DQ-011 / DQ-012** are analysis-layer counts and haven't been measured for this feed yet (analysis not run). They follow from the identical source rows and must be confirmed when analysis runs.

The issue texts below (copied from the 20260930 policy) describe the same rows; feed-specific paths in them refer to the 20260930 snapshot, whose data is identical.

## Rules that apply to every issue

- The raw ZIP and the clean Parquet are **never modified** to resolve these issues.
- **Nothing is fabricated:** no invented IDs, zones, coordinates, headways or rows.
- Any fix belongs in a separate downstream layer that keeps `source_row`, `feed_sha256` and `feed_version`.
- Every downstream result that excludes flagged records must say how many it excluded.

| Classification | Meaning |
|---|---|
| **PRESERVE** | Records stay exactly as published |
| **FLAG** | Downstream must identify, mark and report the affected records |
| **EXCLUDE_DOWNSTREAM_ONLY** | A downstream calculation may leave them out; the clean data keeps them |
| **DO_NOT_REMAP** | IDs must not be guessed, renamed, merged or replaced |

## Errors

### DQ-001: `agency_id` collisions (CCT, SBT)
`PRESERVE` `FLAG` `DO_NOT_REMAP`

| agency_id | source_row | Operator |
|---|---|---|
| CCT | 22 | เชิดชัยทัวร์ (Cherdchai Tour) |
| CCT | 23 | โชคเจริญชัย ทรานสปอร์ต (Chokcharoenchai Transport) |
| SBT | 87 | สมบัติทัวร์ (Sombat Tour) |
| SBT | 88 | เอสบี สันติวิชช์ ทัวร์ (SB Suntivich Tour) |

**Records affected:**
- 70 routes (CCT 28, SBT 42)
- the 123 trips and 666 stop_times on those routes
- 775 fare_attributes (CCT 245, SBT 530)
- the 775 fare_rules that use those fares

- **Clean/source layer:** keep all rows unchanged.
- **Downstream:** `agency_id` alone cannot identify the operator for these records, so treat the operator as unresolved.
- ⚠️ **Join trap:** joining `routes` or `fare_attributes` to `agency` on `agency_id` gives 2 matches per affected ID. That duplicates rows and double-counts.
- Operator-level results must exclude these records or report them separately. Group by `agency_id` only as a source code, not as an operator.
- **Rationale:** the feed has no field that says which operator owns a route or fare. Remapping would be a guess.

### DQ-002: fare rules pointing at zone 221, which doesn't exist
`PRESERVE` `FLAG` `EXCLUDE_DOWNSTREAM_ONLY` `DO_NOT_REMAP`

**120 fare_rules are affected:**
- `origin_id = '221'`: 61 rows
- `destination_id = '221'`: 59 rows
- none have both

They cover 120 distinct fare_ids and 8 routes, at source rows 24332–25392. In this feed `zone_id == stop_id` for every stop, and stop 221 isn't present anywhere.

- **Clean/source layer:** keep all 120 rules. Don't create zone 221, stop 221 or coordinates for it.
- **Downstream:** mark these rules as "unresolved fare zone". Zone- or stop-based fare analysis may exclude them, as long as it reports the 120 excluded rules. Never match them to a nearby stop.
- **Rationale:** these are real published rules whose zone is missing, probably left over from a removed stop.

## Warnings

### DQ-003: duplicate frequency window (trip 6160)
`PRESERVE` `FLAG`

Trip `6160`, `05:00:00–22:00:00`, `headway_secs` 900, appears twice (source rows 7222 and 7223).

- **Clean/source layer:** keep both rows. Delete neither.
- **Downstream:** service, departure and frequency calculations **MUST** treat identical windows as one window, matching on trip_id, start_time, end_time and headway_secs. Never double-count this window. Remove the duplicate only inside the derived calculation, and record that one duplicate was collapsed.

### DQ-004: 555 `single_departure` rows (decided in Phase 3)
`PRESERVE` `FLAG`

These rows are accepted as clean, with `headway_secs = 0` unchanged, and flagged by `is_single_departure = true`.

- **Downstream:** read each one as **one departure at `start_time`**. Never divide by `headway_secs` for these rows.
- Expanding them into service instances is a separate derived step, and those rows are never counted as collected records.

### Other warnings: keep them, flag them, no data changes

| ID | Issue | Table | Count | Classification | What downstream should do |
|---|---|---|---:|---|---|
| DQ-005 | Same stop on consecutive stops (trips 3977, 4018, 4885). 2 of these 3 same-stop hops take 0 seconds; they count here, not under DQ-012 | stop_times | 3 rows | PRESERVE, FLAG | Allow zero-length segments; avoid dividing by zero distance |
| DQ-006 | Repeated consecutive shape coordinates (21% of points; 0 exact duplicates, 0 key conflicts) | shapes | 815,348 points | PRESERVE, FLAG | May collapse repeated points in derived geometry only; don't read point counts as geographic detail |
| DQ-007 | Routes with no trips (2730, 2890, 3187, 3193) | routes | 4 routes | PRESERVE, FLAG, EXCLUDE_DOWNSTREAM_ONLY | May leave out of "active network" metrics, and report it |
| DQ-008 | Stops not used by stop_times | stops | 219 stops | PRESERVE, FLAG, EXCLUDE_DOWNSTREAM_ONLY | May leave out of served-stop and coverage metrics, and report it |
| DQ-009 | Shapes not used by any trip (4343–4350, excluding 4348) | shapes | 7 shapes | PRESERVE, FLAG, EXCLUDE_DOWNSTREAM_ONLY | May leave out of route-geometry analysis, and report it |
| DQ-010 | No-op calendar_dates (6 redundant additions, 27 removals on inactive days) | calendar_dates | 33 rows | PRESERVE, FLAG | Apply normally (the result is the same); don't count them as real service changes |

The exact filter for selecting each issue's affected rows is in the JSON version (`selector`).

## Derived-data quality policy (Phase 4.5)

### DQ-011: 564 derived segments with unrealistic segment speed
`PRESERVE` `FLAG` `EXCLUDE_DOWNSTREAM_ONLY`

There are 564 derived segments with `segment_speed_kmh > 150`, with a maximum observed speed of 2,336 km/h.

- Preserve the derived segment values as calculated.
- Add the boolean flag `unrealistic_segment_speed`.
- Do not repair, cap or replace the speed values.
- Exclude these segments downstream only for realistic bus-speed analysis. Any such exclusion must report the 564 affected segments.

### DQ-012: 1,092 different-stop segments with zero travel time
`PRESERVE` `FLAG` `DO_NOT_FILL_TIME`

| Zero-second segments (`travel_time_to_next_secs = 0`) | Count | Covered by |
|---|---:|---|
| Between different stops | **1,092** | **DQ-012** |
| Between the same stop | 2 | DQ-005 |
| **Total** | 1,094 | |

No rows were modified or reclassified in the data. This only clarifies which policy covers which rows.

- Preserve the segment records. Source arrival and departure times stay unchanged.
- Flag them with the boolean `zero_second_segment`.
- Don't fill or infer the travel time.
- `segment_speed_kmh` stays `NULL` for these segments.
- Travel-time or speed analysis may exclude these 1,092 segments, but must report how many it excluded.
- This may come from source times being rounded to the minute, but that isn't confirmed.

## Frequency-based trip interpretation

Frequency-based trips use relative stop-time templates. `first_departure_time`, `last_arrival_time`, and `duration_seconds` must not automatically be interpreted as actual service-date clock times. Keep `stop_times_are_relative_template`.

Use the frequency start/end/headway rules and the single-departure rules. Do not create service instances.

Estimated departures are labeled `DERIVED_ESTIMATE` and are never presented as observed departures:

- normal frequency: `ceil((end-start)/headway)`
- single departure: `1`

The end-time boundary is an assumption: departures are counted at `start + k*headway` while they remain before `end`, consistent with the stated ceiling convention. This estimate must not be represented as an observed departure count.
