"""PUBLISH: export silver (without duplicate reports) as Parquet, ROWS_PER_FILE (10,000) rows per file.

data/bkk_traffic/parquet/<dataset>/part-00000.parquet, ... + _manifest.json
Written to a temporary folder first and then swapped, so readers never see half a set.

Ported in Phase 9.3 from the friend's parquet_export.py. The datasets, schemas, file
layout and manifest format are unchanged (the published files stay byte-compatible:
timestamps are formatted back to 'YYYY-MM-DD HH:MM:SS' text). PostgreSQL changes:
reads through the incidents_bangkok / accidents_bangkok views, streams with a
server-side cursor, and the signature query is PostgreSQL SQL.
"""
import json
import shutil

import pyarrow as pa
import pyarrow.parquet as pq

from bkk_traffic import config, storage

ROWS_PER_FILE = 10_000
PARQUET_DIR = config.PARQUET_DIR

INCIDENT_SCHEMA = pa.schema([
    ("eid", pa.int64()), ("nid", pa.int64()),
    ("start_time", pa.string()), ("stop_time", pa.string()),
    ("createtime", pa.string()), ("updatedtime", pa.string()),
    ("event_type_id", pa.int16()), ("event_type", pa.string()), ("traffic_relevance", pa.string()),
    ("is_accident", pa.int8()), ("is_bangkok", pa.int8()),
    ("severity", pa.int16()),
    ("title", pa.string()), ("title_en", pa.string()),
    ("comment", pa.string()), ("comment_en", pa.string()),
    ("latitude", pa.float64()), ("longitude", pa.float64()),
    ("province_guess", pa.string()), ("contributor", pa.string()), ("source", pa.string()),
    ("status", pa.string()), ("fetched_via", pa.string()),
    ("first_seen_at", pa.string()), ("last_seen_at", pa.string()),
    ("dq_flags", pa.string()),
])
TIMESTAMP_COLUMNS = {"start_time", "stop_time", "createtime", "updatedtime", "first_seen_at", "last_seen_at",
                     "ts_local", "fetched_at"}


def _select(columns) -> str:
    return ",".join(f"to_char({c}, 'YYYY-MM-DD HH24:MI:SS') AS {c}" if c in TIMESTAMP_COLUMNS else c
                    for c in columns)


_INC_COLS = _select(INCIDENT_SCHEMA.names)
TRAFFIC_INDEX_SCHEMA = pa.schema([("ts", pa.int64()), ("ts_local", pa.string()),
                                  ("index_value", pa.float64()), ("source", pa.string())])
TRAVEL_TIMES_SCHEMA = pa.schema([("route", pa.string()), ("fetched_at", pa.string()), ("distance_m", pa.float64()),
                                 ("duration_s", pa.float64()), ("duration_min", pa.float64()),
                                 ("from_lat", pa.float64()), ("from_lon", pa.float64()),
                                 ("to_lat", pa.float64()), ("to_lon", pa.float64())])

# name -> (query, schema, table/view used for the signature and for verify_postgresql)
DATASETS = {
    "incidents_bangkok": (f"SELECT {_INC_COLS} FROM incidents_bangkok ORDER BY eid", INCIDENT_SCHEMA),
    "accidents_bangkok": (f"SELECT {_INC_COLS} FROM accidents_bangkok ORDER BY eid", INCIDENT_SCHEMA),
    "traffic_index": (f"SELECT {_select(TRAFFIC_INDEX_SCHEMA.names)} FROM traffic_index_history ORDER BY ts",
                      TRAFFIC_INDEX_SCHEMA),
    "travel_times": (f"SELECT {_select(TRAVEL_TIMES_SCHEMA.names)} FROM travel_times ORDER BY fetched_at, route",
                     TRAVEL_TIMES_SCHEMA),
}
SOURCE_RELATION = {"incidents_bangkok": "incidents_bangkok", "accidents_bangkok": "accidents_bangkok",
                   "traffic_index": "traffic_index_history", "travel_times": "travel_times"}


def _signature(conn, name) -> str:
    """Data signature (row count + latest update) used to skip rewriting unchanged datasets."""
    relation = SOURCE_RELATION[name]
    if name in ("incidents_bangkok", "accidents_bangkok"):
        agg = "to_char(MAX(last_seen_at), 'YYYY-MM-DD HH24:MI:SS')"
    elif name == "traffic_index":
        agg = "MAX(ts) || '-' || SUM(index_value)"
    else:
        agg = "to_char(MAX(fetched_at), 'YYYY-MM-DD HH24:MI:SS')"
    row = conn.execute(f"SELECT COUNT(*), {agg} FROM {relation}").fetchone()
    return f"{row[0]}|{row[1]}|{ROWS_PER_FILE}"


def _export_dataset(conn, name, sql, schema, validation=None) -> dict:
    final_dir = PARQUET_DIR / name
    tmp_dir = PARQUET_DIR / f".{name}.tmp"
    signature = _signature(conn, name)
    try:
        old = json.loads((final_dir / "_manifest.json").read_text(encoding="utf-8"))
        if old.get("signature") == signature:
            return {"rows": old["total_rows"], "files": len(old["files"]), "skipped": True}
    except (OSError, ValueError, KeyError):
        pass
    shutil.rmtree(tmp_dir, ignore_errors=True)
    tmp_dir.mkdir(parents=True)

    files, total, part = [], 0, 0
    with conn.cursor(name=f"export_{name}") as cur:      # server-side cursor: never the whole set in memory
        cur.itersize = ROWS_PER_FILE
        cur.execute(sql)
        while True:
            rows = cur.fetchmany(ROWS_PER_FILE)
            if not rows:
                break
            columns = list(zip(*rows))
            table = pa.Table.from_arrays(
                [pa.array(col, type=field.type) for col, field in zip(columns, schema)], schema=schema)
            fname = f"part-{part:05d}.parquet"
            pq.write_table(table, tmp_dir / fname, compression="zstd")
            key = schema.names[0]
            files.append({"file": fname, "rows": len(rows), f"{key}_min": rows[0][0], f"{key}_max": rows[-1][0]})
            total += len(rows)
            part += 1

    manifest = {"dataset": name, "generated_at": storage.now_str(), "rows_per_file": ROWS_PER_FILE,
                "total_rows": total, "signature": signature, "validation": validation, "files": files}
    (tmp_dir / "_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    shutil.rmtree(final_dir, ignore_errors=True)
    tmp_dir.rename(final_dir)
    return {"rows": total, "files": len(files)}


def export_all(validation: dict | None = None) -> dict:
    """Called through publish.publish_parquet() only (the validation gate must pass first)."""
    PARQUET_DIR.mkdir(parents=True, exist_ok=True)
    with storage.connect() as conn:
        return {name: _export_dataset(conn, name, sql, schema, validation)
                for name, (sql, schema) in DATASETS.items()}


def verify_postgresql() -> dict:
    """Published manifests vs PostgreSQL right now: row counts must be equal for every dataset.

    PostgreSQL is the source of truth; this proves the Parquet set on disk was produced
    from it and is complete (no rows are re-loaded: that would be circular)."""
    result, problems = {}, []
    with storage.connect() as conn:
        for name, relation in SOURCE_RELATION.items():
            try:
                manifest = json.loads((PARQUET_DIR / name / "_manifest.json").read_text(encoding="utf-8"))
            except (OSError, ValueError) as exc:
                problems.append(f"{name}: no readable manifest ({exc})")
                continue
            rows = conn.execute(f"SELECT COUNT(*) FROM {relation}").fetchone()[0]
            files_rows = sum(f["rows"] for f in manifest["files"])
            result[name] = {"postgresql_rows": rows, "manifest_rows": manifest["total_rows"],
                            "file_rows": files_rows}
            if not rows == manifest["total_rows"] == files_rows:
                problems.append(f"{name}: postgresql {rows}, manifest {manifest['total_rows']}, files {files_rows}")
    if problems:
        raise RuntimeError("published Parquet does not match PostgreSQL: " + "; ".join(problems))
    return result
