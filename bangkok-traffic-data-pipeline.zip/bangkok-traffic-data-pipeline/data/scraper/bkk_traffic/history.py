"""Traffic-index history: Longdo's 5-minute congestion index, published as one CSV per year.

Source: https://traffic.longdo.com/download -> /api/raw/trafficindex/{year}
        (CSV: timestamp,datetime,index; index 0-10 for Bangkok + vicinity, every 5 minutes).
Longdo's condition: cite "Longdo Traffic (https://traffic.longdo.com)".

Ported in Phase 9.5 from the friend's plugins/bkk_traffic/history.py to PostgreSQL
(docs/integration/bkk_traffic_history_mapping.md). Changes, all deliberate:
  * timestamps in explicit Asia/Bangkok time, and the file's own `datetime` must equal ts
    in UTC+7 (a 7-hour shift is rejected);
  * fail closed: one invalid row rejects the whole year file (rollback + failed run log),
    nothing is skipped silently;
  * one transaction per year: COPY into a session TEMP table, then one upsert that only
    changes rows whose value/source really differ (idempotent rerun);
  * a file value replaces a provisional realtime sample for the same ts (original rule);
    rows are never deleted and missing 5-minute points are never generated;
  * immutable raw copies named by content hash; run log in scrape_runs.
"""
import csv
import hashlib
import io
import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from bkk_traffic import config, storage
from bkk_traffic.client import LongdoClient

log = logging.getLogger(__name__)

URL = f"{config.BASE_URL}/api/raw/trafficindex/{{year}}"
FIRST_YEAR = 2012
HEADER = ["timestamp", "datetime", "index"]
JOB = "traffic_index_history"
DEFAULT_REFRESH_HOURS = 24          # the original DAG ran daily
FUTURE_TOLERANCE = timedelta(minutes=10)
INDEX_RANGE = (0.0, 10.0)
STEP_SECONDS = 300


class HistoryValidationError(ValueError):
    """The year file failed validation; nothing from it is written."""


@dataclass
class ParsedYear:
    year: int
    rows: list[tuple[int, str, float]]                  # (ts, ts_local, index_value), sorted by ts
    duplicates_collapsed: int = 0
    quality: dict = field(default_factory=dict)


def local_text(ts: int) -> str:
    return config.bangkok_from_epoch(ts).strftime("%Y-%m-%d %H:%M:%S")


def parse_year(text: str, year: int, now: datetime | None = None) -> ParsedYear:
    """Validate one downloaded year file. Raises HistoryValidationError on any invalid row."""
    now = now or config.bangkok_now()
    reader = csv.DictReader(io.StringIO(text.lstrip("﻿")))
    if reader.fieldnames != HEADER:
        raise HistoryValidationError(f"{year}: header {reader.fieldnames} != {HEADER}")
    lower = datetime(max(year, FIRST_YEAR), 1, 1)
    upper = min(datetime(year + 1, 1, 1), now + FUTURE_TOLERANCE)
    values: dict[int, float] = {}
    errors, duplicates = [], 0
    for line, r in enumerate(reader, start=2):
        raw_ts, raw_dt, raw_val = (r.get(k) for k in HEADER)
        try:
            ts = int(str(raw_ts).strip())
            value = float(str(raw_val).strip())
        except (TypeError, ValueError):
            errors.append(f"line {line}: unparseable timestamp/index {raw_ts!r}/{raw_val!r}")
            continue
        if not math.isfinite(value) or not INDEX_RANGE[0] <= value <= INDEX_RANGE[1]:
            errors.append(f"line {line}: index {value!r} outside {INDEX_RANGE}")
            continue
        local = config.bangkok_from_epoch(ts)
        if (raw_dt or "").strip() != local.strftime("%Y-%m-%dT%H:%M"):
            errors.append(f"line {line}: datetime {raw_dt!r} != ts {ts} in UTC+7 ({local:%Y-%m-%dT%H:%M})")
            continue
        if not lower <= local < upper:
            errors.append(f"line {line}: {local} outside [{lower}, {upper}) for file {year}")
            continue
        if ts in values:
            if values[ts] != value:
                errors.append(f"line {line}: conflicting duplicate ts {ts} ({values[ts]} vs {value})")
            else:
                duplicates += 1
            continue
        values[ts] = value
        if len(errors) > 20:
            break
    if errors:
        raise HistoryValidationError(f"{year}: {len(errors)} invalid row(s): " + "; ".join(errors[:5]))
    ordered = sorted(values)
    gaps = [(a, b) for a, b in zip(ordered, ordered[1:]) if b - a > STEP_SECONDS]
    quality = {
        "rows": len(ordered),
        "first": local_text(ordered[0]) if ordered else None,
        "last": local_text(ordered[-1]) if ordered else None,
        "misaligned_ts": sum(1 for t in ordered if t % STEP_SECONDS),       # metric only
        "gaps_over_5min": len(gaps),                                         # metric only: never filled
        "largest_gap_minutes": max(((b - a) // 60 for a, b in gaps), default=0),
        "source_freshness_hours": round((now - config.bangkok_from_epoch(ordered[-1])).total_seconds() / 3600, 1)
        if ordered else None,
    }
    rows = [(t, local_text(t), values[t]) for t in ordered]
    return ParsedYear(year, rows, duplicates, quality)


def years_to_refresh(conn, today: datetime | None = None) -> list[int]:
    """Current Bangkok year, last year during the first week of January, and any year with no rows."""
    today = today or config.bangkok_now()
    years = {today.year}
    if today.month == 1 and today.day <= 7:
        years.add(today.year - 1)
    have = {int(r[0]) for r in conn.execute(
        "SELECT DISTINCT extract(year FROM ts_local)::int FROM traffic_index_history")}
    years |= {y for y in range(FIRST_YEAR, today.year) if y not in have}
    return sorted(years)


def _save_raw(text: str, year: int) -> str:
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    folder = config.RAW_DIR / JOB
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{year}_{sha[:12]}.csv"
    if not path.exists():
        path.write_text(text, encoding="utf-8")
    return sha


def write_year(conn, parsed: ParsedYear) -> dict:
    """Upsert one validated year in ONE transaction. Raises (and rolls back) on any problem."""
    source = f"history:{parsed.year}"
    with conn.transaction():
        conn.execute("DROP TABLE IF EXISTS pg_temp.tmp_traffic_index_history")
        conn.execute("CREATE TEMP TABLE tmp_traffic_index_history (ts bigint PRIMARY KEY, ts_local timestamp "
                     "NOT NULL, index_value double precision NOT NULL) ON COMMIT DROP")
        with conn.cursor().copy("COPY tmp_traffic_index_history (ts, ts_local, index_value) FROM STDIN") as copy:
            for row in parsed.rows:
                copy.write_row(row)
        shifted = conn.execute(
            "SELECT count(*) FROM tmp_traffic_index_history t JOIN traffic_index_history h USING (ts) "
            "WHERE h.ts_local <> t.ts_local").fetchone()[0]
        if shifted:
            raise HistoryValidationError(f"{parsed.year}: {shifted} stored row(s) have a different ts_local for "
                                         "the same ts (timezone shift); nothing written")
        changed = conn.execute(
            "INSERT INTO traffic_index_history (ts, ts_local, index_value, source) "
            "SELECT ts, ts_local, index_value, %s FROM tmp_traffic_index_history "
            "ON CONFLICT (ts) DO UPDATE SET index_value = excluded.index_value, source = excluded.source, "
            "baseline_load_id = NULL "
            "WHERE (traffic_index_history.index_value, traffic_index_history.source) "
            "IS DISTINCT FROM (excluded.index_value, excluded.source) "
            "RETURNING (xmax = 0) AS inserted", (source,)).fetchall()
        inserted = sum(1 for r in changed if r[0])
        mismatches = conn.execute(
            "SELECT count(*) FROM traffic_index_history WHERE ts_local <> (to_timestamp(ts) AT TIME ZONE "
            "'Asia/Bangkok')").fetchone()[0]
        if mismatches:
            raise HistoryValidationError(f"{mismatches} ts_local mismatch(es) after the upsert; rolled back")
    return {"rows": len(parsed.rows), "inserted": inserted, "updated": len(changed) - inserted,
            "unchanged": len(parsed.rows) - len(changed), "duplicates_collapsed": parsed.duplicates_collapsed,
            "quality": parsed.quality}


def _hours_since(text: str | None) -> float | None:
    if not text:
        return None
    return (config.bangkok_now() - datetime.strptime(text, "%Y-%m-%d %H:%M:%S")).total_seconds() / 3600


def run(years: list[int] | None = None, refresh_hours: float | None = None) -> dict:
    """Refresh traffic_index_history from Longdo's yearly files (validated, idempotent)."""
    started = storage.now_str()
    with storage.connect() as conn:
        state = storage.get_checkpoint(conn, JOB)
        since = _hours_since(state.get("last_success"))
        if refresh_hours and years is None and since is not None and since < refresh_hours:
            return {"skipped": True, "reason": f"last successful refresh {since:.1f} h ago (< {refresh_hours} h)",
                    "last_success": state.get("last_success")}
        todo = years or years_to_refresh(conn)
        conn.commit()
    client = LongdoClient(JOB)
    result, shas = {}, dict(state.get("file_sha256") or {})
    with storage.connect() as conn:
        try:
            for year in todo:
                text = client.get_text(URL.format(year=year))
                shas[str(year)] = _save_raw(text, year)
                result[year] = write_year(conn, parse_year(text, year))
                log.info("traffic index history %s: %s", year, {k: v for k, v in result[year].items() if k != "quality"})
            latest = conn.execute("SELECT to_char(max(ts_local), 'YYYY-MM-DD HH24:MI:SS') FROM traffic_index_history "
                                  "WHERE source LIKE 'history:%'").fetchone()[0]
            storage.set_checkpoint(conn, JOB, {
                "last_success": storage.now_str(), "years": todo, "file_sha256": shas,
                "last_result": {str(y): {k: v for k, v in r.items() if k != "quality"} for y, r in result.items()},
                "latest_file_point": latest,
            })
            storage.log_run(conn, JOB, started, client.request_count, sum(r["rows"] for r in result.values()),
                            sum(r["inserted"] for r in result.values()), "success",
                            ", ".join(f"{y}: +{r['inserted']} ~{r['updated']}" for y, r in result.items()))
        except Exception as err:
            conn.rollback()
            storage.log_run(conn, JOB, started, client.request_count, 0, 0, "failed", f"{type(err).__name__}: {err}"[:500])
            conn.commit()
            raise
    return {"skipped": False, "years": {str(y): r for y, r in result.items()}, "latest_file_point": latest}


def verify(conn) -> dict:
    """History/current consistency (raises on a correctness problem; interval figures are metrics)."""
    q = lambda sql: conn.execute(sql).fetchone()  # noqa: E731
    checks = {
        "ts_local_mismatches": q("SELECT count(*) FROM traffic_index_history WHERE ts_local <> "
                                 "(to_timestamp(ts) AT TIME ZONE 'Asia/Bangkok')")[0],
        "current_ts_local_mismatches": q("SELECT count(*) FROM traffic_index WHERE ts_local <> "
                                         "(to_timestamp(ts) AT TIME ZONE 'Asia/Bangkok')")[0],
        "current_missing_in_history": q("SELECT count(*) FROM traffic_index c WHERE NOT EXISTS "
                                        "(SELECT 1 FROM traffic_index_history h WHERE h.ts = c.ts)")[0],
        "realtime_value_differs": q("SELECT count(*) FROM traffic_index c JOIN traffic_index_history h USING (ts) "
                                    "WHERE h.source = 'realtime' AND h.index_value IS DISTINCT FROM c.index_value")[0],
        "file_replaced_realtime": q("SELECT count(*) FROM traffic_index c JOIN traffic_index_history h USING (ts) "
                                    "WHERE h.source LIKE 'history:%'")[0],
    }
    bad = {k: v for k, v in checks.items() if k in ("ts_local_mismatches", "current_ts_local_mismatches",
                                                    "current_missing_in_history", "realtime_value_differs") and v}
    if bad:
        raise RuntimeError(f"traffic index history inconsistent: {bad}")
    return checks
