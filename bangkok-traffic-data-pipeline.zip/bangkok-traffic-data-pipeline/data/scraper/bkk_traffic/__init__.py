"""BKK Traffic pipeline (source: traffic.longdo.com), PostgreSQL storage in schema bkk_traffic.

Ported in Phase 9.3 from the friend's Airflow 2.10 / SQLite implementation
(plugins/bkk_traffic in scrapping--main). Business rules are unchanged; storage
is PostgreSQL only (no SQLite). Independent of the Namtang pipeline.
See docs/integration/bkk_traffic_phase9_3.md.
"""
