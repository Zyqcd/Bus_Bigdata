"""Data quality report: what is missing (days / time slots / eids / fields) and what looks wrong.

Writes data/bkk_traffic/quality/dt=<day>/report.json, report.md, quarantine_rows.csv,
missing_days.csv, missing_eids_pending.csv.

Ported in Phase 9.7 from the friend's plugins/bkk_traffic/quality.py to PostgreSQL
(docs/integration/bkk_traffic_quality_mapping.md). Check names, thresholds, statuses and the
report files are unchanged. Adaptations: explicit Asia/Bangkok "now", half-open timestamp ranges
instead of substr(), extract() for 15-minute slots, type-aware NULL checks, text formatting of
timestamps, and a documented coverage start when no backfill checkpoint exists.
"""
import csv
import json
from datetime import date, datetime, time, timedelta

from bkk_traffic import config, storage

OK, WARN, FAIL = "OK", "WARN", "FAIL"
KEY_FIELDS = ("title", "latitude", "longitude", "start_time", "stop_time", "severity", "event_type")
TEXT_FIELDS = {"title", "event_type"}          # '' is only meaningful for text columns (Phase 9.2 A14)
EXPECTED_SNAPSHOTS_PER_DAY = 96                 # 15-minute realtime cadence
DEFAULT_COVERAGE_START = "2015-12-29"           # the friend's last reported window: 2015-12-30..2026-10-01
TS_TEXT = "YYYY-MM-DD HH24:MI:SS"


def _check(name, status, value, detail=""):
    return {"check": name, "status": status, "value": value, "detail": detail}


def _parse(text: str | None) -> datetime | None:
    return datetime.strptime(text, "%Y-%m-%d %H:%M:%S") if text else None


def run_quality_checks(report_day: date | None = None, coverage_start: str | None = None,
                       now: datetime | None = None) -> dict:
    now = now or config.bangkok_now()                      # Bangkok wall-clock, never the container TZ
    today = now.date()
    report_day = report_day or (today - timedelta(days=1))
    day_s = report_day.isoformat()
    day0 = datetime.combine(report_day, time.min)
    day1 = day0 + timedelta(days=1)
    checks, extras = [], {}
    with storage.connect() as conn:
        def q(sql, *args):
            return conn.execute(sql, args or None).fetchone()[0]

        total = q("SELECT COUNT(*) FROM incidents")
        if total == 0:
            checks.append(_check("has_data", FAIL, 0, "no incident data yet"))
            return _write_report(day_s, checks, extras)

        # 1) freshness, measured from realtime only
        rt_last = storage.get_checkpoint(conn, "realtime").get("last_success")
        rt_age = (now - _parse(rt_last)).total_seconds() / 3600 if rt_last else 999
        checks.append(_check("realtime_last_success_hours", OK if rt_age < 1 else WARN if rt_age < 3 else FAIL,
                             round(rt_age, 2), f"last realtime success {rt_last}"))
        newest = q(f"SELECT to_char(MAX(createtime), '{TS_TEXT}') FROM incidents WHERE createtime <= %s", now)
        age_h = (now - _parse(newest)).total_seconds() / 3600 if newest else 999
        checks.append(_check("newest_event_age_hours", OK if age_h < 3 else WARN if age_h < 12 else FAIL,
                             round(age_h, 2), f"newest Bangkok event created {newest}"))
        last_seen = newest or now.strftime("%Y-%m-%d")

        # 2) field completeness (% empty)
        completeness = {}
        for f in KEY_FIELDS:
            condition = f"{f} IS NULL OR {f} = ''" if f in TEXT_FIELDS else f"{f} IS NULL"
            completeness[f] = round(100 * q(f"SELECT COUNT(*) FROM incidents WHERE {condition}") / total, 2)
        completeness["event_type_unknown"] = round(
            100 * q("SELECT COUNT(*) FROM incidents WHERE event_type = 'Unknown'") / total, 2)
        worst = max(v for k, v in completeness.items() if k in ("latitude", "longitude", "start_time"))
        checks.append(_check("field_null_pct", OK if worst < 1 else WARN if worst < 5 else FAIL,
                             completeness, "% empty per field (all rows)"))

        # 3) validity and clean results
        not_bkk = q("SELECT COUNT(*) FROM incidents WHERE is_bangkok = 0")
        checks.append(_check("non_bangkok_rows", OK if not_bkk == 0 else FAIL, not_bkk,
                             "must be 0 - Bangkok only"))
        text_only = q("SELECT COUNT(*) FROM incidents WHERE province_guess = 'bangkok(text)'")
        checks.append(_check("bangkok_by_text_only", OK if text_only < 0.05 * total else WARN, text_only,
                             "no coordinates, Bangkok decided from text - sample-check"))
        flags = {}
        for (f,) in conn.execute("SELECT dq_flags FROM incidents WHERE dq_flags IS NOT NULL"):
            for name in f.split(","):
                flags[name] = flags.get(name, 0) + 1
        checks.append(_check("clean_rule_flags", OK, flags, "rows corrected by clean (still exported)"))
        reasons = {}
        for (r,) in conn.execute("SELECT reasons FROM quarantine"):
            for name in r.split(","):
                reasons[name] = reasons.get(name, 0) + 1
        n_q = q("SELECT COUNT(*) FROM quarantine")
        q_pct = 100 * n_q / (total + n_q)
        checks.append(_check("quarantine_rows", OK if n_q == 0 else WARN if q_pct < 5 else FAIL,
                             {"rows": n_q, **reasons}, "failed the row rules - not exported (quarantine_rows.csv)"))
        dup = q("SELECT COUNT(*) FROM incidents WHERE is_duplicate = 1")
        checks.append(_check("duplicate_reports_removed", OK, dup, "duplicate reports, not exported"))
        by_source = {r[0]: r[1] for r in conn.execute("SELECT fetched_via, COUNT(*) FROM incidents GROUP BY 1")}
        checks.append(_check("rows_by_source", OK, by_source, "rows per fetch path"))
        pending = q("SELECT COUNT(*) FROM bronze_incidents WHERE cleaned_at IS NULL")
        checks.append(_check("bronze_not_cleaned", OK if pending < 1000 else WARN, pending))
        extras["quarantine_sample"] = [
            {"eid": r[0], "reasons": r[1], "detected_at": r[2]} for r in conn.execute(
                f"SELECT eid, reasons, to_char(detected_at, '{TS_TEXT}') FROM quarantine ORDER BY eid DESC LIMIT 1000")]

        # 4) days without incidents / abnormally low days within the coverage window
        backfill_anchor = storage.get_checkpoint(conn, "backfill").get("anchor_time")
        start = (backfill_anchor or coverage_start or DEFAULT_COVERAGE_START or last_seen)[:10]
        daily = {r[0]: r[1] for r in conn.execute(
            "SELECT to_char(start_time::date, 'YYYY-MM-DD'), COUNT(*) FROM incidents "
            "WHERE start_time >= %s AND start_time < %s GROUP BY 1", (start, today + timedelta(days=1)))}
        d0, d1 = date.fromisoformat(start) + timedelta(days=1), today - timedelta(days=1)
        all_days = [(d0 + timedelta(days=i)).isoformat() for i in range((d1 - d0).days + 1)]
        missing_days = [d for d in all_days if daily.get(d, 0) == 0]
        counts = sorted(daily.get(d, 0) for d in all_days) or [0]
        median = counts[len(counts) // 2]
        low_days = [d for d in all_days if 0 < daily.get(d, 0) < 0.3 * median]
        checks.append(_check("days_without_incidents", OK if not missing_days else FAIL, len(missing_days),
                             f"window {d0}..{d1}, see missing_days.csv"))
        checks.append(_check("days_abnormally_low", OK if not low_days else WARN, len(low_days),
                             f"< 30% of the median ({median}/day)"))
        extras["coverage_start"] = start
        extras["missing_days"] = missing_days
        extras["low_days"] = low_days
        extras["daily_counts_last_14"] = {d: daily.get(d, 0) for d in all_days[-14:]}

        # 5) 15-minute slots of the report day
        for table in ("traffic_index", "travel_times"):
            slots = {r[0] for r in conn.execute(
                f"SELECT DISTINCT extract(hour FROM fetched_at)::int * 4 + extract(minute FROM fetched_at)::int / 15 "
                f"FROM {table} WHERE fetched_at >= %s AND fetched_at < %s", (day0, day1))}
            first = q(f"SELECT to_char(MIN(fetched_at), '{TS_TEXT}') FROM {table}") or "9999"
            first_slot = 0
            if first[:10] == day_s:
                first_slot = int(first[11:13]) * 4 + int(first[14:16]) // 15
            elif first[:10] > day_s:
                first_slot = EXPECTED_SNAPSHOTS_PER_DAY
            expected = range(first_slot, EXPECTED_SNAPSHOTS_PER_DAY)
            missing_slots = [f"{s // 4:02d}:{(s % 4) * 15:02d}" for s in expected if s not in slots]
            if not expected:
                checks.append(_check(f"{table}_coverage_pct", OK, None, f"{day_s}: collection not started yet"))
                continue
            pct = round(100 * (len(expected) - len(missing_slots)) / len(expected), 1)
            checks.append(_check(f"{table}_coverage_pct", OK if pct >= 95 else WARN if pct >= 80 else FAIL,
                                 pct, f"{day_s}: {len(missing_slots)} slot(s) missing"))
            extras[f"{table}_missing_slots"] = missing_slots

        # 5.5) 5-minute traffic index: days with < 90% of 288 points (latest day excluded)
        days = conn.execute("SELECT to_char(ts_local::date, 'YYYY-MM-DD'), COUNT(*) FROM traffic_index_history "
                            "GROUP BY 1 ORDER BY 1").fetchall()
        if days:
            incomplete = [d for d, n in days[:-1] if n < 288 * 0.9]
            checks.append(_check("traffic_index_5min_incomplete_days",
                                 OK if len(incomplete) <= 0.02 * len(days) else WARN, len(incomplete),
                                 f"of {len(days):,} days ({days[0][0]}..{days[-1][0]}) with < 90% of 288 points"))
            extras["traffic_index_incomplete_days"] = incomplete[:500]

        # 6) missing eids
        miss = {r[0]: r[1] for r in conn.execute("SELECT status, COUNT(*) FROM missing_eids GROUP BY status")}
        checks.append(_check("missing_eids_pending", OK if miss.get("pending", 0) < 500 else WARN,
                             miss.get("pending", 0), json.dumps(miss)))

        # 6.5) report day vs the 7 previous days
        prev0 = day0 - timedelta(days=7)
        day_n = q("SELECT COUNT(*) FROM incidents WHERE start_time >= %s AND start_time < %s AND is_duplicate = 0",
                  day0, day1)
        day_acc = q("SELECT COUNT(*) FROM incidents WHERE start_time >= %s AND start_time < %s AND is_duplicate = 0 "
                    "AND is_accident = 1", day0, day1)
        prev_n = q("SELECT COUNT(*) FROM incidents WHERE start_time >= %s AND start_time < %s AND is_duplicate = 0",
                   prev0, day0)
        prev_acc = q("SELECT COUNT(*) FROM incidents WHERE start_time >= %s AND start_time < %s AND is_duplicate = 0 "
                     "AND is_accident = 1", prev0, day0)
        if prev_n and day_n:
            share, base = day_acc / day_n, prev_acc / prev_n
            ok = not base or 0.5 <= share / base <= 2
            checks.append(_check("accident_share_vs_7d", OK if ok else WARN,
                                 {"day": round(100 * share, 1), "prev_7d": round(100 * base, 1)},
                                 "% accidents vs the 7-day average (more than 2x apart = WARN)"))
            avg = prev_n / 7
            checks.append(_check("volume_vs_7d", OK if 0.3 * avg <= day_n <= 5 * avg else WARN,
                                 {"day": day_n, "avg_7d": round(avg, 1)}, "event count (normal range 0.3x-5x)"))

        # 6.6) published gold files: schema + row counts match the manifest
        checks.append(_check_parquet_files())

        # 7) failed runs in the last 24 hours (Bangkok)
        failed = q("SELECT COUNT(*) FROM scrape_runs WHERE status = 'failed' AND started_at >= %s",
                   now - timedelta(days=1))
        checks.append(_check("failed_runs_24h", OK if failed == 0 else WARN if failed < 5 else FAIL, failed))

        extras["pending_eids_sample"] = [r[0] for r in conn.execute(
            "SELECT eid FROM missing_eids WHERE status = 'pending' ORDER BY eid DESC LIMIT 1000")]
    return _write_report(day_s, checks, extras)


def _check_parquet_files():
    import pyarrow.parquet as pq

    from bkk_traffic import parquet_export
    problems = []
    for name, (_, schema) in parquet_export.DATASETS.items():
        folder = parquet_export.PARQUET_DIR / name
        try:
            manifest = json.loads((folder / "_manifest.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            problems.append(f"{name}: no manifest")
            continue
        rows = 0
        for f in manifest["files"]:
            try:
                meta = pq.read_metadata(folder / f["file"])
            except OSError as err:
                problems.append(f"{name}/{f['file']}: unreadable ({type(err).__name__})")
                continue
            rows += meta.num_rows
            if not meta.schema.to_arrow_schema().equals(schema):
                problems.append(f"{name}/{f['file']}: schema differs")
            if meta.num_rows > parquet_export.ROWS_PER_FILE:
                problems.append(f"{name}/{f['file']}: more than {parquet_export.ROWS_PER_FILE} rows")
        if rows != manifest["total_rows"]:
            problems.append(f"{name}: {rows} rows in files != manifest {manifest['total_rows']}")
    return _check("parquet_files_valid", OK if not problems else FAIL, len(problems),
                  "; ".join(problems[:5]) or "schema / row counts match the manifests")


def _write_report(day_s, checks, extras):
    out = config.QUALITY_DIR / f"dt={day_s}"
    out.mkdir(parents=True, exist_ok=True)
    overall = FAIL if any(c["status"] == FAIL for c in checks) else WARN if any(
        c["status"] == WARN for c in checks) else OK
    report = {"report_day": day_s, "generated_at": storage.now_str(), "overall": overall, "checks": checks,
              **{k: v for k, v in extras.items() if k not in ("pending_eids_sample", "quarantine_sample")}}
    with open(out / "quarantine_rows.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["eid", "reasons", "detected_at"])
        w.writerows([(r["eid"], r["reasons"], r["detected_at"]) for r in extras.get("quarantine_sample", [])])
    (out / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out / "missing_days.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["date", "problem"])
        w.writerows([(d, "no_incidents") for d in extras.get("missing_days", [])])
        w.writerows([(d, "abnormally_low") for d in extras.get("low_days", [])])
    with open(out / "missing_eids_pending.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["eid"])
        w.writerows([(e,) for e in extras.get("pending_eids_sample", [])])
    icon = {OK: "✅", WARN: "⚠️", FAIL: "❌"}
    lines = [f"# Data Quality Report {day_s}", "", f"Overall: **{icon[overall]} {overall}**", "",
             "| check | status | value | detail |", "|---|---|---|---|"]
    for c in checks:
        val = json.dumps(c["value"], ensure_ascii=False) if isinstance(c["value"], dict) else c["value"]
        lines.append(f"| {c['check']} | {icon[c['status']]} {c['status']} | {val} | {c['detail']} |")
    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report
