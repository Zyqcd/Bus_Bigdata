"""HTTP client for traffic.longdo.com: cross-process rate limit + retry + raw copies.

Ported unchanged from the friend's client.py, except that fcntl is optional and raw folders use explicit Asia/Bangkok time, so the
module imports on Windows (tests use a fake client; the Airflow containers are
Linux and use the real cross-process lock).

Phase 9.7: an optional `deadline` (time.monotonic() value). When set, no crawl-delay wait,
request or retry backoff may run past it (the request timeout is capped at the remaining
time) and DeadlineExceeded is raised instead. Without a deadline the behaviour is unchanged.
"""
import gzip
import json
import logging
import re
import time
from datetime import datetime

import requests

from bkk_traffic import config

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows development machines only
    fcntl = None

log = logging.getLogger(__name__)


class DeadlineExceeded(RuntimeError):
    """The caller's time budget does not allow another wait / request / retry."""


class LongdoClient:
    def __init__(self, source_tag: str = "misc", deadline: float | None = None):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": config.USER_AGENT, "Accept": "application/json"})
        self.source_tag = source_tag
        self.request_count = 0
        self.deadline = deadline
        self._clock = time.monotonic
        config.CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

    def _remaining(self) -> float | None:
        return None if self.deadline is None else self.deadline - self._clock()

    def _wait_turn(self):
        """A lock file shared by every task/DAG keeps >= CRAWL_DELAY between requests."""
        if fcntl is None:
            raise RuntimeError("the Longdo rate limit needs fcntl (run inside the Linux Airflow image)")
        lock_path = config.RATE_LOCK_FILE
        lock_path.touch(exist_ok=True)
        with open(lock_path, "r+") as fh:
            fcntl.flock(fh, fcntl.LOCK_EX)
            try:
                fh.seek(0)
                last = float(fh.read().strip() or 0)
                wait = last + config.CRAWL_DELAY_SEC - time.time()
                remaining = self._remaining()
                if remaining is not None and max(wait, 0) >= remaining:
                    raise DeadlineExceeded("no time left for the crawl-delay wait")
                if wait > 0:
                    time.sleep(wait)
                fh.seek(0)
                fh.truncate()
                fh.write(str(time.time()))
                fh.flush()
            finally:
                fcntl.flock(fh, fcntl.LOCK_UN)

    def get_json(self, url: str, params: dict | None = None, raw_name: str | None = None):
        data = self._get(url, params, lambda resp: resp.json())
        if raw_name:
            self.save_raw(raw_name, data)
        return data

    def get_text(self, url: str, params: dict | None = None) -> str:
        return self._get(url, params, lambda resp: resp.content.decode("utf-8-sig"))

    def _get(self, url, params, parse):
        last_err = None
        for attempt in range(1, config.MAX_RETRIES + 1):
            remaining = self._remaining()
            if remaining is not None and remaining <= 0:
                raise DeadlineExceeded("no time left for a request")
            self._wait_turn()
            remaining = self._remaining()
            timeout = config.REQUEST_TIMEOUT_SEC if remaining is None else max(0.1, min(config.REQUEST_TIMEOUT_SEC,
                                                                                         remaining))
            try:
                resp = self.session.get(url, params=params, timeout=timeout)
                self.request_count += 1
                if resp.status_code in (429, 500, 502, 503, 504):
                    raise requests.HTTPError(f"HTTP {resp.status_code}")
                resp.raise_for_status()
                return parse(resp)
            except (requests.RequestException, ValueError) as err:
                last_err = err
                backoff = 30 * attempt
                remaining = self._remaining()
                if remaining is not None and backoff >= remaining:
                    raise DeadlineExceeded(f"no time left to retry after {type(err).__name__}") from None
                log.warning("GET %s %s failed (%s), retry %d/%d in %ss",
                            url, params, err, attempt, config.MAX_RETRIES, backoff)
                time.sleep(backoff)
        raise RuntimeError(f"GET {url} {params} failed after {config.MAX_RETRIES} tries: {last_err}")

    def save_raw(self, name: str, data):
        now = config.bangkok_now()
        folder = config.RAW_DIR / self.source_tag / f"dt={now:%Y-%m-%d}"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"{now:%H%M%S}_{name}.json.gz"
        with gzip.open(path, "wt", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)

    # ---------- endpoints ----------
    def incident_page(self, page: int, limit: int | None = None):
        """(items, total_pages); total_pages is read from the pager HTML attached to the JSON."""
        params = {"page": page}
        if limit:
            params["limit"] = limit
        data = self.get_json(config.INCIDENT_URL, params)
        pages = [int(p) for p in re.findall(r"getIncident\((\d+)\)", data.get("pager") or "")]
        return data.get("item") or [], max(pages, default=None)

    def event_by_id(self, eid: int):
        data = self.get_json(config.EVENT_URL, {"eid": eid})
        items = data.get("item") or []
        return items[0] if items else None

    def traffic_index(self):
        return self.get_json(config.TRAFFIC_INDEX_URL, {"now": int(time.time() * 1000)}, raw_name="index")

    def event_types(self):
        return self.get_json(config.EVENT_TYPE_URL, raw_name="types")
