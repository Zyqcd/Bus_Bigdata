# Ported in Phase 9.3 from the friend's plugins/bkk_traffic/scrape.py. Scraping logic is
# unchanged. PostgreSQL changes: %s placeholders, INSERT OR REPLACE/IGNORE -> ON CONFLICT,
# MAX(start_time) formatted as text for the checkpoint JSON, and a traffic-index sample
# without a timestamp is skipped (SQLite silently invented a rowid for a NULL key), and
# ts_local is computed in explicit Asia/Bangkok time (not the container TZ).
"""งานดึงข้อมูล: realtime, backfill (มี checkpoint), traffic index, เติม eid ที่ขาด.

API คืนเหตุการณ์ทั้งประเทศ เราเก็บเฉพาะกรุงเทพมหานคร (ทั้งใน DB และไฟล์ raw)
"""
import logging
import time
from datetime import datetime

from bkk_traffic import config, storage
from bkk_traffic.client import DeadlineExceeded, LongdoClient

log = logging.getLogger(__name__)


def _store(conn, client, items, fetched_via, raw_name) -> int:
    """upsert + บันทึก raw เฉพาะรายการ กทม.; คืนจำนวนเหตุการณ์ กทม. ใหม่."""
    new, bkk_items = storage.upsert_incidents(conn, items, fetched_via)
    if bkk_items:
        client.save_raw(raw_name, {"item": bkk_items})
    return new


class InvalidEventTypes(ValueError):
    """The geteventtype response is unsafe to store; nothing is written."""


EVENT_TYPE_UPSERT = (
    "INSERT INTO event_types(id, name, name_en, icon, severity) VALUES(%s,%s,%s,%s,%s) "
    "ON CONFLICT(id) DO UPDATE SET name=excluded.name, name_en=excluded.name_en, icon=excluded.icon, "
    "severity=excluded.severity WHERE (event_types.name, event_types.name_en, event_types.icon, event_types.severity) "
    "IS DISTINCT FROM (excluded.name, excluded.name_en, excluded.icon, excluded.severity) RETURNING (xmax = 0)")


def validate_event_types(types) -> list[tuple]:
    """Phase 9.7: a non-empty list of objects with an integer id (unique) and text / integer fields."""
    if not isinstance(types, list) or not types:
        raise InvalidEventTypes(f"expected a non-empty JSON list, got {type(types).__name__}")
    rows, seen = [], set()
    for t in types:
        if not isinstance(t, dict):
            raise InvalidEventTypes(f"event type entry is not an object ({type(t).__name__})")
        tid, sev = t.get("id"), t.get("severity")
        if not isinstance(tid, int) or isinstance(tid, bool):
            raise InvalidEventTypes(f"event type id must be an integer: {str(tid)[:20]!r}")
        if tid in seen:
            raise InvalidEventTypes(f"duplicate event type id {tid}")
        if sev is not None and (not isinstance(sev, int) or isinstance(sev, bool)):
            raise InvalidEventTypes(f"event type {tid}: severity must be an integer or null")
        for key in ("name", "name_en", "icon"):
            if t.get(key) is not None and not isinstance(t.get(key), str):
                raise InvalidEventTypes(f"event type {tid}: {key} must be text or null")
        seen.add(tid)
        rows.append((tid, t.get("name"), t.get("name_en"), t.get("icon"), sev))
    return rows


def refresh_event_types() -> dict:
    """Refresh event_types from geteventtype (validated; one transaction; types are never deleted)."""
    client = LongdoClient("event_types")
    rows = validate_event_types(client.event_types())
    with storage.connect() as conn:
        with conn.transaction():
            cur = conn.cursor()
            flags = [cur.execute(EVENT_TYPE_UPSERT, row).fetchone() for row in rows]
    inserted = sum(1 for f in flags if f and f[0])
    updated = sum(1 for f in flags if f and not f[0])
    result = {"received": len(rows), "inserted": inserted, "updated": updated,
              "unchanged": len(rows) - inserted - updated, "requests": client.request_count}
    log.info("event types: %s", result)
    return result


def _ensure_event_types():
    with storage.connect() as conn:
        has = conn.execute("SELECT COUNT(*) FROM event_types").fetchone()[0]
    if not has:
        refresh_event_types()


def run_realtime_incidents(max_pages: int):
    """ดึงหน้า 1 (เหตุการณ์ที่ยัง active ทั้งหมด) แล้วไล่หน้า 2.. จนเจอหน้าที่รู้จักทุก eid แล้ว."""
    _ensure_event_types()
    started = storage.now_str()
    client = LongdoClient("incidents_realtime")
    total_items = new_items = 0
    total_pages = None
    new_this_run = set()  # หน้า 1 ซ้อนกับหน้า 2.. จึงต้องเทียบกับสิ่งที่มีก่อนรอบนี้เท่านั้น
    with storage.connect() as conn:
        try:
            for page in range(1, max_pages + 1):
                items, total_pages = client.incident_page(page)
                if not items:
                    break
                eids = {storage.to_int(i.get("eid")) for i in items} - {None}
                unknown = eids - storage.known_eids(conn, eids)
                new_this_run |= unknown
                all_known_before = not (eids & new_this_run)
                new_items += _store(conn, client, items, "realtime", f"page{page:06d}")
                total_items += len(items)
                if page >= 2 and all_known_before:
                    break
            newest = conn.execute("SELECT MAX(eid) m, to_char(MAX(start_time), 'YYYY-MM-DD HH24:MI:SS') t FROM incidents").fetchone()
            storage.set_checkpoint(conn, "realtime", {
                "last_success": storage.now_str(), "pages_read": page, "items_last_run": total_items,
                "new_last_run": new_items, "source_total_pages": total_pages,
                "max_eid": newest["m"], "max_start_time": newest["t"],
            })
            storage.log_run(conn, "realtime", started, client.request_count, total_items, new_items, "success")
        except Exception as err:
            storage.log_run(conn, "realtime", started, client.request_count, total_items, new_items,
                            "failed", str(err)[:500])
            raise
    log.info("realtime: items=%d new=%d requests=%d", total_items, new_items, client.request_count)
    return {"items": total_items, "new": new_items}


def run_traffic_index():
    client = LongdoClient("traffic_index")
    data = client.traffic_index()
    ts = storage.to_int(data.get("time"))
    if not ts:  # PostgreSQL: the key cannot be NULL (SQLite used to invent a rowid)
        log.warning("traffic index response without a timestamp; sample skipped: %s", data)
        return data
    with storage.connect() as conn:
        conn.execute(
            "INSERT INTO traffic_index(ts, ts_local, index_value, fetched_at) VALUES(%s,%s,%s,%s) "
            "ON CONFLICT(ts) DO NOTHING",
            (ts, config.bangkok_from_epoch(ts).strftime("%Y-%m-%d %H:%M:%S"),
             storage.to_float(data.get("index")), storage.now_str()),
        )
        if ts:  # ต่อท้าย time series 5 นาที (ค่าจากไฟล์ย้อนหลังจะทับทีหลังถ้ามี)
            conn.execute(
                "INSERT INTO traffic_index_history(ts, ts_local, index_value, source) VALUES(%s,%s,%s,%s) "
                "ON CONFLICT(ts) DO NOTHING",
                (ts, config.bangkok_from_epoch(ts).strftime("%Y-%m-%d %H:%M:%S"), storage.to_float(data.get("index")),
                 "realtime"),
            )
    return data


def run_backfill_batch(pages_per_run: int, start_date: str, page_size: int = 10,
                       target_rows: int = 0, max_seconds: int = 0):
    """ไล่หน้าย้อนหลังต่อจาก checkpoint.

    รายการเรียงตาม start_time ใหม่->เก่า และมีเหตุการณ์ใหม่แทรกด้านบนตลอด ทำให้หน้าเลื่อน
    จึงเก็บ anchor_time (start_time เก่าสุดที่เคยเห็น) ไว้: ถ้าหน้าที่เปิดมี median ใหม่กว่า anchor
    แปลว่าหน้าเลื่อน -> ข้ามไปหน้าถัดไป (ข้อมูลซ้ำไม่เป็นไร เพราะ upsert ด้วย eid)

    target_rows > 0: หยุดเมื่อเหตุการณ์ กทม. ใน warehouse ครบจำนวนนี้
    """
    _ensure_event_types()
    started = storage.now_str()
    t0 = time.monotonic()
    client = LongdoClient("incidents_backfill")
    with storage.connect() as conn:
        state = storage.get_checkpoint(conn, "backfill")
        if state.get("done") and (state.get("target_start_date") != start_date
                                  or state.get("target_rows") != target_rows):
            state["done"] = False  # เปลี่ยนเป้าหมาย -> ทำต่อ
        state.setdefault("page", 2)  # หน้า 1 เป็นรายการ active พิเศษ realtime ดึงอยู่แล้ว
        state.setdefault("page_size", 10)
        state.setdefault("pages_fetched_total", 0)
        state.setdefault("items_total", 0)
        state.setdefault("skipped_shift_pages", 0)
        if state["page_size"] != page_size:
            # เปลี่ยนขนาดหน้า: แปลงเลขหน้าจาก offset เดิม (ถอยหลังเผื่อไว้ 1 หน้า ซ้ำได้ ไม่ขาด)
            offset = (state["page"] - 1) * state["page_size"]
            state["page"] = max(2, offset // page_size)
            state["page_size"] = page_size
        state["target_start_date"] = start_date
        state["target_rows"] = target_rows
        if state.get("done"):
            log.info("backfill already done: %s", state.get("done_reason"))
            return state

        def bkk_rows():
            return conn.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]

        items_run = new_run = 0
        try:
            for _ in range(pages_per_run):
                if target_rows and bkk_rows() >= target_rows:
                    state["done"] = True
                    state["done_reason"] = f"reached target {target_rows:,} Bangkok rows"
                    break
                if max_seconds and time.monotonic() - t0 > max_seconds:
                    break
                page = state["page"]
                items, total_pages = client.incident_page(page, page_size)
                state["pages_fetched_total"] += 1
                if total_pages:
                    state["source_total_pages"] = total_pages
                if not items:
                    state["done"] = True
                    state["done_reason"] = "end_of_list"
                    break
                # ข้ามวันที่เสีย (0000-00-00, 1467, 1970) ไม่ให้ทำ anchor ผิดจนหยุดก่อนจบ
                times = sorted(t for t in (i.get("start_time") or "" for i in items) if t >= "2000")
                if not times:
                    state["page"] = page + 1
                    storage.set_checkpoint(conn, "backfill", state)
                    continue
                median = times[len(times) // 2]
                anchor = state.get("anchor_time")
                new_run += _store(conn, client, items, "backfill", f"page{page:06d}")
                items_run += len(items)
                state["page"] = page + 1
                if anchor and median > anchor:
                    state["skipped_shift_pages"] += 1
                else:
                    oldest = next((t for t in times if t), None)
                    if oldest and (not anchor or oldest < anchor):
                        state["anchor_time"] = oldest
                state["items_total"] += len(items)
                storage.set_checkpoint(conn, "backfill", state)
                if state.get("anchor_time") and state["anchor_time"] < start_date:
                    state["done"] = True
                    state["done_reason"] = f"reached {start_date}"
                    break
            if target_rows and not state.get("done") and bkk_rows() >= target_rows:
                state["done"] = True
                state["done_reason"] = f"reached target {target_rows:,} Bangkok rows"
            state["bangkok_rows"] = bkk_rows()
            storage.set_checkpoint(conn, "backfill", state)
            storage.log_run(conn, "backfill", started, client.request_count, items_run, new_run, "success",
                            f"page={state['page']} anchor={state.get('anchor_time')}")
        except Exception as err:
            storage.set_checkpoint(conn, "backfill", state)
            storage.log_run(conn, "backfill", started, client.request_count, items_run, new_run,
                            "failed", str(err)[:500])
            raise
    log.info("backfill: page=%s anchor=%s new=%d", state["page"], state.get("anchor_time"), new_run)
    return state


MAX_NEW_MISSING_PER_RUN = 2_000
DETECTION_CHECKPOINT = "missing_eid_detection"


def detect_missing_eids(max_new: int = MAX_NEW_MISSING_PER_RUN) -> dict:
    """Add eids our realtime pipeline should have seen but did not to missing_eids (pending).

    Phase 9.7 (docs/integration/bkk_traffic_quality_mapping.md D1-D3): the window is
    (coverage floor, MAX(seen_eids)]. The floor is persisted in checkpoint missing_eid_detection,
    initialised once to the highest eid still owned by the Parquet baseline; eids up to it were
    covered by the friend's pipeline. Eids already seen, tracked or stored are excluded; at most
    `max_new` (the highest) are added per run.
    """
    with storage.connect() as conn:
        state = storage.get_checkpoint(conn, DETECTION_CHECKPOINT)
        floor = state.get("floor_eid")
        if floor is None:
            floor = conn.execute("SELECT max(eid) FROM incidents WHERE baseline_load_id IS NOT NULL").fetchone()[0]
            if floor is None:
                return {"range": None, "candidates": 0, "new_missing": 0, "truncated": 0,
                        "reason": "no coverage floor (no Parquet baseline rows)"}
            storage.set_checkpoint(conn, DETECTION_CHECKPOINT, {
                "floor_eid": floor, "floor_source": "max eid owned by the Parquet baseline at first detection",
                "initialised_at": storage.now_str()})
        hi = conn.execute("SELECT max(eid) FROM seen_eids").fetchone()[0]
        if hi is None or hi <= floor:
            return {"range": [floor + 1, hi], "candidates": 0, "new_missing": 0, "truncated": 0}
        missing = [r[0] for r in conn.execute(
            "SELECT g FROM generate_series(%s::bigint, %s::bigint) AS g "
            "WHERE NOT EXISTS (SELECT 1 FROM seen_eids s WHERE s.eid = g) "
            "AND NOT EXISTS (SELECT 1 FROM missing_eids m WHERE m.eid = g) "
            "AND NOT EXISTS (SELECT 1 FROM incidents i WHERE i.eid = g) "
            "AND NOT EXISTS (SELECT 1 FROM bronze_incidents b WHERE b.eid = g) "
            "AND NOT EXISTS (SELECT 1 FROM quarantine x WHERE x.eid = g) ORDER BY g DESC", (floor + 1, hi))]
        selected = missing[:max_new]
        ts = storage.now_str()
        conn.cursor().executemany("INSERT INTO missing_eids(eid, detected_at, tries, status) "
                                  "VALUES(%s,%s,0,'pending') ON CONFLICT(eid) DO NOTHING", [(e, ts) for e in selected])
    log.info("gap range %s-%s candidates=%d new missing=%d", floor + 1, hi, len(missing), len(selected))
    return {"range": [floor + 1, hi], "candidates": len(missing), "new_missing": len(selected),
            "truncated": len(missing) - len(selected)}


def recover_missing_eids(limit: int = config.DEFAULT_RECOVER_PER_RUN,
                         max_seconds: int = config.DEFAULT_RECOVER_MAX_SECONDS) -> dict:
    """Fetch pending missing eids one at a time (newest first), bounded by `limit` and `max_seconds`.

    Phase 9.7: the deadline is enforced inside the client (no wait, request or retry may pass it).
    An empty answer -> not_available; an error or a mismatched item -> tries+1, stays pending.
    """
    _ensure_event_types()
    started = storage.now_str()
    t0 = time.monotonic()
    client = LongdoClient("incidents_recover", deadline=t0 + max_seconds if max_seconds else None)
    stats = {"attempted": 0, "recovered": 0, "recovered_bangkok": 0, "not_available": 0, "failed": 0}
    stop = "done"
    with storage.connect() as conn:
        pending = [r[0] for r in conn.execute(
            "SELECT eid FROM missing_eids WHERE status='pending' ORDER BY eid DESC LIMIT %s", (limit,))]
        for eid in pending:
            if max_seconds and time.monotonic() - t0 >= max_seconds:
                stop = "time"
                break
            ts = storage.now_str()
            before = client.request_count
            try:
                item = client.event_by_id(eid)
            except DeadlineExceeded:
                if client.request_count > before:
                    stats["attempted"] += 1
                    stats["failed"] += 1
                    conn.execute("UPDATE missing_eids SET tries=tries+1, last_try_at=%s WHERE eid=%s", (ts, eid))
                    conn.commit()
                stop = "time"
                break
            except Exception as err:  # noqa: BLE001 - this eid stays pending for the next run
                stats["attempted"] += 1
                stats["failed"] += 1
                log.warning("eid %s: %s (stays pending)", eid, type(err).__name__)
                conn.execute("UPDATE missing_eids SET tries=tries+1, last_try_at=%s WHERE eid=%s", (ts, eid))
                conn.commit()
                continue
            stats["attempted"] += 1
            if item is not None and (not isinstance(item, dict) or storage.to_int(item.get("eid")) != eid):
                stats["failed"] += 1
                log.warning("eid %s: malformed or mismatched item (stays pending)", eid)
                conn.execute("UPDATE missing_eids SET tries=tries+1, last_try_at=%s WHERE eid=%s", (ts, eid))
            elif item:
                stats["recovered_bangkok"] += _store(conn, client, [item], "recover", f"eid{eid}")
                stats["recovered"] += 1
                conn.execute("UPDATE missing_eids SET status='recovered', tries=tries+1, last_try_at=%s "
                             "WHERE eid=%s", (ts, eid))
            else:
                conn.execute("UPDATE missing_eids SET status='not_available', tries=tries+1, last_try_at=%s "
                             "WHERE eid=%s", (ts, eid))
                stats["not_available"] += 1
            conn.commit()
        remaining = conn.execute("SELECT count(*) FROM missing_eids WHERE status='pending'").fetchone()[0]
        if stop == "done" and len(pending) == limit and remaining:
            stop = "limit"
        result = {**stats, "selected": len(pending), "remaining_pending": remaining, "stop_reason": stop,
                  "requests": client.request_count, "seconds": round(time.monotonic() - t0, 1),
                  "limit": limit, "max_seconds": max_seconds}
        storage.log_run(conn, "recover", started, client.request_count, stats["attempted"],
                        stats["recovered_bangkok"], "success",
                        " ".join(f"{k}={result[k]}" for k in ("attempted", "recovered", "not_available", "failed",
                                                             "remaining_pending", "stop_reason")))
    log.info("recover: %s", result)
    return result
