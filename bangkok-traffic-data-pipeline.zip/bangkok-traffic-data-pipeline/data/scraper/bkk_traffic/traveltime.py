"""Travel time A -> B in Bangkok (Longdo RouteService, mode=t = with traffic at request time).

Needs a personal Longdo Map API key (free at https://map.longdo.com/console) in the Airflow
Variable `longdo_api_key`. Routes: Airflow Variable `bkk_od_pairs` (JSON), else DEFAULT_OD_PAIRS.

Ported in Phase 9.6 from the friend's plugins/bkk_traffic/traveltime.py to PostgreSQL
(docs/integration/bkk_traffic_traveltime_mapping.md). Endpoint, parameters, OD pairs, field
choice, compact raw copy, quota limits and 1 s spacing are unchanged. Deliberate changes:
  * fetched_at in explicit Asia/Bangkok time (never the container TZ);
  * one transaction per poll; a malformed / implausible payload fails the poll and writes
    nothing; transport failures leave that route without a row (a real gap), as before;
  * upsert on the existing key (route, fetched_at) that rewrites nothing when identical;
  * bounded retries (Phase 9.6.2): connect-stage failures back off 5/10/20/30/30/30 s within a
    150 s retry budget per poll, response-stage failures retry once; hard cap 3 requests per
    route per poll; TLS / 4xx not retried; messages never contain the key;
  * no key -> no request, no write, a 'skipped' run log; duration_min rounded in SQL.
The API returns only the current estimate: no past observation is ever created.
"""
import json
import logging
import math
import time
from datetime import datetime

import requests
import urllib3

from bkk_traffic import config, storage

log = logging.getLogger(__name__)

ROUTE_URL = "https://api.longdo.com/RouteService/json/route/guide"
DELAY_BETWEEN_ROUTES_SEC = 1          # quota: at most 60 calls / minute
JOB = "travel_times"

# Longdo free-key quota: 100,000 calls / month, 5,000 / day (about 10% kept in reserve)
# https://map.longdo.com/products/pricing
QUOTA_PER_DAY = 4_500
QUOTA_PER_MONTH = 95_000

# Retry policy (Phase 9.6.2, docs/integration/bkk_traffic_phase9_6_retry_policy.md)
CONNECT_TIMEOUT_SEC = 5               # per address (normal connect 7-40 ms); 3 IPv4 addresses -> <= ~15 s per attempt
READ_TIMEOUT_SEC = config.REQUEST_TIMEOUT_SEC          # 180 s response wait (unchanged)
CONNECT_RETRY_DELAYS = (5, 10, 20, 30, 30, 30)         # 125 s of backoff: covers the ~100 s outage observed
RESPONSE_RETRY_DELAYS = (5,)                           # one retry for 429 / 5xx / read timeout / reset
RETRY_DELAY_SEC = RESPONSE_RETRY_DELAYS[0]
POLL_RETRY_BUDGET_SEC = 150           # total backoff sleep per poll (all routes, all kinds)
REQUEST_CAP_PER_ROUTE = 3             # hard cap: 3 x routes requests per poll (24 for 8 routes)
MAX_DISTANCE_M = 200_000              # plausibility bounds for an intra-city route
MAX_DURATION_S = 86_400

# (route name, origin lat, origin lon, destination lat, destination lon)
DEFAULT_OD_PAIRS = [
    ("อนุสาวรีย์ชัยฯ -> สยาม", 13.7650, 100.5383, 13.7457, 100.5348),
    ("สีลม -> อโศก", 13.7290, 100.5340, 13.7370, 100.5603),
    ("ห้าแยกลาดพร้าว -> อนุสาวรีย์ชัยฯ", 13.8160, 100.5610, 13.7650, 100.5383),
    ("บางนา -> พระราม 9", 13.6680, 100.6040, 13.7570, 100.5650),
    ("ดอนเมือง -> หมอชิต", 13.9126, 100.6068, 13.8027, 100.5536),
    ("สาทร -> วงเวียนใหญ่", 13.7210, 100.5290, 13.7260, 100.4940),
    ("มีนบุรี -> รามคำแหง", 13.8140, 100.7480, 13.7550, 100.6200),
    ("บางแค -> ปิ่นเกล้า", 13.7130, 100.4060, 13.7600, 100.4900),
]


class TravelTimeError(RuntimeError):
    """The poll failed; nothing from it was written."""


class InvalidResponse(TravelTimeError):
    """A response that is unsafe to store (malformed, implausible, or an API error)."""


def redact(text: str, api_key: str | None) -> str:
    return text.replace(api_key, "***") if api_key else text


# ---------------- usage / quota (checkpoint traveltime_usage, unchanged) ----------------
def _usage(conn):
    state = storage.get_checkpoint(conn, "traveltime_usage")
    today, month = storage.now_str()[:10], storage.now_str()[:7]
    if state.get("day") != today:
        state.update(day=today, day_calls=0)
    if state.get("month") != month:
        state.update(month=month, month_calls=0)
    return state


def quota_left(conn) -> int:
    u = _usage(conn)
    return max(0, min(QUOTA_PER_DAY - u["day_calls"], QUOTA_PER_MONTH - u["month_calls"]))


# ---------------- parsing / validation ----------------
def validate_pairs(pairs) -> list[tuple]:
    out, names = [], set()
    for pair in pairs:
        if not isinstance(pair, (list, tuple)) or len(pair) != 5:
            raise ValueError(f"OD pair must be (name, flat, flon, tlat, tlon): {pair!r}")
        name, *coords = pair
        if not isinstance(name, str) or not name.strip() or name in names:
            raise ValueError(f"OD pair name missing or duplicated: {name!r}")
        try:
            flat, flon, tlat, tlon = (float(c) for c in coords)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"OD pair {name!r}: non-numeric coordinate") from exc
        if not (-90 <= flat <= 90 and -90 <= tlat <= 90 and -180 <= flon <= 180 and -180 <= tlon <= 180):
            raise ValueError(f"OD pair {name!r}: coordinate outside the geographic range")
        names.add(name)
        out.append((name, flat, flon, tlat, tlon))
    if not out:
        raise ValueError("no OD pairs configured")
    return out


def compact_raw(body: dict) -> str:
    """Compact raw copy: drop "guide" (every turn, ~10-20 KB), keep meta + distance/time."""
    data = body.get("data")
    if isinstance(data, list):
        data = [{k: v for k, v in d.items() if k != "guide"} for d in data if isinstance(d, dict)]
    return json.dumps({"meta": body.get("meta"), "data": data}, ensure_ascii=False)


def _number(value, name: str, upper: float) -> float:
    if isinstance(value, bool) or value is None:
        raise InvalidResponse(f"{name} missing or not a number")
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise InvalidResponse(f"{name} is not a number: {str(value)[:30]!r}") from None
    if not math.isfinite(number) or not 0 < number <= upper:
        raise InvalidResponse(f"{name} {number!r} outside (0, {upper}]")
    return number


def parse_route(body) -> tuple[float, float]:
    """(distance_m, duration_s). Accepts {"data": [{...}]} and {...}, like the original."""
    if not isinstance(body, dict):
        raise InvalidResponse(f"response is not a JSON object ({type(body).__name__})")
    data = body.get("data", body)
    if isinstance(data, list):
        if not data or not isinstance(data[0], dict):
            raise InvalidResponse("response data list is empty")
        data = data[0]
    if not isinstance(data, dict):
        raise InvalidResponse("response data is not an object")
    duration = data.get("interval", data.get("time", data.get("duration")))
    return _number(data.get("distance"), "distance", MAX_DISTANCE_M), _number(duration, "duration", MAX_DURATION_S)


# ---------------- HTTP ----------------
# Failure classes (Phase 9.6.2, docs/integration/bkk_traffic_phase9_6_retry_policy.md). Observed with the
# production requests 2.34.2 / urllib3 2.7.0:
#   refused / unreachable -> ConnectionError(MaxRetryError(reason=NewConnectionError))
#   DNS failure           -> ConnectionError(MaxRetryError(reason=NameResolutionError))
#   connect timeout       -> ConnectTimeout                 (also a ConnectionError and a Timeout)
#   reset / closed        -> ConnectionError(ProtocolError) (the request may already have been sent)
#   read timeout          -> ReadTimeout                    (the request was sent)
#   TLS failure           -> SSLError                       (a ConnectionError subclass)
CONNECT = "connect"        # never reached the server: bounded backoff, may cover an outage window
RESPONSE = "response"      # server possibly reached: one short retry (unchanged legacy-port policy)
PERMANENT = "permanent"    # not retried: the route gets no row


def classify_transport_error(exc: BaseException) -> tuple[str, str]:
    """(failure class, key-free cause name) for an exception raised by requests."""
    if isinstance(exc, requests.exceptions.SSLError):
        return PERMANENT, "SSLError"
    if isinstance(exc, requests.exceptions.ConnectTimeout):
        return CONNECT, "ConnectTimeout"
    if isinstance(exc, requests.exceptions.ConnectionError):
        reason = getattr(exc.args[0], "reason", None) if exc.args else None
        if isinstance(reason, urllib3.exceptions.NewConnectionError):    # incl. NameResolutionError
            return CONNECT, type(reason).__name__
        return RESPONSE, "ConnectionError"                               # ProtocolError / unidentified
    if isinstance(exc, requests.exceptions.Timeout):                     # ReadTimeout (or unidentified)
        return RESPONSE, type(exc).__name__
    return PERMANENT, type(exc).__name__


def max_requests_per_poll(routes: int) -> int:
    """Hard cap of HTTP attempts in one poll (also the quota reservation)."""
    return REQUEST_CAP_PER_ROUTE * routes


class RouteRequestError(TravelTimeError):
    """One route could not be requested (the route gets no row; the rest of the poll continues)."""


TransientRouteError = RouteRequestError       # name kept from Phase 9.6


class RouteClient:
    """RouteService client for ONE poll: bounded retries, key-free messages.

    * connect-stage failures: backoff CONNECT_RETRY_DELAYS while the poll's retry budget lasts;
      when it is exhausted the circuit opens and later routes are not requested;
    * response-stage failures (HTTP 429 / 5xx, read timeout, reset): one retry after 5 s;
    * TLS errors and other HTTP 4xx: no retry; API errors / non-JSON: InvalidResponse;
    * never more than max_requests attempts in total.
    """

    def __init__(self, api_key: str, session=None, sleep=time.sleep, max_requests: int | None = None):
        self.api_key = api_key
        self.session = session or requests.Session()
        self.session.headers["User-Agent"] = config.USER_AGENT
        self.request_count = 0
        self.retry_sleep_spent = 0
        self.circuit_open = False
        self.max_requests = max_requests if max_requests is not None else max_requests_per_poll(len(DEFAULT_OD_PAIRS))
        self._sleep = sleep

    def _wait(self, delay: int) -> bool:
        """Sleep `delay` if the poll budget allows it."""
        if self.retry_sleep_spent + delay > POLL_RETRY_BUDGET_SEC:
            return False
        self.retry_sleep_spent += delay
        self._sleep(delay)
        return True

    def route(self, flat, flon, tlat, tlon) -> dict:
        if self.circuit_open:
            raise RouteRequestError("not requested: connection unavailable (poll retry budget exhausted)")
        params = {"flat": flat, "flon": flon, "tlat": tlat, "tlon": tlon, "mode": "t", "type": 25,
                  "locale": "th", "key": self.api_key}
        connect_failures = response_failures = attempts = 0
        while True:
            if self.request_count >= self.max_requests:
                raise RouteRequestError(f"not requested: poll request cap {self.max_requests} reached")
            self.request_count += 1
            attempts += 1
            try:
                resp = self.session.get(ROUTE_URL, params=params, timeout=(CONNECT_TIMEOUT_SEC, READ_TIMEOUT_SEC))
            except requests.RequestException as exc:
                kind, cause = classify_transport_error(exc)          # never str(exc): it may contain the URL
            else:
                if resp.status_code == 429 or resp.status_code >= 500:
                    kind, cause = RESPONSE, f"HTTP {resp.status_code}"
                elif resp.status_code >= 400:
                    raise RouteRequestError(f"HTTP {resp.status_code} (not retried)")
                else:
                    text = resp.text.lstrip()
                    if text.startswith("throw"):
                        raise InvalidResponse(redact("API error: " + text.strip()[:120], self.api_key))
                    try:
                        return resp.json()
                    except ValueError:
                        raise InvalidResponse("response is not JSON") from None
            if kind == PERMANENT:
                raise RouteRequestError(f"{cause} (not retried)")
            if kind == CONNECT:
                if connect_failures < len(CONNECT_RETRY_DELAYS) and self._wait(CONNECT_RETRY_DELAYS[connect_failures]):
                    connect_failures += 1
                    continue
                self.circuit_open = True        # outage outlasted what the poll may wait: skip later routes
                raise RouteRequestError(f"connection failure ({cause}) after {attempts} attempts; "
                                        f"retry sleep {self.retry_sleep_spent}s of {POLL_RETRY_BUDGET_SEC}s")
            if response_failures < len(RESPONSE_RETRY_DELAYS) and self._wait(RESPONSE_RETRY_DELAYS[response_failures]):
                response_failures += 1
                continue
            raise RouteRequestError(f"{cause} after {attempts} attempts")


# ---------------- collect ----------------
UPSERT = """
INSERT INTO travel_times (route, fetched_at, distance_m, duration_s, duration_min,
                          from_lat, from_lon, to_lat, to_lon, raw_json)
VALUES (%s, %s, %s, %s, round((%s::float8 / 60)::numeric, 2)::float8, %s, %s, %s, %s, %s)
ON CONFLICT (route, fetched_at) DO UPDATE SET
    distance_m = excluded.distance_m, duration_s = excluded.duration_s, duration_min = excluded.duration_min,
    from_lat = excluded.from_lat, from_lon = excluded.from_lon, to_lat = excluded.to_lat, to_lon = excluded.to_lon,
    raw_json = excluded.raw_json, baseline_load_id = NULL
WHERE (travel_times.distance_m, travel_times.duration_s, travel_times.duration_min, travel_times.from_lat,
       travel_times.from_lon, travel_times.to_lat, travel_times.to_lon, travel_times.raw_json::text)
      IS DISTINCT FROM (excluded.distance_m, excluded.duration_s, excluded.duration_min, excluded.from_lat,
                        excluded.from_lon, excluded.to_lat, excluded.to_lon, excluded.raw_json::text)
RETURNING (xmax = 0) AS inserted"""


def _record(conn, started, requests_, received, inserted, status, note, api_key):
    storage.log_run(conn, JOB, started, requests_, received, inserted, status, redact(note, api_key)[:500])
    conn.commit()


def collect(api_key: str | None, pairs=None, client=None, fetched_at: str | None = None,
            sleep=time.sleep) -> dict:
    """One poll of every OD pair; all observations of the poll are written in ONE transaction."""
    started = storage.now_str()
    if not api_key:
        log.warning("travel times skipped: Airflow Variable longdo_api_key is not set (no request made)")
        with storage.connect() as conn:
            _record(conn, started, 0, 0, 0, "skipped", "no longdo_api_key", None)
        return {"status": "skipped_no_api_key", "requests": 0, "received": 0, "inserted": 0}
    if fetched_at is not None:                            # tests / reruns: must be Bangkok wall-clock text
        try:
            datetime.strptime(fetched_at, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            raise TravelTimeError(f"fetched_at {fetched_at!r} is not 'YYYY-MM-DD HH:MM:SS'") from None
    pairs = validate_pairs(pairs or DEFAULT_OD_PAIRS)
    client = client or RouteClient(api_key, sleep=sleep, max_requests=max_requests_per_poll(len(pairs)))
    fetched_at = fetched_at or storage.now_str()          # explicit Asia/Bangkok wall-clock (config.bangkok_now)
    with storage.connect() as conn:
        usage = _usage(conn)
        if quota_left(conn) < max_requests_per_poll(len(pairs)):    # reserve the worst case of the poll
            _record(conn, started, 0, 0, 0, "skipped", f"quota: day {usage['day_calls']}, month "
                    f"{usage['month_calls']}", api_key)
            return {"status": "skipped_quota", "requests": 0, "received": 0, "inserted": 0,
                    "usage": {"day": usage["day_calls"], "month": usage["month_calls"]}}
        conn.commit()
        observations, failed = [], []
        try:
            for i, (name, flat, flon, tlat, tlon) in enumerate(pairs):
                if i:
                    sleep(DELAY_BETWEEN_ROUTES_SEC)
                try:
                    body = client.route(flat, flon, tlat, tlon)
                except RouteRequestError as exc:
                    log.warning("route %s: %s (no observation stored)", name, exc)
                    failed.append(f"{name}: {exc}")
                    continue
                distance, duration = parse_route(body)          # InvalidResponse -> whole poll fails
                observations.append((name, fetched_at, distance, duration, duration, flat, flon, tlat, tlon,
                                     compact_raw(body)))
            if not observations:
                raise TravelTimeError("no route returned a travel time: " + (failed[0] if failed else "no pairs"))
            with conn.transaction():
                cur = conn.cursor()
                flags = [cur.execute(UPSERT, row).fetchone() for row in observations]
                stored = conn.execute("SELECT count(*) FROM travel_times WHERE fetched_at = %s AND route = ANY(%s)",
                                      (fetched_at, [o[0] for o in observations])).fetchone()[0]
                if stored != len(observations):
                    raise TravelTimeError(f"{stored} rows stored for {len(observations)} observations")
        except Exception as err:
            conn.rollback()
            usage["day_calls"] += client.request_count
            usage["month_calls"] += client.request_count
            storage.set_checkpoint(conn, "traveltime_usage", usage)
            _record(conn, started, client.request_count, len(observations), 0, "failed",
                    f"{type(err).__name__}: {err}", api_key)
            raise
        inserted = sum(1 for f in flags if f and f[0])
        updated = sum(1 for f in flags if f and not f[0])
        usage["day_calls"] += client.request_count
        usage["month_calls"] += client.request_count
        storage.set_checkpoint(conn, "traveltime_usage", usage)
        _record(conn, started, client.request_count, len(observations), inserted, "success",
                f"fetched_at {fetched_at}: +{inserted} ~{updated}; failed routes: "
                + ("; ".join(failed) if failed else "none"), api_key)
    return {"status": "success", "fetched_at": fetched_at, "requests": client.request_count,
            "received": len(observations), "inserted": inserted, "updated": updated,
            "unchanged": len(observations) - inserted - updated, "rejected": 0,
            "failed_routes": [redact(f, api_key) for f in failed],
            "usage": {"day": usage["day_calls"], "month": usage["month_calls"]}}
