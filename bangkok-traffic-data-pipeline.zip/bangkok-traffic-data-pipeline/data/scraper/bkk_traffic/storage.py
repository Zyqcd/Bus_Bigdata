"""PostgreSQL storage of the BKK Traffic pipeline (schema bkk_traffic) + checkpoints + run log.

BRONZE  bronze_incidents  raw JSON as fetched (Bangkok only)          <- SCRAPE
SILVER  incidents         cleaned rows that passed the row rules        <- CLEAN (clean.py)
        quarantine        rows that failed a rule, with the reasons (never exported)
GOLD    data/bkk_traffic/parquet (outside the DB)                       <- PUBLISH (publish.py), after the gate

Ported in Phase 9.3 from the friend's SQLite storage.py. Changes:
  * no runtime DDL: the schema is owned by database/migrations/bkk_traffic (the app role
    cannot ALTER); sessions use search_path=bkk_traffic and TimeZone=Asia/Bangkok;
  * %s placeholders, ANY(%s) instead of IN (?, ...), checkpoint state as jsonb;
  * rows can be read by index or by column name, like sqlite3.Row.
Timestamps are written as Bangkok wall-clock text (now_str), computed explicitly in Asia/Bangkok.
"""
import json
import logging
from contextlib import contextmanager
from datetime import datetime

from bkk_traffic import config

log = logging.getLogger(__name__)

_DSN: str | None = None


def configure(dsn: str | None) -> None:
    """Set the libpq DSN (the Airflow DAG passes the bkk_traffic_postgres connection)."""
    global _DSN
    _DSN = dsn


def dsn() -> str:
    value = _DSN or config.database_url()
    if not value:
        raise RuntimeError("no BKK Traffic database configured (storage.configure() or BKK_TRAFFIC_DATABASE_URL)")
    return value


class Row(tuple):
    """A result row readable as row[0] and row["column"] (the friend's code uses both)."""
    __slots__ = ()
    _index: dict = {}

    def __getitem__(self, key):
        if isinstance(key, str):
            key = self._index[key]
        return tuple.__getitem__(self, key)

    def keys(self):
        return list(self._index)


def _row_factory(cursor):
    names = [c.name for c in cursor.description or ()]
    cls = type("Row", (Row,), {"__slots__": (), "_index": {n: i for i, n in enumerate(names)}})
    return lambda values: cls(values)


@contextmanager
def connect():
    import psycopg

    conn = psycopg.connect(dsn(), row_factory=_row_factory, connect_timeout=30,
                           options="-c search_path=bkk_traffic -c TimeZone=Asia/Bangkok")
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


def now_str():
    return config.bangkok_now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------- checkpoints ----------------
def get_checkpoint(conn, job: str) -> dict:
    row = conn.execute("SELECT state_json FROM checkpoints WHERE job=%s", (job,)).fetchone()
    return dict(row["state_json"]) if row else {}


def set_checkpoint(conn, job: str, state: dict):
    from psycopg.types.json import Jsonb

    conn.execute(
        "INSERT INTO checkpoints(job, state_json, updated_at) VALUES(%s,%s,%s) "
        "ON CONFLICT(job) DO UPDATE SET state_json=excluded.state_json, updated_at=excluded.updated_at",
        (job, Jsonb(state), now_str()),
    )
    conn.commit()
    # file copy, readable without opening the database
    config.CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
    (config.CHECKPOINT_DIR / f"{job}.json").write_text(
        json.dumps({**state, "updated_at": now_str()}, ensure_ascii=False, indent=2, default=str), encoding="utf-8")


def log_run(conn, job, started_at, requests_, items, new_items, status, note=""):
    conn.execute(
        "INSERT INTO scrape_runs(job, started_at, finished_at, requests, items, new_items, status, note) "
        "VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",
        (job, started_at, now_str(), requests_, items, new_items, status, note),
    )


# ---------------- SCRAPE -> BRONZE (then CLEAN) ----------------
from bkk_traffic.clean import (clean_text, guess_province, load_type_names, normalize,  # noqa: E402,F401
                               to_float, to_int)


def upsert_incidents(conn, items: list[dict], fetched_via: str) -> tuple[int, list[dict]]:
    """Scrape step: keep Bangkok + traffic-related items -> raw into bronze_incidents -> clean at once.

    Out-of-scope events only record their eid in seen_eids. Returns (new Bangkok events, stored raw items).
    """
    from bkk_traffic import clean

    ts = now_str()
    types = clean.load_types(conn)
    new_count = 0
    bkk_items, bkk_eids = [], []
    for item in items:
        eid = to_int(item.get("eid"))
        if eid is None:
            continue
        is_bkk, relevance = clean.in_scope(item, types)
        conn.execute("INSERT INTO seen_eids(eid, is_bangkok, seen_at) VALUES(%s,%s,%s) "
                     "ON CONFLICT(eid) DO UPDATE SET is_bangkok=excluded.is_bangkok", (eid, is_bkk, ts))
        conn.execute("UPDATE missing_eids SET status='recovered' WHERE eid=%s AND status!='recovered'", (eid,))
        if not (is_bkk and relevance):
            # outside Bangkok / not traffic related (it may have been edited later: delete old copies)
            for table in ("incidents", "bronze_incidents", "quarantine"):
                conn.execute(f"DELETE FROM {table} WHERE eid=%s", (eid,))
            continue
        bkk_items.append(item)
        bkk_eids.append(eid)
        if not conn.execute("SELECT 1 FROM bronze_incidents WHERE eid=%s", (eid,)).fetchone():
            new_count += 1
        conn.execute(
            "INSERT INTO bronze_incidents(eid, raw_json, fetched_via, first_fetched_at, last_fetched_at, cleaned_at) "
            "VALUES(%s,%s,%s,%s,%s,NULL) ON CONFLICT(eid) DO UPDATE SET raw_json=excluded.raw_json, "
            "last_fetched_at=excluded.last_fetched_at, fetched_via=excluded.fetched_via, cleaned_at=NULL",
            (eid, json.dumps(item, ensure_ascii=False), fetched_via, ts, ts),
        )
    conn.commit()
    if bkk_eids:
        clean.clean_eids(conn, bkk_eids)
    return new_count, bkk_items


def known_eids(conn, eids) -> set:
    eids = [e for e in eids if e is not None]
    if not eids:
        return set()
    return {r["eid"] for r in conn.execute("SELECT eid FROM seen_eids WHERE eid = ANY(%s)", (list(eids),))}
