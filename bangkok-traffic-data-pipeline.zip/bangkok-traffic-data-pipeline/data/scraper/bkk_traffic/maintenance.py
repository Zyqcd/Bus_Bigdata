"""BKK Traffic maintenance limited to BKK Traffic artifacts.

Replaces the friend's bkk_traffic_maintenance tasks (Phase 9.2 section 12):
  * NO `airflow db clean`: the Airflow metadata database is shared with Namtang, and
    even --dag-ids leaves tables without a dag_id column cleaned globally. Metadata
    retention for bkk_traffic_* DAGs is a manual, dry-run-first procedure
    (docs/integration/bkk_traffic_phase9_3.md).
  * Log cleanup only inside <log root>/dag_id=bkk_traffic_*; every file is resolved and
    must stay inside such a folder (no symlink escapes), so Namtang, scheduler and
    dag-processor logs are never touched.
"""
import time
from pathlib import Path

LOG_RETENTION_DAYS = 7
DAG_LOG_PREFIX = "dag_id=bkk_traffic_"


def delete_old_bkk_logs(log_root: Path, retention_days: int = LOG_RETENTION_DAYS, now: float | None = None) -> dict:
    root = Path(log_root).resolve()
    cutoff = (now if now is not None else time.time()) - retention_days * 86400
    removed, kept, folders = 0, 0, []
    for folder in sorted(root.glob(f"{DAG_LOG_PREFIX}*")):
        folder = folder.resolve()
        if folder.parent != root or not folder.is_dir() or not folder.name.startswith(DAG_LOG_PREFIX):
            continue
        folders.append(folder.name)
        for path in folder.rglob("*.log"):
            target = path.resolve()
            if not target.is_relative_to(folder) or not target.is_file():
                continue
            if target.stat().st_mtime < cutoff:
                target.unlink()
                removed += 1
            else:
                kept += 1
        for sub in sorted((p for p in folder.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
            try:
                sub.rmdir()          # empty folders only
            except OSError:
                pass
    return {"removed_files": removed, "kept_files": kept, "dag_folders": folders, "retention_days": retention_days}
