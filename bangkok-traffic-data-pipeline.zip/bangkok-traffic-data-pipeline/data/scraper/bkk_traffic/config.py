"""Central settings of the BKK Traffic pipeline (overridable by environment variables).

Ported from the friend's config.py. Changes: the data root is the BKK-only folder
data/bkk_traffic of this repository (never data/raw|clean|analysis/namtang), and
there is no SQLite warehouse: storage is PostgreSQL (BKK_TRAFFIC_DATABASE_URL or
the Airflow connection bkk_traffic_postgres).
"""
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE_URL = "https://traffic.longdo.com"
INCIDENT_URL = f"{BASE_URL}/incident.json"          # ?page=N  (10 items/page, newest -> oldest)
EVENT_URL = f"{BASE_URL}/event.json"                # ?eid=X   (one event by id)
TRAFFIC_INDEX_URL = f"{BASE_URL}/api/json/traffic/index"
EVENT_TYPE_URL = f"{BASE_URL}/geteventtype"

# robots.txt of traffic.longdo.com: Crawl-delay: 10
CRAWL_DELAY_SEC = float(os.environ.get("BKK_CRAWL_DELAY", "10"))
REQUEST_TIMEOUT_SEC = 180
MAX_RETRIES = 4
USER_AGENT = os.environ.get(
    "BKK_USER_AGENT",
    "bkk-traffic-research/1.0 (academic data collection; respects robots.txt crawl-delay)",
)

PROJECT_ROOT = Path(os.environ.get("NAMTANG_PROJECT_ROOT", Path(__file__).resolve().parents[3]))
DATA_DIR = Path(os.environ.get("BKK_DATA_DIR", PROJECT_ROOT / "data" / "bkk_traffic"))
RAW_DIR = DATA_DIR / "raw"
PARQUET_DIR = DATA_DIR / "parquet"
QUALITY_DIR = DATA_DIR / "quality"
CHECKPOINT_DIR = DATA_DIR / "checkpoints"
RATE_LOCK_FILE = CHECKPOINT_DIR / ".rate_limit.lock"


# Every pipeline timestamp is Asia/Bangkok wall-clock (Phase 9.2 timestamp policy). It is computed
# explicitly instead of relying on the container's TZ: the friend's compose set TZ=Asia/Bangkok,
# our Airflow containers run in UTC. Bangkok has had no DST since 1920, so UTC+7 is exact.
BANGKOK_TZ = timezone(timedelta(hours=7), "Asia/Bangkok")


def bangkok_now() -> datetime:
    """Current Asia/Bangkok wall-clock time as a naive datetime (the stored representation)."""
    return datetime.now(BANGKOK_TZ).replace(tzinfo=None)


def bangkok_from_epoch(ts: int) -> datetime:
    return datetime.fromtimestamp(ts, BANGKOK_TZ).replace(tzinfo=None)


def database_url() -> str | None:
    return os.environ.get("BKK_TRAFFIC_DATABASE_URL")


# Bangkok only: decided by coordinates against the real boundary (geo.py); without
# coordinates, by the province name that appears LAST in the text (credits removed first).
BANGKOK_WORDS = ("bangkok", "กรุงเทพ", "กทม")
OTHER_PROVINCE_WORDS = (
    "samut prakan", "สมุทรปราการ", "nonthaburi", "นนทบุรี", "pathum thani", "ปทุมธานี",
    "samut sakhon", "สมุทรสาคร", "nakhon pathom", "นครปฐม", "chachoengsao", "ฉะเชิงเทรา",
    "ayutthaya", "อยุธยา", "chon buri", "chonburi", "ชลบุรี",
)
ACCIDENT_WORDS = ("อุบัติเหตุ", "accident", "crash", "collision", "รถชน", "ชนกัน")

# Defaults of the Airflow Variables
DEFAULT_BACKFILL_START_DATE = "2025-01-01"
DEFAULT_BACKFILL_PAGES_PER_RUN = 200
DEFAULT_BACKFILL_MAX_SECONDS = 14 * 60 + 30
DEFAULT_BACKFILL_PAGE_SIZE = 1000
DEFAULT_BACKFILL_TARGET_ROWS = 0
DEFAULT_REALTIME_MAX_PAGES = 30
DEFAULT_RECOVER_PER_RUN = 30                  # Phase 9.7 (friend: 150); see bkk_traffic_quality_mapping.md R1
DEFAULT_RECOVER_MAX_SECONDS = 360             # ~6 min per run while holding the 1-slot longdo_api pool
