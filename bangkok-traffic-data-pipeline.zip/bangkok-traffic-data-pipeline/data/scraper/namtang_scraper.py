"""Namtang GTFS scraper: download, verify and preserve the static GTFS feed.

Usage (from the project root):
    python data/scraper/namtang_scraper.py [--log-level DEBUG] [--log-file PATH]

Each run:
  1. downloads the static GTFS ZIP to a temporary ``.part`` file,
  2. verifies it (HTTP status, size, ZIP integrity, archive safety),
  3. identifies the feed by SHA-256 and compares it with feeds already stored,
  4. stores a new feed immutably under ``data/raw/namtang/YYYY-MM-DD/``
     (``YYYY-MM-DD/HHMMSS/`` for further distinct feeds on the same day)
     together with a ``manifest.json``, or records the run as ``unchanged``,
  5. appends run-level and per-file rows to ``data/metadata/scrape_log.csv``.

The scraper is safe to run repeatedly. Cleaning and Parquet output are not
part of this module.
"""

from __future__ import annotations

import argparse
import codecs
import csv
import hashlib
import io
import json
import logging
import os
import stat
import sys
import uuid
import zipfile
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path, PurePosixPath
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

log = logging.getLogger("namtang_scraper")

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[2]

SOURCE_NAME = "namtang_gtfs"
SOURCE_URL = "https://namtang-api.otp.go.th/download/namtang-gtfs.zip"

RAW_DIR = PROJECT_ROOT / "data" / "raw" / "namtang"
QUARANTINE_DIRNAME = "_quarantine"
SCRAPE_LOG = PROJECT_ROOT / "data" / "metadata" / "scrape_log.csv"

RAW_ZIP_NAME = "gtfs.zip"
MANIFEST_NAME = "manifest.json"
PART_PREFIX = "_download_"

# Thailand has no daylight saving time, so a fixed offset is exact and avoids
# depending on a tz database (not shipped with Python on Windows).
BANGKOK_TZ = timezone(timedelta(hours=7), "Asia/Bangkok")

CONNECT_TIMEOUT_S = 15
READ_TIMEOUT_S = 120
MAX_RETRIES = 4
BACKOFF_FACTOR = 2.0
RETRY_STATUSES = (429, 500, 502, 503, 504)
CHUNK_BYTES = 1 << 20
MAX_DOWNLOAD_BYTES = 1 << 30          # 1 GiB compressed
MAX_UNCOMPRESSED_BYTES = 8 << 30      # zip-bomb guard
USER_AGENT = "bangkok-traffic-project/0.1 (academic data pipeline)"

KEPT_HEADERS = (
    "Content-Type", "Content-Length", "Content-Encoding", "Content-Disposition",
    "Last-Modified", "ETag", "Accept-Ranges", "Cache-Control", "Date", "Server",
)

# One lightweight metadata row per run (file="__run__") and per GTFS file.
# "stage" says which pipeline step wrote the row: scrape | clean | validate.
# It is appended last so positional readers of the earlier layout keep working.
LOG_FIELDS_V1 = [
    "run_id", "scrape_timestamp_utc", "scrape_date", "source", "http_status",
    "feed_version", "zip_sha256", "zip_bytes", "raw_path", "file", "status",
    "raw_rows", "clean_rows", "rejected_rows", "duplicate_rows", "error",
]
LOG_FIELDS = [*LOG_FIELDS_V1, "stage"]
LEGACY_LOG_FIELDS = ["scrape_date", "source", "file", "status", "rows", "timestamp"]
RUN_ROW_FILE = "__run__"

# Very long fields (e.g. encoded geometries) must not abort row counting.
csv.field_size_limit(2**31 - 1)


class ScrapeError(Exception):
    """A failure in one pipeline stage; always logged, never swallowed."""

    def __init__(self, stage: str, message: str, http_status: int | None = None):
        super().__init__(f"[{stage}] {message}")
        self.stage = stage
        self.http_status = http_status


@dataclass
class DownloadResult:
    path: Path
    sha256: str
    size: int
    http_status: int
    headers: dict[str, str]


# --------------------------------------------------------------------------
# Download
# --------------------------------------------------------------------------

def build_session() -> requests.Session:
    """Session that retries connection errors, 429 and 5xx (never other 4xx)."""
    retry = Retry(
        total=MAX_RETRIES,
        connect=MAX_RETRIES,
        read=MAX_RETRIES,
        status=MAX_RETRIES,
        backoff_factor=BACKOFF_FACTOR,
        status_forcelist=RETRY_STATUSES,
        allowed_methods=frozenset({"GET"}),
        respect_retry_after_header=True,
        raise_on_status=False,
    )
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers["User-Agent"] = USER_AGENT
    return session


def download(session: requests.Session, url: str, dest: Path) -> DownloadResult:
    """Stream ``url`` into ``dest`` while hashing; raise ScrapeError on any problem."""
    digest = hashlib.sha256()
    size = 0
    try:
        with session.get(url, stream=True, timeout=(CONNECT_TIMEOUT_S, READ_TIMEOUT_S)) as resp:
            headers = {k: resp.headers[k] for k in KEPT_HEADERS if k in resp.headers}
            if resp.status_code != 200:
                raise ScrapeError("download", f"HTTP {resp.status_code} from {url}",
                                  http_status=resp.status_code)
            with dest.open("wb") as fh:
                for chunk in resp.iter_content(CHUNK_BYTES):
                    size += len(chunk)
                    if size > MAX_DOWNLOAD_BYTES:
                        raise ScrapeError("download", f"exceeded {MAX_DOWNLOAD_BYTES} bytes",
                                          http_status=resp.status_code)
                    digest.update(chunk)
                    fh.write(chunk)
            status = resp.status_code
    except requests.RequestException as exc:
        raise ScrapeError("download", f"{type(exc).__name__}: {exc}") from exc

    if size == 0:
        raise ScrapeError("download", "empty response body", http_status=status)
    expected = headers.get("Content-Length")
    # With Content-Encoding the decoded body length legitimately differs.
    if expected is not None and "Content-Encoding" not in headers and int(expected) != size:
        raise ScrapeError("download", f"size mismatch: Content-Length={expected}, received={size}",
                          http_status=status)
    return DownloadResult(dest, digest.hexdigest(), size, status, headers)


# --------------------------------------------------------------------------
# Verification and inspection (read-only)
# --------------------------------------------------------------------------

def _unsafe_member_name(name: str) -> bool:
    normalized = name.replace("\\", "/")
    parts = PurePosixPath(normalized).parts
    return (
        normalized.startswith("/")
        or (len(normalized) > 1 and normalized[1] == ":")
        or ".." in parts
    )


def verify_zip(path: Path) -> None:
    """Check the file is a sound, safe ZIP that contains at least one .txt file."""
    with path.open("rb") as fh:
        magic = fh.read(4)
    if magic != b"PK\x03\x04":
        raise ScrapeError("verify", f"not a ZIP file (first bytes {magic!r})")
    try:
        with zipfile.ZipFile(path) as zf:
            infos = zf.infolist()
            unsafe = [i.filename for i in infos if _unsafe_member_name(i.filename)]
            if unsafe:
                raise ScrapeError("verify", f"unsafe member paths: {unsafe}")
            encrypted = [i.filename for i in infos if i.flag_bits & 0x1]
            if encrypted:
                raise ScrapeError("verify", f"encrypted members: {encrypted}")
            total = sum(i.file_size for i in infos)
            if total > MAX_UNCOMPRESSED_BYTES:
                raise ScrapeError("verify", f"uncompressed size {total} exceeds limit")
            if not any(i.filename.lower().endswith(".txt") and not i.is_dir() for i in infos):
                raise ScrapeError("verify", "archive contains no .txt files")
            bad = zf.testzip()
    except zipfile.BadZipFile as exc:
        raise ScrapeError("verify", f"corrupt ZIP: {exc}") from exc
    if bad is not None:
        raise ScrapeError("verify", f"CRC check failed for member {bad!r}")


def _inspect_text_member(zf: zipfile.ZipFile, info: zipfile.ZipInfo) -> dict[str, Any]:
    """Header, data-row count and encoding facts for one CSV-like member."""
    with zf.open(info) as fh:
        head = fh.read(4)
    if head.startswith(codecs.BOM_UTF8):
        encoding, bom = "utf-8", "utf-8"
    elif head.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return {"encoding": "utf-16 (BOM)", "bom": "utf-16", "columns": None,
                "row_count": None, "error": "UTF-16 is not supported by GTFS; not parsed"}
    else:
        encoding, bom = "utf-8", None

    result: dict[str, Any] = {"encoding": encoding, "bom": bom, "columns": None,
                              "row_count": None, "blank_lines": 0,
                              "ragged_rows": 0, "has_non_ascii": False, "error": None}
    rows = blank = ragged = 0
    non_ascii = False
    try:
        with zf.open(info) as raw:
            text = io.TextIOWrapper(raw, encoding="utf-8-sig", errors="strict", newline="")
            reader = csv.reader(text)
            header = next(reader, None)
            if header is None:
                result["row_count"] = 0
                result["error"] = "empty file"
                return result
            result["columns"] = header
            non_ascii = any(not c.isascii() for c in header)
            for row in reader:
                if not row:
                    blank += 1
                    continue
                rows += 1
                if len(row) != len(header):
                    ragged += 1
                if not non_ascii and any(not v.isascii() for v in row):
                    non_ascii = True
    except UnicodeDecodeError as exc:
        result["encoding"] = "not valid UTF-8"
        result["error"] = f"UnicodeDecodeError after {rows} data rows: {exc}"
        return result
    except csv.Error as exc:
        result["error"] = f"csv.Error after {rows} data rows: {exc}"
        return result
    result.update(row_count=rows, blank_lines=blank, ragged_rows=ragged, has_non_ascii=non_ascii)
    return result


def inspect_members(path: Path) -> list[dict[str, Any]]:
    """Describe every archive member; .txt members also get header and row counts."""
    members: list[dict[str, Any]] = []
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            entry: dict[str, Any] = {
                "name": info.filename,
                "file_size": info.file_size,
                "compress_size": info.compress_size,
                "crc32": f"{info.CRC:08x}",
                "modified": datetime(*info.date_time).isoformat(),
            }
            if info.filename.lower().endswith(".txt"):
                entry.update(_inspect_text_member(zf, info))
            members.append(entry)
    return members


def read_feed_info(path: Path) -> list[dict[str, str]] | None:
    """Rows of feed_info.txt exactly as stored (keys/values unmodified), or None."""
    with zipfile.ZipFile(path) as zf:
        names = [n for n in zf.namelist() if PurePosixPath(n).name.lower() == "feed_info.txt"]
        if not names:
            return None
        try:
            with zf.open(names[0]) as raw:
                text = io.TextIOWrapper(raw, encoding="utf-8-sig", errors="strict", newline="")
                return [dict(r) for r in csv.DictReader(text)]
        except (UnicodeDecodeError, csv.Error) as exc:
            log.warning("could not parse %s: %s", names[0], exc)
            return None


def feed_version_from(feed_info: list[dict[str, str]] | None) -> str | None:
    """feed_version from the first feed_info row, if that column exists and is non-empty."""
    if not feed_info:
        return None
    for key, value in feed_info[0].items():
        if key is not None and key.strip().lower() == "feed_version" and value and value.strip():
            return value.strip()
    return None


# --------------------------------------------------------------------------
# Raw storage
# --------------------------------------------------------------------------

def known_feeds(raw_dir: Path) -> dict[str, Path]:
    """Map SHA-256 -> raw feed directory for every stored feed with a manifest."""
    feeds: dict[str, Path] = {}
    if not raw_dir.exists():
        return feeds
    for manifest in raw_dir.rglob(MANIFEST_NAME):
        if QUARANTINE_DIRNAME in manifest.relative_to(raw_dir).parts:
            continue
        try:
            sha = json.loads(manifest.read_text(encoding="utf-8"))["zip_sha256"]
        except (OSError, ValueError, KeyError) as exc:
            log.warning("unreadable manifest %s (%s); feed ignored for dedup", manifest, exc)
            continue
        feeds[sha] = manifest.parent
    for zip_path in raw_dir.rglob(RAW_ZIP_NAME):
        if not (zip_path.parent / MANIFEST_NAME).exists():
            log.warning("raw feed without manifest (incomplete earlier run?): %s", zip_path)
    return feeds


def new_feed_dir(raw_dir: Path, now_bkk: datetime) -> Path:
    """First distinct feed of the day -> YYYY-MM-DD/, later ones -> YYYY-MM-DD/HHMMSS/."""
    day_dir = raw_dir / now_bkk.strftime("%Y-%m-%d")
    if not (day_dir / RAW_ZIP_NAME).exists() and not (day_dir / MANIFEST_NAME).exists():
        return day_dir
    sub_dir = day_dir / now_bkk.strftime("%H%M%S")
    if sub_dir.exists():
        raise ScrapeError("store", f"target directory already exists: {sub_dir}")
    return sub_dir


def _make_read_only(path: Path) -> None:
    os.chmod(path, stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)


def store_feed(part: Path, target_dir: Path, manifest: dict[str, Any]) -> Path:
    """Move the verified download into place and write its manifest; never overwrites."""
    target_dir.mkdir(parents=True, exist_ok=True)
    final_zip = target_dir / RAW_ZIP_NAME
    final_manifest = target_dir / MANIFEST_NAME
    if final_zip.exists() or final_manifest.exists():
        raise ScrapeError("store", f"refusing to overwrite existing raw data in {target_dir}")
    part.rename(final_zip)
    _make_read_only(final_zip)
    # Manifest is written last: its presence marks the raw feed as complete.
    tmp_manifest = target_dir / (MANIFEST_NAME + ".tmp")
    tmp_manifest.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp_manifest.rename(final_manifest)
    _make_read_only(final_manifest)
    return final_zip


def quarantine(part: Path, raw_dir: Path, run_id: str, error: str) -> Path | None:
    """Keep a failed download for debugging instead of deleting it."""
    if not part.exists():
        return None
    if part.stat().st_size == 0:
        part.unlink()
        return None
    qdir = raw_dir / QUARANTINE_DIRNAME
    qdir.mkdir(parents=True, exist_ok=True)
    dest = qdir / f"{run_id}.zip"
    part.rename(dest)
    (qdir / f"{run_id}.error.txt").write_text(error + "\n", encoding="utf-8")
    return dest


# --------------------------------------------------------------------------
# Scrape log
# --------------------------------------------------------------------------

def ensure_log(log_path: Path) -> None:
    """Create the log, or upgrade an older layout to LOG_FIELDS without losing rows."""
    if not log_path.exists():
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerow(LOG_FIELDS)
        return
    with log_path.open(newline="", encoding="utf-8") as fh:
        rows = [r for r in csv.reader(fh) if r]
    header = rows[0] if rows else []
    if header == LOG_FIELDS:
        return
    if not rows or (header == LEGACY_LOG_FIELDS and len(rows) == 1):
        log.info("upgrading scrape log header in %s", log_path)
        with log_path.open("w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerow(LOG_FIELDS)
        return
    if header == LOG_FIELDS_V1:
        # Every row written with the V1 layout came from the scraper.
        log.info("adding 'stage' column to scrape log %s", log_path)
        tmp = log_path.with_suffix(log_path.suffix + ".tmp")
        with tmp.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(LOG_FIELDS)
            for row in rows[1:]:
                writer.writerow([*row, "scrape"])
        tmp.replace(log_path)
        return
    raise ScrapeError("log", f"unexpected scrape log header in {log_path}: {header}")


def append_log(log_path: Path, rows: list[dict[str, Any]]) -> None:
    ensure_log(log_path)
    with log_path.open("a", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=LOG_FIELDS, extrasaction="raise")
        for row in rows:
            writer.writerow({k: ("" if row.get(k) is None else row.get(k)) for k in LOG_FIELDS})


def _rel(path: Path | None) -> str | None:
    if path is None:
        return None
    try:
        return path.resolve().relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return path.as_posix()


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def run(
    url: str = SOURCE_URL,
    raw_dir: Path = RAW_DIR,
    log_path: Path = SCRAPE_LOG,
    session: requests.Session | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Execute one scrape run and return a summary dict (also written to the log)."""
    now_utc = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    now_bkk = now_utc.astimezone(BANGKOK_TZ)
    run_id = f"{now_utc:%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    base = {
        "run_id": run_id,
        "scrape_timestamp_utc": now_utc.isoformat(timespec="seconds"),
        "scrape_date": now_bkk.strftime("%Y-%m-%d"),
        "source": SOURCE_NAME,
        "stage": "scrape",
    }
    ensure_log(log_path)  # fail early on an incompatible log, before downloading
    raw_dir.mkdir(parents=True, exist_ok=True)
    for stale in raw_dir.glob(f"{PART_PREFIX}*.part"):
        log.warning("stale partial download from an earlier run left in place: %s", stale)

    part = raw_dir / f"{PART_PREFIX}{run_id}.zip.part"
    session = session or build_session()
    dl: DownloadResult | None = None
    try:
        log.info("downloading %s", url)
        dl = download(session, url, part)
        log.info("downloaded %d bytes, sha256=%s", dl.size, dl.sha256)
        verify_zip(part)
        log.info("ZIP verification passed")

        existing = known_feeds(raw_dir).get(dl.sha256)
        if existing is not None:
            part.unlink()  # byte-identical to a feed that is already preserved
            log.info("feed unchanged; identical to %s", _rel(existing))
            manifest = json.loads((existing / MANIFEST_NAME).read_text(encoding="utf-8"))
            summary = {**base, "http_status": dl.http_status,
                       "feed_version": manifest.get("feed_version"),
                       "zip_sha256": dl.sha256, "zip_bytes": dl.size,
                       "raw_path": _rel(existing), "file": RUN_ROW_FILE,
                       "status": "unchanged", "error": None}
            append_log(log_path, [summary])
            return summary

        feed_info = read_feed_info(part)
        feed_version = feed_version_from(feed_info)
        members = inspect_members(part)
        target_dir = new_feed_dir(raw_dir, now_bkk)
        manifest = {
            "manifest_version": 1,
            "run_id": run_id,
            "source": SOURCE_NAME,
            "source_url": url,
            "scrape_timestamp_utc": base["scrape_timestamp_utc"],
            "scrape_timestamp_bangkok": now_bkk.isoformat(timespec="seconds"),
            "http_status": dl.http_status,
            "http_headers": dl.headers,
            "zip_file": RAW_ZIP_NAME,
            "zip_bytes": dl.size,
            "zip_sha256": dl.sha256,
            "feed_version": feed_version,
            "feed_info": feed_info,
            "members": members,
        }
        zip_path = store_feed(part, target_dir, manifest)
        log.info("stored new feed at %s (feed_version=%s)", _rel(zip_path), feed_version)

        member_errors = [m for m in members if m.get("error")]
        status = "partial" if member_errors else "success"
        summary = {**base, "http_status": dl.http_status, "feed_version": feed_version,
                   "zip_sha256": dl.sha256, "zip_bytes": dl.size,
                   "raw_path": _rel(target_dir), "file": RUN_ROW_FILE, "status": status,
                   "error": "; ".join(f"{m['name']}: {m['error']}" for m in member_errors) or None}
        file_rows = [
            {**base, "http_status": dl.http_status, "feed_version": feed_version,
             "zip_sha256": dl.sha256, "zip_bytes": dl.size, "raw_path": _rel(target_dir),
             "file": m["name"], "status": "failed" if m.get("error") else "success",
             "raw_rows": m.get("row_count"), "error": m.get("error")}
            for m in members if "row_count" in m
        ]
        append_log(log_path, [summary, *file_rows])
        return summary

    except ScrapeError as exc:
        log.error("scrape failed: %s", exc)
        qpath = quarantine(part, raw_dir, run_id, str(exc))
        if qpath:
            log.error("failed download kept at %s", _rel(qpath))
        summary = {**base,
                   "http_status": exc.http_status or (dl.http_status if dl else None),
                   "zip_sha256": dl.sha256 if dl else None,
                   "zip_bytes": dl.size if dl else None,
                   "raw_path": _rel(qpath), "file": RUN_ROW_FILE,
                   "status": "failed", "error": str(exc)}
        append_log(log_path, [summary])
        return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Download and preserve the Namtang GTFS feed.")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    parser.add_argument("--log-file", type=Path, help="also write log messages to this file")
    args = parser.parse_args(argv)

    handlers: list[logging.Handler] = [logging.StreamHandler()]
    if args.log_file:
        handlers.append(logging.FileHandler(args.log_file, encoding="utf-8"))
    logging.basicConfig(level=args.log_level, handlers=handlers,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    summary = run()
    log.info("run %s finished with status=%s", summary["run_id"], summary["status"])
    return 0 if summary["status"] in ("success", "unchanged") else 1


if __name__ == "__main__":
    sys.exit(main())
