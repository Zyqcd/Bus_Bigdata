"""Clean a raw Namtang GTFS feed into Parquet, table by table, in local chunks.

Usage (from the project root):
    python data/scraper/processing/clean_gtfs.py [RAW_FEED_DIR ...] [--force] [--chunk-size N]

RAW_FEED_DIR is a stored raw feed (e.g. ``data/raw/namtang/2026-10-01``) holding
``gtfs.zip`` and ``manifest.json``. Without arguments every raw feed that has no
completed clean output yet is processed. No network access happens here.

For every ``.txt`` member of the ZIP the file is streamed straight from the
archive (no extracted copy), read as strings with the ``csv`` module and handled
in chunks of ``CHUNK_ROWS`` rows. Each chunk is cleaned and appended to
``<table>.parquet``; rows that fail a parse/validation rule go, unchanged and
with a ``reject_reason``, to ``rejected/<table>.parquet``. Nothing is dropped:
``raw_rows == clean_rows + rejected_rows`` is checked for every table.

Out of scope here (later phases): duplicate handling, primary-key conflicts,
cross-table references, feed comparison and service-instance expansion
(``frequencies.txt`` rows stay source rows).
"""

from __future__ import annotations

import argparse
import csv
import ctypes
import hashlib
import io
import json
import logging
import shutil
import sys
import time
import uuid
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterator

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from namtang_scraper import RUN_ROW_FILE, append_log  # noqa: E402  shared run log

log = logging.getLogger("clean_gtfs")

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[3]
RAW_DIR = PROJECT_ROOT / "data" / "raw" / "namtang"
CLEAN_DIR = PROJECT_ROOT / "data" / "clean" / "namtang"
SCRAPE_LOG = PROJECT_ROOT / "data" / "metadata" / "scrape_log.csv"

RAW_ZIP_NAME = "gtfs.zip"
MANIFEST_NAME = "manifest.json"
METADATA_NAME = "metadata.json"
SUCCESS_MARKER = "_SUCCESS"
REJECTED_DIRNAME = "rejected"
QUARANTINE_DIRNAME = "_quarantine"

PIPELINE_VERSION = "phase2-2"
CHUNK_ROWS = 100_000          # local processing chunk, not a network limit
PARQUET_COMPRESSION = "snappy"

PRIMARY_TABLE = "stop_times"  # main operational fact table
LINEAGE_COLUMNS = ("feed_sha256", "feed_version")

# Namtang encodes one-off departures as a frequencies row with
# headway_secs = 0 and start_time == end_time. These rows are accepted with
# their source values unchanged and flagged in this boolean column.
SINGLE_DEPARTURE_COL = "is_single_departure"
SINGLE_DEPARTURE_WARNING = "single_departure (headway_secs = 0, start_time == end_time)"

# Generous Thailand bounding box, used only for warnings (never rejection).
THAILAND_BBOX = {"lat": (5.0, 21.0), "lon": (97.0, 106.0)}

csv.field_size_limit(2**31 - 1)


@dataclass(frozen=True)
class Field:
    """GTFS-spec type of a column that exists in the real feed."""

    kind: str                       # "int" | "float" | "date" | "time"
    min_value: float | None = None  # inclusive lower bound -> reject below
    max_value: float | None = None  # inclusive upper bound -> reject above
    allowed: frozenset[int] | None = None  # spec enum -> warn (not reject) outside
    reason: str | None = None       # reject wording for range failures
    region: str | None = None       # "lat" | "lon" -> Thailand bbox warning


_BIN = frozenset({0, 1})
LAT = Field("float", -90, 90, reason="invalid latitude", region="lat")
LON = Field("float", -180, 180, reason="invalid longitude", region="lon")

# GTFS types for the columns observed in feed_version 20260930. Columns not
# listed here are kept as (trimmed) strings; listed columns that are absent
# from a feed are simply skipped.
TABLE_SPECS: dict[str, dict[str, Field]] = {
    "agency": {},
    "stops": {
        "stop_lat": LAT,
        "stop_lon": LON,
        "wheelchair_boarding": Field("int", allowed=frozenset({0, 1, 2})),
    },
    "routes": {
        "route_type": Field("int", allowed=frozenset(
            {0, 1, 2, 3, 4, 5, 6, 7, 11, 12, *range(100, 1800)})),
    },
    "trips": {
        "direction_id": Field("int", allowed=_BIN),
        "wheelchair_accessible": Field("int", allowed=frozenset({0, 1, 2})),
    },
    "stop_times": {
        "arrival_time": Field("time"),
        "departure_time": Field("time"),
        "stop_sequence": Field("int", min_value=0, reason="negative stop_sequence"),
        "timepoint": Field("int", allowed=_BIN),
    },
    "calendar": {
        **{day: Field("int", allowed=_BIN) for day in
           ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")},
        "start_date": Field("date"),
        "end_date": Field("date"),
    },
    "calendar_dates": {
        "date": Field("date"),
        "exception_type": Field("int", allowed=frozenset({1, 2})),
    },
    "fare_attributes": {
        "price": Field("float", min_value=0, reason="negative price"),
        "payment_method": Field("int", allowed=_BIN),
        "transfers": Field("int", allowed=frozenset({0, 1, 2})),  # empty = unlimited
    },
    "fare_rules": {},
    "shapes": {
        "shape_pt_lat": LAT,
        "shape_pt_lon": LON,
        "shape_pt_sequence": Field("int", min_value=0, reason="negative shape_pt_sequence"),
    },
    "frequencies": {
        "start_time": Field("time"),
        "end_time": Field("time"),
        "headway_secs": Field("int", min_value=0, reason="negative headway_secs"),
    },
    "feed_info": {
        "feed_start_date": Field("date"),
        "feed_end_date": Field("date"),
    },
}

_INT_RE = r"[+-]?\d+"
_DATE_RE = r"\d{8}"
_TIME_RE = r"(\d{1,3}):([0-5]\d):([0-5]\d)"   # H:MM:SS / HH:MM:SS, hours may be >= 24


class CleanError(Exception):
    """A failure that prevents a table or feed from being cleaned safely."""


# --------------------------------------------------------------------------
# Reading
# --------------------------------------------------------------------------

def normalize_columns(header: list[str]) -> list[str]:
    """Strip BOM/whitespace and lowercase; fail on collisions."""
    names = [h.replace("﻿", "").strip().lower() for h in header]
    dupes = sorted({n for n in names if names.count(n) > 1})
    if dupes:
        raise CleanError(f"duplicate column names after normalization: {dupes}")
    if "" in names:
        raise CleanError("empty column name in header")
    return names


def iter_chunks(zf: zipfile.ZipFile, member: str, chunk_rows: int
                ) -> Iterator[tuple[list[str], list[list[str]], int]]:
    """Yield (raw_header, rows, first_row_number) chunks straight from the ZIP.

    Row numbers count data records from 1 (header excluded); blank lines are
    skipped, matching the scraper's row counting.
    """
    with zf.open(member) as raw:
        text = io.TextIOWrapper(raw, encoding="utf-8-sig", errors="strict", newline="")
        reader = csv.reader(text)
        header = next(reader, None)
        if header is None:
            raise CleanError("file is empty (no header)")
        rows: list[list[str]] = []
        start = 1
        for row in reader:
            if not row:
                continue
            rows.append(row)
            if len(rows) == chunk_rows:
                yield header, rows, start
                start += len(rows)
                rows = []
        if rows:
            yield header, rows, start


# --------------------------------------------------------------------------
# Cleaning one chunk
# --------------------------------------------------------------------------

@dataclass
class TableStats:
    raw_rows: int = 0
    clean_rows: int = 0
    rejected_rows: int = 0
    reject_reasons: dict[str, int] = field(default_factory=dict)
    warnings: dict[str, int] = field(default_factory=dict)
    null_counts: dict[str, int] = field(default_factory=dict)

    def add(self, bucket: dict[str, int], key: str, n: int) -> None:
        if n:
            bucket[key] = bucket.get(key, 0) + int(n)


def _fmt(values: pd.Series) -> pd.Series:
    return values.astype(object).map(repr)


def clean_chunk(
    header: list[str],
    columns: list[str],
    rows: list[list[str]],
    start_row: int,
    spec: dict[str, Field],
    stats: TableStats,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return (clean, rejected) frames for one chunk; updates ``stats``."""
    width = len(header)
    row_nums = np.arange(start_row, start_row + len(rows), dtype="int64")

    # Rows with the wrong number of fields cannot be aligned to columns safely.
    good_idx = [i for i, r in enumerate(rows) if len(r) == width]
    bad_idx = [i for i, r in enumerate(rows) if len(r) != width]
    malformed = pd.DataFrame(
        {
            "raw_values": [json.dumps(rows[i], ensure_ascii=False) for i in bad_idx],
            "reject_reason": [f"malformed row: expected {width} fields, got {len(rows[i])}"
                              for i in bad_idx],
            "source_row": row_nums[bad_idx],
        }
    )

    raw = pd.DataFrame([rows[i] for i in good_idx], columns=columns, dtype=object)
    raw_rows = row_nums[good_idx]

    # Trim surrounding whitespace; empty -> null. Text is otherwise untouched.
    vals = {c: raw[c].str.strip() for c in columns}
    vals = {c: s.where(s != "", None) for c, s in vals.items()}

    out: dict[str, pd.Series] = {}
    problems: list[pd.Series] = []        # per-check reason strings (None = ok)
    warns: list[tuple[str, pd.Series]] = []  # counted later, on kept rows only

    def flag(mask: pd.Series, col: str, message: str, shown: pd.Series) -> None:
        mask = mask.fillna(False).astype(bool)
        if mask.any():
            problems.append(pd.Series(np.where(mask, f"{col}: {message} (" + _fmt(shown) + ")",
                                               None), index=raw.index, dtype=object))

    for col in columns:
        s = vals[col]
        f = spec.get(col)
        present = s.notna()
        if f is None:
            out[col] = s
            continue

        if f.kind == "int":
            ok = s.str.fullmatch(_INT_RE).fillna(False).astype(bool)
            flag(present & ~ok, col, "invalid integer", s)
            num = pd.to_numeric(s.where(ok), errors="coerce").astype("Int64")
        elif f.kind == "float":
            num = pd.to_numeric(s, errors="coerce").astype("float64")
            finite = np.isfinite(num.to_numpy(dtype="float64", na_value=np.nan))
            ok = pd.Series(finite, index=raw.index)
            flag(present & ~ok, col, "invalid number", s)
            num = num.where(ok)
        elif f.kind == "date":
            fmt_ok = s.str.fullmatch(_DATE_RE).fillna(False).astype(bool)
            parsed = pd.to_datetime(s.where(fmt_ok), format="%Y%m%d", errors="coerce")
            flag(present & parsed.isna(), col, "invalid date", s)
            out[col] = pd.Series([d.date() if pd.notna(d) else None for d in parsed],
                                 index=raw.index, dtype=object)
            continue
        elif f.kind == "time":
            parts = s.str.extract(f"^{_TIME_RE}$")
            ok = parts[0].notna()
            flag(present & ~ok, col, "malformed time", s)
            p = parts.apply(pd.to_numeric).astype("Int64")
            out[col] = s                                    # original GTFS string
            out[f"{col}_secs"] = p[0] * 3600 + p[1] * 60 + p[2]
            continue
        else:  # pragma: no cover - spec typo guard
            raise CleanError(f"unknown field kind {f.kind!r} for {col}")

        # Range / enum checks on successfully parsed numbers.
        valid = num.notna()
        if f.min_value is not None or f.max_value is not None:
            low = (num < f.min_value) if f.min_value is not None else False
            high = (num > f.max_value) if f.max_value is not None else False
            out_of_range = valid & (low | high)
            flag(out_of_range, col, f.reason or "value out of range", s)
        if f.allowed is not None:
            warns.append((f"{col}: value outside GTFS enum", valid & ~num.isin(list(f.allowed))))
        if f.region:
            lo, hi = THAILAND_BBOX[f.region]
            warns.append((f"{col}: outside Thailand bounding box",
                          valid & ((num < lo) | (num > hi))))
            warns.append((f"{col}: exactly 0", valid & (num == 0)))
        out[col] = num

    if has_single_departure_rule(columns, spec):
        headway = out["headway_secs"]
        zero = (headway == 0).fillna(False).astype(bool)
        same = (out["start_time_secs"] == out["end_time_secs"]).fillna(False).astype(bool)
        single = zero & same
        flag(zero & ~single, "headway_secs",
             "headway_secs = 0 without start_time == end_time", vals["headway_secs"])
        out[SINGLE_DEPARTURE_COL] = single
        warns.append((SINGLE_DEPARTURE_WARNING, single))

    if problems:
        reasons = pd.concat(problems, axis=1).apply(
            lambda r: "; ".join(x for x in r if x is not None) or None, axis=1)
    else:
        reasons = pd.Series(None, index=raw.index, dtype=object)
    rejected_mask = reasons.notna().to_numpy()
    for key, mask in warns:
        stats.add(stats.warnings, key,
                  (mask.fillna(False).to_numpy(dtype=bool) & ~rejected_mask).sum())

    clean = pd.DataFrame(out, index=raw.index)[~rejected_mask]
    clean.insert(len(clean.columns), "source_row", raw_rows[~rejected_mask])

    rejected = pd.DataFrame(
        {
            "raw_values": [json.dumps(r, ensure_ascii=False)
                           for r in raw[rejected_mask].itertuples(index=False, name=None)],
            "reject_reason": reasons[rejected_mask].to_list(),
            "source_row": raw_rows[rejected_mask],
        }
    )
    if len(malformed):
        rejected = pd.concat([malformed, rejected], ignore_index=True)
    if len(rejected):
        for reason in rejected["reject_reason"]:
            for part in reason.split("; "):
                stats.add(stats.reject_reasons, part.split(" (")[0], 1)
    return clean, rejected


# --------------------------------------------------------------------------
# Parquet schemas and table processing
# --------------------------------------------------------------------------

_ARROW = {"int": pa.int64(), "float": pa.float64(), "date": pa.date32()}


def clean_schema(columns: list[str], spec: dict[str, Field]) -> pa.Schema:
    fields: list[pa.Field] = []
    for col in columns:
        f = spec.get(col)
        if f is None:
            fields.append(pa.field(col, pa.string()))
        elif f.kind == "time":
            fields += [pa.field(col, pa.string()), pa.field(f"{col}_secs", pa.int64())]
        else:
            fields.append(pa.field(col, _ARROW[f.kind]))
    if has_single_departure_rule(columns, spec):
        fields.append(pa.field(SINGLE_DEPARTURE_COL, pa.bool_()))
    fields.append(pa.field("source_row", pa.int64()))
    fields += [pa.field(c, pa.string()) for c in lineage_columns_for(columns)]
    return pa.schema(fields)


def has_single_departure_rule(columns: list[str], spec: dict[str, Field]) -> bool:
    needed = ("headway_secs", "start_time", "end_time")
    return all(c in columns and c in spec for c in needed)


def lineage_columns_for(columns: list[str]) -> list[str]:
    """Lineage columns to add; a source column with the same name (feed_info's
    feed_version) is kept as-is instead of being shadowed or duplicated."""
    return [c for c in LINEAGE_COLUMNS if c not in columns]


def check_reserved_names(columns: list[str], spec: dict[str, Field]) -> None:
    generated = {"source_row"} | {f"{c}_secs" for c, f in spec.items()
                                  if f.kind == "time" and c in columns}
    if has_single_departure_rule(columns, spec):
        generated.add(SINGLE_DEPARTURE_COL)
    clash = sorted(generated & set(columns))
    if clash:
        raise CleanError(f"source columns clash with generated column names: {clash}")


REJECTED_SCHEMA = pa.schema([
    pa.field("source_table", pa.string()),
    pa.field("source_row", pa.int64()),
    pa.field("reject_reason", pa.string()),
    pa.field("raw_values", pa.string()),       # JSON array of the original field strings
    pa.field("raw_header", pa.string()),       # JSON array of the original header
    *(pa.field(c, pa.string()) for c in LINEAGE_COLUMNS),
])


@dataclass
class TableResult:
    table: str
    member: str
    status: str
    stats: TableStats
    output_path: str | None
    rejected_path: str | None
    columns: dict[str, str]
    seconds: float
    error: str | None = None

    def to_json(self) -> dict[str, Any]:
        s = self.stats
        return {
            "source_file": self.member,
            "processing_status": self.status,
            "raw_rows": s.raw_rows,
            "clean_rows": s.clean_rows,
            "rejected_rows": s.rejected_rows,
            "invariant_ok": s.raw_rows == s.clean_rows + s.rejected_rows,
            "output_path": self.output_path,
            "rejected_path": self.rejected_path,
            "reject_reasons": s.reject_reasons,
            "warnings": s.warnings,
            "null_counts": s.null_counts,
            "schema": self.columns,
            "seconds": round(self.seconds, 2),
            "error": self.error,
        }


def process_table(
    zf: zipfile.ZipFile,
    member: str,
    out_dir: Path,
    lineage: dict[str, str],
    chunk_rows: int = CHUNK_ROWS,
) -> TableResult:
    table = PurePosixPath(member).stem.lower()
    spec = TABLE_SPECS.get(table, {})
    if table not in TABLE_SPECS:
        log.warning("%s: no GTFS type spec, all columns kept as strings", member)
    out_path = out_dir / f"{table}.parquet"
    rej_path = out_dir / REJECTED_DIRNAME / f"{table}.parquet"
    stats = TableStats()
    started = time.perf_counter()
    writer: pq.ParquetWriter | None = None
    rej_writer: pq.ParquetWriter | None = None
    schema: pa.Schema | None = None

    try:
        for header, rows, start in iter_chunks(zf, member, chunk_rows):
            if schema is None:
                columns = normalize_columns(header)
                check_reserved_names(columns, spec)
                schema = clean_schema(columns, spec)
                added_lineage = {c: lineage[c] for c in lineage_columns_for(columns)}
                writer = pq.ParquetWriter(out_path, schema, compression=PARQUET_COMPRESSION)
                raw_header_json = json.dumps(header, ensure_ascii=False)
            clean, rejected = clean_chunk(header, columns, rows, start, spec, stats)
            stats.raw_rows += len(rows)
            stats.clean_rows += len(clean)
            stats.rejected_rows += len(rejected)
            for c in clean.columns:
                stats.add(stats.null_counts, c, clean[c].isna().sum())

            for c, v in added_lineage.items():
                clean[c] = v
            writer.write_table(pa.Table.from_pandas(clean, schema=schema, preserve_index=False))

            if len(rejected):
                rejected.insert(0, "source_table", table)
                rejected["raw_header"] = raw_header_json
                for c, v in lineage.items():
                    rejected[c] = v
                if rej_writer is None:
                    rej_path.parent.mkdir(exist_ok=True)
                    rej_writer = pq.ParquetWriter(rej_path, REJECTED_SCHEMA,
                                                  compression=PARQUET_COMPRESSION)
                rej_writer.write_table(pa.Table.from_pandas(
                    rejected, schema=REJECTED_SCHEMA, preserve_index=False))
            log.debug("%s: rows %d-%d done", table, start, start + len(rows) - 1)

        if schema is None:  # header-only file never yields a chunk
            raise CleanError("no header")
    except CleanError as exc:
        return _failed(table, member, stats, started, str(exc), writer, rej_writer)
    except (UnicodeDecodeError, csv.Error, pa.ArrowException, ValueError) as exc:
        return _failed(table, member, stats, started, f"{type(exc).__name__}: {exc}",
                       writer, rej_writer)
    finally:
        for w in (writer, rej_writer):
            if w is not None and w.is_open:
                w.close()

    status = "success_with_rejects" if stats.rejected_rows else "success"
    if stats.raw_rows != stats.clean_rows + stats.rejected_rows:
        status = "failed"
    return TableResult(
        table, member, status, stats,
        output_path=f"{table}.parquet",
        rejected_path=f"{REJECTED_DIRNAME}/{table}.parquet" if rej_writer else None,
        columns={f.name: str(f.type) for f in schema},
        seconds=time.perf_counter() - started,
    )


def _failed(table, member, stats, started, error, *writers) -> TableResult:
    for w in writers:
        if w is not None and w.is_open:
            w.close()
    log.error("%s: %s", member, error)
    return TableResult(table, member, "failed", stats, None, None, {},
                       time.perf_counter() - started, error)


# --------------------------------------------------------------------------
# Feed-level orchestration
# --------------------------------------------------------------------------

def peak_memory_bytes() -> int | None:
    """Best-effort peak resident memory of this process."""
    try:
        if sys.platform == "win32":
            class PMC(ctypes.Structure):
                _fields_ = [("cb", ctypes.c_ulong), ("PageFaultCount", ctypes.c_ulong),
                            ("PeakWorkingSetSize", ctypes.c_size_t),
                            ("WorkingSetSize", ctypes.c_size_t),
                            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                            ("PagefileUsage", ctypes.c_size_t),
                            ("PeakPagefileUsage", ctypes.c_size_t)]
            pmc = PMC()
            pmc.cb = ctypes.sizeof(PMC)
            kernel32 = ctypes.windll.kernel32
            kernel32.GetCurrentProcess.restype = ctypes.c_void_p
            get_info = ctypes.windll.psapi.GetProcessMemoryInfo
            get_info.argtypes = [ctypes.c_void_p, ctypes.POINTER(PMC), ctypes.c_ulong]
            get_info.restype = ctypes.c_int
            if get_info(kernel32.GetCurrentProcess(), ctypes.byref(pmc), pmc.cb):
                return int(pmc.PeakWorkingSetSize)
            return None
        import resource
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(peak if sys.platform == "darwin" else peak * 1024)
    except Exception:  # diagnostics only; never affects the data
        log.debug("peak memory unavailable", exc_info=True)
        return None


def sha256_of(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def clean_dir_for(raw_feed_dir: Path, raw_root: Path, clean_root: Path) -> Path:
    """data/raw/namtang/2026-10-01[/HHMMSS] -> data/clean/namtang/2026-10-01[_HHMMSS]."""
    rel = raw_feed_dir.resolve().relative_to(raw_root.resolve())
    return clean_root / "_".join(rel.parts)


def _rel(path: Path) -> str:
    try:
        return path.resolve().relative_to(PROJECT_ROOT).as_posix()
    except ValueError:
        return path.as_posix()


def clean_feed(
    raw_feed_dir: Path,
    raw_root: Path = RAW_DIR,
    clean_root: Path = CLEAN_DIR,
    chunk_rows: int = CHUNK_ROWS,
    force: bool = False,
    log_path: Path = SCRAPE_LOG,
) -> dict[str, Any]:
    """Clean one raw feed into ``clean_root``; returns the metadata dict.

    Output is built in a temporary sibling directory and moved into place only
    when every table succeeded, so a crash never leaves a half-written dataset.
    """
    zip_path = raw_feed_dir / RAW_ZIP_NAME
    manifest_path = raw_feed_dir / MANIFEST_NAME
    if not zip_path.exists() or not manifest_path.exists():
        raise CleanError(f"{raw_feed_dir} is not a complete raw feed")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    target = clean_dir_for(raw_feed_dir, raw_root, clean_root)

    if (target / SUCCESS_MARKER).exists() and not force:
        log.info("%s already cleaned; skipping (use --force to rebuild)", _rel(target))
        return json.loads((target / METADATA_NAME).read_text(encoding="utf-8"))
    if target.exists() and not force:
        raise CleanError(f"{target} exists without {SUCCESS_MARKER}; inspect it or use --force")

    actual_sha = sha256_of(zip_path)
    if actual_sha != manifest["zip_sha256"]:
        raise CleanError(f"raw ZIP hash {actual_sha} does not match manifest "
                         f"{manifest['zip_sha256']}; raw data may be corrupted")
    lineage = {"feed_sha256": manifest["zip_sha256"],
               "feed_version": manifest.get("feed_version")}
    expected_rows = {m["name"]: m.get("row_count") for m in manifest.get("members", [])}

    run_id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    work = clean_root / f".tmp_{target.name}_{run_id}"
    (work / REJECTED_DIRNAME).mkdir(parents=True)
    started_at = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    log.info("cleaning %s (feed_version=%s) -> %s", _rel(zip_path), lineage["feed_version"],
             _rel(target))

    results: list[TableResult] = []
    skipped: list[str] = []
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            if not info.filename.lower().endswith(".txt"):
                skipped.append(info.filename)
                continue
            res = process_table(zf, info.filename, work, lineage, chunk_rows)
            expected = expected_rows.get(info.filename)
            if res.status != "failed" and expected is not None and expected != res.stats.raw_rows:
                res.status = "failed"
                res.error = (f"raw row count {res.stats.raw_rows} differs from manifest "
                             f"row_count {expected}")
            log.info("%-20s raw=%9d clean=%9d rejected=%7d %s (%.1fs)", res.table,
                     res.stats.raw_rows, res.stats.clean_rows, res.stats.rejected_rows,
                     res.status, res.seconds)
            results.append(res)

    tables = {r.table: r.to_json() for r in results}
    for r in results:
        if r.output_path:
            tables[r.table]["output_bytes"] = (work / r.output_path).stat().st_size
        if r.rejected_path:
            tables[r.table]["rejected_bytes"] = (work / r.rejected_path).stat().st_size
    ok = bool(results) and all(r.status != "failed" for r in results)
    metadata = {
        "pipeline_version": PIPELINE_VERSION,
        "run_id": run_id,
        "status": "success" if ok else "failed",
        "source_raw_dir": _rel(raw_feed_dir),
        "source_zip": _rel(zip_path),
        "feed_sha256": lineage["feed_sha256"],
        "feed_version": lineage["feed_version"],
        "feed_sha256_verified": True,
        "started_at_utc": started_at.isoformat(timespec="seconds"),
        "finished_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "seconds": round(time.perf_counter() - t0, 2),
        "peak_memory_bytes": peak_memory_bytes(),
        "chunk_rows": chunk_rows,
        "primary_table": PRIMARY_TABLE,
        "largest_table": max(results, key=lambda r: r.stats.raw_rows).table if results else None,
        "totals": {
            "raw_rows": sum(r.stats.raw_rows for r in results),
            "clean_rows": sum(r.stats.clean_rows for r in results),
            "rejected_rows": sum(r.stats.rejected_rows for r in results),
            "note": "Sum of rows across different GTFS tables (stops, shape points, fares, "
                    "...); not a count of trips or of any single entity.",
        },
        "derived_rows": {"service_instances": None,
                         "note": "Not computed; frequency-based trips are not expanded."},
        "invariant_ok_all_tables": all(t["invariant_ok"] for t in tables.values()),
        "skipped_non_txt_members": skipped,
        "tables": tables,
    }
    (work / METADATA_NAME).write_text(json.dumps(metadata, indent=2, ensure_ascii=False),
                                      encoding="utf-8")
    append_log(log_path, clean_log_rows(metadata, manifest, raw_feed_dir))
    if not ok:
        log.error("cleaning failed; partial output kept for inspection at %s", _rel(work))
        return metadata

    (work / SUCCESS_MARKER).write_text("", encoding="utf-8")
    if target.exists():  # only reachable with --force; clean data is rebuildable from raw
        log.warning("replacing existing clean output %s", _rel(target))
        old = clean_root / f".old_{target.name}_{run_id}"
        target.rename(old)
        work.rename(target)
        shutil.rmtree(old)
    else:
        work.rename(target)
    log.info("clean feed written to %s in %.1fs", _rel(target), metadata["seconds"])
    return metadata


def clean_log_rows(metadata: dict[str, Any], manifest: dict[str, Any],
                   raw_feed_dir: Path) -> list[dict[str, Any]]:
    """Run-level and per-table counts for the shared scrape log (no data rows)."""
    base = {
        "run_id": metadata["run_id"],
        "scrape_timestamp_utc": metadata["started_at_utc"],      # time of this clean run
        "scrape_date": str(manifest.get("scrape_timestamp_bangkok", ""))[:10] or None,
        "source": manifest.get("source"),
        "feed_version": metadata["feed_version"],
        "zip_sha256": metadata["feed_sha256"],
        "zip_bytes": manifest.get("zip_bytes"),
        "raw_path": _rel(raw_feed_dir),
        "stage": "clean",
    }
    totals = metadata["totals"]
    rows = [{**base, "file": RUN_ROW_FILE, "status": metadata["status"],
             "raw_rows": totals["raw_rows"], "clean_rows": totals["clean_rows"],
             "rejected_rows": totals["rejected_rows"]}]
    for t in metadata["tables"].values():
        rows.append({**base, "file": t["source_file"], "status": t["processing_status"],
                     "raw_rows": t["raw_rows"], "clean_rows": t["clean_rows"],
                     "rejected_rows": t["rejected_rows"], "error": t["error"]})
    return rows


def pending_feeds(raw_root: Path = RAW_DIR, clean_root: Path = CLEAN_DIR) -> list[Path]:
    """Raw feed directories (with a manifest) that have no completed clean output."""
    feeds = []
    for manifest in sorted(raw_root.rglob(MANIFEST_NAME)):
        feed_dir = manifest.parent
        if QUARANTINE_DIRNAME in feed_dir.relative_to(raw_root).parts:
            continue
        if not (clean_dir_for(feed_dir, raw_root, clean_root) / SUCCESS_MARKER).exists():
            feeds.append(feed_dir)
    return feeds


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Clean raw Namtang GTFS feeds into Parquet.")
    parser.add_argument("feeds", nargs="*", type=Path,
                        help="raw feed directories (default: all not yet cleaned)")
    parser.add_argument("--force", action="store_true", help="rebuild existing clean output")
    parser.add_argument("--chunk-size", type=int, default=CHUNK_ROWS)
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args(argv)
    logging.basicConfig(level=args.log_level,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if args.chunk_size < 1:
        parser.error("--chunk-size must be positive")

    feeds = args.feeds or pending_feeds()
    if not feeds:
        log.info("nothing to clean")
        return 0
    exit_code = 0
    for feed in feeds:
        try:
            meta = clean_feed(feed, chunk_rows=args.chunk_size, force=args.force)
        except CleanError as exc:
            log.error("%s: %s", feed, exc)
            exit_code = 1
            continue
        if meta["status"] != "success":
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
