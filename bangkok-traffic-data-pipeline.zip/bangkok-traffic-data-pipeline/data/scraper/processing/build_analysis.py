"""Build the analysis-ready layer from a clean Namtang GTFS feed.

Usage (from the project root):
    python data/scraper/processing/build_analysis.py [CLEAN_FEED_DIR ...] [--force]

Inputs (read-only):
  * data/clean/namtang/<feed>/                       clean GTFS Parquet
  * data/metadata/data_quality_policy_<feed>.json    authoritative DQ policy
Output:
  * data/analysis/namtang/<feed>/                    derived Parquet + metadata.json

Principles:
  * Raw and clean data are never modified; the derived layer is rebuildable.
  * No rows are excluded. Data-quality issues are exposed as flag columns tied
    to policy IDs (DQ-001 ...), and every flag count is reconciled against the
    policy.
  * No IDs, zones, coordinates, times or service dates are invented, and no
    service instances are generated.
  * Every row-level dataset keeps ``source_table``, ``source_row`` and the
    feed lineage columns ``feed_sha256`` / ``feed_version``.
"""

from __future__ import annotations

import argparse
import json
import logging
import shutil
import sys
import time
import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

import clean_gtfs as cg
import validate_gtfs as vg
from namtang_scraper import RUN_ROW_FILE, append_log

log = logging.getLogger("build_analysis")

ANALYSIS_DIR = cg.PROJECT_ROOT / "data" / "analysis" / "namtang"
METADATA_DIR = cg.PROJECT_ROOT / "data" / "metadata"
BUILDER_VERSION = "phase4-1"
BATCH_ROWS = cg.CHUNK_ROWS
EARTH_RADIUS_M = 6_371_008.8

PASS, ERROR = vg.PASS, vg.ERROR
_PD_TYPES = {pa.int64(): pd.Int64Dtype(), pa.bool_(): pd.BooleanDtype()}


class AnalysisError(Exception):
    """Input that cannot be turned into a trustworthy derived dataset."""


def haversine_m(lat1, lon1, lat2, lon2) -> np.ndarray:
    """Great-circle distance in metres; NaN in, NaN out."""
    la1, lo1, la2, lo2 = (np.radians(np.asarray(v, dtype="float64"))
                          for v in (lat1, lon1, lat2, lon2))
    a = (np.sin((la2 - la1) / 2) ** 2
         + np.cos(la1) * np.cos(la2) * np.sin((lo2 - lo1) / 2) ** 2)
    return 2 * EARTH_RADIUS_M * np.arcsin(np.sqrt(a))


def _f(series: pd.Series) -> np.ndarray:
    """Nullable numeric -> float64 numpy with NaN for missing."""
    return pd.to_numeric(series, errors="coerce").astype("float64").to_numpy()


# --------------------------------------------------------------------------
# Context
# --------------------------------------------------------------------------

@dataclass
class Ctx:
    clean_dir: Path
    work: Path
    policy_path: Path
    meta: dict[str, Any] = field(init=False)
    manifest: dict[str, Any] = field(init=False)
    policy: dict[str, Any] = field(init=False)
    scrape_date: date | None = field(init=False)
    transformations: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.meta = json.loads((self.clean_dir / cg.METADATA_NAME).read_text(encoding="utf-8"))
        if not (self.clean_dir / cg.SUCCESS_MARKER).exists() or self.meta.get("status") != "success":
            raise AnalysisError(f"{self.clean_dir} is not a completed clean feed")
        raw_dir = cg.PROJECT_ROOT / self.meta["source_raw_dir"]
        self.manifest = json.loads((raw_dir / cg.MANIFEST_NAME).read_text(encoding="utf-8"))
        if not self.policy_path.exists():
            raise AnalysisError(f"data quality policy not found: {self.policy_path}")
        self.policy = json.loads(self.policy_path.read_text(encoding="utf-8"))
        if self.policy.get("feed", {}).get("feed_sha256") != self.meta["feed_sha256"]:
            raise AnalysisError("data quality policy was written for a different feed "
                                f"({self.policy.get('feed', {}).get('feed_sha256')})")
        day = str(self.manifest.get("scrape_timestamp_bangkok", ""))[:10]
        self.scrape_date = date.fromisoformat(day) if day else None

    @property
    def lineage(self) -> dict[str, str]:
        return {"feed_sha256": self.meta["feed_sha256"], "feed_version": self.meta["feed_version"]}

    def path(self, table: str) -> Path:
        return self.clean_dir / f"{table}.parquet"

    def has(self, table: str, *columns: str) -> bool:
        if not self.path(table).exists():
            return False
        names = set(pq.read_schema(self.path(table)).names)
        return all(c in names for c in columns)

    def num_rows(self, table: str) -> int:
        return pq.ParquetFile(self.path(table)).metadata.num_rows if self.path(table).exists() else 0

    def columns(self, table: str, wanted: list[str]) -> list[str]:
        names = pq.read_schema(self.path(table)).names
        return [c for c in wanted if c in names]

    def read(self, table: str, columns: list[str] | None = None) -> pd.DataFrame:
        """Column-projected read; used for tables up to stop_times size."""
        if not self.path(table).exists():
            return pd.DataFrame(columns=columns or [])
        cols = None if columns is None else self.columns(table, columns)
        return pq.read_table(self.path(table), columns=cols).to_pandas(types_mapper=_PD_TYPES.get)

    def policy_issue(self, issue_id: str) -> dict[str, Any] | None:
        return next((i for i in self.policy.get("issues", []) if i.get("id") == issue_id), None)

    def write(self, name: str, df: pd.DataFrame, source_table: str | None) -> int:
        out = df.copy()
        if source_table is not None:
            out.insert(0, "source_table", source_table)
        for col, value in self.lineage.items():
            out[col] = value
        pq.write_table(pa.Table.from_pandas(out, preserve_index=False), self.work / name,
                       compression=cg.PARQUET_COMPRESSION)
        return len(out)

    def record(self, output: str, grain: str, inputs: dict[str, int], output_rows: int,
               flagged: dict[str, int], method: list[str], **extra: Any) -> None:
        self.transformations.append({
            "output": output, "grain": grain, "input_tables": inputs,
            "output_rows": output_rows, "excluded_rows": 0,
            "flagged_rows": {k: int(v) for k, v in flagged.items()},
            "method": method, **extra,
        })


# --------------------------------------------------------------------------
# Shared data-quality context (computed from the data, checked against policy)
# --------------------------------------------------------------------------

def dq_context(ctx: Ctx) -> dict[str, Any]:
    agency = ctx.read("agency")
    src_cols = [c for c in agency.columns
                if c not in ("source_row", *cg.LINEAGE_COLUMNS)]
    per_id = agency.groupby("agency_id", dropna=False)
    sizes = per_id.size()
    differing = per_id[src_cols].nunique(dropna=False).max(axis=1)
    colliding = sorted(i for i in sizes.index if sizes[i] > 1 and differing[i] > 1)

    zones = unique_values(ctx, "stops", "zone_id")
    fare_zone_values = unique_values(ctx, "fare_rules", "origin_id") | \
        unique_values(ctx, "fare_rules", "destination_id")
    orphan_zones = sorted(fare_zone_values - zones)
    return {"colliding_agency_ids": colliding, "orphan_zones": orphan_zones,
            "agency": agency}


def unique_values(ctx: Ctx, table: str, column: str) -> set:
    """Distinct non-null values of one clean column, streamed in batches."""
    if not ctx.has(table, column):
        return set()
    parts = [pc.unique(b.column(0)) for b in pq.ParquetFile(ctx.path(table)).iter_batches(
        batch_size=BATCH_ROWS, columns=[column])]
    return set(pc.unique(pa.concat_arrays(parts)).drop_null().to_pylist()) if parts else set()


def value_counts(column: pa.ChunkedArray) -> pd.Series:
    vc = pc.value_counts(column)
    return pd.Series(vc.field("counts").to_numpy(), index=vc.field("values").to_pylist(),
                     dtype="int64")


def services_in_effect(ctx: Ctx) -> set[str]:
    """Services whose calendar range covers the scrape date, or that are added by a
    calendar_dates exception on/after it. Weekday patterns are not expanded into dates."""
    if ctx.scrape_date is None:
        return set()
    day = ctx.scrape_date
    out: set[str] = set()
    cal = ctx.read("calendar", ["service_id", "start_date", "end_date"])
    if len(cal):
        mask = (cal["start_date"] <= day) & (cal["end_date"] >= day)
        out |= set(cal.loc[mask.fillna(False).astype(bool), "service_id"].dropna())
    cd = ctx.read("calendar_dates", ["service_id", "date", "exception_type"])
    if len(cd):
        added = (cd["exception_type"] == 1).fillna(False) & (cd["date"] >= day).fillna(False)
        out |= set(cd.loc[added.astype(bool), "service_id"].dropna())
    return out


# --------------------------------------------------------------------------
# Datasets
# --------------------------------------------------------------------------

def build_fares(ctx: Ctx, dq: dict[str, Any]) -> dict[str, Any]:
    """fare_rules joined to fare_attributes, streamed in batches (946k rows)."""
    name = "fare_analysis.parquet"
    if not ctx.has("fare_rules"):
        return {"route_rules": pd.Series(dtype="int64"), "route_unresolved": pd.Series(dtype="int64"),
                "origin_zone": pd.Series(dtype="int64"), "destination_zone": pd.Series(dtype="int64"),
                "agency_fares": pd.Series(dtype="int64")}
    fa_cols = ctx.columns("fare_attributes", ["fare_id", "price", "currency_type",
                                              "payment_method", "transfers", "agency_id",
                                              "source_row"])
    fa = pq.read_table(ctx.path("fare_attributes"), columns=fa_cols)
    fa = fa.rename_columns([("fare_attributes_source_row" if c == "source_row" else c)
                            for c in fa.column_names])
    # fare_id is unique in fare_attributes (validated), so a lookup index built once
    # plus take() is an exact left join without rebuilding a hash table per batch.
    fa_index = pd.Index(fa.column("fare_id").to_pylist())
    if not fa_index.is_unique:
        raise AnalysisError("fare_attributes.fare_id is not unique; fare join would fan out")
    fa_attrs = fa.drop_columns(["fare_id"])
    agency_fares = value_counts(fa.column("agency_id")) if "agency_id" in fa_cols \
        else pd.Series(dtype="int64")
    zones = set(ctx.read("stops", ["zone_id"])["zone_id"].dropna())
    colliding = set(dq["colliding_agency_ids"])
    sel_cols = [c for c in ("route_id", "origin_id", "destination_id", "contains_id")
                if ctx.has("fare_rules", c)]
    fr_cols = ["fare_id", *sel_cols, "source_row"]

    writer: pq.ParquetWriter | None = None
    rows = unresolved = agency_flag = 0
    route_rules, route_unres, origin_zone, dest_zone = [], [], [], []
    try:
        for b in pq.ParquetFile(ctx.path("fare_rules")).iter_batches(
                batch_size=BATCH_ROWS, columns=fr_cols):
            t = pa.Table.from_batches([b]).rename_columns(
                [("fare_rules_source_row" if c == "source_row" else c) for c in fr_cols])
            idx = fa_index.get_indexer(t.column("fare_id").to_pylist())
            matched = fa_attrs.take(pa.array(idx, mask=idx < 0))   # unmatched -> nulls
            for col in matched.column_names:
                t = t.append_column(col, matched.column(col))
            df = t.to_pandas(types_mapper=_PD_TYPES.get)
            df.insert(0, "source_table", "fare_rules")
            for col in ("origin_id", "destination_id"):
                if col in df.columns:
                    df[f"{col.split('_')[0]}_zone_resolved"] = (
                        df[col].isin(list(zones)).astype("boolean").where(df[col].notna()))
            res_cols = [c for c in ("origin_zone_resolved", "destination_zone_resolved")
                        if c in df.columns]
            df["unresolved_fare_zone"] = (
                (~df[res_cols].fillna(True).astype(bool)).any(axis=1) if res_cols else False)
            df["agency_identity_unresolved"] = df["agency_id"].isin(list(colliding)) \
                if "agency_id" in df.columns else False
            bits = 1 << np.arange(len(sel_cols))
            codes = df[sel_cols].notna().to_numpy() @ bits
            labels = {c: "+".join(s for i, s in enumerate(sel_cols) if c >> i & 1) or "(none)"
                      for c in np.unique(codes)}
            df["selector_pattern"] = [labels[c] for c in codes]
            for col, value in ctx.lineage.items():
                df[col] = value
            table = pa.Table.from_pandas(df, preserve_index=False)
            if writer is None:
                writer = pq.ParquetWriter(ctx.work / name, table.schema,
                                          compression=cg.PARQUET_COMPRESSION)
            writer.write_table(table.cast(writer.schema))
            rows += len(df)
            unresolved += int(df["unresolved_fare_zone"].sum())
            agency_flag += int(df["agency_identity_unresolved"].sum())
            if "route_id" in df.columns:
                route_rules.append(df["route_id"].value_counts())
                route_unres.append(df.loc[df["unresolved_fare_zone"], "route_id"].value_counts())
            if "origin_id" in df.columns:
                origin_zone.append(df["origin_id"].value_counts())
            if "destination_id" in df.columns:
                dest_zone.append(df["destination_id"].value_counts())
    finally:
        if writer is not None:
            writer.close()

    def total(parts: list[pd.Series]) -> pd.Series:
        return (pd.concat(parts).groupby(level=0).sum().astype("int64") if parts
                else pd.Series(dtype="int64"))

    ctx.record(name, "one row per source fare_rules row",
               {"fare_rules": ctx.num_rows("fare_rules"),
                "fare_attributes": ctx.num_rows("fare_attributes")},
               rows, {"DQ-001": agency_flag, "DQ-002": unresolved},
               ["left join fare_rules -> fare_attributes on fare_id via a unique lookup "
                "index (no fan-out possible), processed in batches of %d rows in source "
                "order" % BATCH_ROWS,
                "origin/destination_zone_resolved = zone id exists in stops.zone_id "
                "(null when the selector is null)",
                "unresolved_fare_zone flags DQ-002 orphan zones; zone values are not replaced",
                "agency_identity_unresolved flags DQ-001 agency_ids; agency_id is not remapped",
                "selector_pattern lists which optional selectors are non-null"],
               source_row_columns={"fare_rules_source_row": "fare_rules",
                                   "fare_attributes_source_row": "fare_attributes"},
               orphan_zones=dq["orphan_zones"])
    return {"route_rules": total(route_rules), "route_unresolved": total(route_unres),
            "origin_zone": total(origin_zone), "destination_zone": total(dest_zone),
            "agency_fares": agency_fares}


def build_frequencies(ctx: Ctx) -> pd.DataFrame:
    name = "frequencies_analysis.parquet"
    fq = ctx.read("frequencies")
    if not len(fq):
        return fq
    fq = fq.drop(columns=list(cg.LINEAGE_COLUMNS)).sort_values("source_row", kind="stable")
    key = ["trip_id", "start_time", "end_time", "headway_secs"]
    g = fq.groupby(key, dropna=False, sort=False)
    rank = g.cumcount()
    size = g["source_row"].transform("size")
    first_row = g["source_row"].transform("min")
    single = fq[cg.SINGLE_DEPARTURE_COL].fillna(False).astype(bool) \
        if cg.SINGLE_DEPARTURE_COL in fq.columns else pd.Series(False, index=fq.index)
    headway = _f(fq["headway_secs"])
    window = _f(fq["end_time_secs"]) - _f(fq["start_time_secs"])
    normal = ~single.to_numpy() & (headway > 0)
    with np.errstate(divide="ignore", invalid="ignore"):
        est = np.where(single, 1.0, np.where(normal, np.ceil(window / headway), np.nan))
        per_hour = np.where(normal, 3600.0 / headway, np.nan)
    fq["window_secs"] = pd.array(window, dtype="Float64").astype("Int64")
    fq["is_duplicate_window"] = (size > 1).astype(bool)
    fq["counted_in_derived"] = (rank == 0).astype(bool)
    fq["duplicate_of_source_row"] = first_row.where(rank > 0).astype("Int64")
    fq["departures_per_hour"] = pd.array(per_hour, dtype="Float64")
    fq["estimated_departures_in_window"] = pd.array(est, dtype="Float64").astype("Int64")
    fq["counted_estimated_departures"] = fq["estimated_departures_in_window"].where(
        fq["counted_in_derived"], 0).astype("Int64")
    rows = ctx.write(name, fq, "frequencies")
    ctx.record(name, "one row per source frequencies row",
               {"frequencies": ctx.num_rows("frequencies")}, rows,
               {"DQ-003": int((rank > 0).sum()), "DQ-004": int(single.sum())},
               ["DQ-003: rows identical on (trip_id, start_time, end_time, headway_secs) are "
                "marked is_duplicate_window; only the first source_row has counted_in_derived = "
                "true, later copies point to it via duplicate_of_source_row. No row is removed.",
                "DQ-004: is_single_departure rows count as exactly 1 departure at start_time; "
                "departures_per_hour is null for them and headway_secs is never divided",
                "normal windows: estimated_departures_in_window = ceil((end - start) / "
                "headway_secs) (departures at start + k*headway while < end_time; exact_times "
                "is absent, so this is the GTFS frequency-based estimate)",
                "counted_estimated_departures = estimated departures for counted rows, else 0"])
    return fq


def build_stop_times(ctx: Ctx, trips: pd.DataFrame, freq_trips: set[str]) -> pd.DataFrame:
    name = "stop_times_analysis.parquet"
    st = ctx.read("stop_times").drop(columns=list(cg.LINEAGE_COLUMNS))
    st = st.sort_values(["trip_id", "stop_sequence", "source_row"], kind="stable") \
        .reset_index(drop=True)
    stops = ctx.read("stops", ["stop_id", "stop_lat", "stop_lon"]).set_index("stop_id")
    st["route_id"] = st["trip_id"].map(trips.set_index("trip_id")["route_id"])
    st["stop_lat"] = st["stop_id"].map(stops["stop_lat"])
    st["stop_lon"] = st["stop_id"].map(stops["stop_lon"])
    g = st.groupby("trip_id", sort=False)
    st["stop_index"] = g.cumcount().astype("int64")
    st["is_first_stop"] = st["stop_index"] == 0
    st["is_last_stop"] = (g.cumcount(ascending=False) == 0)
    prev_stop = g["stop_id"].shift(1)
    st["is_consecutive_repeat_stop"] = (st["stop_id"] == prev_stop).fillna(False).astype(bool)
    st["next_stop_id"] = g["stop_id"].shift(-1)
    st["next_stop_sequence"] = g["stop_sequence"].shift(-1).astype("Int64")
    nxt_arr = _f(g["arrival_time_secs"].shift(-1))
    arr, dep = _f(st["arrival_time_secs"]), _f(st["departure_time_secs"])
    st["dwell_time_secs"] = pd.array(dep - arr, dtype="Float64").astype("Int64")
    travel = nxt_arr - dep
    st["travel_time_to_next_secs"] = pd.array(travel, dtype="Float64").astype("Int64")
    dist = haversine_m(st["stop_lat"], st["stop_lon"],
                       g["stop_lat"].shift(-1), g["stop_lon"].shift(-1))
    st["segment_distance_m"] = pd.array(np.round(dist, 1), dtype="Float64")
    st["next_is_same_stop"] = (st["next_stop_id"] == st["stop_id"]).fillna(False).astype(bool)
    with np.errstate(divide="ignore", invalid="ignore"):
        speed = np.where(travel > 0, dist / travel * 3.6, np.nan)
    st["segment_speed_kmh"] = pd.array(np.round(speed, 2), dtype="Float64")
    st["stop_times_are_relative_template"] = st["trip_id"].isin(list(freq_trips))
    rows = ctx.write(name, st, "stop_times")
    ctx.record(name, "one row per source stop_times row (sorted by trip_id, stop_sequence)",
               {"stop_times": ctx.num_rows("stop_times"), "stops": ctx.num_rows("stops"),
                "trips": ctx.num_rows("trips")}, rows,
               {"DQ-005": int(st["is_consecutive_repeat_stop"].sum())},
               ["stop coordinates and route_id looked up by stop_id / trip_id (unique keys)",
                "segment columns describe the hop to the next stop of the same trip; null on "
                "the last stop",
                "travel_time_to_next_secs = next arrival - this departure; dwell = departure - "
                "arrival; missing times stay null (no interpolation)",
                "segment_distance_m = straight-line (haversine) distance between stops",
                "DQ-005: consecutive identical stops are kept; their segment has distance 0 and "
                "travel time >= 0; speed is null when travel time is 0 (no division by zero)",
                "stop_times_are_relative_template = trip is frequency-based, so its times are a "
                "relative pattern, not clock times"])
    return st


def build_trips(ctx: Ctx, st: pd.DataFrame, fq: pd.DataFrame, dq: dict[str, Any],
                in_effect: set[str], freq_trips: set[str]) -> pd.DataFrame:
    name = "trips_analysis.parquet"
    trips = ctx.read("trips").drop(columns=list(cg.LINEAGE_COLUMNS))
    routes = ctx.read("routes", ["route_id", "agency_id"]).set_index("route_id")
    g = st.groupby("trip_id", sort=False)
    first = st[st["is_first_stop"]].set_index("trip_id")
    last = st[st["is_last_stop"]].set_index("trip_id")
    per = pd.DataFrame({
        "n_stops": g.size(),
        "n_distinct_stops": g["stop_id"].nunique(),
        "has_consecutive_repeat_stop": g["is_consecutive_repeat_stop"].any(),
    })
    per["first_stop_id"] = first["stop_id"]
    per["last_stop_id"] = last["stop_id"]
    per["first_departure_time"] = first["departure_time"]
    per["first_departure_secs"] = first["departure_time_secs"]
    per["last_arrival_time"] = last["arrival_time"]
    per["last_arrival_secs"] = last["arrival_time_secs"]
    out = trips.join(per, on="trip_id")
    out["n_stops"] = out["n_stops"].fillna(0).astype("int64")
    out["n_distinct_stops"] = out["n_distinct_stops"].fillna(0).astype("int64")
    out["has_consecutive_repeat_stop"] = out["has_consecutive_repeat_stop"].fillna(False) \
        .astype(bool)
    out["duration_seconds"] = (out["last_arrival_secs"] - out["first_departure_secs"]) \
        .astype("Int64")
    out["agency_id"] = out["route_id"].map(routes["agency_id"])
    out["agency_identity_unresolved"] = out["agency_id"].isin(dq["colliding_agency_ids"])
    out["schedule_type"] = np.where(out["trip_id"].isin(list(freq_trips)),
                                    "frequency_based", "scheduled")
    if len(fq):
        fg = fq.groupby("trip_id")
        fagg = pd.DataFrame({
            "n_frequency_windows_source": fg.size(),
            "n_frequency_windows_counted": fg["counted_in_derived"].sum(),
            "n_single_departure_windows": fg[cg.SINGLE_DEPARTURE_COL].sum(),
            "freq_departures": fg["counted_estimated_departures"].sum(),
        })
        out = out.join(fagg, on="trip_id")
    for c in ("n_frequency_windows_source", "n_frequency_windows_counted",
              "n_single_departure_windows"):
        out[c] = out.get(c, pd.Series(0, index=out.index)).fillna(0).astype("int64")
    freq_dep = out.get("freq_departures", pd.Series(np.nan, index=out.index))
    out["estimated_departures_per_service_day"] = np.where(
        out["schedule_type"] == "frequency_based", freq_dep, 1).astype("int64")
    out = out.drop(columns=["freq_departures"], errors="ignore")
    out["service_in_effect_at_scrape_date"] = out["service_id"].isin(list(in_effect))
    rows = ctx.write(name, out, "trips")
    ctx.record(name, "one row per source trip (a trip pattern, not a dated departure)",
               {"trips": ctx.num_rows("trips"), "stop_times": ctx.num_rows("stop_times"),
                "frequencies": ctx.num_rows("frequencies"), "routes": ctx.num_rows("routes")},
               rows,
               {"DQ-001": int(out["agency_identity_unresolved"].sum()),
                "DQ-005": int(out["has_consecutive_repeat_stop"].sum())},
               ["first/last stop and times come from the lowest/highest stop_sequence",
                "duration_seconds = last_arrival_secs - first_departure_secs",
                "schedule_type = frequency_based when the trip has frequencies rows; for those "
                "trips the stop_times are a relative template (often starting at 00:00:00), so "
                "first_departure_time is not a clock time",
                "estimated_departures_per_service_day: frequency_based = sum of counted "
                "frequency windows (DQ-003 duplicates counted once, DQ-004 single departures = 1); "
                "scheduled = 1. This applies on each day the trip's service runs; no dates or "
                "service instances are generated",
                "service_in_effect_at_scrape_date: service date range covers the scrape date "
                "(weekday patterns are not expanded)",
                "agency_id is taken from the route as published; DQ-001 rows are flagged, "
                "not remapped"])
    return out


def build_routes(ctx: Ctx, trips: pd.DataFrame, st: pd.DataFrame, dq: dict[str, Any],
                 fares: dict[str, Any], in_effect: set[str]) -> pd.DataFrame:
    name = "routes_analysis.parquet"
    routes = ctx.read("routes").drop(columns=list(cg.LINEAGE_COLUMNS))
    agency = dq["agency"]
    colliding = set(dq["colliding_agency_ids"])
    names = agency.groupby("agency_id")["agency_name"].agg(list)
    routes["agency_identity_unresolved"] = routes["agency_id"].isin(list(colliding))
    unique_name = names[names.map(len) == 1].map(lambda v: v[0])
    routes["agency_name"] = routes["agency_id"].map(unique_name).where(
        ~routes["agency_identity_unresolved"])
    routes["agency_name_candidates"] = routes["agency_id"].map(
        names.map(lambda v: " | ".join(map(str, v)))).where(routes["agency_identity_unresolved"])

    tg = trips.groupby("route_id")
    agg = pd.DataFrame({
        "n_trips": tg.size(),
        "n_directions": tg["direction_id"].nunique() if "direction_id" in trips else 0,
        "n_shapes": tg["shape_id"].nunique() if "shape_id" in trips else 0,
        "n_services": tg["service_id"].nunique(),
        "n_services_in_effect_at_scrape_date": trips[trips["service_id"].isin(list(in_effect))]
        .groupby("route_id")["service_id"].nunique(),
        "n_frequency_based_trips": (trips["schedule_type"] == "frequency_based")
        .groupby(trips["route_id"]).sum(),
        "n_scheduled_trips": (trips["schedule_type"] == "scheduled").groupby(trips["route_id"]).sum(),
        "n_stop_times": tg["n_stops"].sum(),
        "n_stops": st.groupby("route_id")["stop_id"].nunique(),
    })
    routes = routes.join(agg, on="route_id")
    routes["n_fare_rules"] = routes["route_id"].map(fares["route_rules"])
    routes["n_fare_rules_unresolved_zone"] = routes["route_id"].map(fares["route_unresolved"])
    count_cols = [*agg.columns, "n_fare_rules", "n_fare_rules_unresolved_zone"]
    for c in count_cols:
        routes[c] = routes[c].fillna(0).astype("int64")
    routes["is_unused"] = routes["n_trips"] == 0
    rows = ctx.write(name, routes, "routes")
    ctx.record(name, "one row per source route",
               {"routes": ctx.num_rows("routes"), "trips": ctx.num_rows("trips"),
                "stop_times": ctx.num_rows("stop_times"), "agency": ctx.num_rows("agency"),
                "fare_rules": ctx.num_rows("fare_rules")}, rows,
               {"DQ-001": int(routes["agency_identity_unresolved"].sum()),
                "DQ-002": int((routes["n_fare_rules_unresolved_zone"] > 0).sum()),
                "DQ-007": int(routes["is_unused"].sum())},
               ["counts aggregate trips/stop_times/fare_rules by route_id; 0 means no "
                "referencing rows",
                "DQ-001: agency_name is null and agency_name_candidates lists every operator "
                "sharing the agency_id; agency_id is unchanged (no join fan-out)",
                "DQ-002: n_fare_rules_unresolved_zone counts this route's rules with an orphan "
                "zone",
                "DQ-007: is_unused marks routes without trips (kept; exclude only from "
                "active-network metrics)",
                "route_text_color is not present in this feed and is not created"])
    return routes


def build_stops(ctx: Ctx, st: pd.DataFrame, fares: dict[str, Any]) -> pd.DataFrame:
    name = "stops_analysis.parquet"
    stops = ctx.read("stops").drop(columns=list(cg.LINEAGE_COLUMNS))
    g = st.groupby("stop_id")
    visits = st.groupby(["stop_id", "trip_id"]).size()
    agg = pd.DataFrame({
        "n_stop_occurrences": g.size(),
        "n_trips": g["trip_id"].nunique(),
        "n_routes": g["route_id"].nunique(),
        "n_consecutive_repeat_occurrences": g["is_consecutive_repeat_stop"].sum(),
        "n_trips_visiting_more_than_once": (visits > 1).groupby(level=0).sum(),
    })
    stops = stops.join(agg, on="stop_id")
    if "zone_id" in stops.columns:
        stops["n_fare_rules_origin_zone"] = stops["zone_id"].map(fares["origin_zone"])
        stops["n_fare_rules_destination_zone"] = stops["zone_id"].map(fares["destination_zone"])
    count_cols = [c for c in stops.columns if c.startswith("n_")]
    for c in count_cols:
        stops[c] = stops[c].fillna(0).astype("int64")
    stops["is_unused"] = stops["n_stop_occurrences"] == 0
    rows = ctx.write(name, stops, "stops")
    ctx.record(name, "one row per source stop (unused stops included)",
               {"stops": ctx.num_rows("stops"), "stop_times": ctx.num_rows("stop_times"),
                "fare_rules": ctx.num_rows("fare_rules")}, rows,
               {"DQ-005": int((stops["n_consecutive_repeat_occurrences"] > 0).sum()),
                "DQ-008": int(stops["is_unused"].sum())},
               ["occurrence, trip and route counts come from stop_times",
                "n_trips_visiting_more_than_once = trips that call at the stop more than once",
                "fare-zone counts are zone-level (by zone_id) and repeat for stops sharing a zone",
                "DQ-008: is_unused marks stops without stop_times (kept)",
                "DQ-002: orphan zones have no stop, so they cannot appear here; they are flagged "
                "in fare_analysis"],
               orphan_zones_without_stop=sorted(set(fares["origin_zone"].index)
                                                .union(fares["destination_zone"].index)
                                                - set(stops.get("zone_id", pd.Series()).dropna())))
    return stops


def build_agencies(ctx: Ctx, dq: dict[str, Any], routes: pd.DataFrame, trips: pd.DataFrame,
                   fares: dict[str, Any]) -> pd.DataFrame:
    name = "agencies_analysis.parquet"
    agency = dq["agency"].drop(columns=list(cg.LINEAGE_COLUMNS))
    agency["agency_identity_unresolved"] = agency["agency_id"].isin(dq["colliding_agency_ids"])
    agency["n_rows_sharing_agency_id"] = agency.groupby("agency_id")["agency_id"] \
        .transform("size").astype("int64")
    agency["n_routes_with_agency_id"] = agency["agency_id"].map(
        routes.groupby("agency_id").size()).fillna(0).astype("int64")
    agency["n_trips_with_agency_id"] = agency["agency_id"].map(
        trips.groupby("agency_id").size()).fillna(0).astype("int64")
    agency["n_fare_attributes_with_agency_id"] = agency["agency_id"].map(
        fares["agency_fares"]).fillna(0).astype("int64")
    rows = ctx.write(name, agency, "agency")
    ctx.record(name, "one row per source agency row (agency_id is not unique: DQ-001)",
               {"agency": ctx.num_rows("agency"), "routes": ctx.num_rows("routes"),
                "trips": ctx.num_rows("trips"),
                "fare_attributes": ctx.num_rows("fare_attributes")}, rows,
               {"DQ-001": int(agency["agency_identity_unresolved"].sum())},
               ["n_*_with_agency_id are agency_id-code-level counts. For DQ-001 rows they are "
                "repeated on each row sharing the code, so do not sum them across those rows; "
                "operator-level counts are unknown"])
    return agency


def build_shapes(ctx: Ctx, trips: pd.DataFrame) -> pd.DataFrame:
    """One summary row per shape, streamed in file order; no point-level copy."""
    name = "shapes_analysis.parquet"
    cols = ["shape_id", "shape_pt_sequence", "shape_pt_lat", "shape_pt_lon", "source_row"]
    partials: list[pd.DataFrame] = []
    seen: set = set()
    prev: pd.DataFrame | None = None
    for b in pq.ParquetFile(ctx.path("shapes")).iter_batches(batch_size=BATCH_ROWS, columns=cols):
        df = b.to_pandas(types_mapper=_PD_TYPES.get)
        frame = df if prev is None else pd.concat([prev, df], ignore_index=True)
        p = frame.shift()
        same = (frame["shape_id"] == p["shape_id"]).fillna(False).to_numpy(dtype=bool)
        seq, pseq = _f(frame["shape_pt_sequence"]), _f(p["shape_pt_sequence"])
        if (same & ~(seq > pseq)).any():
            raise AnalysisError("shapes are not ordered by shape_pt_sequence within shape_id")
        starts = frame.loc[~same, "shape_id"]
        if prev is not None:
            starts = starts[starts.index >= 1]
        for sid in starts:
            if sid in seen:
                raise AnalysisError(f"shape {sid} is split across the file; cannot stream")
            seen.add(sid)
        lat, lon = _f(frame["shape_pt_lat"]), _f(frame["shape_pt_lon"])
        plat, plon = _f(p["shape_pt_lat"]), _f(p["shape_pt_lon"])
        dist = np.where(same, haversine_m(plat, plon, lat, lon), 0.0)
        repeat = same & (lat == plat) & (lon == plon)
        frame = frame.assign(_dist=np.nan_to_num(dist), _repeat=repeat)
        cur = frame.iloc[0 if prev is None else 1:]
        partials.append(cur.groupby("shape_id", sort=False).agg(
            n_points_source=("shape_pt_sequence", "size"),
            n_repeated_consecutive_points=("_repeat", "sum"),
            length_m=("_dist", "sum"),
            min_shape_pt_sequence=("shape_pt_sequence", "min"),
            max_shape_pt_sequence=("shape_pt_sequence", "max"),
            min_lat=("shape_pt_lat", "min"), max_lat=("shape_pt_lat", "max"),
            min_lon=("shape_pt_lon", "min"), max_lon=("shape_pt_lon", "max"),
            start_lat=("shape_pt_lat", "first"), start_lon=("shape_pt_lon", "first"),
            end_lat=("shape_pt_lat", "last"), end_lon=("shape_pt_lon", "last"),
            first_source_row=("source_row", "first"), last_source_row=("source_row", "last"),
        ))
        prev = df.iloc[[-1]]
    if partials:
        agg = pd.concat(partials).groupby(level=0, sort=False).agg({
            "n_points_source": "sum", "n_repeated_consecutive_points": "sum", "length_m": "sum",
            "min_shape_pt_sequence": "min", "max_shape_pt_sequence": "max",
            "min_lat": "min", "max_lat": "max", "min_lon": "min", "max_lon": "max",
            "start_lat": "first", "start_lon": "first", "end_lat": "last", "end_lon": "last",
            "first_source_row": "first", "last_source_row": "last"})
    else:
        agg = pd.DataFrame()
    agg.index.name = "shape_id"
    out = agg.reset_index()
    out["n_points_collapsed"] = (out["n_points_source"]
                                 - out["n_repeated_consecutive_points"]).astype("int64")
    out["length_m"] = out["length_m"].round(1)
    used = trips["shape_id"].value_counts() if "shape_id" in trips else pd.Series(dtype="int64")
    out["n_trips"] = out["shape_id"].map(used).fillna(0).astype("int64")
    out["is_unused"] = out["n_trips"] == 0
    rows = ctx.write(name, out, "shapes")
    ctx.record(name, "one summary row per source shape_id (point-level table not duplicated)",
               {"shapes": ctx.num_rows("shapes"), "trips": ctx.num_rows("trips")}, rows,
               {"DQ-006": int((out["n_repeated_consecutive_points"] > 0).sum()),
                "DQ-009": int(out["is_unused"].sum())},
               ["streamed in file order in batches of %d rows; the build fails if shapes are "
                "not grouped and ordered by shape_pt_sequence" % BATCH_ROWS,
                "length_m = sum of haversine distances between consecutive points",
                "DQ-006: n_repeated_consecutive_points counts points equal to the previous point; "
                "n_points_collapsed = points left if they were collapsed. No collapsed geometry "
                "is written; the clean shapes keep every point",
                "first/last_source_row give the clean shapes row range for each shape",
                "DQ-009: is_unused marks shapes no trip references (kept)",
                "shape_dist_traveled is not present in this feed and is not created"],
               dq006={"original_points": int(out["n_points_source"].sum()),
                      "points_if_collapsed": int(out["n_points_collapsed"].sum()),
                      "repeated_points": int(out["n_repeated_consecutive_points"].sum()),
                      "method": "drop a point when lat and lon equal the previous point of the "
                                "same shape (by shape_pt_sequence)"})
    return out


# --------------------------------------------------------------------------
# Derived-data validation
# --------------------------------------------------------------------------

def validate_outputs(ctx: Ctx, dq: dict[str, Any]) -> list[dict[str, Any]]:
    """Re-read the written outputs and reconcile them with clean data and the policy."""
    checks: list[dict[str, Any]] = []
    w = ctx.work

    def out(name: str, columns: list[str] | None = None) -> pd.DataFrame:
        return pq.read_table(w / name, columns=columns).to_pandas(types_mapper=_PD_TYPES.get)

    def rows(name: str) -> int:
        return pq.ParquetFile(w / name).metadata.num_rows

    def clean_values(table: str, col: str) -> set:
        return unique_values(ctx, table, col)

    n_shapes = len(clean_values("shapes", "shape_id"))
    datasets = {
        "agencies_analysis.parquet": ("agency", ctx.num_rows("agency"), ["source_row"]),
        "routes_analysis.parquet": ("routes", ctx.num_rows("routes"), ["route_id"]),
        "stops_analysis.parquet": ("stops", ctx.num_rows("stops"), ["stop_id"]),
        "trips_analysis.parquet": ("trips", ctx.num_rows("trips"), ["trip_id"]),
        "stop_times_analysis.parquet": ("stop_times", ctx.num_rows("stop_times"),
                                        ["trip_id", "stop_sequence"]),
        "frequencies_analysis.parquet": ("frequencies", ctx.num_rows("frequencies"),
                                         ["source_row"]),
        "fare_analysis.parquet": ("fare_rules", ctx.num_rows("fare_rules"),
                                  ["fare_rules_source_row"]),
        "shapes_analysis.parquet": ("shapes", n_shapes, ["shape_id"]),
    }
    for name, (table, expected, key) in datasets.items():
        if not (w / name).exists():
            continue
        n = rows(name)
        checks.append(vg.check(f"{name} row count", PASS if n == expected else ERROR,
                               f"{n} output rows; expected {expected} "
                               f"({'distinct shape_ids' if table == 'shapes' else table + ' rows'})",
                               table=table, count=n, total=expected))
        k = out(name, key)
        dup = int(k.duplicated().sum())
        checks.append(vg.check(f"{name} unique key {key}", ERROR if dup else PASS,
                               f"{dup} repeated keys", table=table, count=dup))
        src_col = "fare_rules_source_row" if table == "fare_rules" else (
            "first_source_row" if table == "shapes" else "source_row")
        if table != "shapes":
            src = out(name, [src_col])[src_col].to_numpy(dtype="int64")
            ok = len(src) == expected and len(np.unique(src)) == expected and (
                expected == 0 or (src.min() == 1 and src.max() == expected))
            checks.append(vg.check(f"{name} covers every source row", PASS if ok else ERROR,
                                   f"{src_col} values are 1..{expected}, each once" if ok else
                                   f"{src_col} does not cover the source rows exactly once",
                                   table=table))
        lin = out(name, list(cg.LINEAGE_COLUMNS))
        bad = [c for c, v in ctx.lineage.items() if set(lin[c].unique()) - {v}]
        checks.append(vg.check(f"{name} lineage", ERROR if bad else PASS,
                               f"lineage mismatch in {bad}" if bad else
                               "feed_sha256 and feed_version match the source feed", table=table))

    # No fabricated identifiers: every derived id exists in the clean source.
    id_refs = [
        ("routes_analysis.parquet", "route_id", "routes", "route_id"),
        ("routes_analysis.parquet", "agency_id", "agency", "agency_id"),
        ("stops_analysis.parquet", "stop_id", "stops", "stop_id"),
        ("trips_analysis.parquet", "trip_id", "trips", "trip_id"),
        ("trips_analysis.parquet", "route_id", "routes", "route_id"),
        ("trips_analysis.parquet", "service_id", "trips", "service_id"),
        ("trips_analysis.parquet", "shape_id", "shapes", "shape_id"),
        ("trips_analysis.parquet", "first_stop_id", "stops", "stop_id"),
        ("trips_analysis.parquet", "last_stop_id", "stops", "stop_id"),
        ("stop_times_analysis.parquet", "stop_id", "stops", "stop_id"),
        ("stop_times_analysis.parquet", "next_stop_id", "stops", "stop_id"),
        ("stop_times_analysis.parquet", "route_id", "routes", "route_id"),
        ("frequencies_analysis.parquet", "trip_id", "trips", "trip_id"),
        ("shapes_analysis.parquet", "shape_id", "shapes", "shape_id"),
        ("fare_analysis.parquet", "fare_id", "fare_rules", "fare_id"),
        ("fare_analysis.parquet", "route_id", "fare_rules", "route_id"),
        ("fare_analysis.parquet", "origin_id", "fare_rules", "origin_id"),
        ("fare_analysis.parquet", "destination_id", "fare_rules", "destination_id"),
        ("agencies_analysis.parquet", "agency_id", "agency", "agency_id"),
    ]
    for name, col, table, src_col in id_refs:
        if not (w / name).exists() or col not in pq.read_schema(w / name).names:
            continue
        derived = set(pc.unique(pq.read_table(w / name, columns=[col]).column(0))
                      .drop_null().to_pylist())
        extra = sorted(derived - clean_values(table, src_col))
        checks.append(vg.check(f"no fabricated {name}:{col}", ERROR if extra else PASS,
                               f"{len(extra)} values not found in clean {table}.{src_col}",
                               table=table, count=len(extra), examples=extra[:10]))

    checks += policy_checks(ctx, dq, out)
    excluded = sum(t["excluded_rows"] for t in ctx.transformations)
    checks.append(vg.check("no rows excluded", PASS if excluded == 0 else ERROR,
                           f"{excluded} rows excluded across all derived datasets"))
    return checks


def policy_checks(ctx: Ctx, dq: dict[str, Any], out) -> list[dict[str, Any]]:
    """Derived flag counts must match the counts recorded in the DQ policy."""
    checks = []

    def compare(issue_id: str, label: str, actual: int, path: list[str] | None = None) -> None:
        issue = ctx.policy_issue(issue_id)
        expected = None
        if issue is not None:
            node: Any = issue
            for key in (path or ["affected_rows"]):
                node = node.get(key) if isinstance(node, dict) else None
            expected = node
        if expected is None:
            status = ERROR if actual else PASS
            summary = (f"{actual} rows found but the policy has no matching count"
                       if actual else "not present in data or policy")
        else:
            status = PASS if int(expected) == actual else ERROR
            summary = f"derived {actual}, policy {expected}"
        checks.append(vg.check(f"{issue_id} {label}", status, summary, count=actual,
                               policy_issue=issue_id))

    ag = out("agencies_analysis.parquet", ["agency_identity_unresolved"])
    ro = out("routes_analysis.parquet", ["agency_identity_unresolved", "is_unused"])
    tr = out("trips_analysis.parquet", ["agency_identity_unresolved"])
    compare("DQ-001", "agency rows flagged", int(ag["agency_identity_unresolved"].sum()))
    compare("DQ-001", "routes flagged", int(ro["agency_identity_unresolved"].sum()),
            ["downstream_impact", "routes"])
    compare("DQ-001", "trips flagged", int(tr["agency_identity_unresolved"].sum()),
            ["downstream_impact", "trips_on_those_routes"])
    policy_ids = set((ctx.policy_issue("DQ-001") or {}).get("details", {}))
    checks.append(vg.check("DQ-001 colliding agency_ids match policy",
                           PASS if set(dq["colliding_agency_ids"]) == policy_ids else ERROR,
                           f"data {dq['colliding_agency_ids']}; policy {sorted(policy_ids)}",
                           policy_issue="DQ-001"))
    if (ctx.work / "fare_analysis.parquet").exists():
        fa = pq.read_table(ctx.work / "fare_analysis.parquet",
                           columns=["unresolved_fare_zone", "agency_identity_unresolved"])
        compare("DQ-001", "fare rules flagged",
                pc.sum(fa.column("agency_identity_unresolved")).as_py() or 0,
                ["downstream_impact", "fare_rules_using_those_fares"])
        compare("DQ-002", "fare rules with unresolved zone",
                pc.sum(fa.column("unresolved_fare_zone")).as_py() or 0)
    fq = out("frequencies_analysis.parquet")
    if len(fq):
        compare("DQ-003", "duplicate windows not counted", int((~fq["counted_in_derived"]).sum()),
                ["details", "extra_copies"])
        single = fq[cg.SINGLE_DEPARTURE_COL].fillna(False).astype(bool)
        compare("DQ-004", "single_departure rows", int(single.sum()))
        ok = bool((fq.loc[single, "estimated_departures_in_window"] == 1).all()
                  and fq.loc[single, "departures_per_hour"].isna().all())
        checks.append(vg.check("DQ-004 single departures count as 1, no headway division",
                               PASS if ok else ERROR,
                               "every single_departure row has 1 departure and null "
                               "departures_per_hour" if ok else "rule not applied",
                               policy_issue="DQ-004"))
    st = out("stop_times_analysis.parquet", ["is_consecutive_repeat_stop", "next_is_same_stop",
                                             "segment_distance_m", "travel_time_to_next_secs"])
    compare("DQ-005", "consecutive repeat stops kept", int(st["is_consecutive_repeat_stop"].sum()))
    seg = st[st["next_is_same_stop"]]
    ok = bool((seg["segment_distance_m"] == 0).all() and seg["travel_time_to_next_secs"].notna().all())
    checks.append(vg.check("DQ-005 zero-length segments allowed", PASS if ok else ERROR,
                           f"{len(seg)} same-stop segments with distance 0 and a defined travel "
                           "time" if ok else "same-stop segments were altered",
                           policy_issue="DQ-005"))
    sh = out("shapes_analysis.parquet", ["n_points_source", "n_repeated_consecutive_points",
                                         "is_unused"])
    compare("DQ-006", "repeated consecutive shape points",
            int(sh["n_repeated_consecutive_points"].sum()))
    total_points = int(sh["n_points_source"].sum())
    checks.append(vg.check("DQ-006 shape points reconcile",
                           PASS if total_points == ctx.num_rows("shapes") else ERROR,
                           f"{total_points} points summarised; clean shapes has "
                           f"{ctx.num_rows('shapes')}", policy_issue="DQ-006"))
    compare("DQ-007", "unused routes flagged", int(ro["is_unused"].sum()))
    compare("DQ-008", "unused stops flagged",
            int(out("stops_analysis.parquet", ["is_unused"])["is_unused"].sum()))
    compare("DQ-009", "unused shapes flagged", int(sh["is_unused"].sum()))
    checks.append(vg.check("DQ-010 no-op calendar_dates", PASS,
                           "no derived dataset counts calendar_dates rows as service changes; "
                           "service_in_effect uses calendar ranges and added dates only",
                           policy_issue="DQ-010"))
    return checks


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def network_summary(ctx: Ctx, routes, stops, trips, shapes, fq, st) -> dict[str, Any]:
    source = {t: ctx.num_rows(t) for t in sorted(ctx.meta["tables"])}
    return {
        "source_counts": {
            "note": "Rows in the clean GTFS tables, identical to the published feed.",
            "agency_rows": source.get("agency", 0),
            "distinct_agency_ids": int(ctx.read("agency", ["agency_id"])["agency_id"].nunique()),
            "routes": source.get("routes", 0), "trips": source.get("trips", 0),
            "stops": source.get("stops", 0), "stop_times": source.get("stop_times", 0),
            "shape_points": source.get("shapes", 0), "distinct_shapes": int(len(shapes)),
            "frequencies": source.get("frequencies", 0), "fare_rules": source.get("fare_rules", 0),
            "fare_attributes": source.get("fare_attributes", 0),
            "calendar": source.get("calendar", 0), "calendar_dates": source.get("calendar_dates", 0),
            "total_rows_all_tables": sum(source.values()),
        },
        "derived_active_network_counts": {
            "note": "Derived from the clean data; NOT source counts. 'Active' means referenced by "
                    "trips/stop_times in this feed version.",
            "routes_with_trips": int((~routes["is_unused"]).sum()),
            "stops_with_stop_times": int((~stops["is_unused"]).sum()),
            "shapes_used_by_trips": int((~shapes["is_unused"]).sum()),
            "trips_frequency_based": int((trips["schedule_type"] == "frequency_based").sum()),
            "trips_scheduled": int((trips["schedule_type"] == "scheduled").sum()),
            "trips_with_service_in_effect_at_scrape_date":
                int(trips["service_in_effect_at_scrape_date"].sum()),
            "frequency_windows_counted": int(fq["counted_in_derived"].sum()) if len(fq) else 0,
            "trip_segments": int(st["next_stop_id"].notna().sum()),
            "estimated_departures_per_service_day_all_trips":
                int(trips["estimated_departures_per_service_day"].sum()),
            "estimated_departures_note": "Sum over all trip patterns of all services; services "
                                         "run on different sets of days, so this is not a "
                                         "daily total.",
        },
        "dq_issue_counts": {i["id"]: {"issue": i.get("issue"), "severity": i.get("validation_severity"),
                                      "affected_rows": i.get("affected_rows")}
                            for i in ctx.policy.get("issues", [])},
    }


def build_feed(clean_dir: Path, analysis_root: Path = ANALYSIS_DIR,
               policy_path: Path | None = None, log_path: Path = cg.SCRAPE_LOG,
               force: bool = False) -> dict[str, Any]:
    target = analysis_root / clean_dir.name
    if (target / cg.SUCCESS_MARKER).exists() and not force:
        log.info("%s already built; skipping (use --force to rebuild)", cg._rel(target))
        return json.loads((target / cg.METADATA_NAME).read_text(encoding="utf-8"))
    if target.exists() and not force:
        raise AnalysisError(f"{target} exists without {cg.SUCCESS_MARKER}")
    policy_path = policy_path or METADATA_DIR / f"data_quality_policy_{clean_dir.name}.json"
    run_id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    work = analysis_root / f".tmp_{target.name}_{run_id}"
    work.mkdir(parents=True)
    started = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    ctx = Ctx(clean_dir, work, policy_path)
    log.info("building analysis layer for %s (feed_version=%s)", cg._rel(clean_dir),
             ctx.meta["feed_version"])

    dq = dq_context(ctx)
    in_effect = services_in_effect(ctx)
    fares = build_fares(ctx, dq)
    fq = build_frequencies(ctx)
    freq_trips = set(fq["trip_id"].dropna()) if len(fq) else set()
    trips_src = ctx.read("trips", ["trip_id", "route_id"])
    st = build_stop_times(ctx, trips_src, freq_trips)
    trips = build_trips(ctx, st, fq, dq, in_effect, freq_trips)
    routes = build_routes(ctx, trips, st, dq, fares, in_effect)
    stops = build_stops(ctx, st, fares)
    build_agencies(ctx, dq, routes, trips, fares)
    shapes = build_shapes(ctx, trips)
    log.info("datasets written; validating derived data")

    checks = validate_outputs(ctx, dq)
    status = vg.worst([c["status"] for c in checks])
    metadata = vg.py({
        "builder_version": BUILDER_VERSION,
        "run_id": run_id,
        "status": "success" if status == PASS else "failed",
        "created_at_utc": started.isoformat(timespec="seconds"),
        "source": {"feed_sha256": ctx.meta["feed_sha256"], "feed_version": ctx.meta["feed_version"],
                   "clean_dir": cg._rel(clean_dir), "clean_run_id": ctx.meta["run_id"],
                   "raw_dir": ctx.meta["source_raw_dir"],
                   "scrape_date": ctx.scrape_date.isoformat() if ctx.scrape_date else None},
        "dq_policy": {"path": cg._rel(policy_path), "policy_version": ctx.policy.get("policy_version"),
                      "created_at_utc": ctx.policy.get("created_at_utc")},
        "input_tables": {t: ctx.num_rows(t) for t in sorted(ctx.meta["tables"])},
        "output_tables": {p.name: pq.ParquetFile(p).metadata.num_rows
                          for p in sorted(work.glob("*.parquet"))},
        "output_bytes": {p.name: p.stat().st_size for p in sorted(work.glob("*.parquet"))},
        "transformations": ctx.transformations,
        "exclusions": {"total_excluded_rows": 0,
                       "note": "No rows are excluded in the analysis layer; DQ issues are flag "
                               "columns so each analysis can decide and report exclusions."},
        "lineage": {"columns": ["source_table", "source_row", *cg.LINEAGE_COLUMNS],
                    "notes": ["source_row refers to the row number in the clean table named by "
                              "source_table (1 = first data row of the GTFS file)",
                              "fare_analysis carries fare_rules_source_row and "
                              "fare_attributes_source_row",
                              "shapes_analysis carries first_source_row/last_source_row per shape"]},
        "not_generated": ["service instances / dated departures", "collapsed shape geometry",
                          "route_text_color, shape_dist_traveled (absent from the feed)"],
        "network_summary": network_summary(ctx, routes, stops, trips, shapes, fq, st),
        "validation": {"status": status, "checks": checks},
        "seconds": round(time.perf_counter() - t0, 2),
        "peak_memory_bytes": cg.peak_memory_bytes(),
    })
    (work / cg.METADATA_NAME).write_text(json.dumps(metadata, indent=2, ensure_ascii=False),
                                         encoding="utf-8")
    append_log(log_path, analysis_log_rows(metadata, ctx))
    if status != PASS:
        log.error("derived-data validation failed; output kept for inspection at %s",
                  cg._rel(work))
        return metadata
    (work / cg.SUCCESS_MARKER).write_text("", encoding="utf-8")
    if target.exists():
        old = analysis_root / f".old_{target.name}_{run_id}"
        target.rename(old)
        work.rename(target)
        shutil.rmtree(old)
    else:
        work.rename(target)
    log.info("analysis layer written to %s in %.1fs", cg._rel(target), metadata["seconds"])
    return metadata


def analysis_log_rows(metadata: dict[str, Any], ctx: Ctx) -> list[dict[str, Any]]:
    """raw_rows = input rows of the main source table, clean_rows = output rows,
    rejected_rows = excluded rows."""
    base = {"run_id": metadata["run_id"], "scrape_timestamp_utc": metadata["created_at_utc"],
            "scrape_date": metadata["source"]["scrape_date"], "source": ctx.manifest.get("source"),
            "feed_version": metadata["source"]["feed_version"],
            "zip_sha256": metadata["source"]["feed_sha256"],
            "zip_bytes": ctx.manifest.get("zip_bytes"), "raw_path": metadata["source"]["raw_dir"],
            "stage": "analysis"}
    rows = [{**base, "file": RUN_ROW_FILE, "status": metadata["status"],
             "raw_rows": sum(metadata["input_tables"].values()),
             "clean_rows": sum(metadata["output_tables"].values()), "rejected_rows": 0,
             "error": f"validation {metadata['validation']['status']}"}]
    for t in metadata["transformations"]:
        main_input = next(iter(t["input_tables"].values()))
        rows.append({**base, "file": t["output"], "status": metadata["status"],
                     "raw_rows": main_input, "clean_rows": t["output_rows"],
                     "rejected_rows": t["excluded_rows"]})
    return rows


def pending(clean_root: Path = cg.CLEAN_DIR, analysis_root: Path = ANALYSIS_DIR) -> list[Path]:
    return [d for d in sorted(clean_root.iterdir())
            if d.is_dir() and (d / cg.SUCCESS_MARKER).exists()
            and not (analysis_root / d.name / cg.SUCCESS_MARKER).exists()]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build the Namtang GTFS analysis layer.")
    parser.add_argument("feeds", nargs="*", type=Path,
                        help="clean feed directories (default: all not yet built)")
    parser.add_argument("--force", action="store_true", help="rebuild existing output")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args(argv)
    logging.basicConfig(level=args.log_level,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    feeds = args.feeds or pending()
    if not feeds:
        log.info("nothing to build")
        return 0
    code = 0
    for feed in feeds:
        try:
            meta = build_feed(feed, force=args.force)
        except AnalysisError as exc:
            log.error("%s: %s", feed, exc)
            code = 1
            continue
        if meta["status"] != "success":
            code = 1
    return code


if __name__ == "__main__":
    sys.exit(main())
