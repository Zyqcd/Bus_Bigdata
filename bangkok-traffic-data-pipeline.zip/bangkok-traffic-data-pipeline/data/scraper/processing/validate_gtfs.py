"""Read-only validation of a cleaned Namtang GTFS feed.

Usage (from the project root):
    python data/scraper/processing/validate_gtfs.py [CLEAN_FEED_DIR ...]

CLEAN_FEED_DIR is a completed clean feed (e.g. ``data/clean/namtang/2026-10-01``).
Without arguments every clean feed that has no validation report yet is checked.

The validator never modifies raw or clean data. It reads Parquet files in
column-projected batches, and writes only:
  * ``data/metadata/validation_<feed>.json``  (machine-readable report)
  * ``data/metadata/validation_<feed>.md``    (human summary)
  * run/table rows (stage="validate") in ``data/metadata/scrape_log.csv``

Statuses: ERROR = structurally invalid or broken; WARNING = unusual or
spec-related but potentially valid; PASS = no finding. The overall status is
the worst check status, so warnings alone never make a feed ERROR.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from datetime import date, datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterator

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

import clean_gtfs as cg
from namtang_scraper import RUN_ROW_FILE, append_log

log = logging.getLogger("validate_gtfs")

PASS, WARNING, ERROR = "PASS", "WARNING", "ERROR"
_RANK = {PASS: 0, WARNING: 1, ERROR: 2}

METADATA_DIR = cg.PROJECT_ROOT / "data" / "metadata"
BATCH_ROWS = cg.CHUNK_ROWS
MAX_EXAMPLES = 10
VALIDATOR_VERSION = "phase3-1"

# Logical keys to investigate. "pk" keys are unique by the GTFS spec; fare_rules
# has no primary key in Fares v1, so repeats there are reported as WARNING only.
LOGICAL_KEYS: dict[str, tuple[list[str], bool]] = {
    "agency": (["agency_id"], True),
    "stops": (["stop_id"], True),
    "routes": (["route_id"], True),
    "trips": (["trip_id"], True),
    "stop_times": (["trip_id", "stop_sequence"], True),
    "calendar": (["service_id"], True),
    "calendar_dates": (["service_id", "date"], True),
    "frequencies": (["trip_id", "start_time", "end_time"], True),
    "fare_attributes": (["fare_id"], True),
    "fare_rules": (["fare_id", "route_id", "origin_id", "destination_id"], False),
    "shapes": (["shape_id", "shape_pt_sequence"], True),
    "feed_info": ([], True),
}

_PD_TYPES = {pa.int64(): pd.Int64Dtype(), pa.bool_(): pd.BooleanDtype()}


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def py(v: Any) -> Any:
    """Convert numpy/pandas/date scalars into JSON-friendly Python values."""
    if isinstance(v, dict):
        return {str(k): py(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [py(x) for x in v]
    if v is None or v is pd.NA or v is pd.NaT:
        return None
    if isinstance(v, np.bool_):
        return bool(v)
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, (float, np.floating)):
        return None if np.isnan(v) else float(v)
    if isinstance(v, (date, datetime, pd.Timestamp)):
        return v.isoformat()
    return v


def worst(statuses: list[str]) -> str:
    return max(statuses, key=_RANK.__getitem__, default=PASS)


def check(name: str, status: str, summary: str, *, table: str | None = None,
          count: int | None = None, total: int | None = None,
          examples: list | None = None, **details: Any) -> dict[str, Any]:
    result: dict[str, Any] = {"check": name, "status": status, "summary": summary}
    if table:
        result["table"] = table
    if count is not None:
        result["count"] = int(count)
    if total is not None:
        result["total"] = int(total)
        if count is not None:
            result["percent"] = round(100.0 * count / total, 4) if total else 0.0
    if examples:
        result["examples"] = examples[:MAX_EXAMPLES]
    result.update(details)
    return result


def section(checks: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    return {"status": worst([c["status"] for c in checks]), **extra, "checks": checks}


class CleanFeed:
    """Read-only, column-projected access to one clean feed directory."""

    def __init__(self, clean_dir: Path):
        self.dir = clean_dir
        self.metadata = json.loads((clean_dir / cg.METADATA_NAME).read_text(encoding="utf-8"))
        self.raw_dir = cg.PROJECT_ROOT / self.metadata["source_raw_dir"]
        self.manifest = json.loads((self.raw_dir / cg.MANIFEST_NAME).read_text(encoding="utf-8"))
        self.tables = sorted(self.metadata["tables"])

    def path(self, table: str) -> Path:
        return self.dir / f"{table}.parquet"

    def has(self, table: str, *columns: str) -> bool:
        if not self.path(table).exists():
            return False
        names = set(pq.ParquetFile(self.path(table)).schema_arrow.names)
        return all(c in names for c in columns)

    def num_rows(self, table: str) -> int:
        return pq.ParquetFile(self.path(table)).metadata.num_rows

    def source_columns(self, table: str) -> list[str]:
        """Columns that came from the source file (generated columns excluded)."""
        member = self.metadata["tables"][table]["source_file"]
        for m in self.manifest.get("members", []):
            if m["name"] == member and m.get("columns"):
                return cg.normalize_columns(m["columns"])
        names = pq.ParquetFile(self.path(table)).schema_arrow.names
        generated = {"source_row", cg.SINGLE_DEPARTURE_COL, *cg.LINEAGE_COLUMNS}
        return [c for c in names if c not in generated and not c.endswith("_secs")]

    def arrow_batches(self, table: str, columns: list[str]) -> Iterator[pa.RecordBatch]:
        yield from pq.ParquetFile(self.path(table)).iter_batches(
            batch_size=BATCH_ROWS, columns=columns)

    def batches(self, table: str, columns: list[str]) -> Iterator[pd.DataFrame]:
        for b in self.arrow_batches(table, columns):
            yield b.to_pandas(types_mapper=_PD_TYPES.get)

    def read(self, table: str, columns: list[str]) -> pd.DataFrame:
        """Whole-column read; only used for small tables or narrow projections."""
        return pq.read_table(self.path(table), columns=columns).to_pandas(
            types_mapper=_PD_TYPES.get)

    def unique(self, table: str, column: str) -> pa.Array:
        parts = [pc.unique(b.column(0)) for b in self.arrow_batches(table, [column])]
        if not parts:
            return pa.array([], pa.string())
        return pc.drop_null(pc.unique(pa.concat_arrays(parts)))


# --------------------------------------------------------------------------
# Generic analyses
# --------------------------------------------------------------------------

def group_analysis(feed: CleanFeed, table: str, key_cols: list[str],
                   full_cols: list[str] | None = None) -> dict[str, Any]:
    """Find rows sharing the same ``key_cols`` values, memory-safely.

    Pass 1 keeps one 64-bit hash per row. Pass 2 re-reads only rows whose hash
    repeats and groups them on the real values, so hash collisions cannot
    produce false findings. Groups are split into "identical" (all
    ``full_cols`` equal) and "conflicting" (rows differ outside the key).
    """
    full_cols = full_cols or key_cols
    total = feed.num_rows(table)
    h = np.empty(total, dtype=np.uint64)       # 8 bytes per row, filled batch by batch
    pos = null_key_rows = 0
    for df in feed.batches(table, key_cols):
        h[pos:pos + len(df)] = pd.util.hash_pandas_object(df[key_cols], index=False).to_numpy()
        pos += len(df)
        null_key_rows += int(df[key_cols].isna().any(axis=1).sum())
    res: dict[str, Any] = {"key": key_cols, "total_rows": total, "unique_keys": total,
                           "duplicate_rows": 0, "groups": 0, "affected_rows": 0,
                           "identical_groups": 0, "conflicting_groups": 0,
                           "rows_with_null_key_part": null_key_rows, "examples": []}
    if not total:
        return res
    sorted_h = np.sort(h)
    dup_h = np.unique(sorted_h[1:][sorted_h[1:] == sorted_h[:-1]])
    del sorted_h
    if not len(dup_h):
        return res

    cols = list(dict.fromkeys([*key_cols, *full_cols, "source_row"]))
    parts, offset = [], 0
    for df in feed.batches(table, cols):
        mask = np.isin(h[offset:offset + len(df)], dup_h)
        offset += len(df)
        if mask.any():
            parts.append(df[mask])
    cand = pd.concat(parts, ignore_index=True)
    gid = cand.groupby(key_cols, dropna=False, sort=False).ngroup().to_numpy()
    keep = np.bincount(gid)[gid] > 1
    cand, gid = cand[keep].reset_index(drop=True), gid[keep]
    if not len(cand):
        return res

    groups = int(len(np.unique(gid)))
    full_h = pd.util.hash_pandas_object(cand[full_cols], index=False).to_numpy()
    distinct = pd.Series(full_h).groupby(gid).nunique()
    conflicting = int((distinct > 1).sum())
    affected = int(len(cand))
    res.update(unique_keys=total - (affected - groups), duplicate_rows=affected - groups,
               groups=groups, affected_rows=affected,
               identical_groups=groups - conflicting, conflicting_groups=conflicting)
    for g in distinct.sort_values(ascending=False, kind="stable").index[:MAX_EXAMPLES]:
        rows = cand[gid == g]
        res["examples"].append({
            "key": {c: py(rows[c].iloc[0]) for c in key_cols},
            "rows": int(len(rows)),
            "source_rows": [int(x) for x in rows["source_row"].head(5)],
            "differing_columns": [c for c in full_cols if c not in key_cols
                                  and rows[c].nunique(dropna=False) > 1],
        })
    return res


def fk_check(feed: CleanFeed, child: str, column: str, parent: pa.Array, parent_name: str,
             required: bool, note: str | None = None) -> dict[str, Any]:
    """Child values that do not exist in ``parent``; nulls are counted separately."""
    name = f"{child}.{column} -> {parent_name}"
    if not feed.has(child, column):
        return check(name, PASS, "column not present in this feed; not applicable", table=child)
    total = nulls = missing = 0
    missing_values: set = set()
    examples: list[dict[str, Any]] = []
    for b in feed.arrow_batches(child, [column, "source_row"]):
        values = b.column(0)
        value_set = parent if parent.type == values.type else parent.cast(values.type)
        total += len(values)
        is_null = pc.is_null(values)
        nulls += pc.sum(is_null).as_py() or 0
        found = pc.is_in(values, value_set=value_set, skip_nulls=True)
        miss = pc.and_kleene(pc.invert(is_null), pc.invert(found))
        n = pc.sum(miss).as_py() or 0
        if n:
            missing += n
            sel = b.filter(miss)
            missing_values.update(sel.column(0).to_pylist())
            if len(examples) < MAX_EXAMPLES:
                examples += [{"source_row": r, column: v} for v, r in
                             zip(sel.column(0).to_pylist(), sel.column(1).to_pylist())]
    if missing:
        status = ERROR
    elif nulls and required:
        status = ERROR
    else:
        status = PASS
    if missing:
        summary = f"{missing} rows reference {len(missing_values)} values missing from {parent_name}"
    elif nulls and required:
        summary = f"{nulls} rows have a null required reference"
    elif nulls:
        summary = f"all non-null references resolve; {nulls} null values (optional field)"
    else:
        summary = "all references resolve"
    return check(name, status, summary, table=child, count=missing, total=total,
                 examples=examples, child_rows=total, null_rows=nulls,
                 null_allowed=not required, missing_parent_rows=missing,
                 distinct_missing_values=len(missing_values),
                 **({"note": note} if note else {}))


def unused_check(name: str, table: str, parent: pa.Array, used: pa.Array, what: str) -> dict:
    """Parent values never referenced (WARNING: valid but worth reviewing)."""
    if len(parent) == 0:
        return check(name, PASS, "no values", table=table, count=0, total=0)
    used_cast = used if used.type == parent.type else used.cast(parent.type)
    unused_mask = pc.invert(pc.is_in(parent, value_set=used_cast))
    unused = pc.filter(parent, unused_mask).to_pylist()
    status = WARNING if unused else PASS
    return check(name, status, f"{len(unused)} {what} are never referenced" if unused
                 else f"every {what[:-1] if what.endswith('s') else what} is referenced",
                 table=table, count=len(unused), total=len(parent),
                 examples=[str(u) for u in unused[:MAX_EXAMPLES]])


def distribution(series: pd.Series) -> dict[str, int]:
    counts = series.value_counts(dropna=False)
    return {("null" if pd.isna(k) else str(k)): int(v) for k, v in counts.items()}


def enum_check(df: pd.DataFrame, table: str, col: str, allowed: set, bad_status: str,
               required: bool = False) -> dict[str, Any]:
    if col not in df.columns:
        return check(f"{table}.{col} values", PASS, "column not present; not applicable",
                     table=table)
    s = df[col]
    nulls = int(s.isna().sum())
    bad = s.notna() & ~s.isin(list(allowed))
    n_bad = int(bad.sum())
    status = bad_status if n_bad else PASS
    if nulls and required:
        status = ERROR
    return check(f"{table}.{col} values", status,
                 f"{n_bad} values outside {sorted(allowed) if len(allowed) < 20 else 'GTFS enum'}"
                 f"; {nulls} null", table=table, count=n_bad, total=len(s),
                 distribution=distribution(s))


# --------------------------------------------------------------------------
# Sections
# --------------------------------------------------------------------------

def duplicates_section(feed: CleanFeed) -> dict[str, Any]:
    checks, per_table = [], {}
    for t in feed.tables:
        cols = feed.source_columns(t)
        g = group_analysis(feed, t, cols)
        per_table[t] = {"total_rows": g["total_rows"], "unique_rows": g["unique_keys"],
                        "exact_duplicate_rows": g["duplicate_rows"],
                        "duplicate_groups": g["groups"], "affected_rows": g["affected_rows"]}
        status = WARNING if g["duplicate_rows"] else PASS
        checks.append(check(f"{t} exact duplicate rows", status,
                            f"{g['duplicate_rows']} extra copies in {g['groups']} groups "
                            f"(compared on all {len(cols)} source columns)",
                            table=t, count=g["duplicate_rows"], total=g["total_rows"],
                            examples=g["examples"]))
    return section(checks, tables=per_table,
                   note="Rows are compared on source columns only (source_row and lineage "
                        "excluded). Nothing was removed.")


def keys_section(feed: CleanFeed) -> tuple[dict[str, Any], dict[str, dict]]:
    checks, results = [], {}
    for t in feed.tables:
        key, is_pk = LOGICAL_KEYS.get(t, ([], True))
        if not key:
            checks.append(check(f"{t} logical key", PASS, "no logical key defined", table=t))
            continue
        if not feed.has(t, *key):
            checks.append(check(f"{t} logical key {key}", PASS,
                                "key columns not all present; not applicable", table=t))
            continue
        g = group_analysis(feed, t, key, feed.source_columns(t))
        results[t] = g
        if not g["groups"]:
            status = PASS
        elif is_pk and g["conflicting_groups"]:
            status = ERROR
        else:
            status = WARNING
        null_note = ""
        if g["rows_with_null_key_part"]:
            null_note = f"; {g['rows_with_null_key_part']} rows have a null key part"
            if is_pk:
                status = ERROR
        checks.append(check(
            f"{t} logical key {key}", status,
            f"{g['groups']} repeated keys over {g['affected_rows']} rows "
            f"({g['conflicting_groups']} conflicting, {g['identical_groups']} identical)"
            + null_note,
            table=t, count=g["affected_rows"], total=g["total_rows"], examples=g["examples"],
            groups=g["groups"], conflicting_groups=g["conflicting_groups"],
            identical_groups=g["identical_groups"], primary_key=is_pk,
            rows_with_null_key_part=g["rows_with_null_key_part"]))
    return section(checks), results


def foreign_keys_section(feed: CleanFeed, parents: dict[str, pa.Array]) -> dict[str, Any]:
    multi_agency = len(parents["agency.agency_id"]) > 1
    agency_note = ("conditionally required: the feed has more than one agency"
                   if multi_agency else "optional: the feed has a single agency")
    service_ids = pc.unique(pa.concat_arrays([parents["calendar.service_id"],
                                              parents["calendar_dates.service_id"]]))
    zone_ids = parents["stops.zone_id"]
    checks = [
        fk_check(feed, "routes", "agency_id", parents["agency.agency_id"], "agency.agency_id",
                 required=multi_agency, note=agency_note),
        fk_check(feed, "trips", "route_id", parents["routes.route_id"], "routes.route_id", True),
        fk_check(feed, "trips", "service_id", service_ids,
                 "calendar.service_id ∪ calendar_dates.service_id", True),
        fk_check(feed, "trips", "shape_id", parents["shapes.shape_id"], "shapes.shape_id", False,
                 note="optional field"),
        fk_check(feed, "stop_times", "trip_id", parents["trips.trip_id"], "trips.trip_id", True),
        fk_check(feed, "stop_times", "stop_id", parents["stops.stop_id"], "stops.stop_id", True),
        fk_check(feed, "frequencies", "trip_id", parents["trips.trip_id"], "trips.trip_id", True),
        fk_check(feed, "fare_attributes", "agency_id", parents["agency.agency_id"],
                 "agency.agency_id", required=multi_agency, note=agency_note),
        fk_check(feed, "fare_rules", "fare_id", parents["fare_attributes.fare_id"],
                 "fare_attributes.fare_id", True),
        fk_check(feed, "fare_rules", "route_id", parents["routes.route_id"], "routes.route_id",
                 False, note="optional; null means the rule is not route-specific"),
        fk_check(feed, "fare_rules", "origin_id", zone_ids, "stops.zone_id", False,
                 note="optional; references a fare zone (stops.zone_id)"),
        fk_check(feed, "fare_rules", "destination_id", zone_ids, "stops.zone_id", False,
                 note="optional; references a fare zone (stops.zone_id)"),
    ]
    return section(checks)


def stop_times_section(feed: CleanFeed, keys: dict[str, dict],
                       parents: dict[str, pa.Array]) -> dict[str, Any]:
    t = "stop_times"
    cols = ["trip_id", "stop_sequence", "stop_id", "arrival_time", "departure_time",
            "arrival_time_secs", "departure_time_secs", "source_row"]
    if feed.has(t, "timepoint"):
        cols.append("timepoint")
    # Narrow projection: ~160k rows x 9 columns; per-trip checks need trip rows together.
    df = feed.read(t, cols)
    checks = []

    trip_ids = parents["trips.trip_id"]
    used = pc.unique(pa.array(df["trip_id"].dropna().astype(str).to_numpy(), pa.string()))
    no_st = pc.filter(trip_ids, pc.invert(pc.is_in(trip_ids, value_set=used))).to_pylist()
    checks.append(check("trips without stop_times", ERROR if no_st else PASS,
                        f"{len(no_st)} trips have no stop_times", table="trips",
                        count=len(no_st), total=len(trip_ids), examples=no_st))

    seq_null = int(df["stop_sequence"].isna().sum())
    checks.append(check("stop_sequence numeric and present", ERROR if seq_null else PASS,
                        f"stored as int64; {seq_null} null", table=t, count=seq_null,
                        total=len(df)))

    k = keys.get(t, {})
    checks.append(check("stop_sequence repeats within trip", ERROR if k.get("groups") else PASS,
                        f"{k.get('groups', 0)} (trip_id, stop_sequence) pairs repeat",
                        table=t, count=k.get("affected_rows", 0), total=len(df),
                        examples=k.get("examples")))

    by_file = df.sort_values(["trip_id", "source_row"], kind="stable")
    step = by_file.groupby("trip_id", sort=False)["stop_sequence"].diff()
    unordered_trips = by_file.loc[step <= 0, "trip_id"].unique().tolist()
    checks.append(check("stop_sequence increasing in file order", PASS,
                        f"{len(unordered_trips)} trips are not listed in stop_sequence order "
                        "in the file (GTFS does not require file order)", table=t,
                        count=len(unordered_trips), examples=unordered_trips))

    s = df.sort_values(["trip_id", "stop_sequence", "source_row"], kind="stable")
    g = s.groupby("trip_id", sort=False)
    arr, dep = s["arrival_time_secs"], s["departure_time_secs"]

    for col in ("arrival_time", "departure_time"):
        bad = s[col].notna() & s[f"{col}_secs"].isna()
        checks.append(check(f"{col} valid", ERROR if bad.any() else PASS,
                            f"{int(bad.sum())} values not parsed as GTFS time; "
                            f"{int(s[col].isna().sum())} null (allowed between timepoints)",
                            table=t, count=int(bad.sum()), total=len(s)))

    over24 = int(((arr >= 86400) | (dep >= 86400)).fillna(False).sum())
    max_secs = py(pd.concat([arr, dep]).max())
    checks.append(check("GTFS times >= 24:00:00", PASS,
                        f"{over24} rows use times >= 24:00:00 (supported, kept as GTFS strings)",
                        table=t, count=over24, total=len(s),
                        max_time_secs=max_secs))

    first = g.cumcount() == 0
    last = g.cumcount(ascending=False) == 0
    edge_missing = (first | last) & (arr.isna() | dep.isna())
    checks.append(check("first/last stop of trip has times", ERROR if edge_missing.any() else PASS,
                        f"{int(edge_missing.sum())} first/last stop rows lack arrival or departure",
                        table=t, count=int(edge_missing.sum()),
                        examples=_rows(s[edge_missing], ["trip_id", "stop_sequence", "source_row"])))

    if "timepoint" in s.columns:
        tp_missing = (s["timepoint"] == 1).fillna(False) & (arr.isna() | dep.isna())
        checks.append(check("timepoint=1 rows have times", ERROR if tp_missing.any() else PASS,
                            f"{int(tp_missing.sum())} exact timepoints lack a time", table=t,
                            count=int(tp_missing.sum()),
                            examples=_rows(s[tp_missing], ["trip_id", "stop_sequence",
                                                           "source_row"])))
        checks.append(enum_check(s, t, "timepoint", {0, 1}, WARNING))

    dep_before_arr = (dep < arr).fillna(False)
    checks.append(check("departure_time >= arrival_time", ERROR if dep_before_arr.any() else PASS,
                        f"{int(dep_before_arr.sum())} rows depart before they arrive", table=t,
                        count=int(dep_before_arr.sum()), total=len(s),
                        examples=_rows(s[dep_before_arr], ["trip_id", "stop_sequence",
                                                           "arrival_time", "departure_time",
                                                           "source_row"])))

    prev_dep = g["departure_time_secs"].shift()
    prev_dep = prev_dep.groupby(s["trip_id"], sort=False).ffill()
    backwards = (arr < prev_dep).fillna(False)
    back_trips = s.loc[backwards, "trip_id"].nunique()
    checks.append(check("times do not go backwards along trip", ERROR if backwards.any() else PASS,
                        f"{int(backwards.sum())} rows arrive before the previous stop's "
                        f"departure ({back_trips} trips)", table=t, count=int(backwards.sum()),
                        total=len(s), examples=_rows(s[backwards], ["trip_id", "stop_sequence",
                                                                    "arrival_time",
                                                                    "source_row"])))

    sizes = g.size()
    single = sizes[sizes < 2].index.tolist()
    checks.append(check("trips with fewer than 2 stop_times", WARNING if single else PASS,
                        f"{len(single)} trips have a single stop_time", table=t,
                        count=len(single), examples=single,
                        stops_per_trip={"min": py(sizes.min()), "median": py(sizes.median()),
                                        "max": py(sizes.max())}))

    same_stop = (s["stop_id"] == g["stop_id"].shift()).fillna(False)
    checks.append(check("same stop_id on consecutive stops", WARNING if same_stop.any() else PASS,
                        f"{int(same_stop.sum())} rows repeat the previous stop_id within a trip",
                        table=t, count=int(same_stop.sum()),
                        examples=_rows(s[same_stop], ["trip_id", "stop_sequence", "stop_id",
                                                      "source_row"])))
    return section(checks, rows=len(df), trips_with_stop_times=int(df["trip_id"].nunique()))


def _rows(df: pd.DataFrame, cols: list[str]) -> list[dict[str, Any]]:
    return [{c: py(v) for c, v in zip(cols, r)}
            for r in df[cols].head(MAX_EXAMPLES).itertuples(index=False, name=None)]


def trips_routes_section(feed: CleanFeed, parents: dict[str, pa.Array]) -> dict[str, Any]:
    checks = []
    routes = feed.read("routes", feed.source_columns("routes"))
    trips = feed.read("trips", [c for c in ("trip_id", "route_id", "service_id", "direction_id",
                                            "wheelchair_accessible", "shape_id")
                                if feed.has("trips", c)])
    agency = feed.read("agency", feed.source_columns("agency"))
    stops = feed.read("stops", [c for c in ("stop_id", "stop_name", "stop_lat", "stop_lon",
                                            "wheelchair_boarding") if feed.has("stops", c)])

    checks.append(enum_check(routes, "routes", "route_type",
                             cg.TABLE_SPECS["routes"]["route_type"].allowed, WARNING,
                             required=True))
    if {"route_short_name", "route_long_name"} <= set(routes.columns):
        no_name = routes["route_short_name"].isna() & routes["route_long_name"].isna()
        checks.append(check("route has short or long name", ERROR if no_name.any() else PASS,
                            f"{int(no_name.sum())} routes have neither name", table="routes",
                            count=int(no_name.sum()), total=len(routes),
                            examples=routes.loc[no_name, "route_id"].head(10).tolist()))
    if "route_color" in routes.columns:
        c = routes["route_color"]
        bad = c.notna() & ~c.astype("string").str.fullmatch(r"[0-9A-Fa-f]{6}").fillna(False)
        checks.append(check("route_color format", WARNING if bad.any() else PASS,
                            f"{int(bad.sum())} colours are not 6-digit hex; {int(c.isna().sum())}"
                            " null", table="routes", count=int(bad.sum()), total=len(routes),
                            examples=c[bad].head(10).tolist()))
    checks.append(unused_check("routes without trips", "routes", parents["routes.route_id"],
                               pc.unique(pa.array(trips["route_id"].dropna().astype(str)
                                                  .to_numpy(), pa.string())), "routes"))
    checks.append(enum_check(trips, "trips", "direction_id", {0, 1}, ERROR))
    checks.append(enum_check(trips, "trips", "wheelchair_accessible", {0, 1, 2}, WARNING))

    if "agency_timezone" in agency.columns:
        tzs = agency["agency_timezone"].dropna().unique().tolist()
        checks.append(check("single agency_timezone", ERROR if len(tzs) > 1 else PASS,
                            f"timezones used: {tzs}", table="agency", count=len(tzs)))

    if {"stop_lat", "stop_lon"} <= set(stops.columns):
        no_coord = stops["stop_lat"].isna() | stops["stop_lon"].isna()
        checks.append(check("stops have coordinates", ERROR if no_coord.any() else PASS,
                            f"{int(no_coord.sum())} stops lack lat/lon", table="stops",
                            count=int(no_coord.sum()), total=len(stops)))
        checks.append(_bbox_check(stops["stop_lat"], stops["stop_lon"], "stops"))
    if "stop_name" in stops.columns:
        no_name = stops["stop_name"].isna()
        checks.append(check("stops have stop_name", ERROR if no_name.any() else PASS,
                            f"{int(no_name.sum())} stops lack a name", table="stops",
                            count=int(no_name.sum()), total=len(stops)))
    checks.append(enum_check(stops, "stops", "wheelchair_boarding", {0, 1, 2}, WARNING))
    checks.append(unused_check("stops not used by stop_times", "stops", parents["stops.stop_id"],
                               feed.unique("stop_times", "stop_id"), "stops"))
    return section(checks, routes=len(routes), trips=len(trips), agencies=len(agency),
                   stops=len(stops), route_type_distribution=distribution(routes["route_type"]))


def _bbox_check(lat: pd.Series, lon: pd.Series, table: str) -> dict[str, Any]:
    (la0, la1), (lo0, lo1) = cg.THAILAND_BBOX["lat"], cg.THAILAND_BBOX["lon"]
    outside = ((lat < la0) | (lat > la1) | (lon < lo0) | (lon > lo1)).fillna(False)
    zero = ((lat == 0) & (lon == 0)).fillna(False)
    n = int((outside | zero).sum())
    return check(f"{table} coordinates inside Thailand bounding box", WARNING if n else PASS,
                 f"{int(outside.sum())} outside {cg.THAILAND_BBOX}; {int(zero.sum())} at (0, 0)",
                 table=table, count=n, total=len(lat))


def shapes_section(feed: CleanFeed, keys: dict[str, dict], dup: dict[str, Any],
                   parents: dict[str, pa.Array]) -> dict[str, Any]:
    """Streams shapes in file order; per-shape state is tiny (one row per shape)."""
    t = "shapes"
    cols = ["shape_id", "shape_pt_sequence", "shape_pt_lat", "shape_pt_lon"]
    (la0, la1), (lo0, lo1) = cg.THAILAND_BBOX["lat"], cg.THAILAND_BBOX["lon"]
    per_shape: list[pd.DataFrame] = []
    rows = null_coord = out_range = out_bbox = 0
    order_breaks = repeated_consecutive = 0
    noncontiguous: set = set()
    seen: set = set()
    prev: pd.DataFrame | None = None
    for df in feed.batches(t, cols):
        rows += len(df)
        lat, lon = df["shape_pt_lat"], df["shape_pt_lon"]
        null_coord += int((lat.isna() | lon.isna()).sum())
        out_range += int(((lat.abs() > 90) | (lon.abs() > 180)).fillna(False).sum())
        out_bbox += int(((lat < la0) | (lat > la1) | (lon < lo0) | (lon > lo1)).fillna(False).sum())
        per_shape.append(df.groupby("shape_id", sort=False)["shape_pt_sequence"]
                         .agg(["count", "min", "max"]))
        # Consecutive comparisons in file order, carrying the last row across batches.
        frame = df if prev is None else pd.concat([prev, df], ignore_index=True)
        p = frame.shift()
        same = (frame["shape_id"] == p["shape_id"]).fillna(False)
        offset = 0 if prev is None else 1
        same_b = same.iloc[offset:]
        order_breaks += int((same_b & (frame["shape_pt_sequence"] <= p["shape_pt_sequence"])
                             .iloc[offset:].fillna(False)).sum())
        repeated_consecutive += int((same_b & (frame["shape_pt_lat"] == p["shape_pt_lat"])
                                     .iloc[offset:].fillna(False)
                                     & (frame["shape_pt_lon"] == p["shape_pt_lon"])
                                     .iloc[offset:].fillna(False)).sum())
        # A block starts where shape_id changes; row 0 of a continued frame is the
        # carried-over row from the previous batch and was already counted.
        block_starts = frame.loc[~same, "shape_id"]
        if prev is not None:
            block_starts = block_starts[block_starts.index >= 1]
        for sid in block_starts:
            if sid in seen:
                noncontiguous.add(sid)
            seen.add(sid)
        prev = df.iloc[[-1]]
    agg = pd.concat(per_shape).groupby(level=0).agg({"count": "sum", "min": "min", "max": "max"})
    points = agg["count"]
    k = keys.get(t, {})
    exact = dup.get("tables", {}).get(t, {})
    has_key_dups = bool(k.get("groups"))
    gaps = int(((agg["max"] - agg["min"] + 1) != agg["count"]).sum()) if not has_key_dups else None
    sorted_ok = order_breaks == 0 and not noncontiguous

    checks = [
        check("exact duplicate rows", WARNING if exact.get("exact_duplicate_rows") else PASS,
              f"{exact.get('exact_duplicate_rows', 0)} identical rows (all four columns equal)",
              table=t, count=exact.get("exact_duplicate_rows", 0), total=rows),
        check("duplicate logical key (shape_id, shape_pt_sequence)",
              ERROR if k.get("conflicting_groups") else (WARNING if has_key_dups else PASS),
              f"{k.get('groups', 0)} repeated keys ({k.get('conflicting_groups', 0)} with "
              "different coordinates)", table=t, count=k.get("affected_rows", 0), total=rows,
              examples=k.get("examples")),
        check("repeated consecutive coordinates", WARNING if repeated_consecutive else PASS,
              f"{repeated_consecutive} points repeat the previous point's coordinates within "
              "the same shape (valid but redundant; not an error)", table=t,
              count=repeated_consecutive, total=rows,
              basis="consecutive by shape_pt_sequence" if sorted_ok else "consecutive in file order"),
        check("sequence ordering in file", PASS,
              f"{order_breaks} order breaks; {len(noncontiguous)} shapes split across the file "
              "(GTFS only requires increasing sequence per shape, not file order)", table=t,
              count=order_breaks + len(noncontiguous)),
        check("sequence gaps", PASS,
              ("not evaluated because logical keys repeat" if gaps is None else
               f"{gaps} shapes have non-contiguous shape_pt_sequence values (gaps are allowed)"),
              table=t, count=gaps or 0, total=len(agg)),
        check("latitude/longitude validity", ERROR if (null_coord or out_range) else PASS,
              f"{null_coord} null, {out_range} out of range", table=t,
              count=null_coord + out_range, total=rows),
        check("coordinates inside Thailand bounding box", WARNING if out_bbox else PASS,
              f"{out_bbox} points outside {cg.THAILAND_BBOX}", table=t, count=out_bbox, total=rows),
        check("shapes with fewer than 2 points", WARNING if (points < 2).any() else PASS,
              f"{int((points < 2).sum())} shapes have a single point", table=t,
              count=int((points < 2).sum()), total=len(agg),
              examples=points[points < 2].index[:MAX_EXAMPLES].tolist()),
        unused_check("shapes not used by trips", t, parents["shapes.shape_id"],
                     feed.unique("trips", "shape_id") if feed.has("trips", "shape_id")
                     else pa.array([], pa.string()), "shapes"),
    ]
    return section(checks, rows=rows, shapes=int(len(agg)),
                   points_per_shape={"min": py(points.min()), "median": py(points.median()),
                                     "mean": round(float(points.mean()), 1),
                                     "max": py(points.max())})


def frequencies_section(feed: CleanFeed, keys: dict[str, dict]) -> dict[str, Any]:
    t = "frequencies"
    if not feed.has(t):
        return section([check("frequencies present", PASS, "no frequencies table", table=t)])
    cols = ["trip_id", "start_time", "end_time", "start_time_secs", "end_time_secs",
            "headway_secs", "source_row"]
    has_flag = feed.has(t, cg.SINGLE_DEPARTURE_COL)
    if has_flag:
        cols.append(cg.SINGLE_DEPARTURE_COL)
    df = feed.read(t, cols)
    st, et, hw = df["start_time_secs"], df["end_time_secs"], df["headway_secs"]
    single_rule = ((hw == 0) & (st == et)).fillna(False)
    flagged = df[cg.SINGLE_DEPARTURE_COL].fillna(False) if has_flag else single_rule
    normal = (hw > 0).fillna(False) & ~single_rule
    checks = []

    checks.append(check("single_departure rows", WARNING if single_rule.any() else PASS,
                        f"{int(single_rule.sum())} rows encode a single departure "
                        "(headway_secs = 0, start_time == end_time); accepted, not expanded",
                        table=t, count=int(single_rule.sum()), total=len(df),
                        flag="single_departure",
                        examples=_rows(df[single_rule], ["trip_id", "start_time", "end_time",
                                                         "headway_secs", "source_row"])))
    mismatch = int((flagged != single_rule).sum())
    checks.append(check(f"{cg.SINGLE_DEPARTURE_COL} flag consistent",
                        ERROR if (mismatch or not has_flag) else PASS,
                        f"{mismatch} rows where the flag disagrees with the rule"
                        if has_flag else "flag column missing from clean data",
                        table=t, count=mismatch))
    bad_hw = ((hw <= 0) & ~single_rule).fillna(False) | hw.isna()
    checks.append(check("headway_secs > 0 (except single_departure)",
                        ERROR if bad_hw.any() else PASS,
                        f"{int((hw <= 0).fillna(False).sum())} rows have headway_secs <= 0, of which "
                        f"{int(bad_hw.sum())} are not single_departure", table=t,
                        count=int(bad_hw.sum()), total=len(df),
                        examples=_rows(df[bad_hw], ["trip_id", "start_time", "end_time",
                                                    "headway_secs", "source_row"])))
    reversed_ = (st > et).fillna(False)
    checks.append(check("start_time <= end_time", ERROR if reversed_.any() else PASS,
                        f"{int(reversed_.sum())} rows start after they end", table=t,
                        count=int(reversed_.sum()), total=len(df),
                        examples=_rows(df[reversed_], ["trip_id", "start_time", "end_time",
                                                       "source_row"])))
    zero_window = ((st == et) & (hw > 0)).fillna(False)
    checks.append(check("zero-length window with positive headway",
                        WARNING if zero_window.any() else PASS,
                        f"{int(zero_window.sum())} rows have start_time == end_time but "
                        "headway_secs > 0", table=t, count=int(zero_window.sum())))
    k = keys.get(t, {})
    checks.append(check("duplicate (trip_id, start_time, end_time)",
                        ERROR if k.get("conflicting_groups") else
                        (WARNING if k.get("groups") else PASS),
                        f"{k.get('groups', 0)} repeated keys", table=t,
                        count=k.get("affected_rows", 0), examples=k.get("examples")))

    s = df.sort_values(["trip_id", "start_time_secs", "end_time_secs"], kind="stable")
    gs = s.groupby("trip_id", sort=False)
    prev_start, prev_end = gs["start_time_secs"].shift(), gs["end_time_secs"].shift()
    identical = ((s["start_time_secs"] == prev_start) & (s["end_time_secs"] == prev_end)
                 & (s["headway_secs"] == gs["headway_secs"].shift())).fillna(False)
    overlap = (s["start_time_secs"] < prev_end).fillna(False) & ~identical
    checks.append(check("frequency windows do not overlap within trip",
                        ERROR if overlap.any() else PASS,
                        f"{int(overlap.sum())} rows start before the previous window of the "
                        f"same trip ends ({int(identical.sum())} identical duplicate windows are "
                        "excluded here and reported as duplicates)", table=t,
                        count=int(overlap.sum()),
                        examples=_rows(s[overlap], ["trip_id", "start_time", "end_time",
                                                    "source_row"])))
    per_trip = df.groupby("trip_id").size()
    mixed = df.groupby("trip_id").apply(
        lambda g: bool(single_rule[g.index].any() and normal[g.index].any()),
        include_groups=False)
    checks.append(check("trips mixing single_departure and normal windows",
                        WARNING if mixed.any() else PASS,
                        f"{int(mixed.sum())} trips have both kinds of rows", table=t,
                        count=int(mixed.sum()), examples=mixed[mixed].index[:10].tolist()))
    return section(checks, rows=len(df), normal_rows=int(normal.sum()),
                   single_departure_rows=int(single_rule.sum()),
                   headway_le_zero_rows=int((hw <= 0).fillna(False).sum()),
                   trips_with_frequencies=int(per_trip.size),
                   rows_per_trip={"min": py(per_trip.min()), "median": py(per_trip.median()),
                                  "max": py(per_trip.max()),
                                  "distribution": {str(k): int(v) for k, v in
                                                   per_trip.value_counts().sort_index().items()}},
                   exact_times="column absent: windows are frequency-based (GTFS default 0)",
                   service_instance_expansion="not performed")


DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def calendar_section(feed: CleanFeed, keys: dict[str, dict],
                     parents: dict[str, pa.Array]) -> dict[str, Any]:
    checks = []
    cal = feed.read("calendar", feed.source_columns("calendar")) if feed.has("calendar") else None
    cd = (feed.read("calendar_dates", feed.source_columns("calendar_dates"))
          if feed.has("calendar_dates") else None)
    if cal is not None:
        k = keys.get("calendar", {})
        checks.append(check("calendar.service_id unique", ERROR if k.get("groups") else PASS,
                            f"{k.get('groups', 0)} repeated service_ids", table="calendar",
                            count=k.get("affected_rows", 0), total=len(cal)))
        req_null = cal[["service_id", *DAYS, "start_date", "end_date"]].isna().sum()
        req_null = {c: int(n) for c, n in req_null.items() if n}
        checks.append(check("calendar required fields present", ERROR if req_null else PASS,
                            f"null counts: {req_null or 'none'}", table="calendar",
                            count=sum(req_null.values())))
        reversed_ = (cal["start_date"] > cal["end_date"]).fillna(False)
        checks.append(check("calendar start_date <= end_date", ERROR if reversed_.any() else PASS,
                            f"{int(reversed_.sum())} services end before they start",
                            table="calendar", count=int(reversed_.sum()), total=len(cal)))
        for d in DAYS:
            checks.append(enum_check(cal, "calendar", d, {0, 1}, ERROR, required=True))
        no_days = (cal[DAYS].fillna(0).sum(axis=1) == 0)
        checks.append(check("calendar services with no weekday", WARNING if no_days.any() else PASS,
                            f"{int(no_days.sum())} services run on no weekday (only via "
                            "calendar_dates, if at all)", table="calendar",
                            count=int(no_days.sum()),
                            examples=cal.loc[no_days, "service_id"].tolist()))
        scrape_day = pd.Timestamp(str(feed.manifest.get("scrape_timestamp_bangkok", ""))[:10]
                                  or None)
        if not pd.isna(scrape_day):
            expired = (pd.to_datetime(cal["end_date"]) < scrape_day).fillna(False)
            checks.append(check("calendar services expired at scrape date",
                                WARNING if expired.any() else PASS,
                                f"{int(expired.sum())} services ended before "
                                f"{scrape_day.date()}", table="calendar",
                                count=int(expired.sum()),
                                examples=cal.loc[expired, "service_id"].tolist()))
    if cd is not None:
        k = keys.get("calendar_dates", {})
        checks.append(check("calendar_dates (service_id, date) unique",
                            ERROR if k.get("conflicting_groups") else
                            (WARNING if k.get("groups") else PASS),
                            f"{k.get('groups', 0)} repeated pairs "
                            f"({k.get('conflicting_groups', 0)} with different exception_type)",
                            table="calendar_dates", count=k.get("affected_rows", 0),
                            examples=k.get("examples")))
        checks.append(enum_check(cd, "calendar_dates", "exception_type", {1, 2}, ERROR,
                                 required=True))
        null_dates = int(cd["date"].isna().sum()) + int(cd["service_id"].isna().sum())
        checks.append(check("calendar_dates required fields present",
                            ERROR if null_dates else PASS, f"{null_dates} null service_id/date",
                            table="calendar_dates", count=null_dates))
        if cal is not None:
            only_cd = sorted(set(cd["service_id"].dropna()) - set(cal["service_id"].dropna()))
            checks.append(check("calendar_dates service_ids not in calendar", PASS,
                                f"{len(only_cd)} service_ids are defined only by calendar_dates "
                                "(allowed by GTFS)", table="calendar_dates", count=len(only_cd),
                                examples=only_cd))
            m = cd.merge(cal, on="service_id", how="inner", suffixes=("", "_cal"))
            if len(m):
                dates = pd.to_datetime(m["date"])
                in_range = ((dates >= pd.to_datetime(m["start_date"]))
                            & (dates <= pd.to_datetime(m["end_date"])))
                weekday_on = pd.Series([m.at[i, DAYS[d.weekday()]] == 1
                                        for i, d in zip(m.index, dates)], index=m.index)
                active = in_range & weekday_on
                redundant_add = (m["exception_type"] == 1) & active
                noop_remove = (m["exception_type"] == 2) & ~active
                n = int(redundant_add.sum() + noop_remove.sum())
                checks.append(check("calendar_dates consistent with calendar",
                                    WARNING if n else PASS,
                                    f"{int(redundant_add.sum())} additions on days the service "
                                    f"already runs; {int(noop_remove.sum())} removals on days it "
                                    "does not run", table="calendar_dates", count=n,
                                    examples=_rows(m[redundant_add | noop_remove],
                                                   ["service_id", "date", "exception_type"])))
    used = feed.unique("trips", "service_id")
    all_services = pc.unique(pa.concat_arrays([parents["calendar.service_id"],
                                               parents["calendar_dates.service_id"]]))
    checks.append(unused_check("services not used by trips", "calendar", all_services, used,
                               "services"))
    extra: dict[str, Any] = {}
    if cal is not None:
        extra["calendar_range"] = {"min_start": py(cal["start_date"].min()),
                                   "max_end": py(cal["end_date"].max())}
    if cd is not None:
        extra["calendar_dates_exception_types"] = distribution(cd["exception_type"])
    return section(checks, **extra)


def fares_section(feed: CleanFeed, keys: dict[str, dict], parents: dict[str, pa.Array],
                  fk: dict[str, Any]) -> dict[str, Any]:
    checks = []
    fa_t, fr_t = "fare_attributes", "fare_rules"
    if feed.has(fa_t):
        k = keys.get(fa_t, {})
        checks.append(check("fare_id unique", ERROR if k.get("groups") else PASS,
                            f"{k.get('groups', 0)} repeated fare_ids", table=fa_t,
                            count=k.get("affected_rows", 0), examples=k.get("examples")))
        rows = price_null = price_zero = cur_null = cur_bad = 0
        pmin, pmax = np.inf, -np.inf
        dists: dict[str, dict[str, int]] = {"currency_type": {}, "payment_method": {},
                                            "transfers": {}}
        agency_null = 0
        for df in feed.batches(fa_t, feed.source_columns(fa_t)):
            rows += len(df)
            price = df["price"]
            price_null += int(price.isna().sum())
            price_zero += int((price == 0).sum())
            if price.notna().any():
                pmin, pmax = min(pmin, price.min()), max(pmax, price.max())
            cur = df["currency_type"]
            cur_null += int(cur.isna().sum())
            cur_bad += int((cur.notna() & ~cur.astype("string").str.fullmatch(r"[A-Z]{3}")
                            .fillna(False)).sum())
            for col in dists:
                if col in df.columns:
                    for key, n in distribution(df[col]).items():
                        dists[col][key] = dists[col].get(key, 0) + n
            if "agency_id" in df.columns:
                agency_null += int(df["agency_id"].isna().sum())
        checks.append(check("price present and non-negative", ERROR if price_null else PASS,
                            f"{price_null} null; range {py(pmin)}–{py(pmax)}; {price_zero} free "
                            "fares (price 0)", table=fa_t, count=price_null, total=rows))
        checks.append(check("currency_type", ERROR if cur_null else (WARNING if cur_bad else PASS),
                            f"{cur_null} null; {cur_bad} not ISO-4217-shaped; values "
                            f"{dists['currency_type']}", table=fa_t, count=cur_null + cur_bad,
                            total=rows))
        pm_bad = sum(n for v, n in dists["payment_method"].items() if v not in {"0", "1"})
        checks.append(check("payment_method values", ERROR if pm_bad else PASS,
                            f"{pm_bad} null or outside {{0, 1}}; values {dists['payment_method']}",
                            table=fa_t, count=pm_bad, total=rows))
        tr_bad = sum(n for v, n in dists["transfers"].items() if v not in {"0", "1", "2", "null"})
        checks.append(check("transfers values", ERROR if tr_bad else PASS,
                            f"{tr_bad} outside {{0, 1, 2, empty}}; empty means unlimited "
                            f"transfers; values {dists['transfers']}", table=fa_t, count=tr_bad,
                            total=rows))
        agency_fk = fk.get(f"{fa_t}.agency_id -> agency.agency_id", {})
        checks.append(check("fare_attributes.agency_id", agency_fk.get("status", PASS),
                            f"{agency_null} null; {agency_fk.get('summary', 'n/a')}",
                            table=fa_t, count=agency_null, total=rows,
                            mirror_of="foreign_keys"))
    if feed.has(fr_t):
        for col in ("fare_id", "route_id", "origin_id", "destination_id"):
            r = fk.get(next((n for n in fk if n.startswith(f"{fr_t}.{col} ")), ""), {})
            if r:
                checks.append(check(f"fare_rules.{col} references", r["status"], r["summary"],
                                    table=fr_t, count=r.get("count", 0), total=r.get("total"),
                                    mirror_of="foreign_keys"))
        # Null pattern of the optional selectors, aggregated in batches.
        patterns: dict[str, int] = {}
        sel_cols = [c for c in ("route_id", "origin_id", "destination_id", "contains_id")
                    if feed.has(fr_t, c)]
        bits = 1 << np.arange(len(sel_cols))
        for df in feed.batches(fr_t, sel_cols):
            codes = df[sel_cols].notna().to_numpy() @ bits
            for code, n in zip(*np.unique(codes, return_counts=True)):
                label = "+".join(c for i, c in enumerate(sel_cols) if code >> i & 1) or "(none)"
                patterns[label] = patterns.get(label, 0) + int(n)
        all_null = patterns.get("(none)", 0)
        checks.append(check("fare_rules selector null pattern", WARNING if all_null else PASS,
                            f"non-null selectors per rule: {patterns}. Null route_id / origin_id "
                            "/ destination_id are valid optional fields (a null selector means "
                            "'any'); rules with no selector apply to every trip", table=fr_t,
                            count=all_null, patterns=patterns))
        k = keys.get(fr_t, {})
        checks.append(check("duplicate fare rules", WARNING if k.get("groups") else PASS,
                            f"{k.get('groups', 0)} repeated (fare_id, route_id, origin_id, "
                            "destination_id) rules", table=fr_t, count=k.get("affected_rows", 0),
                            examples=k.get("examples")))
        amb_cols = [c for c in ("route_id", "origin_id", "destination_id") if c in sel_cols]
        amb = group_analysis(feed, fr_t, amb_cols, ["fare_id", *amb_cols])
        checks.append(check("same selectors mapped to several fare_ids",
                            WARNING if amb["conflicting_groups"] else PASS,
                            f"{amb['conflicting_groups']} selector combinations "
                            f"({'/'.join(amb_cols)}) map to more than one fare_id",
                            table=fr_t, count=amb["conflicting_groups"],
                            examples=amb["examples"]))
        if feed.has(fa_t):
            checks.append(unused_check("fare_attributes not used by fare_rules", fa_t,
                                       parents["fare_attributes.fare_id"],
                                       feed.unique(fr_t, "fare_id"), "fares"))
    return section(checks)


def lineage_section(feed: CleanFeed) -> dict[str, Any]:
    checks = []
    meta, man = feed.metadata, feed.manifest
    zip_path = feed.raw_dir / cg.RAW_ZIP_NAME
    actual = cg.sha256_of(zip_path)
    ok_sha = actual == man.get("zip_sha256") == meta.get("feed_sha256")
    checks.append(check("feed SHA-256", PASS if ok_sha else ERROR,
                        f"raw ZIP {actual}; manifest {man.get('zip_sha256')}; "
                        f"clean metadata {meta.get('feed_sha256')}", sha256=actual))
    fi_version = None
    if feed.has("feed_info", "feed_version"):
        fi_version = feed.read("feed_info", ["feed_version"])["feed_version"].dropna().unique()
        fi_version = fi_version[0] if len(fi_version) == 1 else list(fi_version)
    ok_ver = man.get("feed_version") == meta.get("feed_version") and (
        fi_version is None or fi_version == meta.get("feed_version"))
    checks.append(check("feed_version", PASS if ok_ver else ERROR,
                        f"manifest {man.get('feed_version')}; clean metadata "
                        f"{meta.get('feed_version')}; feed_info.parquet {fi_version}",
                        feed_version=meta.get("feed_version")))
    checks.append(check("clean run completed",
                        PASS if (feed.dir / cg.SUCCESS_MARKER).exists()
                        and meta.get("status") == "success" else ERROR,
                        f"_SUCCESS present: {(feed.dir / cg.SUCCESS_MARKER).exists()}; "
                        f"metadata status: {meta.get('status')}"))

    manifest_tables = {PurePosixPath(m["name"]).stem.lower(): m for m in man.get("members", [])
                       if m["name"].lower().endswith(".txt")}
    parquet_tables = {p.stem for p in feed.dir.glob("*.parquet")}
    same_set = set(manifest_tables) == set(meta["tables"]) == parquet_tables
    checks.append(check("table set matches raw feed", PASS if same_set else ERROR,
                        f"raw {sorted(manifest_tables)}; metadata {sorted(meta['tables'])}; "
                        f"parquet {sorted(parquet_tables)}"))

    bad_lineage = []
    for t in feed.tables:
        names = pq.ParquetFile(feed.path(t)).schema_arrow.names
        for col, expected in (("feed_sha256", meta["feed_sha256"]),
                              ("feed_version", meta["feed_version"])):
            if col not in names:
                bad_lineage.append(f"{t}.{col} missing")
                continue
            values = set(feed.unique(t, col).to_pylist())
            if feed.num_rows(t) and values != {expected}:
                bad_lineage.append(f"{t}.{col} = {sorted(values)}")
    checks.append(check("lineage columns match feed identity", ERROR if bad_lineage else PASS,
                        "; ".join(bad_lineage) or "every row carries the feed's SHA-256 and "
                        "feed_version", count=len(bad_lineage)))
    return section(checks)


def source_rows_complete(feed: CleanFeed, table: str, rej_path: Path,
                         raw_rows: int | None) -> bool:
    """True if clean + rejected source_row values are exactly 1..raw_rows, each once.

    Uses a one-byte-per-row bitmap filled batch by batch instead of collecting
    and sorting every source_row value.
    """
    if raw_rows is None:
        return False
    seen = np.zeros(raw_rows, dtype=bool)
    sources = [pq.ParquetFile(feed.path(table))]
    if rej_path.exists():
        sources.append(pq.ParquetFile(rej_path))
    for pf in sources:
        for b in pf.iter_batches(batch_size=BATCH_ROWS, columns=["source_row"]):
            v = b.column(0).to_numpy(zero_copy_only=False)
            if len(v) and (v.min() < 1 or v.max() > raw_rows):
                return False
            idx = v - 1
            if seen[idx].any() or len(np.unique(idx)) != len(idx):
                return False
            seen[idx] = True
    return bool(seen.all())


def row_counts_section(feed: CleanFeed, freq: dict[str, Any]) -> dict[str, Any]:
    checks, tables = [], {}
    meta, man = feed.metadata, feed.manifest
    manifest_rows = {PurePosixPath(m["name"]).stem.lower(): m.get("row_count")
                     for m in man.get("members", [])}
    for t in feed.tables:
        tm = meta["tables"][t]
        clean_rows = feed.num_rows(t)
        rej_path = feed.dir / cg.REJECTED_DIRNAME / f"{t}.parquet"
        rejected_rows = pq.ParquetFile(rej_path).metadata.num_rows if rej_path.exists() else 0
        raw_rows = manifest_rows.get(t)
        coverage = source_rows_complete(feed, t, rej_path, raw_rows)
        problems = []
        if raw_rows != tm["raw_rows"]:
            problems.append(f"manifest raw {raw_rows} != metadata raw {tm['raw_rows']}")
        if clean_rows != tm["clean_rows"]:
            problems.append(f"parquet clean {clean_rows} != metadata clean {tm['clean_rows']}")
        if rejected_rows != tm["rejected_rows"]:
            problems.append(f"rejected parquet {rejected_rows} != metadata {tm['rejected_rows']}")
        if raw_rows is None or raw_rows != clean_rows + rejected_rows:
            problems.append(f"raw {raw_rows} != clean {clean_rows} + rejected {rejected_rows}")
        if not coverage:
            problems.append("source_row values do not cover 1..raw_rows exactly once")
        tables[t] = {"raw_rows": raw_rows, "clean_rows": clean_rows,
                     "rejected_rows": rejected_rows,
                     "invariant_ok": raw_rows == clean_rows + rejected_rows,
                     "source_rows_complete": bool(coverage)}
        checks.append(check(f"{t} row counts", ERROR if problems else PASS,
                            "; ".join(problems) or
                            f"raw {raw_rows} = clean {clean_rows} + rejected {rejected_rows}; "
                            "each source row present exactly once", table=t))
    totals = {k: sum(v[k] or 0 for v in tables.values())
              for k in ("raw_rows", "clean_rows", "rejected_rows")}
    expected_single = freq.get("single_departure_rows", 0)
    rejected_freq = tables.get("frequencies", {}).get("rejected_rows", 0)
    meta_single = (meta["tables"].get("frequencies", {}).get("warnings", {})
                   .get(cg.SINGLE_DEPARTURE_WARNING, 0))
    single_ok = rejected_freq == 0 and meta_single == expected_single
    checks.append(check("single_departure rows present in clean data",
                        PASS if single_ok else ERROR,
                        f"{expected_single} single_departure rows in frequencies.parquet; "
                        f"cleaning metadata reports {meta_single}; {rejected_freq} frequencies "
                        "rows rejected", table="frequencies", count=expected_single))
    return section(checks, tables=tables, totals=totals,
                   primary_table=meta.get("primary_table"),
                   largest_table=meta.get("largest_table"),
                   note="Totals add rows from different GTFS tables; they are not trip counts.")


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def load_parents(feed: CleanFeed) -> dict[str, pa.Array]:
    wanted = ["agency.agency_id", "routes.route_id", "trips.trip_id", "stops.stop_id",
              "stops.zone_id", "calendar.service_id", "calendar_dates.service_id",
              "shapes.shape_id", "fare_attributes.fare_id"]
    out = {}
    for name in wanted:
        table, col = name.split(".")
        out[name] = feed.unique(table, col) if feed.has(table, col) else pa.array([], pa.string())
    return out


def validate_feed(clean_dir: Path, metadata_dir: Path = METADATA_DIR,
                  log_path: Path = cg.SCRAPE_LOG) -> dict[str, Any]:
    """Validate one clean feed; writes the JSON/Markdown reports and log rows."""
    t0 = time.perf_counter()
    started = datetime.now(timezone.utc)
    feed = CleanFeed(clean_dir)
    log.info("validating %s (feed_version=%s)", cg._rel(clean_dir), feed.metadata["feed_version"])

    parents = load_parents(feed)
    dup = duplicates_section(feed)
    log.info("exact duplicates: %s", dup["status"])
    keys_sec, keys = keys_section(feed)
    log.info("logical keys: %s", keys_sec["status"])
    fk_sec = foreign_keys_section(feed, parents)
    fk_by_name = {c["check"]: c for c in fk_sec["checks"]}
    log.info("foreign keys: %s", fk_sec["status"])
    sections = {
        "lineage": lineage_section(feed),
        "exact_duplicates": dup,
        "logical_keys": keys_sec,
        "foreign_keys": fk_sec,
        "stop_times": stop_times_section(feed, keys, parents),
        "trips_routes_stops": trips_routes_section(feed, parents),
        "shapes": shapes_section(feed, keys, dup, parents),
        "frequencies": frequencies_section(feed, keys),
        "calendar": calendar_section(feed, keys, parents),
        "fares": fares_section(feed, keys, parents, fk_by_name),
    }
    sections["row_counts"] = row_counts_section(feed, sections["frequencies"])
    for name, sec in sections.items():
        log.info("%-20s %s", name, sec["status"])

    findings = {s: [] for s in (ERROR, WARNING)}
    for name, sec in sections.items():
        for c in sec["checks"]:
            if c["status"] in findings and not c.get("mirror_of"):
                findings[c["status"]].append({"section": name, "check": c["check"],
                                              "table": c.get("table"), "count": c.get("count"),
                                              "summary": c["summary"]})
    overall = worst([s["status"] for s in sections.values()])
    report = {
        "validator_version": VALIDATOR_VERSION,
        "validated_at_utc": started.isoformat(timespec="seconds"),
        "overall_status": overall,
        "feed": {"feed_sha256": feed.metadata["feed_sha256"],
                 "feed_version": feed.metadata["feed_version"],
                 "clean_dir": cg._rel(clean_dir), "raw_dir": feed.metadata["source_raw_dir"],
                 "clean_run_id": feed.metadata["run_id"]},
        "row_counts": {"tables": sections["row_counts"]["tables"],
                       "totals": sections["row_counts"]["totals"]},
        "summary": {"errors": len(findings[ERROR]), "warnings": len(findings[WARNING]),
                    "sections": {n: s["status"] for n, s in sections.items()}},
        "errors": findings[ERROR],
        "warnings": findings[WARNING],
        "sections": sections,
        "seconds": round(time.perf_counter() - t0, 2),
        "peak_memory_bytes": cg.peak_memory_bytes(),
        "modifications": "none; raw and clean data were only read",
    }
    report = py(report)

    metadata_dir.mkdir(parents=True, exist_ok=True)
    json_path = metadata_dir / f"validation_{clean_dir.name}.json"
    md_path = metadata_dir / f"validation_{clean_dir.name}.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    md_path.write_text(render_markdown(report), encoding="utf-8")
    append_log(log_path, validation_log_rows(report, feed, dup))
    log.info("overall %s (%d errors, %d warnings) in %.1fs -> %s", overall,
             len(findings[ERROR]), len(findings[WARNING]), report["seconds"], cg._rel(json_path))
    return report


def validation_log_rows(report: dict[str, Any], feed: CleanFeed,
                        dup: dict[str, Any]) -> list[dict[str, Any]]:
    base = {"run_id": f"validate-{report['validated_at_utc']}",
            "scrape_timestamp_utc": report["validated_at_utc"],
            "scrape_date": str(feed.manifest.get("scrape_timestamp_bangkok", ""))[:10] or None,
            "source": feed.manifest.get("source"),
            "feed_version": report["feed"]["feed_version"],
            "zip_sha256": report["feed"]["feed_sha256"],
            "zip_bytes": feed.manifest.get("zip_bytes"),
            "raw_path": report["feed"]["raw_dir"], "stage": "validate"}
    totals = report["row_counts"]["totals"]
    table_status: dict[str, list[str]] = {}
    for sec in report["sections"].values():
        for c in sec["checks"]:
            if c.get("table"):
                table_status.setdefault(c["table"], []).append(c["status"])
    rows = [{**base, "file": RUN_ROW_FILE, "status": report["overall_status"],
             "raw_rows": totals["raw_rows"], "clean_rows": totals["clean_rows"],
             "rejected_rows": totals["rejected_rows"],
             "duplicate_rows": sum(t["exact_duplicate_rows"] for t in dup["tables"].values()),
             "error": f"{report['summary']['errors']} errors, "
                      f"{report['summary']['warnings']} warnings"}]
    for t, counts in report["row_counts"]["tables"].items():
        rows.append({**base, "file": feed.metadata["tables"][t]["source_file"],
                     "status": worst(table_status.get(t, [PASS])),
                     "raw_rows": counts["raw_rows"], "clean_rows": counts["clean_rows"],
                     "rejected_rows": counts["rejected_rows"],
                     "duplicate_rows": dup["tables"][t]["exact_duplicate_rows"]})
    return rows


def render_markdown(r: dict[str, Any]) -> str:
    lines = [f"# GTFS validation — {r['feed']['clean_dir']}", "",
             f"- **Overall status:** {r['overall_status']} "
             f"({r['summary']['errors']} errors, {r['summary']['warnings']} warnings)",
             f"- **feed_version:** {r['feed']['feed_version']}",
             f"- **feed_sha256:** `{r['feed']['feed_sha256']}`",
             f"- **Validated at (UTC):** {r['validated_at_utc']}",
             f"- **Data modified:** {r['modifications']}", "",
             "## Sections", "", "| Section | Status |", "|---|---|"]
    lines += [f"| {n} | {s} |" for n, s in r["summary"]["sections"].items()]
    lines += ["", "## Row counts", "", "| Table | Raw | Clean | Rejected | Exact duplicates |",
              "|---|---:|---:|---:|---:|"]
    dups = r["sections"]["exact_duplicates"]["tables"]
    for t, c in r["row_counts"]["tables"].items():
        lines.append(f"| {t} | {c['raw_rows']:,} | {c['clean_rows']:,} | {c['rejected_rows']:,} "
                     f"| {dups[t]['exact_duplicate_rows']:,} |")
    tot = r["row_counts"]["totals"]
    lines += [f"| **total** | {tot['raw_rows']:,} | {tot['clean_rows']:,} | "
              f"{tot['rejected_rows']:,} | |", "",
              "_Totals add rows from different GTFS tables; they are not trip counts._", ""]
    for level, key in ((ERROR, "errors"), (WARNING, "warnings")):
        lines += [f"## {level} findings ({len(r[key])})", ""]
        lines += [f"- **{f['section']} / {f['check']}**: {f['summary']}" for f in r[key]] or ["- none"]
        lines.append("")
    return "\n".join(lines)


def pending_clean_feeds(clean_root: Path = cg.CLEAN_DIR,
                        metadata_dir: Path = METADATA_DIR) -> list[Path]:
    return [d for d in sorted(clean_root.iterdir())
            if d.is_dir() and (d / cg.SUCCESS_MARKER).exists()
            and not (metadata_dir / f"validation_{d.name}.json").exists()]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate cleaned Namtang GTFS feeds.")
    parser.add_argument("feeds", nargs="*", type=Path,
                        help="clean feed directories (default: all without a report)")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args(argv)
    logging.basicConfig(level=args.log_level,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    feeds = args.feeds or pending_clean_feeds()
    if not feeds:
        log.info("nothing to validate")
        return 0
    exit_code = 0
    for feed in feeds:
        report = validate_feed(feed)
        if report["overall_status"] == ERROR:
            exit_code = 1
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
