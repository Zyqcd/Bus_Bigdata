"""Daily Namtang GTFS pipeline: scrape -> clean -> validate -> DQ policy gate ->
analysis -> PostgreSQL load.

Usage (from the project root):
    python data/scraper/run_pipeline.py [--dsn DSN | env DATABASE_URL] [--no-load]

The runner only orchestrates the existing stage implementations; it does not
re-implement them. Every stage is already idempotent and atomic:

The stage steps (``step_scrape`` ... ``step_load``) are also used, one per task,
by the Airflow DAG in airflow/dags/namtang_gtfs_pipeline.py.

* scrape   - downloads the static ZIP once; an unchanged feed (same SHA-256) is
             not stored again and its existing raw_path is returned.
* clean    - skipped when the target feed already has a completed clean output.
* validate - the existing report is reused when it matches the clean run.
* gate     - continues only if every validation ERROR is covered by the
             reviewed DQ policy written for this exact feed SHA-256.
* analysis - skipped when the target feed already has a completed analysis.
* load     - "unchanged" (no database writes) when PostgreSQL already holds
             this feed; otherwise the snapshot is replaced in one transaction.

The target feed is always the scraper's returned raw_path, never "the newest
folder". A failing stage stops the run; earlier outputs and the database stay
as they were, and the next run resumes at the first incomplete stage.

Exit codes: 0 success/unchanged, 1 failed, 2 awaiting_policy, 3 already running.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import logging
import os
import shutil
import socket
import sys
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable

_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE / "processing"))
sys.path.insert(0, str(_HERE.parents[1] / "database" / "load"))

import build_analysis as ba  # noqa: E402
import clean_gtfs as cg  # noqa: E402
import load_namtang as ld  # noqa: E402
import namtang_scraper as ns  # noqa: E402
import validate_gtfs as vg  # noqa: E402

log = logging.getLogger("run_pipeline")

STALE_TMP_HOURS = 24
AIRFLOW_LEASE_TTL = timedelta(hours=6)   # a DAG run normally takes minutes
EXIT_CODES = {"success": 0, "unchanged": 0, "failed": 1, "awaiting_policy": 2, "locked": 3}


@dataclass
class Paths:
    raw_root: Path = ns.RAW_DIR
    clean_root: Path = cg.CLEAN_DIR
    analysis_root: Path = ba.ANALYSIS_DIR
    metadata_dir: Path = vg.METADATA_DIR
    log_path: Path = ns.SCRAPE_LOG
    lock_path: Path = ns.PROJECT_ROOT / "data" / "metadata" / "namtang_pipeline.lock"
    project_root: Path = ns.PROJECT_ROOT


@dataclass
class Stages:
    """Stage callables; defaults bind the existing implementations to ``Paths``."""

    scrape: Callable[[], dict]
    clean: Callable[[Path], dict]
    validate: Callable[[Path], dict]
    analysis: Callable[[Path, Path], dict]
    load: Callable[[Path, Path], dict] | None = None


def default_stages(paths: Paths, dsn: str | None, run_id: str) -> Stages:
    return Stages(
        scrape=lambda: ns.run(raw_dir=paths.raw_root, log_path=paths.log_path),
        clean=lambda raw: cg.clean_feed(raw, raw_root=paths.raw_root,
                                        clean_root=paths.clean_root, log_path=paths.log_path),
        validate=lambda clean: vg.validate_feed(clean, metadata_dir=paths.metadata_dir,
                                                log_path=paths.log_path),
        analysis=lambda clean, policy: ba.build_feed(clean, analysis_root=paths.analysis_root,
                                                     policy_path=policy,
                                                     log_path=paths.log_path),
        load=None if not dsn else (
            lambda clean, analysis: ld.load_feed(dsn, clean, analysis, run_id=f"{run_id}-load",
                                                 log_path=paths.log_path)),
    )


class StageFailure(Exception):
    def __init__(self, stage: str, message: str):
        super().__init__(f"[{stage}] {message}")
        self.stage = stage
        self.message = message


class PipelineLocked(Exception):
    """Another pipeline run holds the lock."""


# --------------------------------------------------------------------------
# Lock
# --------------------------------------------------------------------------

def pid_alive(pid: Any) -> bool:
    """Whether a local process id is running (never sends a signal on Windows)."""
    if not isinstance(pid, int) or pid <= 0:
        return False
    if sys.platform == "win32":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.restype = ctypes.c_void_p
        handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not handle:
            return ctypes.get_last_error() == 5             # access denied -> it exists
        try:
            code = ctypes.c_ulong()
            kernel32.GetExitCodeProcess(ctypes.c_void_p(handle), ctypes.byref(code))
            return code.value == 259                          # STILL_ACTIVE
        finally:
            kernel32.CloseHandle(ctypes.c_void_p(handle))
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class PipelineLock:
    """Exclusive pipeline lock file shared by the manual runner and Airflow.

    The lock file (``data/metadata/namtang_pipeline.lock``) is created with
    O_CREAT|O_EXCL, which works across the Windows host and the Linux containers
    that share the checkout. It records who holds it. There are two kinds of owner:

    * ``process`` - the manual runner (run_pipeline.py). One process holds it for
      the whole run. It is stale only when it was taken on THIS host and that pid
      is no longer running.
    * ``airflow`` - a DAG-run lease. The ``scrape`` task takes it, every later
      task of the same DAG run re-enters it (same owner), and it is released when
      the run ends (load succeeds, any task fails, or the DAG failure callback).
      Several task processes share it, so the pid is not used: it is stale only
      after its recorded ``expires_at_utc`` (refreshed by every task), so a crashed
      run cannot block the pipeline forever.

    A lock file that cannot be read is never treated as stale. Stale takeover and
    release rename the file to a private name first and check its content, so a
    process never deletes a lock that another owner has just created.
    """

    def __init__(self, path: Path, run_id: str, kind: str = "process",
                 ttl: timedelta | None = None, stage: str | None = None):
        if kind not in ("process", "airflow"):
            raise ValueError(f"unknown lock kind {kind!r}")
        if kind == "airflow" and ttl is None:
            raise ValueError("an airflow lease needs a ttl")
        self.path = path
        self.run_id = run_id          # owner id
        self.kind = kind
        self.ttl = ttl
        self.stage = stage
        self.acquired = False

    # -- reading -------------------------------------------------------------
    def _read(self) -> tuple[bool, dict[str, Any] | None]:
        """(exists, parsed content or None if unreadable)."""
        try:
            text = self.path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return False, None
        except OSError:
            return True, None
        try:
            data = json.loads(text)
        except ValueError:
            return True, None
        return True, data if isinstance(data, dict) else None

    def holder(self) -> dict[str, Any] | None:
        return self._read()[1]

    @staticmethod
    def is_stale(holder: dict[str, Any] | None, now: datetime | None = None) -> bool:
        if not isinstance(holder, dict):
            return False
        if holder.get("kind") == "airflow":
            try:
                expires = datetime.fromisoformat(holder["expires_at_utc"])
            except (KeyError, TypeError, ValueError):
                return False
            return (now or datetime.now(timezone.utc)) >= expires
        return holder.get("host") == socket.gethostname() and not pid_alive(holder.get("pid"))

    def describe(self, holder: dict[str, Any] | None) -> str:
        if holder is None:
            return (f"pipeline lock {self.path} exists but cannot be read; check that no run "
                    "is active, then remove it manually")
        info = (f"pipeline lock {self.path} is held by {holder.get('kind', 'process')} owner "
                f"{holder.get('run_id')} (host {holder.get('host')}, pid {holder.get('pid')}, "
                f"stage {holder.get('stage')}, since {holder.get('acquired_at_utc') or holder.get('started_at_utc')}")
        if holder.get("expires_at_utc"):
            info += f", lease expires {holder['expires_at_utc']}"
        return info + ")"

    # -- writing -------------------------------------------------------------
    def _record(self) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        record = {"run_id": self.run_id, "kind": self.kind, "pid": os.getpid(),
                  "host": socket.gethostname(), "stage": self.stage,
                  "acquired_at_utc": now.isoformat()}
        if self.ttl is not None:
            record["expires_at_utc"] = (now + self.ttl).isoformat()
        return record

    def _create(self) -> bool:
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(self._record(), fh)
        return True

    def _refresh(self) -> None:
        """Rewrite a lease we already own (new stage, new expiry) atomically."""
        tmp = self.path.with_name(f"{self.path.name}.{uuid.uuid4().hex}.tmp")
        tmp.write_text(json.dumps(self._record()), encoding="utf-8")
        os.replace(tmp, self.path)

    def _remove_if(self, expected: dict[str, Any]) -> bool:
        """Remove the lock only if it still holds exactly ``expected``."""
        private = self.path.with_name(f"{self.path.name}.{uuid.uuid4().hex}.removing")
        try:
            os.rename(self.path, private)
        except FileNotFoundError:
            return False
        text = private.read_text(encoding="utf-8")
        try:
            content = json.loads(text)
        except ValueError:
            content = None
        if content == expected:
            private.unlink(missing_ok=True)
            return True
        # Someone else owns it now: put it back unchanged (it cannot be overwritten).
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            log.error("pipeline lock conflict: kept displaced lock at %s", private)
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        private.unlink(missing_ok=True)
        return False

    # -- public --------------------------------------------------------------
    def acquire(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        for _ in range(3):
            if self._create():
                self.acquired = True
                return
            exists, holder = self._read()
            if not exists:
                continue                                   # vanished meanwhile; try again
            if holder is None:
                raise PipelineLocked(self.describe(None))
            if (self.kind == "airflow" and holder.get("kind") == "airflow"
                    and holder.get("run_id") == self.run_id):
                self._refresh()                            # later task of the same DAG run
                self.acquired = True
                return
            if self.is_stale(holder):
                log.warning("recovering stale pipeline lock: %s", self.describe(holder))
                self._remove_if(holder)
                continue
            raise PipelineLocked(self.describe(holder))
        raise PipelineLocked(f"could not acquire pipeline lock {self.path} (contended)")

    def release_if_owner(self) -> bool:
        """Remove the lock if (and only if) this owner holds it."""
        holder = self.holder()
        if not holder or holder.get("run_id") != self.run_id:
            return False
        return self._remove_if(holder)

    def release(self) -> None:
        if self.acquired:
            self.release_if_owner()
        self.acquired = False


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

def clean_stale_temp_dirs(paths: Paths, max_age_hours: float = STALE_TMP_HOURS) -> list[str]:
    """Remove leftover .tmp_* / .old_* work directories of earlier clean/analysis
    runs. Only called while holding the lock, only directly under the clean and
    analysis roots, and only when older than ``max_age_hours`` so recent failures
    stay available for inspection. Raw data is never touched."""
    removed = []
    cutoff = time.time() - max_age_hours * 3600
    for root in (paths.clean_root, paths.analysis_root):
        if not root.is_dir():
            continue
        for d in root.iterdir():
            if (d.is_dir() and d.parent == root and d.name.startswith((".tmp_", ".old_"))
                    and d.stat().st_mtime < cutoff):
                shutil.rmtree(d)
                removed.append(str(d))
                log.info("removed stale temporary directory %s", d)
    return removed


def resolve_raw_path(paths: Paths, raw_path: str | None) -> Path:
    if not raw_path:
        raise StageFailure("scrape", "scraper returned no raw_path")
    p = Path(raw_path)
    return p if p.is_absolute() else paths.project_root / p


def existing_validation(paths: Paths, clean_dir: Path, clean_meta: dict) -> dict | None:
    """Reuse a validation report only if it was made from this exact clean run."""
    path = paths.metadata_dir / f"validation_{clean_dir.name}.json"
    if not path.exists():
        return None
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    feed = report.get("feed", {})
    if (feed.get("feed_sha256") == clean_meta.get("feed_sha256")
            and feed.get("clean_run_id") == clean_meta.get("run_id")):
        return report
    return None


def policy_gate(report: dict, clean_meta: dict, policy_path: Path) -> dict[str, Any]:
    """Decide whether validation findings are all covered by the reviewed policy.

    The policy must exist, be written for this exact feed SHA-256 and record a
    human approval (``approval.approved`` is true; drafts are refused). Every
    validation ERROR must name a table that has policy ERROR issues
    (``validation_severity`` / ``affected_table``), and per table the ERROR
    finding counts must add up to the policy's ``affected_rows``. Anything else
    (a new table, a changed count, a feed-level error) is "uncovered" and the
    decision is ``awaiting_policy``. Warnings never block.
    """
    gate: dict[str, Any] = {"policy_path": str(policy_path),
                            "validation_overall_status": report.get("overall_status"),
                            "validation_errors": len(report.get("errors", [])),
                            "validation_warnings": len(report.get("warnings", [])),
                            # always listed so a reviewer can write or update the policy
                            "error_findings": [{k: f.get(k) for k in ("section", "check",
                                                                      "table", "count")}
                                               for f in report.get("errors", [])],
                            "covered": [], "uncovered": [], "policy_issues_not_observed": []}
    if not policy_path.exists():
        return {**gate, "decision": "awaiting_policy",
                "reason": "no reviewed DQ policy exists for this feed; none was generated"}
    policy = json.loads(policy_path.read_text(encoding="utf-8"))
    if policy.get("feed", {}).get("feed_sha256") != clean_meta.get("feed_sha256"):
        return {**gate, "decision": "awaiting_policy",
                "reason": "the DQ policy was written for a different feed SHA-256"}
    approval = policy.get("approval")
    if not isinstance(approval, dict) or approval.get("approved") is not True:
        # A draft (or a file without a recorded human approval) never passes.
        return {**gate, "decision": "awaiting_policy",
                "reason": "the DQ policy for this feed is not approved "
                          "(approval.approved must be true)"}
    gate["policy_version"] = policy.get("policy_version")
    gate["approved_by"] = approval.get("approved_by")

    policy_rows: dict[str, int] = {}
    policy_ids: dict[str, list[str]] = {}
    for issue in policy.get("issues", []):
        if issue.get("validation_severity") == "ERROR" and issue.get("affected_table"):
            t = issue["affected_table"]
            policy_rows[t] = policy_rows.get(t, 0) + int(issue.get("affected_rows") or 0)
            policy_ids.setdefault(t, []).append(issue.get("id"))

    found: dict[str, list[dict]] = {}
    for f in report.get("errors", []):
        if f.get("table") in policy_rows:
            found.setdefault(f["table"], []).append(f)
        else:
            gate["uncovered"].append({**f, "why": "no policy ERROR issue for this table"})
    for table, findings in found.items():
        total = sum(int(f.get("count") or 0) for f in findings)
        entry = {"table": table, "dq_ids": policy_ids[table], "validation_count": total,
                 "policy_affected_rows": policy_rows[table],
                 "checks": [f["check"] for f in findings]}
        if total == policy_rows[table]:
            gate["covered"].append(entry)
        else:
            gate["uncovered"] += [{**f, "why": f"table total {total} != policy affected_rows "
                                               f"{policy_rows[table]}"} for f in findings]
    gate["policy_issues_not_observed"] = sorted(
        i for t in policy_rows if t not in found for i in policy_ids[t])
    if gate["uncovered"]:
        return {**gate, "decision": "awaiting_policy",
                "reason": f"{len(gate['uncovered'])} validation ERROR findings are not covered "
                          "by the DQ policy"}
    return {**gate, "decision": "pass",
            "reason": "every validation ERROR is covered by the DQ policy for this feed"}


def log_event(paths: Paths, run_id: str, stage: str, status: str, message: str | None,
              feed: dict[str, Any] | None = None) -> None:
    """Append one lightweight run row to the shared scrape log (no data rows)."""
    feed = feed or {}
    ns.append_log(paths.log_path, [{
        "run_id": run_id,
        "scrape_timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": ns.SOURCE_NAME, "feed_version": feed.get("feed_version"),
        "zip_sha256": feed.get("feed_sha256"), "raw_path": feed.get("raw_path"),
        "file": ns.RUN_ROW_FILE, "status": status, "error": message, "stage": stage,
    }])


_log = log_event  # backwards-compatible private name


class AwaitingPolicy(Exception):
    """The DQ policy gate did not pass; carries the gate decision and feed context."""

    def __init__(self, gate: dict[str, Any], ctx: dict[str, Any]):
        super().__init__(gate["reason"])
        self.gate = gate
        self.ctx = ctx


# --------------------------------------------------------------------------
# Steps
#
# Each step runs exactly one stage for the feed described by a small, JSON-safe
# context dict (paths, SHA-256, versions, run ids, statuses - never data rows)
# and returns the updated context. The local runner below calls them in order;
# the Airflow DAG (airflow/dags/namtang_gtfs_pipeline.py) runs each one as a
# separate task and passes the context through XCom.
# --------------------------------------------------------------------------

CONTEXT_FEED_KEYS = ("feed_sha256", "feed_version", "raw_path", "scrape_status",
                     "clean_dir", "analysis_dir")


def feed_fields(ctx: dict[str, Any] | None) -> dict[str, Any]:
    return {k: (ctx or {}).get(k) for k in ("feed_sha256", "feed_version", "raw_path")}


def _call(stage: str, fn: Callable, *args: Any) -> dict:
    log.info("stage %s: start", stage)
    try:
        out = fn(*args)
    except StageFailure:
        raise
    except Exception as exc:  # recorded and re-raised as a visible stage failure
        log.exception("stage %s raised", stage)
        raise StageFailure(stage, f"{type(exc).__name__}: {exc}") from exc
    return out or {}


def _next(ctx: dict[str, Any], stage: str, status: Any, **updates: Any) -> dict[str, Any]:
    new = json.loads(json.dumps(ctx))           # independent copy; proves JSON-safety
    new.update(updates)
    new["stage_status"][stage] = status
    log.info("stage %s: %s", stage, status)
    return new


def step_scrape(paths: Paths, stages: Stages, run_id: str) -> dict[str, Any]:
    """Run the scraper and pin the target feed to the raw_path it returns."""
    summary = _call("scrape", stages.scrape)
    if summary.get("status") not in ("success", "unchanged"):
        raise StageFailure("scrape", f"scraper status {summary.get('status')}: "
                                     f"{summary.get('error')}")
    raw_dir = resolve_raw_path(paths, summary.get("raw_path"))
    try:
        manifest = json.loads((raw_dir / ns.MANIFEST_NAME).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise StageFailure("scrape", f"cannot read manifest of target feed {raw_dir}: {exc}")
    if manifest.get("zip_sha256") != summary.get("zip_sha256"):
        raise StageFailure("scrape", f"target feed {raw_dir} does not hold the scraped SHA-256")
    log.info("stage scrape: %s", summary["status"])
    return {"run_id": run_id, "feed_sha256": summary["zip_sha256"],
            "feed_version": summary.get("feed_version"), "raw_path": summary.get("raw_path"),
            "raw_dir": str(raw_dir), "scrape_status": summary["status"],
            "created": {"raw": summary["status"] == "success"},
            "stage_status": {"scrape": summary["status"]}}


def step_clean(paths: Paths, stages: Stages, ctx: dict[str, Any]) -> dict[str, Any]:
    raw_dir = Path(ctx["raw_dir"])
    clean_dir = cg.clean_dir_for(raw_dir, paths.raw_root, paths.clean_root)
    had_clean = (clean_dir / cg.SUCCESS_MARKER).exists()
    meta = _call("clean", stages.clean, raw_dir)
    if meta.get("status") != "success" or not (clean_dir / cg.SUCCESS_MARKER).exists():
        raise StageFailure("clean", f"clean output for {clean_dir} is not complete "
                                    f"(status {meta.get('status')})")
    if meta.get("feed_sha256") != ctx["feed_sha256"]:
        raise StageFailure("clean", "clean output belongs to a different feed SHA-256")
    new = _next(ctx, "clean", meta.get("status"), clean_dir=str(clean_dir),
                clean_run_id=meta.get("run_id"))
    new["created"]["clean"] = not had_clean
    return new


def step_validate(paths: Paths, stages: Stages,
                  ctx: dict[str, Any]) -> tuple[dict[str, Any], dict]:
    """Validate the clean output (or reuse the report of this exact clean run)."""
    clean_dir = Path(ctx["clean_dir"])
    clean_meta = {"feed_sha256": ctx["feed_sha256"], "run_id": ctx["clean_run_id"]}
    report = existing_validation(paths, clean_dir, clean_meta)
    created = report is None
    if created:
        report = _call("validate", stages.validate, clean_dir)
    else:
        log.info("stage validate: reusing existing report for clean run %s", ctx["clean_run_id"])
    if report.get("feed", {}).get("feed_sha256") != ctx["feed_sha256"]:
        raise StageFailure("validate", "validation report belongs to a different feed SHA-256")
    new = _next(ctx, "validate", "validated" if created else "reused",
                validation_report=str(paths.metadata_dir / f"validation_{clean_dir.name}.json"),
                validation_overall_status=report.get("overall_status"))
    if created:
        new["created"]["validation_report"] = True
    return new, report


def step_policy_gate(paths: Paths, ctx: dict[str, Any],
                     report: dict | None = None) -> tuple[dict[str, Any], dict]:
    """Apply the DQ policy gate; raises AwaitingPolicy unless it passes.

    ``report`` may be passed in memory (local runner); otherwise the report file
    written by the validate step is read from disk (Airflow)."""
    if report is None:
        try:
            report = json.loads(Path(ctx["validation_report"]).read_text(encoding="utf-8"))
        except (OSError, ValueError, KeyError) as exc:
            raise StageFailure("policy_gate", f"cannot read the validation report: {exc}")
    if report.get("feed", {}).get("feed_sha256") != ctx["feed_sha256"]:
        raise StageFailure("policy_gate", "validation report belongs to a different feed SHA-256")
    clean_dir = Path(ctx["clean_dir"])
    policy_path = paths.metadata_dir / f"data_quality_policy_{clean_dir.name}.json"
    gate = policy_gate(report, {"feed_sha256": ctx["feed_sha256"]}, policy_path)
    message = gate["reason"]
    if gate["decision"] != "pass":   # tell the operator exactly what needs a reviewed policy
        message += f"; feed_sha256={ctx['feed_sha256']}; expected policy file {policy_path}"
    gate["operator_message"] = message
    log_event(paths, ctx["run_id"], "policy_gate", gate["decision"], message, feed_fields(ctx))
    log.info("policy gate: %s (%s)", gate["decision"], gate["reason"])
    new = _next(ctx, "policy_gate", gate["decision"], policy_path=str(policy_path),
                policy_decision=gate["decision"], policy_reason=gate["reason"])
    if gate["decision"] != "pass":
        raise AwaitingPolicy(gate, new)
    return new, gate


def step_analysis(paths: Paths, stages: Stages, ctx: dict[str, Any]) -> dict[str, Any]:
    if ctx.get("policy_decision") != "pass":
        raise StageFailure("analysis", "the DQ policy gate has not passed for this feed")
    clean_dir = Path(ctx["clean_dir"])
    analysis_dir = paths.analysis_root / clean_dir.name
    had_analysis = (analysis_dir / cg.SUCCESS_MARKER).exists()
    meta = _call("analysis", stages.analysis, clean_dir, Path(ctx["policy_path"]))
    if meta.get("status") != "success" or not (analysis_dir / cg.SUCCESS_MARKER).exists():
        raise StageFailure("analysis", f"analysis output for {analysis_dir} is not complete "
                                       f"(status {meta.get('status')})")
    source = meta.get("source", {})
    if (source.get("feed_sha256") != ctx["feed_sha256"]
            or source.get("clean_run_id") != ctx["clean_run_id"]):
        raise StageFailure("analysis", "analysis output was not built from this clean run; "
                                       "rebuild it with build_analysis.py --force")
    new = _next(ctx, "analysis", meta.get("status"), analysis_dir=str(analysis_dir),
                analysis_run_id=meta.get("run_id"))
    new["created"]["analysis"] = not had_analysis
    return new


def step_load(paths: Paths, stages: Stages, ctx: dict[str, Any],
              load: bool = True) -> dict[str, Any]:
    if not load:
        return _next(ctx, "load", "skipped")
    if stages.load is None:
        raise StageFailure("load", "no database DSN configured")
    if not ctx.get("analysis_dir"):
        raise StageFailure("load", "the analysis step has not completed for this feed")
    loaded = _call("load", stages.load, Path(ctx["clean_dir"]), Path(ctx["analysis_dir"]))
    if loaded.get("status") not in ("unchanged", "loaded"):
        raise StageFailure("load", f"loader status {loaded.get('status')}")
    new = _next(ctx, "load", loaded["status"], load_run_id=loaded.get("run_id"),
                previous_feed_sha256=loaded.get("previous_feed_sha256"))
    new["created"]["database_snapshot"] = loaded["status"] == "loaded"
    return new


def summary_message(ctx: dict[str, Any]) -> str:
    """One-line operator summary for the final scrape_log row."""
    steps = ", ".join(f"{k}={v}" for k, v in ctx.get("stage_status", {}).items())
    load = ctx.get("stage_status", {}).get("load")
    if load in ("loaded", "unchanged"):
        steps += (f"; db previous={ctx.get('previous_feed_sha256')}"
                  f" current={ctx.get('feed_sha256')}")
    return steps


def final_status(ctx: dict[str, Any]) -> str:
    """'unchanged' only when the feed was unchanged and no stage created anything."""
    created = ctx.get("created", {})
    return ("unchanged" if ctx.get("scrape_status") == "unchanged" and not any(created.values())
            else "success")


# --------------------------------------------------------------------------
# Local runner
# --------------------------------------------------------------------------

def _sync(result: dict, ctx: dict[str, Any]) -> None:
    result["created"] = dict(ctx.get("created", {}))
    result["feed"] = {k: ctx[k] for k in CONTEXT_FEED_KEYS if k in ctx}


def _timed(result: dict, name: str, fn: Callable, *args: Any) -> Any:
    t0 = time.perf_counter()
    try:
        out = fn(*args)
    except AwaitingPolicy:
        result["stages"][name] = {"status": "awaiting_policy",
                                  "seconds": round(time.perf_counter() - t0, 2)}
        raise
    except Exception:
        result["stages"][name] = {"status": "failed",
                                  "seconds": round(time.perf_counter() - t0, 2)}
        raise
    ctx = out[0] if isinstance(out, tuple) else out
    result["stages"][name] = {"status": ctx["stage_status"][name],
                              "seconds": round(time.perf_counter() - t0, 2)}
    _sync(result, ctx)
    return out


def run_pipeline(paths: Paths | None = None, stages: Stages | None = None,
                 dsn: str | None = None, load: bool = True,
                 stale_tmp_hours: float = STALE_TMP_HOURS) -> dict[str, Any]:
    paths = paths or Paths()
    run_id = f"pipeline-{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"
    stages = stages or default_stages(paths, dsn, run_id)
    result: dict[str, Any] = {
        "run_id": run_id, "status": None,
        "started_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "stages": {}, "created": {}, "feed": {},
    }
    lock = PipelineLock(paths.lock_path, run_id)
    try:
        lock.acquire()
    except PipelineLocked as exc:
        # Not written to the CSV log: the running pipeline owns it right now.
        log.error("%s", exc)
        result.update(status="locked", error=str(exc))
        return result
    try:
        log_event(paths, run_id, "pipeline", "started", None)
        if load and stages.load is None:
            raise StageFailure("config", "no database DSN; pass --dsn / DATABASE_URL or --no-load")
        result["removed_temp_dirs"] = clean_stale_temp_dirs(paths, stale_tmp_hours)
        ctx = _timed(result, "scrape", step_scrape, paths, stages, run_id)
        ctx = _timed(result, "clean", step_clean, paths, stages, ctx)
        ctx, report = _timed(result, "validate", step_validate, paths, stages, ctx)
        ctx, gate = _timed(result, "policy_gate", step_policy_gate, paths, ctx, report)
        result["policy_gate"] = gate
        ctx = _timed(result, "analysis", step_analysis, paths, stages, ctx)
        ctx = _timed(result, "load", step_load, paths, stages, ctx, load)
        result["status"] = final_status(ctx)
        result["summary"] = summary_message(ctx)
    except AwaitingPolicy as exc:
        _sync(result, exc.ctx)
        result.update(status="awaiting_policy", policy_gate=exc.gate,
                      error=exc.gate.get("operator_message", exc.gate["reason"]))
    except StageFailure as exc:
        result.update(status="failed", failed_stage=exc.stage, error=exc.message)
        log.error("pipeline failed at %s: %s", exc.stage, exc.message)
    except Exception as exc:  # unexpected orchestration bug: still visible and non-zero
        log.exception("pipeline failed unexpectedly")
        result.update(status="failed", failed_stage="pipeline", error=f"{type(exc).__name__}: {exc}")
    finally:
        result["finished_at_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        message = result.get("error") or result.get("summary") or ", ".join(
            f"{k}={v['status']}" for k, v in result["stages"].items())
        if result.get("failed_stage"):
            message = f"failed at {result['failed_stage']}: {message}"
        log_event(paths, run_id, "pipeline", result["status"] or "failed", message, result["feed"])
        lock.release()
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the daily Namtang GTFS pipeline.")
    parser.add_argument("--dsn", default=os.environ.get("DATABASE_URL"),
                        help="PostgreSQL DSN for the load stage (or DATABASE_URL)")
    parser.add_argument("--no-load", action="store_true",
                        help="stop after the analysis stage (no PostgreSQL load)")
    parser.add_argument("--stale-tmp-hours", type=float, default=STALE_TMP_HOURS)
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    args = parser.parse_args(argv)
    logging.basicConfig(level=args.log_level,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    result = run_pipeline(dsn=args.dsn, load=not args.no_load,
                          stale_tmp_hours=args.stale_tmp_hours)
    print(json.dumps(vg.py(result), indent=2, ensure_ascii=False))
    return EXIT_CODES.get(result["status"], 1)


if __name__ == "__main__":
    sys.exit(main())
