"""Tests for GTFS cleaning / Parquet conversion. All feeds are tiny synthetic
fixtures built in memory; no network access and no real data."""

from __future__ import annotations

import hashlib
import io
import json
import sys
import zipfile
from datetime import date
from pathlib import Path

import pyarrow.parquet as pq
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "data" / "scraper" / "processing"))
import clean_gtfs as cg  # noqa: E402

FAKE_SHA = None  # filled per feed from the actual bytes


def make_feed(tmp_path: Path, files: dict[str, str | bytes], day: str = "2026-10-01",
              feed_version: str | None = "v1") -> Path:
    """Write gtfs.zip + manifest.json the way the scraper stores them."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data.encode("utf-8") if isinstance(data, str) else data)
    body = buf.getvalue()
    feed_dir = tmp_path / "raw" / day
    feed_dir.mkdir(parents=True)
    (feed_dir / "gtfs.zip").write_bytes(body)
    manifest = {"zip_sha256": hashlib.sha256(body).hexdigest(), "feed_version": feed_version,
                "members": []}
    (feed_dir / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    return feed_dir


def run_clean(tmp_path: Path, feed_dir: Path, **kw) -> dict:
    return cg.clean_feed(feed_dir, raw_root=tmp_path / "raw", clean_root=tmp_path / "clean",
                         log_path=tmp_path / "scrape_log.csv", **kw)


def read(tmp_path: Path, rel: str, day: str = "2026-10-01") -> list[dict]:
    return pq.read_table(tmp_path / "clean" / day / rel).to_pylist()


STOPS = (
    "﻿ Stop_ID ,stop_name,stop_lat,stop_lon,zone_id,wheelchair_boarding\n"
    "S1,  สยาม  ,13.7456,100.5340,,1\n"
    "S2,Silom,95.0,100.5,,\n"
    "S3,Far,13.7,-200,,0\n"
    "007,Zero,abc,100.5,Z1,\n"
)


def test_stops_cleaning_trim_unicode_nulls_and_coordinates(tmp_path):
    meta = run_clean(tmp_path, make_feed(tmp_path, {"stops.txt": STOPS}))
    rows = read(tmp_path, "stops.parquet")

    assert [r["stop_id"] for r in rows] == ["S1"]          # header BOM/space/case normalized
    s1 = rows[0]
    assert s1["stop_name"] == "สยาม"                         # trimmed, Thai preserved
    assert s1["zone_id"] is None                             # empty -> null, not invented
    assert s1["stop_lat"] == pytest.approx(13.7456)
    assert s1["wheelchair_boarding"] == 1
    assert s1["feed_version"] == "v1" and s1["source_row"] == 1

    rej = {r["source_row"]: r for r in read(tmp_path, "rejected/stops.parquet")}
    assert "invalid latitude" in rej[2]["reject_reason"]
    assert "invalid longitude" in rej[3]["reject_reason"]
    assert "invalid number" in rej[4]["reject_reason"]
    assert json.loads(rej[4]["raw_values"])[0] == "007"      # IDs kept as strings
    assert rej[2]["source_table"] == "stops" and rej[2]["feed_sha256"] == meta["feed_sha256"]

    t = meta["tables"]["stops"]
    assert (t["raw_rows"], t["clean_rows"], t["rejected_rows"]) == (4, 1, 3)
    assert t["invariant_ok"] and t["processing_status"] == "success_with_rejects"


def test_gtfs_times_beyond_24h_and_malformed_times(tmp_path):
    st = ("trip_id,arrival_time,departure_time,stop_id,stop_sequence,timepoint\n"
          "T1,08:00:00,08:00:30,S1,1,1\n"
          "T1,25:10:05,25:10:05,S2,2,0\n"
          "T1,7:05:00,7:05:00,S3,3,\n"
          "T1,,,S4,4,0\n"
          "T1,8:61:00,08:00:00,S5,5,1\n"
          "T1,09:00:00,09:00:00,S6,x,1\n")
    meta = run_clean(tmp_path, make_feed(tmp_path, {"stop_times.txt": st}))
    rows = {r["stop_id"]: r for r in read(tmp_path, "stop_times.parquet")}

    assert rows["S2"]["arrival_time"] == "25:10:05"          # original string kept
    assert rows["S2"]["arrival_time_secs"] == 25 * 3600 + 10 * 60 + 5
    assert rows["S3"]["arrival_time_secs"] == 7 * 3600 + 5 * 60
    assert rows["S4"]["arrival_time"] is None and rows["S4"]["arrival_time_secs"] is None
    assert rows["S1"]["stop_sequence"] == 1

    reasons = [r["reject_reason"] for r in read(tmp_path, "rejected/stop_times.parquet")]
    assert any("arrival_time: malformed time" in r for r in reasons)
    assert any("stop_sequence: invalid integer" in r for r in reasons)
    assert meta["tables"]["stop_times"]["rejected_rows"] == 2


def test_dates_numbers_and_enum_warnings(tmp_path):
    files = {
        "calendar.txt": ("service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,"
                         "start_date,end_date\n"
                         "WK,1,1,1,1,1,0,0,20260101,20261231\n"
                         "BAD,1,1,1,1,1,0,0,20261301,20261231\n"
                         "ODD,2,1,1,1,1,0,0,20260101,2026-12-31\n"),
        "fare_attributes.txt": ("fare_id,price,currency_type,payment_method,transfers,agency_id\n"
                                "F1,15.5,THB,0,,A\nF2,-1,THB,0,0,A\nF3,ten,THB,0,0,A\n"),
        "frequencies.txt": ("trip_id,start_time,end_time,headway_secs\n"
                            "T1,05:00:00,24:30:00,600\nT2,05:00:00,06:00:00,0\n"
                            "T3,07:00:00,08:00:00,-5\n"),
    }
    meta = run_clean(tmp_path, make_feed(tmp_path, files))

    cal = read(tmp_path, "calendar.parquet")
    assert [(r["service_id"], r["start_date"]) for r in cal] == [("WK", date(2026, 1, 1))]
    cal_rej = {json.loads(r["raw_values"])[0]: r["reject_reason"]
               for r in read(tmp_path, "rejected/calendar.parquet")}
    assert "start_date: invalid date" in cal_rej["BAD"]
    assert "end_date: invalid date" in cal_rej["ODD"]

    fares = read(tmp_path, "fare_attributes.parquet")
    assert fares == [dict(fares[0], fare_id="F1", price=15.5, transfers=None)]
    fare_rej = [r["reject_reason"] for r in read(tmp_path, "rejected/fare_attributes.parquet")]
    assert any("negative price" in r for r in fare_rej)
    assert any("price: invalid number" in r for r in fare_rej)

    freq = read(tmp_path, "frequencies.parquet")
    assert len(freq) == 1 and freq[0]["end_time_secs"] == 24 * 3600 + 30 * 60  # not expanded
    assert meta["tables"]["frequencies"]["rejected_rows"] == 2   # 0 with a window, negative
    freq_rej = [r["reject_reason"] for r in read(tmp_path, "rejected/frequencies.parquet")]
    assert any("headway_secs = 0 without start_time == end_time" in r for r in freq_rej)
    assert any("negative headway_secs" in r for r in freq_rej)
    assert meta["tables"]["calendar"]["warnings"] == {}      # ODD row rejected before enum check?
    assert meta["derived_rows"]["service_instances"] is None


def test_unusual_but_valid_values_are_kept_with_warning(tmp_path):
    routes = ("route_id,agency_id,route_short_name,route_long_name,route_desc,route_type,"
              "route_color\nR1,A,1,Long,,3,FF0000\nR2,A,2,Long,,99,\n")
    meta = run_clean(tmp_path, make_feed(tmp_path, {"routes.txt": routes}))
    assert len(read(tmp_path, "routes.parquet")) == 2
    assert meta["tables"]["routes"]["warnings"] == {"route_type: value outside GTFS enum": 1}


def test_malformed_rows_are_rejected_not_shifted(tmp_path):
    trips = ("route_id,service_id,trip_id\n"
             "R1,WK,T1\n"
             "R1,WK\n"
             "R1,WK,T3,extra\n")
    meta = run_clean(tmp_path, make_feed(tmp_path, {"trips.txt": trips}))
    assert [r["trip_id"] for r in read(tmp_path, "trips.parquet")] == ["T1"]
    rej = read(tmp_path, "rejected/trips.parquet")
    assert [r["reject_reason"] for r in rej] == ["malformed row: expected 3 fields, got 2",
                                                 "malformed row: expected 3 fields, got 4"]
    assert json.loads(rej[1]["raw_values"]) == ["R1", "WK", "T3", "extra"]
    assert meta["tables"]["trips"]["invariant_ok"]


def test_large_table_is_processed_in_chunks(tmp_path):
    n = 2_503
    lines = ["shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence"]
    lines += [f"SH{i // 1000},13.{i:04d},100.5,{i}" for i in range(n)]
    lines[1000] = "SH0,13.5,999,999"                         # one bad row in chunk 2
    feed = make_feed(tmp_path, {"shapes.txt": "\n".join(lines) + "\n"})
    meta = run_clean(tmp_path, feed, chunk_rows=500)

    pf = pq.ParquetFile(tmp_path / "clean" / "2026-10-01" / "shapes.parquet")
    assert pf.metadata.num_row_groups == 6                   # ceil(2503 / 500) chunks
    seqs = pf.read(columns=["shape_pt_sequence"]).column(0).to_pylist()
    assert len(seqs) == n - 1 and seqs == sorted(seqs)       # order preserved across chunks
    rej = read(tmp_path, "rejected/shapes.parquet")
    assert [r["source_row"] for r in rej] == [1000]
    t = meta["tables"]["shapes"]
    assert (t["raw_rows"], t["clean_rows"], t["rejected_rows"]) == (n, n - 1, 1)


def test_iter_chunks_reads_from_zip_without_extracting(tmp_path):
    body = "a,b\n" + "".join(f"{i},x\n" for i in range(7)) + "\n"
    feed = make_feed(tmp_path, {"t.txt": body})
    with zipfile.ZipFile(feed / "gtfs.zip") as zf:
        chunks = list(cg.iter_chunks(zf, "t.txt", 3))
    assert [len(rows) for _, rows, _ in chunks] == [3, 3, 1]
    assert [start for _, _, start in chunks] == [1, 4, 7]
    assert sorted(p.name for p in feed.iterdir()) == ["gtfs.zip", "manifest.json"]


def test_full_feed_outputs_metadata_success_and_invariant(tmp_path):
    files = {"stops.txt": STOPS,
             "agency.txt": "agency_id,agency_name,agency_url,agency_timezone\n"
                           "A,ขสมก.,https://x,Asia/Bangkok\n",
             "feed_info.txt": "feed_publisher_name,feed_lang,feed_start_date,feed_end_date,"
                              "feed_version\nP,tha,20260101,20261231,v1\n"}
    feed = make_feed(tmp_path, files)
    meta = run_clean(tmp_path, feed)
    out = tmp_path / "clean" / "2026-10-01"

    assert meta["status"] == "success" and (out / "_SUCCESS").exists()
    assert sorted(p.name for p in out.glob("*.parquet")) == [
        "agency.parquet", "feed_info.parquet", "stops.parquet"]
    assert sorted(p.name for p in (out / "rejected").iterdir()) == ["stops.parquet"]
    assert meta["invariant_ok_all_tables"]
    assert meta["totals"]["raw_rows"] == 6
    assert meta["totals"]["raw_rows"] == meta["totals"]["clean_rows"] + meta["totals"]["rejected_rows"]
    assert read(tmp_path, "agency.parquet")[0]["agency_name"] == "ขสมก."
    assert json.loads((out / "metadata.json").read_text(encoding="utf-8")) == meta
    assert not list((tmp_path / "clean").glob(".tmp_*"))


def test_rerun_is_skipped_and_raw_untouched(tmp_path):
    feed = make_feed(tmp_path, {"stops.txt": STOPS})
    raw_before = (feed / "gtfs.zip").read_bytes()
    first = run_clean(tmp_path, feed)
    second = run_clean(tmp_path, feed)
    assert second["run_id"] == first["run_id"]               # skipped, not rebuilt
    forced = run_clean(tmp_path, feed, force=True)
    assert forced["run_id"] != first["run_id"]
    assert (feed / "gtfs.zip").read_bytes() == raw_before
    assert cg.pending_feeds(tmp_path / "raw", tmp_path / "clean") == []


def test_hash_mismatch_refuses_to_clean(tmp_path):
    feed = make_feed(tmp_path, {"stops.txt": STOPS})
    manifest = json.loads((feed / "manifest.json").read_text())
    manifest["zip_sha256"] = "0" * 64
    (feed / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(cg.CleanError, match="does not match manifest"):
        run_clean(tmp_path, feed)
    assert not (tmp_path / "clean").exists() or not any((tmp_path / "clean").iterdir())


def test_manifest_row_count_mismatch_fails_table(tmp_path):
    feed = make_feed(tmp_path, {"stops.txt": STOPS})
    manifest = json.loads((feed / "manifest.json").read_text())
    manifest["members"] = [{"name": "stops.txt", "row_count": 99}]
    (feed / "manifest.json").write_text(json.dumps(manifest))
    meta = run_clean(tmp_path, feed)
    assert meta["status"] == "failed"
    assert not (tmp_path / "clean" / "2026-10-01").exists()  # never promoted


def test_duplicate_columns_after_normalization_fail(tmp_path):
    meta = run_clean(tmp_path, make_feed(tmp_path, {"stops.txt": "stop_id,STOP_ID\n1,2\n"}))
    assert meta["tables"]["stops"]["processing_status"] == "failed"
    assert "duplicate column" in meta["tables"]["stops"]["error"]


def test_duplicate_rows_are_not_removed(tmp_path):
    body = "agency_id,agency_name,agency_url,agency_timezone\n" + "A,X,u,Asia/Bangkok\n" * 2
    meta = run_clean(tmp_path, make_feed(tmp_path, {"agency.txt": body}))
    assert meta["tables"]["agency"]["clean_rows"] == 2


def test_feed_info_keeps_source_feed_version_column(tmp_path):
    body = ("feed_publisher_name,feed_lang,feed_start_date,feed_end_date,feed_version\n"
            "P,tha,20260101,20261231,v1\n")
    meta = run_clean(tmp_path, make_feed(tmp_path, {"feed_info.txt": body}))
    row = read(tmp_path, "feed_info.parquet")[0]
    assert row["feed_version"] == "v1" and row["feed_sha256"] == meta["feed_sha256"]
    assert row["feed_start_date"] == date(2026, 1, 1)
    assert list(meta["tables"]["feed_info"]["schema"]).count("feed_version") == 1


def test_source_column_clashing_with_generated_name_fails(tmp_path):
    body = "trip_id,start_time,end_time,headway_secs,start_time_secs\nT,05:00:00,06:00:00,60,1\n"
    meta = run_clean(tmp_path, make_feed(tmp_path, {"frequencies.txt": body}))
    assert meta["tables"]["frequencies"]["processing_status"] == "failed"
    assert "clash" in meta["tables"]["frequencies"]["error"]


def test_single_departure_rows_are_accepted_and_flagged(tmp_path):
    body = ("trip_id,start_time,end_time,headway_secs\n"
            "T1,06:00:00,07:00:00,360\n"
            "7293,10:30:00,10:30:00,0\n"
            "T3,25:00:00,25:00:00,0\n")
    meta = run_clean(tmp_path, make_feed(tmp_path, {"frequencies.txt": body}))
    rows = {r["trip_id"]: r for r in read(tmp_path, "frequencies.parquet")}
    assert rows["7293"]["headway_secs"] == 0                  # source value unchanged
    assert rows["7293"]["is_single_departure"] is True
    assert rows["T3"]["is_single_departure"] is True
    assert rows["T1"]["is_single_departure"] is False
    assert len(rows) == 3                                     # nothing expanded
    t = meta["tables"]["frequencies"]
    assert t["rejected_rows"] == 0
    assert t["warnings"] == {cg.SINGLE_DEPARTURE_WARNING: 2}


def test_clean_run_writes_counts_to_scrape_log(tmp_path):
    import csv as _csv
    run_clean(tmp_path, make_feed(tmp_path, {"stops.txt": STOPS}))
    with (tmp_path / "scrape_log.csv").open(newline="", encoding="utf-8") as fh:
        rows = list(_csv.DictReader(fh))
    assert {r["stage"] for r in rows} == {"clean"}
    run_row = next(r for r in rows if r["file"] == "__run__")
    table_row = next(r for r in rows if r["file"] == "stops.txt")
    assert (run_row["raw_rows"], run_row["clean_rows"], run_row["rejected_rows"]) == ("4", "1", "3")
    assert table_row["status"] == "success_with_rejects"
