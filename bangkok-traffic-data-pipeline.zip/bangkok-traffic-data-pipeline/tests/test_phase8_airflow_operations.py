"""Phase 8: Airflow scheduling and operational behaviour of namtang_gtfs_pipeline.

Runs inside the Airflow image (airflow/run_dag_tests.sh). Pipelines run on the
TEST-ONLY Phase 7 fixtures in tmp_path; scraping is the real scraper with a fake
HTTP session, and no database is needed (load is stubbed or never reached)."""

from __future__ import annotations

import importlib.util
import json
import os
from datetime import datetime, timedelta
from pathlib import Path

import pytest

pytest.importorskip("airflow.sdk")

import pendulum  # noqa: E402

import phase7_support as p7  # noqa: E402
import run_pipeline as rp  # noqa: E402
from test_airflow_dag import DAG_FILE, EXPECTED_TASKS, _states  # noqa: E402
from test_run_pipeline import FakeDatabase  # noqa: E402

RETRIES = {"scrape": (2, timedelta(minutes=10)), "clean": (0, None), "validate": (0, None),
           "dq_policy_gate": (0, None), "analysis": (0, None),
           "load_postgresql": (1, timedelta(minutes=5))}


@pytest.fixture(autouse=True)
def production_untouched():
    before = p7.production_snapshot()
    yield
    assert p7.production_snapshot() == before


def load_dag(monkeypatch, schedule_enabled: str | None):
    if schedule_enabled is None:
        monkeypatch.delenv("NAMTANG_SCHEDULE_ENABLED", raising=False)
    else:
        monkeypatch.setenv("NAMTANG_SCHEDULE_ENABLED", schedule_enabled)
    spec = importlib.util.spec_from_file_location("namtang_dag_phase8", DAG_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# --------------------------------------------------------------------------
# Schedule, timezone, catchup, concurrency, retries
# --------------------------------------------------------------------------

def test_schedule_is_off_by_default(monkeypatch):
    dag = load_dag(monkeypatch, None).namtang_dag
    assert dag.schedule is None
    for value in ("false", "0", "", "no"):
        assert load_dag(monkeypatch, value).namtang_dag.schedule is None


def test_enabled_schedule_is_daily_0600_asia_bangkok(monkeypatch):
    from airflow.timetables.trigger import CronTriggerTimetable

    module = load_dag(monkeypatch, "true")
    dag = module.namtang_dag
    timetable = dag.timetable
    assert isinstance(timetable, CronTriggerTimetable)
    assert timetable._expression == "0 6 * * *"
    assert str(timetable._timezone.name) == "Asia/Bangkok"
    # Next fire times are 06:00 Bangkok (= 23:00 UTC the day before), once per day.
    after = pendulum.datetime(2026, 10, 2, 7, 0, tz="Asia/Bangkok")
    first = timetable._get_next(after)
    second = timetable._get_next(first)
    assert first == pendulum.datetime(2026, 10, 3, 6, 0, tz="Asia/Bangkok")
    assert first.in_timezone("UTC").hour == 23
    assert second - first == timedelta(days=1)


def test_dag_safety_settings_hold_with_schedule_enabled(monkeypatch):
    for enabled in (None, "true"):
        dag = load_dag(monkeypatch, enabled).namtang_dag
        assert dag.catchup is False and dag.max_active_runs == 1
        # Airflow stores start_date normalised to UTC; it must be the same instant as
        # midnight 2026-10-01 in Asia/Bangkok (= 2026-09-30 17:00 UTC).
        assert dag.start_date == pendulum.datetime(2026, 10, 1, 0, 0, tz="Asia/Bangkok")
        assert dag.start_date.in_timezone("UTC").hour == 17
        assert dag.on_failure_callback is not None
        assert sorted(dag.task_ids) == sorted(EXPECTED_TASKS)
        for a, b in zip(EXPECTED_TASKS, EXPECTED_TASKS[1:]):
            assert dag.get_task(a).downstream_task_ids == {b}


def test_retry_configuration_is_exact(monkeypatch):
    dag = load_dag(monkeypatch, None).namtang_dag
    for task_id, (retries, delay) in RETRIES.items():
        task = dag.get_task(task_id)
        assert task.retries == retries, task_id
        if delay is not None:
            assert task.retry_delay == delay, task_id
        assert task.multiple_outputs is False


def test_import_with_schedule_enabled_has_no_side_effects(monkeypatch):
    before = p7.production_snapshot()
    load_dag(monkeypatch, "true")
    assert p7.production_snapshot() == before
    assert not (p7.ROOT / "data" / "metadata" / "namtang_pipeline.lock").exists()


# --------------------------------------------------------------------------
# Lease across tasks, failure propagation, failure callback
# --------------------------------------------------------------------------

def point_at_fixture(module, monkeypatch, paths, *, clean=None, analysis=None, load=None):
    for t in module.namtang_dag.tasks:
        monkeypatch.setattr(t, "retries", 0)
    monkeypatch.setattr(module, "pipeline_paths", lambda: paths)
    monkeypatch.setattr(module, "namtang_dsn", lambda: "stub-dsn")

    def stages(p, run_id, dsn=None):
        s = rp.default_stages(p, None, run_id)
        s.scrape = p7.fixture_scraper(p, "A")
        if clean:
            s.clean = clean(s.clean)
        if analysis:
            s.analysis = analysis(s.analysis)
        s.load = load
        return s

    monkeypatch.setattr(module, "pipeline_stages", stages)


def test_lease_blocks_manual_run_between_tasks_and_is_released(monkeypatch, tmp_path):
    module = load_dag(monkeypatch, None)
    paths = p7.isolated_paths(tmp_path)
    seen = {}

    def clean_probe(real_clean):
        def wrapped(raw_dir):
            holder = json.loads(paths.lock_path.read_text())       # lease left by scrape
            seen["holder"] = holder
            try:
                rp.PipelineLock(paths.lock_path, "manual-run").acquire()
                seen["manual"] = "acquired"
            except rp.PipelineLocked:
                seen["manual"] = "refused"
            return real_clean(raw_dir)
        return wrapped

    db = FakeDatabase()
    point_at_fixture(module, monkeypatch, paths, clean=clean_probe, load=db.load)
    first = module.namtang_dag.test()                              # stops at the gate
    assert seen["manual"] == "refused"
    assert seen["holder"]["kind"] == "airflow" and seen["holder"]["stage"] in ("scrape", "clean")
    assert seen["holder"]["run_id"] == f"airflow-{first.run_id}"
    assert _states(first)["dq_policy_gate"] == "failed"
    assert not paths.lock_path.exists()                            # released on failure

    clean_dir = next(d for d in paths.clean_root.iterdir() if not d.name.startswith("."))
    p7.install_policy(paths, clean_dir)
    ok = module.namtang_dag.test()
    assert str(ok.state) == "success"
    assert not paths.lock_path.exists()                            # released after load


@pytest.mark.parametrize("failing", ["clean", "analysis"])
def test_failure_stops_downstream_and_releases_lease(monkeypatch, tmp_path, failing):
    module = load_dag(monkeypatch, None)
    paths = p7.isolated_paths(tmp_path)

    def broken(real):
        def wrapped(*args):
            raise RuntimeError(f"simulated {failing} failure")
        return wrapped

    if failing == "analysis":                                      # get past the gate first
        point_at_fixture(module, monkeypatch, paths, load=FakeDatabase().load)
        module.namtang_dag.test()
        clean_dir = next(d for d in paths.clean_root.iterdir() if not d.name.startswith("."))
        p7.install_policy(paths, clean_dir)
    db = FakeDatabase()
    point_at_fixture(module, monkeypatch, paths, load=db.load, **{failing: broken})
    run = module.namtang_dag.test()
    states = _states(run)
    position = EXPECTED_TASKS.index(failing)
    assert str(run.state) == "failed" and states[failing] == "failed"
    assert all(states[t] == "success" for t in EXPECTED_TASKS[:position])
    assert all(states[t] == "upstream_failed" for t in EXPECTED_TASKS[position + 1:])
    assert db.calls == []                                          # load never ran
    assert not paths.lock_path.exists()


def test_failure_callback_releases_only_its_own_lease(monkeypatch, tmp_path):
    module = load_dag(monkeypatch, None)
    paths = p7.isolated_paths(tmp_path)
    monkeypatch.setattr(module, "pipeline_paths", lambda: paths)

    class Run:
        run_id = "manual__2026-10-02T06:00:00+07:00"

    mine = module._lease(paths, f"airflow-{Run.run_id}", "analysis")
    mine.acquire()
    module.on_dag_run_failure({"dag_run": Run()})
    assert not paths.lock_path.exists()

    other = module._lease(paths, "airflow-another-run", "clean")
    other.acquire()
    module.on_dag_run_failure({"dag_run": Run()})
    assert json.loads(paths.lock_path.read_text())["run_id"] == "airflow-another-run"
