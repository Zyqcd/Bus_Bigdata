"""Shared helpers for the Phase 7 new-feed lifecycle tests.

Everything here targets ISOLATED resources only:
  * fixture ZIPs under tests/fixtures/phase7 (TEST-ONLY, derived from real rows)
  * a throwaway PostgreSQL database `namtang_test_db` (NAMTANG_TEST_DATABASE_URL)
  * per-test pipeline roots in pytest's tmp_path
The production database `namtang_db` is refused by name, host and port, and the
real Namtang URL is never contacted (the real scraper gets a fake HTTP session).
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "data" / "scraper" / "processing"))
sys.path.insert(0, str(ROOT / "database" / "load"))

import namtang_scraper as ns  # noqa: E402
import run_pipeline as rp  # noqa: E402

FIXTURE_DIR = ROOT / "tests" / "fixtures" / "phase7"
MANIFEST = json.loads((FIXTURE_DIR / "fixture_manifest.json").read_text(encoding="utf-8"))
APPROVED_POLICY_A = FIXTURE_DIR / "data_quality_policy_phase7_A.json"
FIXTURE_URL = "https://phase7-fixture.invalid/namtang-gtfs.zip"
PRODUCTION_SHA256 = "6b1a6a2d2d77ea9c6fccfe955899e080946f46d459e2411316d5e7c766951f42"
TEST_DATABASE = "namtang_test_db"
MIGRATIONS = sorted((ROOT / "database" / "migrations" / "namtang").glob("*.sql"))
SOURCE_TABLES = ("agency", "routes", "trips", "stop_times", "stops", "calendar", "calendar_dates",
                 "shapes", "frequencies", "fare_attributes", "fare_rules", "feed_info")
ANALYSIS_TABLES = ("agencies_analysis", "fare_analysis", "frequencies_analysis", "routes_analysis",
                   "shapes_analysis", "stop_times_analysis", "stops_analysis", "trips_analysis")


def variant(key: str) -> dict:
    info = dict(MANIFEST["variants"][key])
    info["path"] = FIXTURE_DIR / info["file"]
    return info


# --------------------------------------------------------------------------
# Isolated database
# --------------------------------------------------------------------------

def isolated_test_dsn() -> str:
    """The test DSN, after proving it cannot be the production database."""
    dsn = os.environ.get("NAMTANG_TEST_DATABASE_URL")
    if not dsn:
        pytest.skip("NAMTANG_TEST_DATABASE_URL not set (start the namtang-test-db service)")
    psycopg = pytest.importorskip("psycopg")
    from psycopg.conninfo import conninfo_to_dict

    info = conninfo_to_dict(dsn)
    if (info.get("dbname") != TEST_DATABASE or info.get("host") == "namtang_db"
            or str(info.get("port")) == "5433"):
        raise RuntimeError(f"refusing non-isolated database target: {info}")
    try:
        with psycopg.connect(dsn, connect_timeout=5) as conn:
            name = conn.execute("SELECT current_database()").fetchone()[0]
    except psycopg.OperationalError as exc:
        pytest.skip(f"isolated test database not reachable: {exc}")
    if name != TEST_DATABASE:
        raise RuntimeError(f"connected to {name!r}, expected {TEST_DATABASE!r}")
    return dsn


def reset_test_database(dsn: str) -> None:
    """Fresh schema in the TEST database: drop both schemas, apply migrations 001-005."""
    import psycopg

    with psycopg.connect(dsn, autocommit=True) as conn:
        if conn.execute("SELECT current_database()").fetchone()[0] != TEST_DATABASE:
            raise RuntimeError("reset refused: not the isolated test database")
        conn.execute("DROP SCHEMA IF EXISTS namtang_analysis CASCADE")
        conn.execute("DROP SCHEMA IF EXISTS namtang CASCADE")
        for migration in MIGRATIONS:
            conn.execute(migration.read_text(encoding="utf-8"))


def db_state(dsn: str) -> dict:
    """Row counts, feed identity, load history and write counters of the test DB."""
    import psycopg

    with psycopg.connect(dsn) as conn:
        state = {"rows": {}}
        for schema, tables in (("namtang", SOURCE_TABLES), ("namtang_analysis", ANALYSIS_TABLES)):
            for t in tables:
                state["rows"][f"{schema}.{t}"] = conn.execute(
                    f'SELECT count(*) FROM "{schema}"."{t}"').fetchone()[0]
        state["feed_identities"] = sorted(r[0] for r in conn.execute(
            "SELECT DISTINCT feed_sha256 FROM namtang.feed_info").fetchall())
        state["load_history"] = [tuple(r) for r in conn.execute(
            "SELECT feed_sha256, feed_version, status, previous_feed_sha256 "
            "FROM namtang.load_history ORDER BY load_id").fetchall()]
        state["migrations"] = [r[0] for r in conn.execute(
            "SELECT version FROM namtang.migration_history ORDER BY version").fetchall()]
    return state


# --------------------------------------------------------------------------
# Fixture scraping (real scraper, fake HTTP)
# --------------------------------------------------------------------------

class FixtureResponse:
    def __init__(self, body: bytes):
        self.body, self.status_code = body, 200
        self.headers = {"Content-Length": str(len(body)), "Content-Type": "application/zip"}

    def iter_content(self, size):
        for i in range(0, len(self.body), size):
            yield self.body[i:i + size]

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FixtureSession:
    """Serves one fixture ZIP; any other URL (e.g. the real Namtang URL) is an error."""

    def __init__(self, body: bytes):
        self.body, self.urls = body, []

    def get(self, url, **kwargs):
        if url != FIXTURE_URL:
            raise AssertionError(f"Phase 7 tests must not contact {url}")
        self.urls.append(url)
        return FixtureResponse(self.body)


def fixture_scraper(paths: rp.Paths, key: str):
    """Stage callable that runs the REAL scraper against a fixture variant."""
    body = variant(key)["path"].read_bytes()
    return lambda: ns.run(url=FIXTURE_URL, raw_dir=paths.raw_root, log_path=paths.log_path,
                          session=FixtureSession(body))


def isolated_paths(tmp_path: Path) -> rp.Paths:
    paths = rp.Paths(raw_root=tmp_path / "raw", clean_root=tmp_path / "clean",
                     analysis_root=tmp_path / "analysis", metadata_dir=tmp_path / "metadata",
                     log_path=tmp_path / "metadata" / "scrape_log.csv",
                     lock_path=tmp_path / "metadata" / "pipeline.lock", project_root=tmp_path)
    paths.metadata_dir.mkdir(parents=True, exist_ok=True)
    return paths


def install_policy(paths: rp.Paths, clean_dir: str | Path, feed_sha256: str | None = None) -> Path:
    """Place the reviewed TEST policy where the gate looks for this feed.

    ``feed_sha256`` defaults to the SHA the policy was reviewed for (fixture A);
    passing another SHA models a reviewer approving the same findings for that feed."""
    policy = json.loads(APPROVED_POLICY_A.read_text(encoding="utf-8"))
    if feed_sha256 is not None:
        policy["feed"]["feed_sha256"] = feed_sha256
    target = paths.metadata_dir / f"data_quality_policy_{Path(clean_dir).name}.json"
    target.write_text(json.dumps(policy, indent=2), encoding="utf-8")
    return target


def production_snapshot() -> dict:
    """mtime+size of every real data/metadata file (read-only), to prove no change."""
    roots = [ROOT / "data" / d for d in ("raw", "clean", "analysis", "metadata")]
    return {str(p): (p.stat().st_mtime_ns, p.stat().st_size)
            for r in roots if r.exists() for p in r.rglob("*") if p.is_file()}
