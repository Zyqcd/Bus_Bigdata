"""Phase 7: new-feed lifecycle through the real pipeline steps, fully isolated.

Real scraper (fake HTTP session serving TEST-ONLY fixture ZIPs), real clean /
validate / policy gate / analysis, and the real PostgreSQL loader - pointed at
the throwaway database ``namtang_test_db`` and at pytest tmp directories.
Requires NAMTANG_TEST_DATABASE_URL (see README, Phase 7); skipped without it.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import zipfile
from pathlib import Path

import pytest

import phase7_support as p7
import run_pipeline as rp

A, B, C = (p7.variant(k) for k in "ABC")


@pytest.fixture(autouse=True)
def production_untouched():
    """Every Phase 7 test must leave the real data/ tree exactly as it was."""
    before = p7.production_snapshot()
    yield
    assert p7.production_snapshot() == before


@pytest.fixture
def test_db():
    dsn = p7.isolated_test_dsn()
    p7.reset_test_database(dsn)
    return dsn


def run(paths: rp.Paths, key: str, dsn: str | None) -> dict:
    stages = rp.default_stages(paths, dsn, f"phase7-{key}")
    stages.scrape = p7.fixture_scraper(paths, key)
    return rp.run_pipeline(paths, stages, dsn=dsn, load=dsn is not None)


def tree(*roots: Path) -> dict:
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for r in roots if r.exists() for p in sorted(r.rglob("*")) if p.is_file()}


def zip_counts(path: Path) -> dict[str, int]:
    with zipfile.ZipFile(path) as zf:
        return {n: sum(1 for r in csv.reader(io.TextIOWrapper(zf.open(n), encoding="utf-8-sig",
                                                              newline="")) if r) - 1
                for n in zf.namelist()}


# --------------------------------------------------------------------------
# 7.1 fixture and 7.2 isolation
# --------------------------------------------------------------------------

def test_fixtures_are_deterministic_test_only_and_not_production():
    shas = set()
    for v in (A, B, C):
        assert hashlib.sha256(v["path"].read_bytes()).hexdigest() == v["sha256"]
        assert v["sha256"] != p7.PRODUCTION_SHA256
        assert v["feed_version"].startswith("PHASE7-TEST-")
        assert zip_counts(v["path"]) == v["row_counts"]
        assert p7.FIXTURE_DIR in v["path"].parents          # never under data/
        shas.add(v["sha256"])
    assert len(shas) == 3
    policy = json.loads(p7.APPROVED_POLICY_A.read_text(encoding="utf-8"))
    assert policy["feed"]["feed_sha256"] == A["sha256"] and "TEST-ONLY" in policy["warning"]


def test_isolation_guard_refuses_production_targets(monkeypatch):
    for dsn in ("postgresql://postgres:x@namtang_db:5432/namtang_db",
                "postgresql://postgres:x@127.0.0.1:5433/namtang_test_db",
                "postgresql://postgres:x@127.0.0.1:5434/namtang_db"):
        monkeypatch.setenv("NAMTANG_TEST_DATABASE_URL", dsn)
        with pytest.raises(RuntimeError, match="refusing non-isolated"):
            p7.isolated_test_dsn()


def test_real_scraper_never_contacts_real_url():
    session = p7.FixtureSession(b"zip")
    with pytest.raises(AssertionError, match="must not contact"):
        session.get("https://namtang-api.otp.go.th/download/namtang-gtfs.zip")


# --------------------------------------------------------------------------
# 7.3 new feed + missing policy
# --------------------------------------------------------------------------

def test_new_feed_without_policy_stops_at_gate(tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    db_before = p7.db_state(test_db)
    result = run(paths, "A", test_db)

    assert result["status"] == "awaiting_policy"
    assert {k: v["status"] for k, v in result["stages"].items()} == {
        "scrape": "success", "clean": "success", "validate": "validated",
        "policy_gate": "awaiting_policy"}                    # analysis and load never ran
    assert result["feed"]["feed_sha256"] == A["sha256"]
    assert result["feed"]["feed_version"] == "PHASE7-TEST-A"
    assert result["created"]["raw"] is True                 # detected as a NEW feed

    clean_dir = Path(result["feed"]["clean_dir"])
    report = json.loads((paths.metadata_dir / f"validation_{clean_dir.name}.json")
                        .read_text(encoding="utf-8"))
    assert report["feed"]["feed_sha256"] == A["sha256"] and report["overall_status"] == "ERROR"
    gate = result["policy_gate"]
    assert gate["decision"] == "awaiting_policy" and "no reviewed DQ policy" in gate["reason"]
    assert {f["table"] for f in gate["error_findings"]} == {"agency", "fare_rules"}
    assert not (paths.analysis_root / clean_dir.name).exists()
    assert p7.db_state(test_db) == db_before                 # no load into the test DB


# --------------------------------------------------------------------------
# 7.4 approved policy and 7.7 unchanged feed
# --------------------------------------------------------------------------

def test_approved_policy_loads_fixture_then_unchanged_is_noop(tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    first = run(paths, "A", test_db)
    assert first["status"] == "awaiting_policy"

    p7.install_policy(paths, first["feed"]["clean_dir"])    # reviewer approves SHA-A
    approved = run(paths, "A", test_db)
    assert approved["status"] == "success", approved
    assert {k: v["status"] for k, v in approved["stages"].items()} == {
        "scrape": "unchanged", "clean": "success", "validate": "reused",
        "policy_gate": "pass", "analysis": "success", "load": "loaded"}
    assert approved["feed"]["feed_sha256"] == A["sha256"]
    assert {c["table"]: c["dq_ids"] for c in approved["policy_gate"]["covered"]} == {
        "agency": ["DQ-001"], "fare_rules": ["DQ-002"]}

    state = p7.db_state(test_db)
    for table, rows in A["row_counts"].items():
        assert state["rows"][f"namtang.{table[:-4]}"] == rows, table
    analysis_meta = json.loads((Path(approved["feed"]["analysis_dir"]) / "metadata.json")
                               .read_text(encoding="utf-8"))
    for name, rows in analysis_meta["output_tables"].items():
        assert state["rows"][f"namtang_analysis.{name[:-8]}"] == rows, name
    assert state["feed_identities"] == [A["sha256"]]
    assert state["load_history"] == [(A["sha256"], "PHASE7-TEST-A", "success", None)]

    # Same SHA again: unchanged path, nothing new on disk, no database write.
    files_before = tree(paths.raw_root, paths.clean_root, paths.analysis_root)
    unchanged = run(paths, "A", test_db)
    assert unchanged["status"] == "unchanged"
    assert unchanged["stages"]["load"]["status"] == "unchanged"
    assert not any(unchanged["created"].values())
    assert tree(paths.raw_root, paths.clean_root, paths.analysis_root) == files_before
    assert p7.db_state(test_db) == state


# --------------------------------------------------------------------------
# 7.5 policy SHA mismatch (and the corrected policy afterwards)
# --------------------------------------------------------------------------

def test_policy_for_other_sha_is_rejected_then_correct_policy_replaces(tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    p7.install_policy(paths, run(paths, "A", test_db)["feed"]["clean_dir"])
    assert run(paths, "A", test_db)["status"] == "success"           # test DB holds SHA-A
    loaded_a = p7.db_state(test_db)

    first_b = run(paths, "B", test_db)
    assert first_b["status"] == "awaiting_policy" and first_b["feed"]["feed_sha256"] == B["sha256"]
    clean_b = Path(first_b["feed"]["clean_dir"])
    p7.install_policy(paths, clean_b)                        # policy file says SHA-A, feed is SHA-B
    mismatch = run(paths, "B", test_db)
    assert mismatch["status"] == "awaiting_policy"
    assert "different feed SHA-256" in mismatch["policy_gate"]["reason"]
    assert "analysis" not in mismatch["stages"] and "load" not in mismatch["stages"]
    assert not (paths.analysis_root / clean_b.name).exists()
    assert p7.db_state(test_db) == loaded_a                   # no load for the rejected run

    p7.install_policy(paths, clean_b, feed_sha256=B["sha256"])   # reviewer approves SHA-B
    replaced = run(paths, "B", test_db)
    assert replaced["status"] == "success" and replaced["stages"]["load"]["status"] == "loaded"
    state = p7.db_state(test_db)
    assert state["feed_identities"] == [B["sha256"]]
    assert state["load_history"][-1] == (B["sha256"], "PHASE7-TEST-B", "success", A["sha256"])
    assert len(state["load_history"]) == 2


# --------------------------------------------------------------------------
# 7.6 unexpected validation ERROR not covered by the approved policy
# --------------------------------------------------------------------------

def test_unexpected_validation_error_is_not_approved(tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    first = run(paths, "C", test_db)
    assert first["status"] == "awaiting_policy"
    # The reviewer's policy covers the known DQ-001/DQ-002 findings for this exact SHA,
    # but variant C also has a stop_times row pointing at a removed stop.
    p7.install_policy(paths, first["feed"]["clean_dir"], feed_sha256=C["sha256"])
    result = run(paths, "C", test_db)
    gate = result["policy_gate"]
    assert result["status"] == "awaiting_policy" and gate["decision"] == "awaiting_policy"
    assert {u["table"] for u in gate["uncovered"]} == {"stop_times"}
    assert any("stop_times.stop_id" in u["check"] for u in gate["uncovered"])
    assert {c["table"] for c in gate["covered"]} == {"agency", "fare_rules"}
    assert "analysis" not in result["stages"] and "load" not in result["stages"]
    assert p7.db_state(test_db)["rows"]["namtang.feed_info"] == 0
