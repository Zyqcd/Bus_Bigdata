"""Phase 9.3: BKK Traffic Parquet -> PostgreSQL loader (database/load/load_bkk_traffic.py).

Fixture snapshots are TEST-ONLY: small synthetic rows written with the friend's
exact Parquet schemas into pytest temporary directories (never production data).
Database tests run ONLY against the isolated throwaway database
namtang_bkk_traffic_test_db (BKK_TRAFFIC_TEST_DATABASE_URL), guarded by the
helpers of test_bkk_traffic_migrations (name, host and port checks plus
current_database()). One test loads the real snapshot copy under
data/bkk_traffic/source_snapshots/ when it exists (git-ignored).
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "database" / "load"))

import load_bkk_traffic as L  # noqa: E402

pa = pytest.importorskip("pyarrow")
pq = pytest.importorskip("pyarrow.parquet")

REAL_SNAPSHOT = ROOT / "data" / "bkk_traffic" / "source_snapshots" / "friend_parquet_2026-10-02"
REAL_COUNTS = {"incidents_bangkok": 484_803, "accidents_bangkok": 223_715,
               "traffic_index": 1_414_001, "travel_times": 839}
GATE = {g: "PASS" for g in L.GATE_CHECKS}


# --------------------------------------------------------------------------
# TEST-ONLY fixture snapshots
# --------------------------------------------------------------------------

def incident(eid: int, **over) -> dict:
    row = {"eid": eid, "nid": eid * 10, "start_time": "2026-10-01 08:00:00", "stop_time": "2026-10-01 09:00:00",
           "createtime": "2026-10-01 08:01:00", "updatedtime": None, "event_type_id": 3, "event_type": "Accident",
           "traffic_relevance": "direct", "is_accident": 1, "is_bangkok": 1, "severity": 1,
           "title": f"test incident {eid}", "title_en": None, "comment": "a,b \"quoted\"\nnew line",
           "comment_en": None, "latitude": 13.7563 + eid / 1e5, "longitude": 100.5018 + eid / 1e5,
           "province_guess": "bangkok", "contributor": "tester", "source": "test", "status": "1",
           "fetched_via": "realtime", "first_seen_at": "2026-10-01 08:05:00", "last_seen_at": "2026-10-01 08:05:00",
           "dq_flags": None}
    row.update(over)
    return row


def traffic(ts: int, **over) -> dict:
    local = (datetime.fromtimestamp(ts, timezone.utc) + timedelta(hours=7)).strftime(L.TS_FORMAT)
    row = {"ts": ts, "ts_local": local, "index_value": 3.25, "source": "history:2026"}
    row.update(over)
    return row


def travel(route: str, fetched_at: str, **over) -> dict:
    row = {"route": route, "fetched_at": fetched_at, "distance_m": 1234.5, "duration_s": 600.0,
           "duration_min": 10.0, "from_lat": 13.8, "from_lon": 100.55, "to_lat": 13.74, "to_lon": 100.56}
    row.update(over)
    return row


def default_rows() -> dict[str, list[dict]]:
    incidents = [incident(1), incident(2, is_accident=0, event_type="Trafficjam", traffic_relevance="direct",
                                       status="", title="ไฟแดงนาน"),
                 incident(3, severity=None, latitude=None, longitude=None, province_guess="bangkok(text)"),
                 incident(4, is_accident=0, event_type="Rain", traffic_relevance="affects", stop_time=None),
                 incident(5, dq_flags="R4_stop_before_start", stop_time=None)]
    return {"incidents_bangkok": incidents,
            "traffic_index": [traffic(1790940000 + 300 * i) for i in range(7)],
            "travel_times": [travel("A -> B", "2026-10-01 10:00:00"), travel("B -> A", "2026-10-01 10:00:00"),
                             travel("A -> B", "2026-10-01 10:05:00")]}


SCHEMAS = {"incidents_bangkok": L.INCIDENT_SCHEMA, "accidents_bangkok": L.INCIDENT_SCHEMA,
           "traffic_index": L.TRAFFIC_INDEX_SCHEMA, "travel_times": L.TRAVEL_TIMES_SCHEMA}


def write_dataset(root: Path, name: str, rows: list[dict], schema=None, parts: int = 2,
                  manifest_edit=None) -> None:
    directory = root / name
    directory.mkdir(parents=True)
    schema = schema or SCHEMAS[name]
    size = max(1, -(-len(rows) // parts))
    files = []
    for i in range(0, len(rows), size):
        chunk = rows[i:i + size]
        fname = f"part-{len(files):05d}.parquet"
        table = pa.Table.from_pylist(chunk, schema=schema)
        pq.write_table(table, directory / fname, compression="zstd")
        files.append({"file": fname, "rows": len(chunk)})
    manifest = {"dataset": name, "generated_at": "2026-10-02 19:03:00", "rows_per_file": 10_000,
                "total_rows": len(rows), "signature": f"{len(rows)}|test|10000",
                "validation": {"gate_passed_at": "2026-10-02 19:02:00", "gate": dict(GATE)}, "files": files}
    if manifest_edit:
        manifest_edit(manifest)
    (directory / "_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")


def make_snapshot(root: Path, rows: dict[str, list[dict]] | None = None, accidents: list[dict] | None = None,
                  **dataset_kwargs) -> Path:
    rows = rows or default_rows()
    if accidents is None:
        accidents = [r for r in rows["incidents_bangkok"] if r["is_accident"] == 1]
    root.mkdir(parents=True, exist_ok=True)
    all_rows = {**rows, "accidents_bangkok": accidents}
    for name in SCHEMAS:
        write_dataset(root, name, all_rows[name], **dataset_kwargs.get(name, {}))
    return root


def validation_errors(root: Path) -> str:
    with pytest.raises(L.LoadError) as info:
        L.validate_snapshot(root)
    return str(info.value)


# --------------------------------------------------------------------------
# 1-3, 6, 8-12 (source side): validation without a database
# --------------------------------------------------------------------------

def test_valid_fixture_snapshot_passes_validation(tmp_path):
    snap = L.validate_snapshot(make_snapshot(tmp_path / "s"))
    assert {n: r.rows for n, r in snap.reports.items()} == {
        "incidents_bangkok": 5, "accidents_bangkok": 3, "traffic_index": 7, "travel_times": 3}
    assert len(snap.sha256) == 64 and "incidents_bangkok=5|test|10000" in snap.signature


@pytest.mark.parametrize("edit, expected", [
    (lambda m: m.__setitem__("total_rows", 99), "total_rows"),
    (lambda m: m["validation"]["gate"].__setitem__("G3_non_bangkok_rows", "FAIL"), "gate not PASS"),
    (lambda m: m["validation"]["gate"].pop("G8_clean_backlog"), "gate checks"),
    (lambda m: m.__setitem__("dataset", "other"), "manifest dataset"),
    (lambda m: m.__setitem__("rows_per_file", 50_000), "rows_per_file"),
    (lambda m: m["files"].pop(), "manifest files != parquet files"),
    (lambda m: m["files"][0].__setitem__("rows", 1), "manifest says"),
], ids=["total_rows", "gate_fail", "gate_missing", "dataset_name", "rows_per_file", "missing_file", "file_rows"])
def test_manifest_and_row_count_validation(tmp_path, edit, expected):
    root = make_snapshot(tmp_path / "s", incidents_bangkok={"manifest_edit": edit})
    assert expected in validation_errors(root)


def test_missing_dataset_and_invalid_manifest_json_fail(tmp_path):
    root = make_snapshot(tmp_path / "s")
    (root / "travel_times" / "_manifest.json").write_text("{not json", encoding="utf-8")
    assert "not valid JSON" in validation_errors(root)
    (root / "travel_times" / "_manifest.json").unlink()
    assert "not found" in validation_errors(root)


def test_extra_parquet_file_on_disk_fails(tmp_path):
    root = make_snapshot(tmp_path / "s")
    pq.write_table(pa.Table.from_pylist([traffic(1)], schema=L.TRAFFIC_INDEX_SCHEMA),
                   root / "traffic_index" / "part-00099.parquet")
    assert "extra ['part-00099.parquet']" in validation_errors(root)


def test_schema_mismatch_fails(tmp_path):
    wrong = L.TRAVEL_TIMES_SCHEMA.set(1, pa.field("fetched_at", pa.timestamp("s")))
    rows = default_rows()
    rows["travel_times"] = [dict(r, fetched_at=datetime(2026, 10, 1, 10, i)) for i, r in enumerate(rows["travel_times"])]
    root = make_snapshot(tmp_path / "s", rows, travel_times={"schema": wrong})
    assert "schema differs" in validation_errors(root)


@pytest.mark.parametrize("over, expected", [
    ({"start_time": "2026/10/01 08:00:00"}, "invalid timestamp(s) in start_time"),
    ({"createtime": "2026-02-30 08:00:00"}, "invalid timestamp(s) in createtime"),
    ({"stop_time": ""}, "invalid timestamp(s) in stop_time"),
    ({"last_seen_at": "2026-10-01T08:05:00"}, "invalid timestamp(s) in last_seen_at"),
    ({"title": None}, "NULL in required column title"),
    ({"title": ""}, "empty title"),
    ({"start_time": None}, "NULL in required column start_time"),
    ({"fetched_via": None}, "NULL in required column fetched_via"),
    ({"is_accident": 2}, "is_accident not in (0, 1)"),
    ({"is_bangkok": 0}, "is_bangkok != 1"),
    ({"severity": 7}, "severity value(s) outside 1-3"),
    ({"traffic_relevance": "other"}, "traffic_relevance value(s) outside"),
    ({"latitude": 95.0}, "outside the geographic range"),
    ({"longitude": -181.0}, "outside the geographic range"),
    ({"source": "\\N"}, "reserved NULL token"),
], ids=lambda v: v if isinstance(v, str) else next(iter(v)))
def test_row_rules_fail_the_whole_snapshot(tmp_path, over, expected):
    rows = default_rows()
    rows["incidents_bangkok"][1] = dict(rows["incidents_bangkok"][1], **over)
    assert expected in validation_errors(make_snapshot(tmp_path / "s", rows))


def test_duplicate_keys_fail(tmp_path):
    rows = default_rows()
    rows["incidents_bangkok"].append(incident(1))
    assert "duplicate key value(s) on ('eid',)" in validation_errors(make_snapshot(tmp_path / "a", rows))
    rows = default_rows()
    rows["traffic_index"].append(traffic(1790940000))
    assert "on ('ts',)" in validation_errors(make_snapshot(tmp_path / "b", rows))
    rows = default_rows()
    rows["travel_times"].append(travel("A -> B", "2026-10-01 10:00:00", distance_m=1.0))
    assert "on ('route', 'fetched_at')" in validation_errors(make_snapshot(tmp_path / "c", rows))


def test_ts_local_must_match_epoch_in_bangkok_time(tmp_path):
    rows = default_rows()
    ts = rows["traffic_index"][3]["ts"]
    utc = datetime.fromtimestamp(ts, timezone.utc).strftime(L.TS_FORMAT)   # a silent UTC conversion
    rows["traffic_index"][3]["ts_local"] = utc
    assert "ts_local != ts as Asia/Bangkok local time" in validation_errors(make_snapshot(tmp_path / "s", rows))


def test_accidents_must_be_flagged_accidents(tmp_path):
    rows = default_rows()
    accidents = [r for r in rows["incidents_bangkok"] if r["is_accident"] == 1]
    accidents.append(rows["incidents_bangkok"][1])     # is_accident = 0
    assert "is_accident != 1" in validation_errors(make_snapshot(tmp_path / "s", rows, accidents))


# --------------------------------------------------------------------------
# 18: production guard (no connection is attempted)
# --------------------------------------------------------------------------

@pytest.mark.parametrize("dsn, expected_db, message", [
    ("host=127.0.0.1 port=5433 dbname=namtang_db user=postgres", "namtang_db", "production target"),
    ("host=namtang_db port=5432 dbname=namtang_db user=postgres", "namtang_db", "production target"),
    ("host=127.0.0.1 port=5432 dbname=namtang_bkk_traffic_test_db user=x", "namtang_bkk_traffic_test_db", "5432"),
    ("host=127.0.0.1 port=5435 dbname=itproject_db user=x", "itproject_db", "forbidden"),
    ("host=127.0.0.1 port=5435 dbname=namtang_bkk_traffic_test_db user=x", "other_db", "--expected-database"),
])
def test_target_guard_refuses_before_connecting(dsn, expected_db, message):
    with pytest.raises(L.TargetRefused, match=message):
        L.check_target_dsn(dsn, expected_db, production_approved=False)


def test_cli_refuses_production_with_exit_code_2(tmp_path, capsys):
    code = L.main(["--source-dir", str(tmp_path), "--expected-database", "namtang_db",
                   "--dsn", "host=127.0.0.1 port=5433 dbname=namtang_db user=postgres password=x"])
    assert code == 2 and '"refused"' in capsys.readouterr().out


def test_loader_never_references_namtang_schemas_or_sqlite():
    source = (ROOT / "database" / "load" / "load_bkk_traffic.py").read_text(encoding="utf-8")
    code = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith("#"))
    assert "namtang." not in code and "namtang_analysis" not in code
    assert "import sqlite3" not in code and "load_namtang" not in code


# --------------------------------------------------------------------------
# Database tests (isolated test DB only)
# --------------------------------------------------------------------------

@pytest.fixture(scope="module")
def dsn():
    import test_bkk_traffic_migrations as mig

    dsn = mig._isolated_dsn()
    mig._reset(dsn)          # Namtang migrations (to prove isolation) + clean slate
    mig._apply_all(dsn)      # bkk_traffic 001-006
    return dsn


def _conn(dsn):
    import test_bkk_traffic_migrations as mig

    return mig._connect(dsn)


@pytest.fixture
def db(dsn):
    with _conn(dsn) as conn:
        conn.execute("TRUNCATE bkk_traffic.incidents, bkk_traffic.traffic_index_history, bkk_traffic.travel_times, "
                     "bkk_traffic.quarantine, bkk_traffic.bronze_incidents, bkk_traffic.load_history RESTART IDENTITY")
        yield conn


def load(dsn, root, **kw):
    return L.run(dsn, root, "namtang_bkk_traffic_test_db", **kw)


def counts(conn) -> dict:
    return {t: conn.execute(f"SELECT count(*) FROM bkk_traffic.{t}").fetchone()[0]
            for t in ("incidents", "traffic_index_history", "travel_times", "load_history")}


def history(conn) -> list[tuple]:
    return conn.execute("SELECT load_id, status, source_sha256 FROM bkk_traffic.load_history ORDER BY load_id").fetchall()


def test_successful_load_and_reconciliation(dsn, db, tmp_path):
    root = make_snapshot(tmp_path / "s")
    result = load(dsn, root, run_id="t-success")
    assert result["status"] == "success" and result["load_id"] == 1
    rc = result["row_counts"]
    keys = ("manifest_rows", "parquet_rows", "loaded_rows", "rejected_rows")
    assert {k: rc["incidents_bangkok"][k] for k in keys} == dict(zip(keys, (5, 5, 5, 0)))
    assert (rc["traffic_index"]["loaded_rows"], rc["travel_times"]["loaded_rows"]) == (7, 3)
    assert rc["accidents_bangkok"]["view_rows"] == 3 and rc["accidents_bangkok"]["physical_copies"] == 0
    assert counts(db) == {"incidents": 5, "traffic_index_history": 7, "travel_times": 3, "load_history": 1}
    row = db.execute("SELECT status, run_id, source_sha256, source_signature, source_manifests, row_counts, "
                     "finished_at IS NOT NULL FROM bkk_traffic.load_history").fetchone()
    assert row[0] == "success" and row[1] == "t-success" and row[2] == result["source_sha256"]
    assert row[4]["incidents_bangkok"]["manifest_rows"] == 5 and row[5]["travel_times"]["rejected_rows"] == 0
    assert row[6] is True


def test_values_are_stored_exactly(dsn, db, tmp_path):
    load(dsn, make_snapshot(tmp_path / "s"))
    db.execute("SET TIME ZONE 'UTC'")
    r = db.execute("SELECT start_time::text, stop_time, status, comment, latitude, is_duplicate, bronze_eid, "
                   "baseline_load_id, title FROM bkk_traffic.incidents WHERE eid = 2").fetchone()
    assert r[0] == "2026-10-01 08:00:00"            # Bangkok wall-clock, not converted
    assert r[2] == "" and r[3] == 'a,b "quoted"\nnew line' and r[8] == "ไฟแดงนาน"   # '' stays '', text verbatim
    assert r[4] == 13.7563 + 2 / 1e5 and r[5] == 0 and r[6] is None and r[7] == 1
    assert db.execute("SELECT stop_time, severity, latitude FROM bkk_traffic.incidents WHERE eid = 3").fetchone() \
        == (datetime(2026, 10, 1, 9, 0), None, None)
    assert db.execute("SELECT count(*) FROM bkk_traffic.travel_times WHERE raw_json IS NULL").fetchone()[0] == 3
    ts, local = db.execute("SELECT ts, ts_local::text FROM bkk_traffic.traffic_index_history ORDER BY ts LIMIT 1"
                           ).fetchone()
    assert local == traffic(ts)["ts_local"]
    db.execute("RESET TIME ZONE")


def test_accidents_view_is_the_subset_without_physical_copies(dsn, db, tmp_path):
    load(dsn, make_snapshot(tmp_path / "s"))
    assert [r[0] for r in db.execute("SELECT eid FROM bkk_traffic.accidents_bangkok ORDER BY eid")] == [1, 3, 5]
    assert db.execute("SELECT count(*) FROM bkk_traffic.incidents_bangkok").fetchone()[0] == 5
    assert db.execute("SELECT to_regclass('bkk_traffic.accidents')").fetchone()[0] is None


@pytest.mark.parametrize("change", ["missing_row", "extra_row", "changed_value"])
def test_accidents_that_are_not_the_subset_fail_and_roll_back(dsn, db, tmp_path, change):
    rows = default_rows()
    accidents = [r for r in rows["incidents_bangkok"] if r["is_accident"] == 1]
    if change == "missing_row":
        accidents = accidents[:-1]
    elif change == "extra_row":
        accidents.append(incident(99))
    else:
        accidents[0] = dict(accidents[0], title="edited title")
    with pytest.raises(L.LoadError, match="not the is_accident=1 subset"):
        load(dsn, make_snapshot(tmp_path / "s", rows, accidents))
    assert counts(db) == {"incidents": 0, "traffic_index_history": 0, "travel_times": 0, "load_history": 1}
    assert history(db)[0][1] == "failed"


def test_constraints_and_foreign_keys_after_load(dsn, db, tmp_path):
    import psycopg

    load(dsn, make_snapshot(tmp_path / "s"))
    # baseline rows need no bronze parent; a pipeline row (baseline_load_id NULL) still does
    with _conn(dsn) as conn:
        conn.autocommit = False
        conn.execute("INSERT INTO bkk_traffic.incidents (eid, title, start_time, traffic_relevance, is_accident, "
                     "is_bangkok, fetched_via, first_seen_at, last_seen_at) VALUES "
                     "(100, 't', '2026-10-02 00:00:00', 'direct', 0, 1, 'realtime', now(), now())")
        with pytest.raises(psycopg.errors.ForeignKeyViolation):
            conn.commit()
    with pytest.raises(psycopg.errors.CheckViolation):
        db.execute("UPDATE bkk_traffic.incidents SET latitude = 91 WHERE eid = 1")
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        db.execute("UPDATE bkk_traffic.incidents SET baseline_load_id = 999 WHERE eid = 1")
    with pytest.raises(psycopg.errors.UniqueViolation):
        db.execute("INSERT INTO bkk_traffic.travel_times (route, fetched_at) VALUES ('A -> B', '2026-10-01 10:00:00')")
    with pytest.raises(psycopg.errors.ForeignKeyViolation):
        db.execute("DELETE FROM bkk_traffic.load_history")


def test_business_key_duplicates_are_reported_not_hidden(dsn, db, tmp_path):
    rows = default_rows()
    twin = dict(rows["incidents_bangkok"][3], eid=6, nid=60)       # same contributor/title/time/coords as eid 4
    rows["incidents_bangkok"].append(twin)
    result = load(dsn, make_snapshot(tmp_path / "s", rows))
    assert result["row_counts"]["incidents_bangkok"]["business_key_duplicates"] == 1
    assert "business-key duplicates 1" in result["message"]


def test_rollback_on_failure_keeps_the_previous_snapshot(dsn, db, tmp_path):
    first = load(dsn, make_snapshot(tmp_path / "a"))
    rows = default_rows()
    rows["incidents_bangkok"].append(incident(7))
    for stage in ("incidents", "traffic_index_history", "travel_times"):
        with pytest.raises(L.InjectedFailure):
            load(dsn, make_snapshot(tmp_path / stage, rows), fail_after=stage)
    assert counts(db) == {"incidents": 5, "traffic_index_history": 7, "travel_times": 3, "load_history": 4}
    assert [h[1] for h in history(db)] == ["success", "failed", "failed", "failed"]
    assert db.execute("SELECT DISTINCT baseline_load_id FROM bkk_traffic.incidents").fetchall() == [(first["load_id"],)]


def test_rerun_same_snapshot_is_unchanged(dsn, db, tmp_path):
    root = make_snapshot(tmp_path / "s")
    first = load(dsn, root)
    before = db.execute("SELECT xmin::text, eid FROM bkk_traffic.incidents ORDER BY eid").fetchall()
    second = load(dsn, root)
    assert second["status"] == "unchanged" and second["source_sha256"] == first["source_sha256"]
    assert db.execute("SELECT xmin::text, eid FROM bkk_traffic.incidents ORDER BY eid").fetchall() == before
    assert [h[1] for h in history(db)] == ["success", "unchanged"]
    assert counts(db)["incidents"] == 5


def test_new_snapshot_replaces_the_baseline_atomically(dsn, db, tmp_path):
    first = load(dsn, make_snapshot(tmp_path / "a"))
    rows = default_rows()
    rows["incidents_bangkok"] = rows["incidents_bangkok"][1:] + [incident(8, is_accident=0, event_type="Rain",
                                                                          traffic_relevance="affects")]
    rows["traffic_index"].append(traffic(1790950000))
    second = load(dsn, make_snapshot(tmp_path / "b", rows))
    assert second["status"] == "success" and second["previous_load_id"] == first["load_id"]
    assert second["row_counts"]["incidents_bangkok"]["replaced_rows"] == 5
    assert counts(db) == {"incidents": 5, "traffic_index_history": 8, "travel_times": 3, "load_history": 2}
    assert db.execute("SELECT DISTINCT baseline_load_id FROM bkk_traffic.incidents").fetchall() == [(2,)]
    assert db.execute("SELECT count(*) FROM bkk_traffic.incidents WHERE eid = 1").fetchone()[0] == 0


def test_pipeline_rows_make_the_loader_refuse(dsn, db, tmp_path):
    load(dsn, make_snapshot(tmp_path / "a"))
    db.execute("INSERT INTO bkk_traffic.traffic_index_history (ts, ts_local, index_value, source) "
               "VALUES (1, '1970-01-01 07:00:01', 1, 'realtime')")
    with pytest.raises(L.LoadError, match="pipeline-written rows"):
        load(dsn, make_snapshot(tmp_path / "b"))
    assert counts(db)["incidents"] == 5


def test_dry_run_writes_nothing(dsn, db, tmp_path, capsys):
    root = make_snapshot(tmp_path / "s")
    assert load(dsn, root, dry_run=True)["status"] == "would_load"
    assert counts(db) == {"incidents": 0, "traffic_index_history": 0, "travel_times": 0, "load_history": 0}
    code = L.main(["--source-dir", str(root), "--expected-database", "namtang_bkk_traffic_test_db",
                   "--dsn", dsn, "--dry-run"])
    assert code == 0 and '"would_load"' in capsys.readouterr().out
    load(dsn, root)
    assert load(dsn, root, dry_run=True)["status"] == "unchanged"
    assert counts(db)["load_history"] == 1


def test_invalid_snapshot_is_recorded_as_failed_without_data(dsn, db, tmp_path):
    rows = default_rows()
    rows["incidents_bangkok"][0]["start_time"] = "0000-00-00 00:00:00"
    with pytest.raises(L.LoadError, match="invalid timestamp"):
        load(dsn, make_snapshot(tmp_path / "s", rows))
    assert history(db)[0][1] == "failed" and counts(db)["incidents"] == 0


def test_connected_database_must_match(dsn, db, monkeypatch):
    # bypass the DSN pre-check to prove the server-side current_database() check on its own
    monkeypatch.setattr(L, "check_target_dsn", lambda *a, **k: {})
    with pytest.raises(L.TargetRefused, match="connected to 'postgres'"):
        L.connect(dsn.replace("dbname=namtang_bkk_traffic_test_db", "dbname=postgres"),
                  "namtang_bkk_traffic_test_db")


def test_namtang_schemas_are_untouched(dsn, db, tmp_path):
    def namtang_state(conn):
        tables = [r[0] for r in conn.execute("SELECT schemaname || '.' || tablename FROM pg_tables "
                                             "WHERE schemaname IN ('namtang', 'namtang_analysis') ORDER BY 1")]
        return tables, {t: conn.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in tables}

    before = namtang_state(db)
    load(dsn, make_snapshot(tmp_path / "s"))
    assert namtang_state(db) == before and len(before[0]) == 22


# --------------------------------------------------------------------------
# Real snapshot (git-ignored copy; isolated test DB only)
# --------------------------------------------------------------------------

@pytest.mark.skipif(not REAL_SNAPSHOT.is_dir(), reason="real BKK Parquet snapshot copy not present")
def test_real_snapshot_full_load(dsn, db):
    result = load(dsn, REAL_SNAPSHOT, run_id="phase9_3-real-snapshot")
    rc = result["row_counts"]
    for name, expected in REAL_COUNTS.items():
        assert rc[name]["manifest_rows"] == rc[name]["parquet_rows"] == expected
        assert rc[name]["rejected_rows"] == 0
    assert rc["accidents_bangkok"]["view_rows"] == REAL_COUNTS["accidents_bangkok"]
    assert counts(db) == {"incidents": 484_803, "traffic_index_history": 1_414_001, "travel_times": 839,
                          "load_history": 1}
    assert load(dsn, REAL_SNAPSHOT)["status"] == "unchanged"
    print(json.dumps(rc, indent=1))
