"""Tests for the Namtang GTFS downloader. No network access: HTTP is faked and
all GTFS archives are tiny synthetic fixtures built in memory."""

from __future__ import annotations

import csv
import io
import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pytest
import requests

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "data" / "scraper"))
import namtang_scraper as ns  # noqa: E402

NOW = datetime(2026, 10, 1, 3, 0, 0, tzinfo=timezone.utc)  # 10:00 in Bangkok


def make_zip(files: dict[str, bytes]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return buf.getvalue()


SAMPLE_FEED = make_zip({
    "stops.txt": "﻿stop_id,stop_name,stop_lat,stop_lon\n"
                 "S1,สยาม,13.7456,100.5340\nS2,Silom,13.7290,100.5340\n".encode("utf-8"),
    "feed_info.txt": b"feed_publisher_name,feed_version\nTest,v42\n",
})


class FakeResponse:
    def __init__(self, body: bytes, status: int = 200, headers: dict | None = None):
        self.body, self.status_code = body, status
        self.headers = {"Content-Length": str(len(body))} if headers is None else headers

    def iter_content(self, size):
        for i in range(0, len(self.body), size):
            yield self.body[i:i + size]

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeSession:
    def __init__(self, response=None, exc: Exception | None = None):
        self.response, self.exc, self.calls = response, exc, 0

    def get(self, url, **kwargs):
        self.calls += 1
        if self.exc:
            raise self.exc
        return self.response


def read_log(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


@pytest.fixture
def dirs(tmp_path):
    return tmp_path / "raw", tmp_path / "scrape_log.csv"


def do_run(dirs, session, now=NOW):
    raw, log_path = dirs
    return ns.run(url="https://example.invalid/gtfs.zip", raw_dir=raw,
                  log_path=log_path, session=session, now=now)


def test_new_feed_is_stored_with_manifest(dirs):
    raw, log_path = dirs
    summary = do_run(dirs, FakeSession(FakeResponse(SAMPLE_FEED)))

    assert summary["status"] == "success"
    feed_dir = raw / "2026-10-01"
    assert (feed_dir / "gtfs.zip").read_bytes() == SAMPLE_FEED
    manifest = json.loads((feed_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["feed_version"] == "v42"
    stops = next(m for m in manifest["members"] if m["name"] == "stops.txt")
    assert stops["columns"] == ["stop_id", "stop_name", "stop_lat", "stop_lon"]
    assert stops["row_count"] == 2
    assert stops["bom"] == "utf-8" and stops["has_non_ascii"] is True
    assert not list(raw.glob("*.part"))

    rows = read_log(log_path)
    assert rows[0]["file"] == "__run__" and rows[0]["status"] == "success"
    assert {r["file"]: r["raw_rows"] for r in rows[1:]} == {"stops.txt": "2", "feed_info.txt": "1"}


def test_unchanged_feed_is_not_stored_again(dirs):
    raw, log_path = dirs
    do_run(dirs, FakeSession(FakeResponse(SAMPLE_FEED)))
    later = NOW.replace(hour=5)
    summary = do_run(dirs, FakeSession(FakeResponse(SAMPLE_FEED)), now=later)

    assert summary["status"] == "unchanged"
    assert summary["feed_version"] == "v42"
    assert len(list(raw.rglob("gtfs.zip"))) == 1
    assert not list(raw.glob("*.part"))
    assert read_log(log_path)[-1]["status"] == "unchanged"


def test_changed_feed_same_day_goes_to_time_subfolder(dirs):
    raw, _ = dirs
    do_run(dirs, FakeSession(FakeResponse(SAMPLE_FEED)))
    other = make_zip({"stops.txt": b"stop_id\nS9\n"})
    summary = do_run(dirs, FakeSession(FakeResponse(other)), now=NOW.replace(hour=5))

    assert summary["status"] == "success"
    assert (raw / "2026-10-01" / "120000" / "gtfs.zip").read_bytes() == other
    assert (raw / "2026-10-01" / "gtfs.zip").read_bytes() == SAMPLE_FEED


def test_corrupt_zip_is_quarantined_and_logged(dirs):
    raw, log_path = dirs
    summary = do_run(dirs, FakeSession(FakeResponse(b"PK\x03\x04 not really a zip")))

    assert summary["status"] == "failed"
    assert "[verify]" in summary["error"]
    assert not list(raw.rglob("gtfs.zip"))
    assert len(list((raw / "_quarantine").glob("*.zip"))) == 1
    assert read_log(log_path)[-1]["status"] == "failed"


def test_html_error_page_is_rejected(dirs):
    summary = do_run(dirs, FakeSession(FakeResponse(b"<html>maintenance</html>")))
    assert summary["status"] == "failed" and "not a ZIP" in summary["error"]


def test_http_error_is_logged_without_storing(dirs):
    raw, log_path = dirs
    summary = do_run(dirs, FakeSession(FakeResponse(b"nope", status=404)))
    assert summary["status"] == "failed"
    assert summary["http_status"] == 404
    assert not list(raw.rglob("gtfs.zip"))
    assert read_log(log_path)[-1]["http_status"] == "404"


def test_network_error_is_logged(dirs):
    summary = do_run(dirs, FakeSession(exc=requests.ConnectionError("boom")))
    assert summary["status"] == "failed" and "ConnectionError" in summary["error"]


def test_truncated_download_fails_size_check(dirs):
    resp = FakeResponse(SAMPLE_FEED[:-10], headers={"Content-Length": str(len(SAMPLE_FEED))})
    summary = do_run(dirs, FakeSession(resp))
    assert summary["status"] == "failed" and "size mismatch" in summary["error"]


def test_zip_slip_member_is_rejected(dirs):
    evil = make_zip({"../evil.txt": b"a\n1\n", "stops.txt": b"stop_id\nS1\n"})
    summary = do_run(dirs, FakeSession(FakeResponse(evil)))
    assert summary["status"] == "failed" and "unsafe member" in summary["error"]


def test_non_utf8_member_marks_run_partial(dirs):
    feed = make_zip({"stops.txt": "stop_id,stop_name\nS1,สยาม\n".encode("tis-620")})
    raw, _ = dirs
    summary = do_run(dirs, FakeSession(FakeResponse(feed)))
    assert summary["status"] == "partial"
    manifest = json.loads((raw / "2026-10-01" / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["members"][0]["encoding"] == "not valid UTF-8"
    assert (raw / "2026-10-01" / "gtfs.zip").exists()  # raw bytes are still preserved


def test_ragged_and_blank_rows_are_counted(tmp_path):
    path = tmp_path / "feed.zip"
    path.write_bytes(make_zip({"trips.txt": b"route_id,trip_id\nR1,T1\n\nR2\nR3,T3,extra\n"}))
    info = ns.inspect_members(path)[0]
    assert info["row_count"] == 3
    assert info["blank_lines"] == 1
    assert info["ragged_rows"] == 2


def test_legacy_header_only_log_is_upgraded(tmp_path):
    log_path = tmp_path / "scrape_log.csv"
    log_path.write_text(",".join(ns.LEGACY_LOG_FIELDS) + "\n", encoding="utf-8")
    ns.ensure_log(log_path)
    assert log_path.read_text(encoding="utf-8").strip() == ",".join(ns.LOG_FIELDS)


def test_legacy_log_with_data_is_not_touched(tmp_path):
    log_path = tmp_path / "scrape_log.csv"
    original = ",".join(ns.LEGACY_LOG_FIELDS) + "\n2026-01-01,x,y,ok,1,t\n"
    log_path.write_text(original, encoding="utf-8")
    with pytest.raises(ns.ScrapeError):
        ns.ensure_log(log_path)
    assert log_path.read_text(encoding="utf-8") == original


def test_stored_zip_is_never_overwritten(tmp_path):
    target = tmp_path / "feed"
    target.mkdir()
    (target / "gtfs.zip").write_bytes(b"original")
    part = tmp_path / "x.part"
    part.write_bytes(b"new")
    with pytest.raises(ns.ScrapeError):
        ns.store_feed(part, target, {})
    assert (target / "gtfs.zip").read_bytes() == b"original"


def test_v1_log_gets_stage_column_and_keeps_rows(tmp_path):
    log_path = tmp_path / "scrape_log.csv"
    with log_path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(ns.LOG_FIELDS_V1)
        w.writerow([f"v{i}" for i in range(len(ns.LOG_FIELDS_V1))])
    ns.ensure_log(log_path)
    rows = read_log(log_path)
    assert list(rows[0]) == ns.LOG_FIELDS
    assert rows[0]["run_id"] == "v0" and rows[0]["error"] == "v15" and rows[0]["stage"] == "scrape"


def test_scrape_rows_are_tagged_with_stage(dirs):
    _, log_path = dirs
    do_run(dirs, FakeSession(FakeResponse(SAMPLE_FEED)))
    assert {r["stage"] for r in read_log(log_path)} == {"scrape"}
