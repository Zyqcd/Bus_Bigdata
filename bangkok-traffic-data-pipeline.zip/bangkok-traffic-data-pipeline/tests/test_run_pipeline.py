"""Tests for the daily pipeline runner and the snapshot loader decisions.

Scraping and PostgreSQL are always stubbed: no network and no real database.
Clean / validate / analysis run for real on tiny synthetic feeds in tmp_path."""

from __future__ import annotations

import copy
import csv
import hashlib
import io
import json
import os
import socket
import subprocess
import sys
import time
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "data" / "scraper" / "processing"))
sys.path.insert(0, str(ROOT / "database" / "load"))
import load_namtang as ld  # noqa: E402
import namtang_scraper as ns  # noqa: E402
import run_pipeline as rp  # noqa: E402
from test_build_analysis import DQ_FEED, write_policy  # noqa: E402
from test_validate_gtfs import BASE  # noqa: E402

SHA_A = "a" * 64


def make_paths(tmp_path: Path) -> rp.Paths:
    return rp.Paths(raw_root=tmp_path / "raw", clean_root=tmp_path / "clean",
                    analysis_root=tmp_path / "analysis", metadata_dir=tmp_path / "metadata",
                    log_path=tmp_path / "metadata" / "scrape_log.csv",
                    lock_path=tmp_path / "metadata" / "pipeline.lock", project_root=tmp_path)


def log_rows(paths: rp.Paths) -> list[dict]:
    if not paths.log_path.exists():
        return []
    with paths.log_path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


# --------------------------------------------------------------------------
# Stub stages (ordering, failure, lock, gate)
# --------------------------------------------------------------------------

class StubFeed:
    """Stages that only create the markers the runner checks, recording calls."""

    def __init__(self, tmp_path: Path, paths: rp.Paths, sha: str = SHA_A, day: str = "2026-10-01",
                 scrape_status: str = "success", errors: list | None = None):
        self.paths, self.sha, self.calls = paths, sha, []
        self.raw = paths.raw_root / day
        self.raw.mkdir(parents=True, exist_ok=True)
        (self.raw / "manifest.json").write_text(json.dumps({"zip_sha256": sha}))
        self.scrape_status = scrape_status
        self.errors = errors or []
        self.load_args = None

    def stages(self, **override) -> rp.Stages:
        base = dict(scrape=self.scrape, clean=self.clean, validate=self.validate,
                    analysis=self.analysis, load=self.load)
        base.update(override)
        return rp.Stages(**base)

    def scrape(self):
        self.calls.append("scrape")
        return {"status": self.scrape_status, "zip_sha256": self.sha, "feed_version": "v1",
                "raw_path": str(self.raw), "error": None}

    def clean(self, raw_dir):
        self.calls.append("clean")
        self.clean_dir = self.paths.clean_root / raw_dir.name
        self.clean_dir.mkdir(parents=True, exist_ok=True)
        (self.clean_dir / "_SUCCESS").write_text("")
        return {"status": "success", "feed_sha256": self.sha, "run_id": "clean-1"}

    def validate(self, clean_dir):
        self.calls.append("validate")
        return {"feed": {"feed_sha256": self.sha, "clean_run_id": "clean-1"},
                "overall_status": "ERROR" if self.errors else "WARNING",
                "errors": self.errors, "warnings": []}

    def analysis(self, clean_dir, policy_path):
        self.calls.append("analysis")
        out = self.paths.analysis_root / clean_dir.name
        out.mkdir(parents=True, exist_ok=True)
        (out / "_SUCCESS").write_text("")
        return {"status": "success", "source": {"feed_sha256": self.sha, "clean_run_id": "clean-1"}}

    def load(self, clean_dir, analysis_dir):
        self.calls.append("load")
        self.load_args = (clean_dir, analysis_dir)
        return {"status": "loaded"}

    def write_policy(self, issues: list | None = None, sha: str | None = None):
        self.paths.metadata_dir.mkdir(parents=True, exist_ok=True)
        (self.paths.metadata_dir / f"data_quality_policy_{self.raw.name}.json").write_text(
            json.dumps({"policy_version": "t", "feed": {"feed_sha256": sha or self.sha},
                        "approval": {"approved": True, "approved_by": "test-reviewer"},
                        "issues": issues or []}))


KNOWN_ERRORS = [
    {"section": "logical_keys", "check": "agency logical key ['agency_id']", "table": "agency",
     "count": 4, "summary": "..."},
    {"section": "foreign_keys", "check": "fare_rules.origin_id -> stops.zone_id",
     "table": "fare_rules", "count": 61, "summary": "..."},
    {"section": "foreign_keys", "check": "fare_rules.destination_id -> stops.zone_id",
     "table": "fare_rules", "count": 59, "summary": "..."},
]
KNOWN_ISSUES = [
    {"id": "DQ-001", "validation_severity": "ERROR", "affected_table": "agency", "affected_rows": 4},
    {"id": "DQ-002", "validation_severity": "ERROR", "affected_table": "fare_rules",
     "affected_rows": 120},
    {"id": "DQ-004", "validation_severity": "WARNING", "affected_table": "frequencies",
     "affected_rows": 555},
]


def test_successful_stage_order_and_explicit_load_paths(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths)
    feed.write_policy()
    result = rp.run_pipeline(paths, feed.stages())
    assert feed.calls == ["scrape", "clean", "validate", "analysis", "load"]
    assert result["status"] == "success" and rp.EXIT_CODES[result["status"]] == 0
    assert feed.load_args == (paths.clean_root / "2026-10-01", paths.analysis_root / "2026-10-01")
    stages = [r["stage"] for r in log_rows(paths)]
    assert stages == ["pipeline", "policy_gate", "pipeline"]
    assert log_rows(paths)[-1]["status"] == "success"
    assert not paths.lock_path.exists()


def test_target_feed_is_scraper_raw_path_not_newest_folder(tmp_path):
    paths = make_paths(tmp_path)
    newer = paths.raw_root / "2026-12-31"
    newer.mkdir(parents=True)
    (newer / "manifest.json").write_text(json.dumps({"zip_sha256": "b" * 64}))
    feed = StubFeed(tmp_path, paths, scrape_status="unchanged")       # points at 2026-10-01
    feed.write_policy()
    seen = []
    result = rp.run_pipeline(paths, feed.stages(
        clean=lambda raw: (seen.append(raw), feed.clean(raw))[1]))
    assert seen == [feed.raw]
    assert feed.load_args[0].name == "2026-10-01"
    assert result["status"] == "success"


def test_failure_stops_later_stages_and_is_logged(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths)
    feed.write_policy()

    def broken(raw):
        feed.calls.append("clean")
        raise RuntimeError("disk full")

    result = rp.run_pipeline(paths, feed.stages(clean=broken))
    assert feed.calls == ["scrape", "clean"]
    assert result["status"] == "failed" and result["failed_stage"] == "clean"
    assert "disk full" in result["error"] and rp.EXIT_CODES["failed"] == 1
    last = log_rows(paths)[-1]
    assert (last["stage"], last["status"]) == ("pipeline", "failed")
    assert "failed at clean" in last["error"]
    assert not paths.lock_path.exists()                     # next run can retry


def test_failed_or_partial_scrape_stops_pipeline(tmp_path):
    for status in ("failed", "partial"):
        paths = make_paths(tmp_path / status)
        feed = StubFeed(tmp_path, paths, scrape_status=status)
        result = rp.run_pipeline(paths, feed.stages())
        assert feed.calls == ["scrape"] and result["failed_stage"] == "scrape"


def test_raw_path_without_matching_manifest_fails(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths)
    (feed.raw / "manifest.json").write_text(json.dumps({"zip_sha256": "c" * 64}))
    result = rp.run_pipeline(paths, feed.stages())
    assert result["failed_stage"] == "scrape" and feed.calls == ["scrape"]


def test_missing_policy_stops_with_awaiting_policy(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths)
    result = rp.run_pipeline(paths, feed.stages())           # no policy file written
    assert result["status"] == "awaiting_policy" and rp.EXIT_CODES["awaiting_policy"] == 2
    assert feed.calls == ["scrape", "clean", "validate"]      # no analysis, no load
    assert not any(p.name.startswith("data_quality_policy") for p in paths.metadata_dir.iterdir())
    gate_row = next(r for r in log_rows(paths) if r["stage"] == "policy_gate")
    assert gate_row["status"] == "awaiting_policy" and "no reviewed DQ policy" in gate_row["error"]


def test_policy_for_other_feed_is_not_accepted(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths)
    feed.write_policy(sha="d" * 64)
    result = rp.run_pipeline(paths, feed.stages())
    assert result["status"] == "awaiting_policy"
    assert "different feed" in result["policy_gate"]["reason"]


def test_known_policy_covered_errors_continue(tmp_path):
    paths = make_paths(tmp_path)
    feed = StubFeed(tmp_path, paths, errors=KNOWN_ERRORS)
    feed.write_policy(KNOWN_ISSUES)
    result = rp.run_pipeline(paths, feed.stages())
    assert result["status"] == "success" and "load" in feed.calls
    gate = result["policy_gate"]
    assert gate["decision"] == "pass" and gate["uncovered"] == []
    assert {c["table"]: c["dq_ids"] for c in gate["covered"]} == {
        "agency": ["DQ-001"], "fare_rules": ["DQ-002"]}


def test_unexpected_validation_error_stops_pipeline(tmp_path):
    paths = make_paths(tmp_path)
    new_error = {"section": "stop_times", "check": "times do not go backwards", "table": "stop_times",
                 "count": 7, "summary": "..."}
    feed = StubFeed(tmp_path, paths, errors=[*KNOWN_ERRORS, new_error])
    feed.write_policy(KNOWN_ISSUES)
    result = rp.run_pipeline(paths, feed.stages())
    assert result["status"] == "awaiting_policy"
    assert "analysis" not in feed.calls and "load" not in feed.calls
    assert [u["table"] for u in result["policy_gate"]["uncovered"]] == ["stop_times"]


def test_changed_error_count_is_not_covered(tmp_path):
    errors = copy.deepcopy(KNOWN_ERRORS)
    errors[1]["count"] = 70                                    # 70 + 59 != 120
    gate = rp.policy_gate({"errors": errors, "warnings": []}, {"feed_sha256": SHA_A},
                          _policy_file(tmp_path, KNOWN_ISSUES))
    assert gate["decision"] == "awaiting_policy"
    assert {u["table"] for u in gate["uncovered"]} == {"fare_rules"}


def test_feed_level_error_without_table_is_not_covered(tmp_path):
    lineage_error = {"section": "lineage", "check": "feed SHA-256", "table": None, "count": None}
    gate = rp.policy_gate({"errors": [*KNOWN_ERRORS, lineage_error], "warnings": []},
                          {"feed_sha256": SHA_A}, _policy_file(tmp_path, KNOWN_ISSUES))
    assert gate["decision"] == "awaiting_policy"


def test_real_policy_covers_real_validation_report():
    """The committed DQ policy must cover the committed validation report (read-only)."""
    report_path = ROOT / "data" / "metadata" / "validation_2026-10-01.json"
    policy_path = ROOT / "data" / "metadata" / "data_quality_policy_2026-10-01.json"
    if not report_path.exists() or not policy_path.exists():
        pytest.skip("real metadata not present in this checkout")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    gate = rp.policy_gate(report, {"feed_sha256": report["feed"]["feed_sha256"]}, policy_path)
    assert gate["decision"] == "pass", gate
    assert {c["table"] for c in gate["covered"]} == {"agency", "fare_rules"}


def _policy_file(tmp_path: Path, issues: list) -> Path:
    path = tmp_path / "policy.json"
    path.write_text(json.dumps({"feed": {"feed_sha256": SHA_A},
                                "approval": {"approved": True, "approved_by": "test-reviewer"},
                                "issues": issues}))
    return path


# --------------------------------------------------------------------------
# Lock and temporary-directory cleanup
# --------------------------------------------------------------------------

def test_lock_prevents_overlapping_runs(tmp_path):
    paths = make_paths(tmp_path)
    paths.lock_path.parent.mkdir(parents=True)
    paths.lock_path.write_text(json.dumps({"run_id": "other", "pid": os.getpid(),
                                           "host": socket.gethostname()}))
    feed = StubFeed(tmp_path, paths)
    result = rp.run_pipeline(paths, feed.stages())
    assert result["status"] == "locked" and rp.EXIT_CODES["locked"] == 3
    assert feed.calls == []
    assert json.loads(paths.lock_path.read_text())["run_id"] == "other"   # not stolen


def test_stale_lock_from_dead_process_is_replaced(tmp_path):
    proc = subprocess.Popen([sys.executable, "-c", "pass"])
    proc.wait()
    paths = make_paths(tmp_path)
    paths.lock_path.parent.mkdir(parents=True)
    paths.lock_path.write_text(json.dumps({"run_id": "dead", "pid": proc.pid,
                                           "host": socket.gethostname()}))
    feed = StubFeed(tmp_path, paths)
    feed.write_policy()
    assert rp.run_pipeline(paths, feed.stages())["status"] == "success"
    assert not paths.lock_path.exists()


def test_lock_is_exclusive_while_held(tmp_path):
    first = rp.PipelineLock(tmp_path / "x.lock", "one")
    first.acquire()
    with pytest.raises(rp.PipelineLocked):
        rp.PipelineLock(tmp_path / "x.lock", "two").acquire()
    first.release()
    rp.PipelineLock(tmp_path / "x.lock", "three").acquire()


def test_stale_temp_dirs_removed_safely(tmp_path):
    paths = make_paths(tmp_path)
    old = paths.clean_root / ".tmp_2026-10-01_old"
    recent = paths.analysis_root / ".tmp_2026-10-01_recent"
    keep = paths.clean_root / "2026-10-01"
    raw_tmp = paths.raw_root / ".tmp_should_not_touch"
    for d in (old, recent, keep, raw_tmp):
        d.mkdir(parents=True)
    past = time.time() - 48 * 3600
    for d in (old, raw_tmp):
        os.utime(d, (past, past))
    removed = rp.clean_stale_temp_dirs(paths, max_age_hours=24)
    assert removed == [str(old)]
    assert recent.exists() and keep.exists() and raw_tmp.exists()


# --------------------------------------------------------------------------
# Integration: real clean / validate / analysis, stubbed scrape and database
# --------------------------------------------------------------------------

def write_raw(paths: rp.Paths, day: str, files: dict) -> dict:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data.encode("utf-8"))
    body = buf.getvalue()
    raw = paths.raw_root / day
    raw.mkdir(parents=True)
    (raw / "gtfs.zip").write_bytes(body)
    sha = hashlib.sha256(body).hexdigest()
    (raw / "manifest.json").write_text(json.dumps({
        "source": "namtang_gtfs", "zip_sha256": sha, "zip_bytes": len(body), "feed_version": "v1",
        "scrape_timestamp_bangkok": "2026-10-01T10:00:00+07:00",
        "members": ns.inspect_members(raw / "gtfs.zip")}), encoding="utf-8")
    return {"status": "success", "zip_sha256": sha, "feed_version": "v1", "raw_path": str(raw)}


def dq_files(**changes) -> dict:
    files = {**BASE, **{k.replace("__", "."): v for k, v in DQ_FEED.items()}}
    files.update({k.replace("__", "."): v for k, v in changes.items()})
    return files


def add_policy(paths: rp.Paths, day: str) -> None:
    """Reviewed policy for the synthetic DQ feed (same counts as test_build_analysis)."""
    clean = paths.clean_root / day
    policy_file = write_policy(paths.metadata_dir.parent, clean)
    policy = json.loads(policy_file.read_text(encoding="utf-8"))
    for issue in policy["issues"]:
        if issue["id"] == "DQ-001":
            issue.update(validation_severity="ERROR", affected_table="agency")
        if issue["id"] == "DQ-002":
            issue.update(validation_severity="ERROR", affected_table="fare_rules")
    policy["approval"] = {"approved": True, "approved_by": "test-reviewer"}
    (paths.metadata_dir / f"data_quality_policy_{day}.json").write_text(json.dumps(policy))


class FakeDatabase:
    """Latest-snapshot semantics of load_namtang.load_feed, without PostgreSQL."""

    def __init__(self):
        self.feed_sha256, self.writes, self.calls = None, 0, []

    def load(self, clean_dir, analysis_dir):
        self.calls.append((clean_dir, analysis_dir))
        sha = json.loads((clean_dir / "metadata.json").read_text(encoding="utf-8"))["feed_sha256"]
        if sha == self.feed_sha256:
            return {"status": "unchanged"}
        self.feed_sha256, self.writes = sha, self.writes + 1
        return {"status": "loaded"}


def real_stages(paths: rp.Paths, scrape, db: FakeDatabase) -> rp.Stages:
    stages = rp.default_stages(paths, None, "test")
    stages.scrape, stages.load = scrape, db.load
    return stages


def snapshot(*roots: Path) -> dict:
    return {p: (p.stat().st_mtime_ns, hashlib.sha256(p.read_bytes()).hexdigest())
            for root in roots if root.exists() for p in sorted(root.rglob("*")) if p.is_file()}


def test_known_errors_continue_and_unchanged_feed_writes_nothing(tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)
    first_scrape = write_raw(paths, "2026-10-01", dq_files())
    db = FakeDatabase()

    # First run: new feed -> clean, validate, gate awaits the (not yet written) policy.
    r1 = rp.run_pipeline(paths, real_stages(paths, lambda: first_scrape, db))
    assert r1["status"] == "awaiting_policy" and db.calls == []
    assert "no reviewed DQ policy" in r1["policy_gate"]["reason"]
    assert {f["table"] for f in r1["policy_gate"]["error_findings"]} == {"agency", "fare_rules"}

    # A reviewer writes the policy; the next run continues from the existing outputs.
    add_policy(paths, "2026-10-01")
    r2 = rp.run_pipeline(paths, real_stages(paths, lambda: {**first_scrape,
                                                            "status": "unchanged"}, db))
    assert r2["status"] == "success", r2
    assert r2["stages"]["validate"]["status"] == "reused"
    assert r2["policy_gate"]["decision"] == "pass"
    assert r2["created"] == {"raw": False, "clean": False, "analysis": True,
                             "database_snapshot": True}
    assert db.writes == 1

    # Third run, feed unchanged: nothing new anywhere, no database write.
    before = snapshot(paths.raw_root, paths.clean_root, paths.analysis_root)
    reports = {p: p.read_bytes() for p in paths.metadata_dir.glob("validation_*")}
    r3 = rp.run_pipeline(paths, real_stages(paths, lambda: {**first_scrape,
                                                            "status": "unchanged"}, db))
    assert r3["status"] == "unchanged" and rp.EXIT_CODES["unchanged"] == 0
    assert snapshot(paths.raw_root, paths.clean_root, paths.analysis_root) == before
    assert {p: p.read_bytes() for p in paths.metadata_dir.glob("validation_*")} == reports
    assert db.writes == 1 and db.calls[-1][0] == paths.clean_root / "2026-10-01"
    assert [d.name for d in paths.clean_root.iterdir()] == ["2026-10-01"]
    assert log_rows(paths)[-1]["status"] == "unchanged"


def test_new_feed_replaces_snapshot_and_keeps_old_outputs(tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)
    db = FakeDatabase()
    feed_a = write_raw(paths, "2026-10-01", dq_files())
    rp.run_pipeline(paths, real_stages(paths, lambda: feed_a, db))
    add_policy(paths, "2026-10-01")
    assert rp.run_pipeline(paths, real_stages(
        paths, lambda: {**feed_a, "status": "unchanged"}, db))["status"] == "success"
    old = snapshot(paths.raw_root / "2026-10-01", paths.clean_root / "2026-10-01",
                   paths.analysis_root / "2026-10-01")

    agency_b = DQ_FEED["agency__txt"].replace("https://a2", "https://a2-new")
    feed_b = write_raw(paths, "2026-10-02", dq_files(agency__txt=agency_b))
    assert feed_b["zip_sha256"] != feed_a["zip_sha256"]
    r = rp.run_pipeline(paths, real_stages(paths, lambda: feed_b, db))
    assert r["status"] == "awaiting_policy" and db.feed_sha256 == feed_a["zip_sha256"]

    add_policy(paths, "2026-10-02")
    r = rp.run_pipeline(paths, real_stages(paths, lambda: {**feed_b, "status": "unchanged"}, db))
    assert r["status"] == "success" and db.feed_sha256 == feed_b["zip_sha256"]
    assert db.calls[-1] == (paths.clean_root / "2026-10-02", paths.analysis_root / "2026-10-02")
    assert snapshot(paths.raw_root / "2026-10-01", paths.clean_root / "2026-10-01",
                    paths.analysis_root / "2026-10-01") == old


# --------------------------------------------------------------------------
# Loader decisions (fake connection; never touches a real database)
# --------------------------------------------------------------------------

class FakeConnection:
    def __init__(self):
        self.exit_exc = "not closed"

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.exit_exc = exc_type                      # psycopg: exception -> rollback
        return False

    def cursor(self):
        return self

    def execute(self, *a, **k):
        raise AssertionError("SQL must not run in this test")


@pytest.fixture
def feed_dirs(tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)
    scrape = write_raw(paths, "2026-10-01", dq_files())
    db = FakeDatabase()
    rp.run_pipeline(paths, real_stages(paths, lambda: scrape, db))
    add_policy(paths, "2026-10-01")
    rp.run_pipeline(paths, real_stages(paths, lambda: {**scrape, "status": "unchanged"}, db))
    return paths.clean_root / "2026-10-01", paths.analysis_root / "2026-10-01", scrape["zip_sha256"]


def _state(inputs: ld.FeedInputs, sha: str | None, rows_delta: int = 0) -> dict:
    return {(s, t): {"rows": inputs.expected[(s, t)] + rows_delta, "min_sha": sha, "max_sha": sha}
            for s, t, _ in inputs.selected}


def test_loader_requires_success_marker_and_matching_analysis(feed_dirs, tmp_path):
    clean, analysis, _ = feed_dirs
    (clean / "_SUCCESS").rename(clean / "_SUCCESS.bak")
    with pytest.raises(ld.LoadError, match="_SUCCESS"):
        ld.FeedInputs(clean, analysis, False)
    (clean / "_SUCCESS.bak").rename(clean / "_SUCCESS")
    meta = json.loads((analysis / "metadata.json").read_text(encoding="utf-8"))
    meta["source"]["clean_run_id"] = "another-run"
    (analysis / "metadata.json").write_text(json.dumps(meta), encoding="utf-8")
    with pytest.raises(ld.LoadError, match="different clean run"):
        ld.FeedInputs(clean, analysis, False)


def test_loader_requires_explicit_feed_directory():
    with pytest.raises(SystemExit):
        ld.parse_args(["--dsn", "postgresql://x"])               # no --clean-dir
    with pytest.raises(SystemExit):
        ld.parse_args(["--dsn", "postgresql://x", "--clean-dir", "c"])   # no --analysis-dir
    assert "2026-10-01" not in (ROOT / "database" / "load" / "load_namtang.py").read_text(
        encoding="utf-8")


def test_loader_unchanged_feed_writes_nothing(feed_dirs, tmp_path, monkeypatch):
    clean, analysis, sha = feed_dirs
    inputs = ld.FeedInputs(clean, analysis, False)
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, sha))
    replaced = []
    monkeypatch.setattr(ld, "replace_snapshot", lambda *a, **k: replaced.append(a))
    conn = FakeConnection()
    result = ld.load_feed("dsn", clean, analysis, log_path=tmp_path / "log.csv",
                          connect=lambda dsn: conn)
    assert result["status"] == "unchanged" and replaced == []     # no duplicate records
    assert conn.exit_exc is None


def test_loader_new_feed_replaces_snapshot(feed_dirs, tmp_path, monkeypatch):
    clean, analysis, sha = feed_dirs
    inputs = ld.FeedInputs(clean, analysis, False)
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, "f" * 64))
    monkeypatch.setattr(ld, "require_history_table", lambda cur: None)
    calls = []
    monkeypatch.setattr(ld, "replace_snapshot",
                        lambda cur, i, run_id, previous, bs: calls.append(previous) or {"x": 1})
    result = ld.load_feed("dsn", clean, analysis, log_path=tmp_path / "log.csv",
                          connect=lambda dsn: FakeConnection())
    assert result["status"] == "loaded" and calls == ["f" * 64]


def test_loader_partial_or_forced_reload_replaces(feed_dirs, tmp_path, monkeypatch):
    clean, analysis, sha = feed_dirs
    inputs = ld.FeedInputs(clean, analysis, False)
    monkeypatch.setattr(ld, "require_history_table", lambda cur: None)
    calls = []
    monkeypatch.setattr(ld, "replace_snapshot", lambda *a: calls.append(1) or {})
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, sha, rows_delta=-1))
    ld.load_feed("dsn", clean, analysis, log_path=None, connect=lambda d: FakeConnection())
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, sha))
    ld.load_feed("dsn", clean, analysis, force=True, log_path=None,
                 connect=lambda d: FakeConnection())
    assert calls == [1, 1]


def test_loader_failure_rolls_back_and_raises(feed_dirs, tmp_path, monkeypatch):
    clean, analysis, sha = feed_dirs
    inputs = ld.FeedInputs(clean, analysis, False)
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, None, rows_delta=-10**9))
    monkeypatch.setattr(ld, "require_history_table", lambda cur: None)

    def boom(*a):
        raise ld.LoadError("row-count mismatch for namtang.stops")

    monkeypatch.setattr(ld, "replace_snapshot", boom)
    conn = FakeConnection()
    with pytest.raises(ld.LoadError, match="row-count mismatch"):
        ld.load_feed("dsn", clean, analysis, log_path=tmp_path / "log.csv",
                     connect=lambda dsn: conn)
    assert conn.exit_exc is ld.LoadError                  # transaction left with an exception
    with (tmp_path / "log.csv").open(newline="", encoding="utf-8") as fh:
        row = list(csv.DictReader(fh))[-1]
    assert (row["stage"], row["status"]) == ("load", "failed")


def test_loader_dry_run_never_writes(feed_dirs, tmp_path, monkeypatch):
    clean, analysis, _ = feed_dirs
    inputs = ld.FeedInputs(clean, analysis, False)
    monkeypatch.setattr(ld, "snapshot_state", lambda cur, i: _state(inputs, "f" * 64))
    monkeypatch.setattr(ld, "replace_snapshot", lambda *a: pytest.fail("dry run wrote"))
    result = ld.load_feed("dsn", clean, analysis, dry_run=True, log_path=None,
                          connect=lambda dsn: FakeConnection())
    assert result["status"] == "would_load"


# --------------------------------------------------------------------------
# Step contract used by the Airflow DAG (one step per task, context via XCom)
# --------------------------------------------------------------------------

def _flat_json(value) -> bool:
    if isinstance(value, dict):
        return all(isinstance(k, str) and _flat_json(v) for k, v in value.items())
    return value is None or isinstance(value, (str, int, float, bool))


def test_step_contexts_are_small_json_and_match_the_runner(tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)
    scrape = write_raw(paths, "2026-10-01", dq_files())
    db = FakeDatabase()
    rp.run_pipeline(paths, real_stages(paths, lambda: scrape, db))     # stops at the gate
    add_policy(paths, "2026-10-01")

    stages = real_stages(paths, lambda: {**scrape, "status": "unchanged"}, db)
    contexts = [rp.step_scrape(paths, stages, "airflow-test")]
    contexts.append(rp.step_clean(paths, stages, contexts[-1]))
    contexts.append(rp.step_validate(paths, stages, contexts[-1])[0])
    contexts.append(rp.step_policy_gate(paths, contexts[-1])[0])        # report read from disk
    contexts.append(rp.step_analysis(paths, stages, contexts[-1]))
    contexts.append(rp.step_load(paths, stages, contexts[-1]))
    for ctx in contexts:
        encoded = json.dumps(ctx)
        assert _flat_json(ctx) and len(encoded) < 4096                # XCom-sized, no rows
    final = contexts[-1]
    assert final["stage_status"] == {"scrape": "unchanged", "clean": "success",
                                     "validate": "reused", "policy_gate": "pass",
                                     "analysis": "success", "load": "loaded"}
    assert final["clean_dir"] == str(paths.clean_root / "2026-10-01")
    assert db.calls[-1] == (paths.clean_root / "2026-10-01", paths.analysis_root / "2026-10-01")


def test_steps_refuse_to_skip_the_gate(tmp_path):
    paths = make_paths(tmp_path)
    ctx = {"run_id": "x", "feed_sha256": SHA_A, "clean_dir": str(tmp_path / "c"),
           "clean_run_id": "c1", "policy_decision": "awaiting_policy", "stage_status": {},
           "created": {}}
    with pytest.raises(rp.StageFailure, match="policy gate has not passed"):
        rp.step_analysis(paths, rp.Stages(scrape=None, clean=None, validate=None,
                                          analysis=lambda *a: pytest.fail("ran")), ctx)
    with pytest.raises(rp.StageFailure, match="analysis step has not completed"):
        rp.step_load(paths, rp.Stages(None, None, None, None, load=lambda *a: pytest.fail("ran")),
                     ctx)
