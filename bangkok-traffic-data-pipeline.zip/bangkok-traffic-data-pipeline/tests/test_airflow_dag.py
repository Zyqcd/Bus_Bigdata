"""Tests for the Airflow DAG. They need Airflow, so they run inside the Airflow
image (airflow/run_dag_tests.sh) and are skipped in an environment without it.

The end-to-end tests execute the real DAG with ``dag.test()`` against tiny
synthetic feeds in tmp_path; scraping and PostgreSQL are stubbed."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pytest

# "airflow" alone would match the repo's own airflow/ folder (namespace package).
pytest.importorskip("airflow.sdk")

ROOT = Path(__file__).resolve().parents[1]
DAG_FILE = ROOT / "airflow" / "dags" / "namtang_gtfs_pipeline.py"
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "data" / "scraper" / "processing"))

import run_pipeline as rp  # noqa: E402
from test_run_pipeline import FakeDatabase, add_policy, dq_files, make_paths, write_raw  # noqa: E402

EXPECTED_TASKS = ["scrape", "clean", "validate", "dq_policy_gate", "analysis", "load_postgresql"]


def data_snapshot() -> dict:
    roots = [ROOT / "data" / d for d in ("raw", "clean", "analysis", "metadata")]
    return {p: p.stat().st_mtime_ns for r in roots if r.exists() for p in r.rglob("*")
            if p.is_file()}


@pytest.fixture(scope="module")
def dagbag():
    try:
        from airflow.dag_processing.dagbag import DagBag
    except ImportError:  # older Airflow
        from airflow.models.dagbag import DagBag

    before = data_snapshot()
    bag = DagBag(dag_folder=str(DAG_FILE.parent))  # examples disabled via AIRFLOW__CORE__LOAD_EXAMPLES
    bag.after_snapshot = data_snapshot()
    bag.before_snapshot = before
    return bag


@pytest.fixture
def dag_module():
    spec = importlib.util.spec_from_file_location("namtang_gtfs_pipeline_under_test", DAG_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_dag_imports_without_errors(dagbag):
    assert dagbag.import_errors == {}
    assert "namtang_gtfs_pipeline" in dagbag.dags


def test_dag_has_exactly_the_pipeline_tasks_in_order(dagbag):
    dag = dagbag.dags["namtang_gtfs_pipeline"]
    assert sorted(dag.task_ids) == sorted(EXPECTED_TASKS)
    for upstream, downstream in zip(EXPECTED_TASKS, EXPECTED_TASKS[1:]):
        assert dag.get_task(upstream).downstream_task_ids == {downstream}
        assert dag.get_task(downstream).upstream_task_ids == {upstream}
    assert dag.get_task("scrape").upstream_task_ids == set()
    assert dag.get_task("load_postgresql").downstream_task_ids == set()


def test_dag_is_manual_and_safe_by_default(dagbag):
    dag = dagbag.dags["namtang_gtfs_pipeline"]
    assert dag.schedule is None or str(dag.timetable.summary) in ("None", "")
    assert dag.catchup is False and dag.max_active_runs == 1
    assert dag.get_task("dq_policy_gate").retries == 0


def test_every_task_pushes_a_single_return_value(dagbag):
    dag = dagbag.dags["namtang_gtfs_pipeline"]
    for task_id in EXPECTED_TASKS:
        assert dag.get_task(task_id).multiple_outputs is False, task_id


def test_dag_import_does_not_touch_data(dagbag):
    assert dagbag.before_snapshot == dagbag.after_snapshot
    assert not (ROOT / "data" / "metadata" / "namtang_pipeline.lock").exists()


def _configure(module, monkeypatch, paths, scrape, db):
    # Tests must not wait for production retry delays (scrape: 2 x 10 min).
    for t in module.namtang_dag.tasks:
        monkeypatch.setattr(t, "retries", 0)
    monkeypatch.setattr(module, "pipeline_paths", lambda: paths)

    def stages(p, run_id, dsn=None):
        s = rp.default_stages(p, None, run_id)
        s.scrape = scrape
        s.load = db.load if dsn else None
        return s

    monkeypatch.setattr(module, "pipeline_stages", stages)
    monkeypatch.setattr(module, "namtang_dsn", lambda: "stub-dsn")


def _states(dag_run) -> dict:
    return {ti.task_id: str(ti.state) for ti in dag_run.get_task_instances()}


def _xcom_rows(dag_run) -> list[tuple[str, str]]:
    """(task_id, key) of every XCom row stored for this DAG run."""
    from airflow.models.xcom import XComModel
    from airflow.utils.session import create_session

    with create_session() as session:
        rows = session.query(XComModel.task_id, XComModel.key).filter(
            XComModel.dag_id == dag_run.dag_id, XComModel.run_id == dag_run.run_id).all()
    return sorted((r[0], r[1]) for r in rows)


def _xcom(dag_run, task_id: str):
    ti = next(t for t in dag_run.get_task_instances() if t.task_id == task_id)
    return ti.xcom_pull(task_ids=task_id)


def test_dag_end_to_end_known_errors_pass_and_unchanged_feed(dag_module, monkeypatch, tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)
    scrape = write_raw(paths, "2026-10-01", dq_files())
    db = FakeDatabase()
    _configure(dag_module, monkeypatch, paths, lambda: scrape, db)

    # No reviewed policy yet: the gate fails as awaiting_policy, analysis/load never run.
    run = dag_module.namtang_dag.test()
    states = _states(run)
    assert str(run.state) == "failed"
    assert states["scrape"] == states["clean"] == states["validate"] == "success"
    assert states["dq_policy_gate"] == "failed"
    assert states["analysis"] == states["load_postgresql"] == "upstream_failed"
    assert db.calls == []

    # Policy written by a reviewer: known DQ-001/DQ-002 errors are covered, load runs.
    add_policy(paths, "2026-10-01")
    _configure(dag_module, monkeypatch, paths, lambda: {**scrape, "status": "unchanged"}, db)
    run = dag_module.namtang_dag.test()
    assert str(run.state) == "success", _states(run)
    assert db.calls == [(paths.clean_root / "2026-10-01", paths.analysis_root / "2026-10-01")]
    final = _xcom(run, "load_postgresql")
    assert final["stage_status"]["load"] == "loaded"
    assert final["feed_sha256"] == scrape["zip_sha256"]

    # Exactly one XCom per task (return_value) - no multiple_outputs key explosion.
    assert _xcom_rows(run) == sorted((t, "return_value") for t in EXPECTED_TASKS)

    # Every XCom is a small JSON context, never data rows.
    for task_id in EXPECTED_TASKS:
        value = _xcom(run, task_id)
        encoded = json.dumps(value)
        assert isinstance(value, dict) and len(encoded) < 4096, (task_id, len(encoded))

    # Unchanged feed again: database untouched, status logged as unchanged.
    run = dag_module.namtang_dag.test()
    assert str(run.state) == "success"
    assert db.writes == 1 and _xcom(run, "load_postgresql")["stage_status"]["load"] == "unchanged"


def test_dag_failure_stops_downstream(dag_module, monkeypatch, tmp_path):
    paths = make_paths(tmp_path)
    paths.metadata_dir.mkdir(parents=True)

    def broken_scrape():
        raise RuntimeError("network down")

    _configure(dag_module, monkeypatch, paths, broken_scrape, FakeDatabase())
    run = dag_module.namtang_dag.test()
    states = _states(run)
    assert str(run.state) == "failed" and states["scrape"] == "failed"
    assert all(states[t] == "upstream_failed" for t in EXPECTED_TASKS[1:])
