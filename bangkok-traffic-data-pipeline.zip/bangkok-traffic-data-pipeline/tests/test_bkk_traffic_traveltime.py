"""Phase 9.6: travel-time port (data/scraper/bkk_traffic/traveltime.py).

* No network: RouteService is replaced by fake clients / fake HTTP sessions (TEST-ONLY bodies
  shaped like the legacy parser expects). No real API key is used: tests build an obviously
  fake marker string at runtime and assert it never reaches logs or the database.
* Database tests use ONLY the isolated namtang_bkk_traffic_test_db through the guarded
  fixtures of test_bkk_traffic_pipeline (pipeline code runs as a bkk_traffic_app member).
"""

from __future__ import annotations

import importlib.util
import json
import logging
import math
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))

from bkk_traffic import config, storage, traveltime  # noqa: E402

from test_bkk_traffic_pipeline import dsns, env, q  # noqa: E402,F401  (fixtures)

FAKE_KEY = "test-only-" + "not-a-real-longdo-key-" + "7f3a"      # built at runtime, never a real credential
FETCHED = "2026-10-03 04:00:00"
NO_SLEEP = lambda seconds: None                                     # noqa: E731


def body(distance=5000, interval=900, **extra):
    return {"meta": {"code": 0}, "data": [{"distance": distance, "interval": interval,
                                           "guide": [{"turn": i} for i in range(3)], **extra}]}


class FakeRouteClient:
    """Answers per origin latitude; values: dict body | Exception instance."""

    def __init__(self, answers=None, default=None):
        self.answers = answers or {}
        self.default = default if default is not None else body()
        self.request_count = 0

    def route(self, flat, flon, tlat, tlon):
        self.request_count += 1
        answer = self.answers.get(flat, self.default)
        if isinstance(answer, Exception):
            raise answer
        return answer


# --------------------------------------------------------------------------
# Parsing and mapping (no database)
# --------------------------------------------------------------------------

@pytest.mark.parametrize("payload, expected", [
    (body(5000, 900), (5000.0, 900.0)),
    ({"distance": 1200, "interval": 300}, (1200.0, 300.0)),                         # object without list
    ({"data": [{"distance": 1200, "time": 301}]}, (1200.0, 301.0)),                 # 'time' fallback
    ({"data": [{"distance": 1200, "duration": "302"}]}, (1200.0, 302.0)),           # 'duration' fallback, numeric text
])
def test_valid_responses(payload, expected):
    assert traveltime.parse_route(payload) == expected


@pytest.mark.parametrize("payload, expected", [
    ({}, "distance missing"),
    ({"data": []}, "empty"),
    ([], "not a JSON object"),
    ({"data": "oops"}, "not an object"),
    ({"data": [{"interval": 300}]}, "distance missing"),
    ({"data": [{"distance": 1000}]}, "duration missing"),
    ({"data": [{"distance": "far", "interval": 300}]}, "not a number"),
    ({"data": [{"distance": float("nan"), "interval": 300}]}, "outside"),
    ({"data": [{"distance": 1000, "interval": -5}]}, "outside"),
    ({"data": [{"distance": 0, "interval": 300}]}, "outside"),
    ({"data": [{"distance": 1000, "interval": 90_000}]}, "outside"),
    ({"data": [{"distance": True, "interval": 300}]}, "not a number"),
], ids=["empty_object", "empty_list", "not_object", "data_string", "no_distance", "no_duration", "text",
        "nan", "negative", "zero", "too_long", "bool"])
def test_invalid_responses_are_rejected(payload, expected):
    with pytest.raises(traveltime.InvalidResponse, match=expected):
        traveltime.parse_route(payload)


def test_compact_raw_drops_the_guide_only():
    raw = json.loads(traveltime.compact_raw(body(5000, 900, name="x")))
    assert raw == {"meta": {"code": 0}, "data": [{"distance": 5000, "interval": 900, "name": "x"}]}


@pytest.mark.parametrize("pairs, expected", [
    ([], "no OD pairs"),
    ([("", 13.7, 100.5, 13.8, 100.6)], "name missing"),
    ([("a", 13.7, 100.5, 13.8, 100.6), ("a", 13.7, 100.5, 13.8, 100.6)], "duplicated"),
    ([("a", 95, 100.5, 13.8, 100.6)], "geographic range"),
    ([("a", "x", 100.5, 13.8, 100.6)], "non-numeric"),
    ([("a", 13.7, 100.5)], "must be"),
])
def test_od_pair_validation(pairs, expected):
    with pytest.raises(ValueError, match=expected):
        traveltime.validate_pairs(pairs)


def test_default_routes_are_the_legacy_routes():
    assert [p[0] for p in traveltime.DEFAULT_OD_PAIRS] == [
        "อนุสาวรีย์ชัยฯ -> สยาม", "สีลม -> อโศก", "ห้าแยกลาดพร้าว -> อนุสาวรีย์ชัยฯ", "บางนา -> พระราม 9",
        "ดอนเมือง -> หมอชิต", "สาทร -> วงเวียนใหญ่", "มีนบุรี -> รามคำแหง", "บางแค -> ปิ่นเกล้า"]


def test_code_is_postgresql_only_and_key_free():
    text = (ROOT / "data" / "scraper" / "bkk_traffic" / "traveltime.py").read_text(encoding="utf-8").split('"""', 2)[-1]
    code = "\n".join(line.split("#", 1)[0] for line in text.splitlines())        # comments may name what is avoided
    assert "sqlite3" not in code and "INSERT OR REPLACE" not in code and "str(exc)" not in code
    assert "ON CONFLICT (route, fetched_at) DO UPDATE" in code and "round((%s::float8 / 60)::numeric, 2)" in code


# --------------------------------------------------------------------------
# HTTP layer with a fake session (no network)
# --------------------------------------------------------------------------

class FakeResponse:
    def __init__(self, status=200, payload=None, text=None):
        self.status_code = status
        self._payload = payload
        self.text = text if text is not None else json.dumps(payload)

    def json(self):
        if self._payload is None:
            raise ValueError("not json")
        return self._payload


class FakeSession:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.headers = {}
        self.calls = []

    def get(self, url, params=None, timeout=None):
        self.calls.append((url, dict(params)))
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


def client(*responses):
    sleeps = []
    c = traveltime.RouteClient(FAKE_KEY, session=FakeSession(*responses), sleep=sleeps.append)
    return c, sleeps


def test_request_parameters_are_the_legacy_ones():
    c, _ = client(FakeResponse(payload=body()))
    assert c.route(13.765, 100.5383, 13.7457, 100.5348) == body()
    url, params = c.session.calls[0]
    assert url == "https://api.longdo.com/RouteService/json/route/guide"
    assert params == {"flat": 13.765, "flon": 100.5383, "tlat": 13.7457, "tlon": 100.5348, "mode": "t", "type": 25,
                      "locale": "th", "key": FAKE_KEY}


def test_transient_failures_are_retried_once():
    leaky = requests.Timeout(f"read timed out for url ...?key={FAKE_KEY}")
    c, sleeps = client(leaky, FakeResponse(payload=body()))
    assert c.route(1, 2, 3, 4) == body() and c.request_count == 2 and sleeps == [traveltime.RETRY_DELAY_SEC]
    c, _ = client(FakeResponse(429, text="slow down"), FakeResponse(503, text="busy"))
    with pytest.raises(traveltime.TransientRouteError, match="HTTP 503 after 2 attempts") as info:
        c.route(1, 2, 3, 4)
    assert FAKE_KEY not in str(info.value)
    c, _ = client(requests.ConnectionError(f"https://api.longdo.com/...&key={FAKE_KEY}"),
                  requests.ConnectionError(f"https://api.longdo.com/...&key={FAKE_KEY}"))
    with pytest.raises(traveltime.TransientRouteError) as info:
        c.route(1, 2, 3, 4)
    assert FAKE_KEY not in str(info.value) and "ConnectionError" in str(info.value)


def test_api_errors_and_non_json_are_invalid_not_retried():
    c, _ = client(FakeResponse(200, text=f"throw 'Route Service API Key Error {FAKE_KEY}'"))
    with pytest.raises(traveltime.InvalidResponse) as info:
        c.route(1, 2, 3, 4)
    assert "API Key Error" in str(info.value) and FAKE_KEY not in str(info.value) and c.request_count == 1
    c, _ = client(FakeResponse(200, payload=None, text="<html>"))
    with pytest.raises(traveltime.InvalidResponse, match="not JSON"):
        c.route(1, 2, 3, 4)
    c, _ = client(FakeResponse(404, text="nope"))
    with pytest.raises(traveltime.TransientRouteError, match="HTTP 404"):
        c.route(1, 2, 3, 4)


# --------------------------------------------------------------------------
# Database (isolated test DB)
# --------------------------------------------------------------------------

def rows(dsn):
    return q(dsn, "SELECT route, fetched_at::text, distance_m, duration_s, duration_min, from_lat, raw_json::text, "
                  "baseline_load_id, xmin::text FROM bkk_traffic.travel_times ORDER BY route, fetched_at")


def runs(dsn):
    return q(dsn, "SELECT status, requests, items, new_items, note FROM bkk_traffic.scrape_runs "
                  "WHERE job = 'travel_times' ORDER BY id")


def test_insert_maps_every_column(env):
    fake = FakeRouteClient(answers={13.7650: body(2817, 1777)})
    result = traveltime.collect(FAKE_KEY, client=fake, fetched_at=FETCHED, sleep=NO_SLEEP)
    assert (result["status"], result["received"], result["inserted"], result["updated"], result["unchanged"]) == \
        ("success", 8, 8, 0, 0)
    got = {r[0]: r for r in rows(env["admin"])}
    first = got["อนุสาวรีย์ชัยฯ -> สยาม"]
    assert first[1:6] == (FETCHED, 2817.0, 1777.0, 29.62, 13.765)                # round(1777/60, 2)
    assert json.loads(first[6]) == {"meta": {"code": 0}, "data": [{"distance": 2817, "interval": 1777}]}
    assert first[7] is None
    assert len(got) == 8 and runs(env["admin"])[0][:4] == ("success", 8, 8, 8)
    usage = q(env["admin"], "SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'traveltime_usage'")[0][0]
    assert usage["day_calls"] == 8 and usage["month_calls"] == 8


def test_duration_minutes_use_numeric_rounding(env):
    # 4.5 s / 60 = 0.075: binary float round() gives 0.07, numeric rounding gives 0.08.
    # (For whole seconds both agree for every value 1..86,400, as all 839 legacy rows do.)
    assert round(4.5 / 60, 2) == 0.07
    traveltime.collect(FAKE_KEY, pairs=[("r", 13.7, 100.5, 13.8, 100.6)],
                       client=FakeRouteClient(default=body(1000, 4.5)), fetched_at=FETCHED, sleep=NO_SLEEP)
    assert q(env["admin"], "SELECT duration_min FROM bkk_traffic.travel_times")[0][0] == 0.08


def test_fetched_at_is_bangkok_wall_clock(env):
    traveltime.collect(FAKE_KEY, pairs=[("r", 13.7, 100.5, 13.8, 100.6)], client=FakeRouteClient(), sleep=NO_SLEEP)
    stored = q(env["admin"], "SELECT fetched_at FROM bkk_traffic.travel_times")[0][0]
    utc_plus_7 = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
    assert abs((stored - utc_plus_7).total_seconds()) < 10                         # never the container's UTC


@pytest.mark.parametrize("bad", ["03/10/2026 04:00", "2026-10-03T04:00:00", "2026-13-45 99:00:00", "2026-10-03"])
def test_invalid_fetched_at_is_rejected_before_any_request(env, bad):
    fake = FakeRouteClient()
    with pytest.raises(traveltime.TravelTimeError, match="is not 'YYYY-MM-DD HH:MM:SS'"):
        traveltime.collect(FAKE_KEY, client=fake, fetched_at=bad, sleep=NO_SLEEP)
    assert fake.request_count == 0 and rows(env["admin"]) == []


def test_same_observation_twice_is_idempotent(env):
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    before = rows(env["admin"])
    again = traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    assert (again["inserted"], again["updated"], again["unchanged"]) == (0, 0, 8)
    assert rows(env["admin"]) == before                                            # no rewritten tuples (xmin)
    assert q(env["admin"], "SELECT count(*) - count(DISTINCT (route, fetched_at)) FROM bkk_traffic.travel_times")[0][0] == 0


def test_changed_value_for_the_same_key_is_updated(env):
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    changed = traveltime.collect(FAKE_KEY, client=FakeRouteClient(answers={13.7290: body(4700, 1200)}),
                                 fetched_at=FETCHED, sleep=NO_SLEEP)
    assert (changed["inserted"], changed["updated"], changed["unchanged"]) == (0, 1, 7)
    assert q(env["admin"], "SELECT distance_m, duration_min FROM bkk_traffic.travel_times WHERE route = 'สีลม -> อโศก'") \
        == [(4700.0, 20.0)]


def test_a_new_poll_appends_and_keeps_existing_rows(env):
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at="2026-10-03 04:15:00", sleep=NO_SLEEP)
    assert q(env["admin"], "SELECT fetched_at::text, count(*) FROM bkk_traffic.travel_times GROUP BY 1 ORDER BY 1") == [
        (FETCHED, 8), ("2026-10-03 04:15:00", 8)]


def test_invalid_payload_fails_the_whole_poll(env):
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    before = rows(env["admin"])
    bad = FakeRouteClient(answers={13.7290: {"data": [{"distance": "?", "interval": 300}]}})
    with pytest.raises(traveltime.InvalidResponse):
        traveltime.collect(FAKE_KEY, client=bad, fetched_at="2026-10-03 04:15:00", sleep=NO_SLEEP)
    assert rows(env["admin"]) == before                                            # nothing from the bad poll
    assert runs(env["admin"])[-1][0] == "failed"


def test_constraint_failure_rolls_back_every_row(env, monkeypatch):
    import psycopg

    monkeypatch.setattr(traveltime, "validate_pairs", lambda pairs: list(pairs))   # let a bad pair reach the DB
    pairs = [("ok", 13.7, 100.5, 13.8, 100.6), ("bad", 95.0, 100.5, 13.8, 100.6)]
    with pytest.raises(psycopg.errors.CheckViolation):
        traveltime.collect(FAKE_KEY, pairs=pairs, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    assert rows(env["admin"]) == []                                                # 'ok' was rolled back too


def test_zero_observations_fail_and_write_nothing(env):
    down = FakeRouteClient(default=traveltime.TransientRouteError("ConnectionError after 2 attempts"))
    with pytest.raises(traveltime.TravelTimeError, match="no route returned"):
        traveltime.collect(FAKE_KEY, client=down, fetched_at=FETCHED, sleep=NO_SLEEP)
    assert rows(env["admin"]) == []
    assert runs(env["admin"])[0][:3] == ("failed", 8, 0)


def test_transport_failure_leaves_a_real_gap(env):
    one_down = FakeRouteClient(answers={13.9126: traveltime.TransientRouteError("HTTP 503 after 2 attempts")})
    result = traveltime.collect(FAKE_KEY, client=one_down, fetched_at=FETCHED, sleep=NO_SLEEP)
    assert result["received"] == 7 and result["failed_routes"] == ["ดอนเมือง -> หมอชิต: HTTP 503 after 2 attempts"]
    assert q(env["admin"], "SELECT count(*) FROM bkk_traffic.travel_times WHERE route = 'ดอนเมือง -> หมอชิต'")[0][0] == 0
    assert "ดอนเมือง -> หมอชิต" in runs(env["admin"])[0][4]


def test_existing_baseline_rows_are_preserved(env):
    q(env["admin"], "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('t', 'parquet:t', 'success')")
    q(env["admin"], "INSERT INTO bkk_traffic.travel_times (route, fetched_at, distance_m, duration_s, duration_min, "
                    "from_lat, from_lon, to_lat, to_lon, baseline_load_id) VALUES "
                    "('สีลม -> อโศก', '2026-10-02 19:00:02', 4604, 569, 9.48, 13.729, 100.534, 13.737, 100.5603, 1)")
    before = rows(env["admin"])
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    assert [r for r in rows(env["admin"]) if r[7] == 1] == before                  # untouched, same xmin
    assert q(env["admin"], "SELECT count(*) FROM bkk_traffic.travel_times")[0][0] == 9


def test_quota_guard_skips_without_requests(env):
    with storage.connect() as conn:
        storage.set_checkpoint(conn, "traveltime_usage", {"day": storage.now_str()[:10], "day_calls": 4_495,
                                                          "month": storage.now_str()[:7], "month_calls": 4_495})
    fake = FakeRouteClient()
    assert traveltime.collect(FAKE_KEY, client=fake, sleep=NO_SLEEP)["status"] == "skipped_quota"
    assert fake.request_count == 0 and rows(env["admin"]) == [] and runs(env["admin"])[0][0] == "skipped"


def test_missing_api_key_fails_safely(env, monkeypatch):
    def no_client(*a, **k):
        raise AssertionError("no client may be created without a key")

    monkeypatch.setattr(traveltime, "RouteClient", no_client)
    for key in (None, ""):
        assert traveltime.collect(key)["status"] == "skipped_no_api_key"
    assert rows(env["admin"]) == []
    assert runs(env["admin"]) == [("skipped", 0, 0, 0, "no longdo_api_key")] * 2


def test_api_key_never_reaches_logs_or_database(env, caplog):
    caplog.set_level(logging.DEBUG)
    session = FakeSession(requests.Timeout(f"GET https://api.longdo.com/x?key={FAKE_KEY}"),
                          requests.Timeout(f"GET https://api.longdo.com/x?key={FAKE_KEY}"),
                          *[FakeResponse(payload=body()) for _ in range(7)])
    c = traveltime.RouteClient(FAKE_KEY, session=session, sleep=NO_SLEEP)
    result = traveltime.collect(FAKE_KEY, client=c, fetched_at=FETCHED, sleep=NO_SLEEP)
    assert result["received"] == 7
    bad = traveltime.RouteClient(FAKE_KEY, session=FakeSession(FakeResponse(200, text=f"throw 'Key Error {FAKE_KEY}'")),
                                 sleep=NO_SLEEP)
    with pytest.raises(traveltime.InvalidResponse):
        traveltime.collect(FAKE_KEY, pairs=[("r", 13.7, 100.5, 13.8, 100.6)], client=bad,
                           fetched_at="2026-10-03 04:15:00", sleep=NO_SLEEP)
    assert FAKE_KEY not in caplog.text
    stored = q(env["admin"], "SELECT coalesce(string_agg(note, ' '), '') FROM bkk_traffic.scrape_runs")[0][0]
    stored += q(env["admin"], "SELECT coalesce(string_agg(raw_json::text, ' '), '') FROM bkk_traffic.travel_times")[0][0]
    stored += json.dumps(q(env["admin"], "SELECT state_json FROM bkk_traffic.checkpoints")[0][0] if
                         q(env["admin"], "SELECT count(*) FROM bkk_traffic.checkpoints")[0][0] else {})
    assert FAKE_KEY not in stored and FAKE_KEY not in json.dumps(result)


def test_other_bkk_tables_and_namtang_are_untouched(env):
    tables = ("incidents", "traffic_index", "traffic_index_history", "quarantine", "seen_eids", "missing_eids",
              "bronze_incidents", "event_types", "load_history")

    def state():
        bkk = {t: q(env["admin"], f"SELECT count(*) FROM bkk_traffic.{t}")[0][0] for t in tables}
        nt = [r[0] for r in q(env["admin"], "SELECT schemaname || '.' || tablename FROM pg_tables "
                                            "WHERE schemaname IN ('namtang', 'namtang_analysis') ORDER BY 1")]
        return bkk, nt, [q(env["admin"], f"SELECT count(*) FROM {t}")[0][0] for t in nt]

    before = state()
    traveltime.collect(FAKE_KEY, client=FakeRouteClient(), fetched_at=FETCHED, sleep=NO_SLEEP)
    assert state() == before and len(before[1]) == 22


# --------------------------------------------------------------------------
# Airflow (only inside the Airflow image)
# --------------------------------------------------------------------------

def test_travel_time_task_in_the_dag():
    pytest.importorskip("airflow.sdk")
    spec = importlib.util.spec_from_file_location("bkk_pipeline_traveltime_test",
                                                  ROOT / "airflow" / "dags" / "bkk_traffic_pipeline.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    dag = module.pipeline_dag
    task = dag.get_task("collect_travel_times")
    assert [t.task_id for t in task.upstream_list] == ["update_history"]
    assert [t.task_id for t in task.downstream_list] == ["clean"]
    assert task.pool == dag.get_task("scrape").pool == dag.get_task("update_history").pool
    assert task.retries == 0 and module.pipeline_schedule() is None
    namtang = (ROOT / "airflow" / "dags" / "namtang_gtfs_pipeline.py").read_text(encoding="utf-8")
    assert "travel" not in namtang and "bkk_traffic" not in namtang
