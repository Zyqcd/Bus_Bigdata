"""Tests for the analysis-ready layer. The feed is a tiny synthetic fixture with one
instance of each data-quality issue; no network and no real data."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "data" / "scraper" / "processing"))
import build_analysis as ba  # noqa: E402
from test_validate_gtfs import BASE, build  # noqa: E402

DQ_FEED = {
    # DQ-001: A1 is used by two operators
    "agency__txt": BASE["agency.txt"] + "A1,Other Operator,https://x,Asia/Bangkok\n",
    # DQ-007: R9 has no trips
    "routes__txt": BASE["routes.txt"] + "R9,A2,9,Unused route,,3,\n",
    # DQ-008: S5 is never used
    "stops__txt": BASE["stops.txt"] + "S5,Unused,13.75,100.55,Z3,\n",
    # DQ-005: S3 twice in a row on T1
    "stop_times__txt": BASE["stop_times.txt"] + "T1,08:25:00,08:26:00,S3,4,1\n",
    # DQ-002: zone Z9 has no stop
    "fare_rules__txt": BASE["fare_rules.txt"] + "F2,R2,Z1,Z9\n",
    # DQ-003: identical window for T1 (T3 is the DQ-004 single departure)
    "frequencies__txt": BASE["frequencies.txt"] + "T1,06:00:00,07:00:00,600\n",
    # DQ-006: repeated point on SH1; DQ-009: SH9 is unused
    "shapes__txt": BASE["shapes.txt"] + "SH1,13.72,100.52,4\nSH9,13.80,100.60,1\n"
                                        "SH9,13.81,100.61,2\n",
}


def write_policy(tmp_path: Path, clean_dir: Path, **override) -> Path:
    meta = json.loads((clean_dir / "metadata.json").read_text(encoding="utf-8"))
    counts = {"DQ-002": 1, "DQ-004": 1, "DQ-005": 1, "DQ-006": 1, "DQ-007": 1, "DQ-008": 1,
              "DQ-009": 1, "DQ-010": 0, **override}
    issues = [{"id": "DQ-001", "affected_rows": override.get("DQ-001", 2),
               "details": {"A1": ["ขสมก.", "Other Operator"]},
               "downstream_impact": {"routes": 1, "trips_on_those_routes": 2,
                                     "fare_rules_using_those_fares": 1}},
              {"id": "DQ-003", "affected_rows": 2, "details": {"extra_copies": 1}}]
    issues += [{"id": k, "affected_rows": v} for k, v in counts.items() if k != "DQ-001"]
    policy = {"policy_version": "test", "feed": {"feed_sha256": meta["feed_sha256"]},
              "issues": issues}
    path = tmp_path / "metadata" / "policy.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(policy), encoding="utf-8")
    return path


def run(tmp_path: Path, clean_dir: Path, policy: Path, **kw) -> dict:
    return ba.build_feed(clean_dir, analysis_root=tmp_path / "analysis", policy_path=policy,
                         log_path=tmp_path / "scrape_log.csv", **kw)


@pytest.fixture
def built(tmp_path):
    clean = build(tmp_path, **DQ_FEED)
    policy = write_policy(tmp_path, clean)
    meta = run(tmp_path, clean, policy)
    return tmp_path, clean, meta, tmp_path / "analysis" / "2026-10-01"


def rows(out: Path, name: str, key: str | None = None):
    data = pq.read_table(out / name).to_pylist()
    return {r[key]: r for r in data} if key else data


# --------------------------------------------------------------------------


def test_build_succeeds_and_reconciles_row_counts(built):
    _, clean, meta, out = built
    assert meta["status"] == "success", [c for c in meta["validation"]["checks"]
                                         if c["status"] != "PASS"]
    assert (out / "_SUCCESS").exists()
    expected = {"agencies_analysis.parquet": 3, "routes_analysis.parquet": 3,
                "stops_analysis.parquet": 5, "trips_analysis.parquet": 3,
                "stop_times_analysis.parquet": 8, "frequencies_analysis.parquet": 3,
                "fare_analysis.parquet": 3, "shapes_analysis.parquet": 2}
    assert meta["output_tables"] == expected
    assert meta["exclusions"]["total_excluded_rows"] == 0
    assert all(t["excluded_rows"] == 0 for t in meta["transformations"])
    src = meta["network_summary"]["source_counts"]
    assert src["routes"] == 3 and src["shape_points"] == 6 and src["distinct_shapes"] == 2
    active = meta["network_summary"]["derived_active_network_counts"]
    assert active["routes_with_trips"] == 2 and active["stops_with_stop_times"] == 4


def test_lineage_is_preserved_everywhere(built):
    _, clean, meta, out = built
    for name in meta["output_tables"]:
        t = pq.read_table(out / name)
        assert set(t.column("feed_sha256").to_pylist()) == {meta["source"]["feed_sha256"]}
        assert set(t.column("feed_version").to_pylist()) == {"v1"}
        assert "source_table" in t.column_names
    st = rows(out, "stop_times_analysis.parquet")
    clean_rows = pq.read_table(clean / "stop_times.parquet", columns=["source_row"]).column(0)
    assert sorted(r["source_row"] for r in st) == sorted(clean_rows.to_pylist())
    fare = rows(out, "fare_analysis.parquet")
    assert {r["fare_rules_source_row"] for r in fare} == {1, 2, 3}
    assert {r["fare_attributes_source_row"] for r in fare} == {1, 2}


def test_no_fabricated_ids_and_validator_catches_tampering(built):
    tmp_path, clean, meta, out = built
    ids = [c for c in meta["validation"]["checks"] if c["check"].startswith("no fabricated")]
    assert ids and all(c["status"] == "PASS" for c in ids)
    # Tamper with a derived file and re-run the derived-data validation on it.
    t = pq.read_table(out / "trips_analysis.parquet")
    route = t.column("route_id").to_pylist()
    route[0] = "R_INVENTED"
    t = t.set_column(t.schema.get_field_index("route_id"), "route_id", pa.array(route))
    pq.write_table(t.slice(0, 2), out / "trips_analysis.parquet")
    ctx = ba.Ctx(clean, out, tmp_path / "metadata" / "policy.json")
    checks = {c["check"]: c for c in ba.validate_outputs(ctx, ba.dq_context(ctx))}
    assert checks["no fabricated trips_analysis.parquet:route_id"]["status"] == "ERROR"
    assert checks["trips_analysis.parquet row count"]["status"] == "ERROR"


def test_route_aggregation_and_agency_collision(built):
    out = built[3]
    r = rows(out, "routes_analysis.parquet", "route_id")
    assert (r["R1"]["n_trips"], r["R1"]["n_services"], r["R1"]["n_shapes"]) == (2, 2, 1)
    assert (r["R1"]["n_stops"], r["R1"]["n_stop_times"]) == (4, 6)
    assert r["R1"]["agency_identity_unresolved"] is True
    assert r["R1"]["agency_id"] == "A1"                       # not remapped
    assert r["R1"]["agency_name"] is None
    assert r["R1"]["agency_name_candidates"] == "ขสมก. | Other Operator"
    assert r["R2"]["agency_name"] == "BTS" and r["R2"]["n_fare_rules_unresolved_zone"] == 1
    assert r["R9"]["is_unused"] is True and r["R9"]["n_trips"] == 0
    agencies = rows(out, "agencies_analysis.parquet")
    assert sum(a["agency_identity_unresolved"] for a in agencies) == 2
    assert len(agencies) == 3                                  # no join fan-out, no merge


def test_stop_aggregation(built):
    out = built[3]
    s = rows(out, "stops_analysis.parquet", "stop_id")
    assert (s["S3"]["n_stop_occurrences"], s["S3"]["n_trips"], s["S3"]["n_routes"]) == (3, 2, 1)
    assert s["S3"]["n_consecutive_repeat_occurrences"] == 1
    assert s["S3"]["n_trips_visiting_more_than_once"] == 1
    assert s["S5"]["is_unused"] is True and s["S5"]["n_stop_occurrences"] == 0
    assert s["S1"]["n_fare_rules_origin_zone"] == 2            # Z1 used by 2 rules
    assert "Z9" not in {x["zone_id"] for x in s.values()}      # orphan zone not invented


def test_trip_aggregation(built):
    out = built[3]
    t = rows(out, "trips_analysis.parquet", "trip_id")
    t1 = t["T1"]
    assert (t1["n_stops"], t1["first_stop_id"], t1["last_stop_id"]) == (4, "S1", "S3")
    assert (t1["first_departure_time"], t1["last_arrival_time"]) == ("08:00:00", "08:25:00")
    assert t1["duration_seconds"] == 25 * 60
    assert t1["schedule_type"] == "frequency_based"
    assert t1["n_frequency_windows_source"] == 2 and t1["n_frequency_windows_counted"] == 1
    assert t1["estimated_departures_per_service_day"] == 6     # counted once, not 12
    assert t1["has_consecutive_repeat_stop"] is True
    assert t["T2"]["schedule_type"] == "scheduled"
    assert t["T2"]["estimated_departures_per_service_day"] == 1
    assert t["T2"]["duration_seconds"] == 20 * 60               # 24:50 -> 25:10 kept as GTFS time
    assert t["T3"]["estimated_departures_per_service_day"] == 1  # single departure
    assert t["T3"]["agency_identity_unresolved"] is True


def test_consecutive_identical_stops_are_zero_length_segments(built):
    out = built[3]
    st = [r for r in rows(out, "stop_times_analysis.parquet") if r["trip_id"] == "T1"]
    assert [r["stop_sequence"] for r in st] == [1, 2, 3, 4]
    hop = st[2]
    assert hop["next_stop_id"] == "S3" and hop["next_is_same_stop"] is True
    assert hop["segment_distance_m"] == 0 and hop["travel_time_to_next_secs"] == 240
    assert hop["segment_speed_kmh"] == 0
    assert st[3]["is_consecutive_repeat_stop"] is True and st[3]["is_last_stop"] is True
    assert st[3]["next_stop_id"] is None
    assert st[1]["travel_time_to_next_secs"] is None            # missing time not interpolated


def test_single_departure_is_one_departure_without_headway_division(built):
    out = built[3]
    f = [r for r in rows(out, "frequencies_analysis.parquet") if r["trip_id"] == "T3"][0]
    assert f["is_single_departure"] is True and f["headway_secs"] == 0
    assert f["estimated_departures_in_window"] == 1 and f["departures_per_hour"] is None


def test_duplicate_frequency_window_counted_once(built):
    out = built[3]
    t1 = sorted((r for r in rows(out, "frequencies_analysis.parquet") if r["trip_id"] == "T1"),
                key=lambda r: r["source_row"])
    assert len(t1) == 2                                         # source row not removed
    assert [r["is_duplicate_window"] for r in t1] == [True, True]
    assert [r["counted_in_derived"] for r in t1] == [True, False]
    assert t1[1]["duplicate_of_source_row"] == t1[0]["source_row"]
    assert [r["counted_estimated_departures"] for r in t1] == [6, 0]
    assert t1[0]["departures_per_hour"] == 6.0


def test_fare_flags_and_shapes_summary(built):
    out = built[3]
    fare = rows(out, "fare_analysis.parquet", "fare_rules_source_row")
    assert fare[3]["destination_id"] == "Z9"                    # kept as published
    assert fare[3]["unresolved_fare_zone"] is True and fare[3]["destination_zone_resolved"] is False
    assert fare[2]["origin_zone_resolved"] is None              # null selector stays null
    assert fare[1]["agency_identity_unresolved"] is True and fare[1]["price"] == 15
    sh = rows(out, "shapes_analysis.parquet", "shape_id")
    assert (sh["SH1"]["n_points_source"], sh["SH1"]["n_repeated_consecutive_points"],
            sh["SH1"]["n_points_collapsed"]) == (4, 1, 3)
    assert sh["SH1"]["length_m"] > 0 and sh["SH1"]["n_trips"] == 2
    assert (sh["SH1"]["first_source_row"], sh["SH1"]["last_source_row"]) == (1, 4)
    assert sh["SH9"]["is_unused"] is True


def test_dq_policy_compliance_is_enforced(tmp_path):
    clean = build(tmp_path, **DQ_FEED)
    policy = write_policy(tmp_path, clean, **{"DQ-002": 5})       # policy disagrees with data
    meta = run(tmp_path, clean, policy)
    assert meta["status"] == "failed"
    bad = [c for c in meta["validation"]["checks"] if c["status"] == "ERROR"]
    assert [c["policy_issue"] for c in bad] == ["DQ-002"]
    assert not (tmp_path / "analysis" / "2026-10-01").exists()     # never promoted


def test_policy_for_other_feed_is_refused(tmp_path):
    clean = build(tmp_path, **DQ_FEED)
    policy = write_policy(tmp_path, clean)
    data = json.loads(policy.read_text(encoding="utf-8"))
    data["feed"]["feed_sha256"] = "0" * 64
    policy.write_text(json.dumps(data), encoding="utf-8")
    with pytest.raises(ba.AnalysisError, match="different feed"):
        run(tmp_path, clean, policy)


def test_unordered_shapes_are_refused(tmp_path):
    shapes = ("shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n"
              "SH1,13.71,100.51,2\nSH1,13.70,100.50,1\nSH1,13.72,100.52,3\n")
    clean = build(tmp_path, shapes__txt=shapes)
    meta = json.loads((clean / "metadata.json").read_text(encoding="utf-8"))
    policy = tmp_path / "policy.json"
    policy.write_text(json.dumps({"feed": {"feed_sha256": meta["feed_sha256"]}, "issues": []}))
    with pytest.raises(ba.AnalysisError, match="not ordered"):
        run(tmp_path, clean, policy)


def test_build_does_not_modify_raw_or_clean(tmp_path):
    clean = build(tmp_path, **DQ_FEED)
    policy = write_policy(tmp_path, clean)
    files = [p for root in (tmp_path / "raw", clean) for p in sorted(root.rglob("*"))
             if p.is_file()]
    before = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    run(tmp_path, clean, policy)
    assert {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in files} == before


def test_rerun_skips_force_rebuilds_and_logs(built):
    tmp_path, clean, meta, out = built
    policy = tmp_path / "metadata" / "policy.json"
    assert run(tmp_path, clean, policy)["run_id"] == meta["run_id"]
    assert run(tmp_path, clean, policy, force=True)["run_id"] != meta["run_id"]
    with (tmp_path / "scrape_log.csv").open(newline="", encoding="utf-8") as fh:
        logged = [r for r in csv.DictReader(fh) if r["stage"] == "analysis"]
    assert len(logged) == 2 * (1 + 8)
    assert all(r["rejected_rows"] == "0" for r in logged)
