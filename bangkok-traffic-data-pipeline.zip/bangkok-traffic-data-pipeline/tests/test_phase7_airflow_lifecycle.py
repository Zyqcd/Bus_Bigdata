"""Phase 7: new-feed lifecycle through the REAL Airflow DAG (dag.test()), isolated.

The DAG's hooks are pointed at pytest tmp roots, the TEST-ONLY fixture scraper
and the throwaway database ``namtang_test_db``. Runs inside the Airflow image
(airflow/run_dag_tests.sh), where the production connection is unset and the
production database network is not attached.
"""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

import pytest

pytest.importorskip("airflow.sdk")

import phase7_support as p7  # noqa: E402
import run_pipeline as rp  # noqa: E402
from test_airflow_dag import DAG_FILE, EXPECTED_TASKS, _states, _xcom, _xcom_rows  # noqa: E402

A, B = p7.variant("A"), p7.variant("B")


@pytest.fixture(autouse=True)
def production_untouched():
    assert "AIRFLOW_CONN_NAMTANG_POSTGRES" not in os.environ   # production connection absent
    before = p7.production_snapshot()
    yield
    assert p7.production_snapshot() == before


@pytest.fixture
def test_db():
    dsn = p7.isolated_test_dsn()
    p7.reset_test_database(dsn)
    return dsn


@pytest.fixture
def dag_module():
    spec = importlib.util.spec_from_file_location("namtang_dag_phase7", DAG_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def point_dag_at_fixture(module, monkeypatch, paths: rp.Paths, key: str, dsn: str) -> None:
    for t in module.namtang_dag.tasks:                       # no production retry delays
        monkeypatch.setattr(t, "retries", 0)
    monkeypatch.setattr(module, "pipeline_paths", lambda: paths)
    monkeypatch.setattr(module, "namtang_dsn", lambda: dsn)  # isolated test DB only

    def stages(p, run_id, dsn=None):
        s = rp.default_stages(p, dsn, run_id)                # real clean/validate/analysis/loader
        s.scrape = p7.fixture_scraper(p, key)                # real scraper, fixture bytes
        return s

    monkeypatch.setattr(module, "pipeline_stages", stages)


def clean_dir_of(run) -> str:
    return _xcom(run, "clean")["clean_dir"]


def test_dag_new_feed_missing_policy_then_approved(dag_module, monkeypatch, tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    point_dag_at_fixture(dag_module, monkeypatch, paths, "A", test_db)
    db_empty = p7.db_state(test_db)

    run = dag_module.namtang_dag.test()
    states = _states(run)
    assert str(run.state) == "failed"
    assert [states[t] for t in EXPECTED_TASKS] == [
        "success", "success", "success", "failed", "upstream_failed", "upstream_failed"]
    assert _xcom(run, "scrape")["feed_sha256"] == A["sha256"]
    assert _xcom(run, "validate")["validation_overall_status"] == "ERROR"
    assert _xcom_rows(run) == sorted((t, "return_value") for t in ("scrape", "clean", "validate"))
    assert p7.db_state(test_db) == db_empty

    p7.install_policy(paths, clean_dir_of(run))              # reviewer approves SHA-A
    run = dag_module.namtang_dag.test()
    assert str(run.state) == "success", _states(run)
    assert _xcom_rows(run) == sorted((t, "return_value") for t in EXPECTED_TASKS)
    for task_id in EXPECTED_TASKS:
        ctx = _xcom(run, task_id)
        assert ctx["feed_sha256"] == A["sha256"] and ctx["feed_version"] == "PHASE7-TEST-A"
        assert len(json.dumps(ctx)) < 4096                   # metadata only
    final = _xcom(run, "load_postgresql")
    assert final["policy_decision"] == "pass" and final["stage_status"]["load"] == "loaded"
    state = p7.db_state(test_db)
    assert state["feed_identities"] == [A["sha256"]]
    assert state["rows"]["namtang.shapes"] == A["row_counts"]["shapes.txt"]
    assert state["load_history"] == [(A["sha256"], "PHASE7-TEST-A", "success", None)]

    run = dag_module.namtang_dag.test()                       # unchanged feed
    assert str(run.state) == "success"
    assert _xcom(run, "load_postgresql")["stage_status"]["load"] == "unchanged"
    assert p7.db_state(test_db) == state


def test_dag_policy_sha_mismatch_stops_before_analysis(dag_module, monkeypatch, tmp_path, test_db):
    paths = p7.isolated_paths(tmp_path)
    point_dag_at_fixture(dag_module, monkeypatch, paths, "B", test_db)
    run = dag_module.namtang_dag.test()                       # first sight of SHA-B
    assert _states(run)["dq_policy_gate"] == "failed"
    p7.install_policy(paths, clean_dir_of(run))               # policy is for SHA-A
    run = dag_module.namtang_dag.test()
    states = _states(run)
    assert str(run.state) == "failed" and states["dq_policy_gate"] == "failed"
    assert states["analysis"] == states["load_postgresql"] == "upstream_failed"
    assert _xcom(run, "clean")["feed_sha256"] == B["sha256"]
    assert p7.db_state(test_db)["rows"]["namtang.feed_info"] == 0
    gate_rows = [line for line in paths.log_path.read_text(encoding="utf-8").splitlines()
                 if line.endswith(",policy_gate")]
    assert "different feed SHA-256" in gate_rows[-1]
