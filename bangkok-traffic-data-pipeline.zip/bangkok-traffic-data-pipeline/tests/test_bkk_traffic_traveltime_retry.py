"""Phase 9.6.2: bounded retry policy of the travel-time collector (traveltime.RouteClient).

* No network: HTTP is a fake session driven by a fake clock (deterministic outage windows);
  the classification is also checked against REAL requests/urllib3 exceptions produced by
  local sockets only (refused localhost port, '.invalid' DNS name, silent / plain local servers).
* Database tests use ONLY the isolated namtang_bkk_traffic_test_db (guarded fixtures).
* The key is an obviously fake runtime string; no real Longdo request, no real quota.
"""

from __future__ import annotations

import json
import socket
import sys
import threading
import time
from pathlib import Path

import pytest
import requests
import urllib3

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))

from bkk_traffic import storage, traveltime  # noqa: E402

from test_bkk_traffic_pipeline import dsns, env, q  # noqa: E402,F401  (fixtures)

FAKE_KEY = "test-only-" + "retry-key-" + "c41d"
FETCHED = "2026-10-03 05:00:00"
URL_WITH_KEY = f"/RouteService/json/route/guide?flat=1&key={FAKE_KEY}"


# --------------------------------------------------------------------------
# Exceptions shaped exactly like the observed requests 2.34 / urllib3 2.7 ones
# --------------------------------------------------------------------------

def refused():
    reason = urllib3.exceptions.NewConnectionError(None, "Failed to establish a new connection: [Errno 111] refused")
    return requests.exceptions.ConnectionError(urllib3.exceptions.MaxRetryError(None, URL_WITH_KEY, reason))


def dns_failure():
    reason = urllib3.exceptions.NameResolutionError("api.longdo.com", None, socket.gaierror(-2, "Name or service not known"))
    return requests.exceptions.ConnectionError(urllib3.exceptions.MaxRetryError(None, URL_WITH_KEY, reason))


def connect_timeout():
    reason = urllib3.exceptions.ConnectTimeoutError(None, "connect timed out")
    return requests.exceptions.ConnectTimeout(urllib3.exceptions.MaxRetryError(None, URL_WITH_KEY, reason))


def reset():
    return requests.exceptions.ConnectionError(urllib3.exceptions.ProtocolError("Connection aborted.",
                                                                                ConnectionResetError(104, "reset")))


def read_timeout():
    return requests.exceptions.ReadTimeout(f"HTTPSConnectionPool: Read timed out. url={URL_WITH_KEY}")


def tls_failure():
    reason = urllib3.exceptions.SSLError("certificate verify failed")
    return requests.exceptions.SSLError(urllib3.exceptions.MaxRetryError(None, URL_WITH_KEY, reason))


def body(distance=5000, interval=900):
    return {"meta": {"status": 200}, "data": [{"distance": distance, "interval": interval, "guide": []}]}


class Resp:
    def __init__(self, status=200, payload=None, text=None):
        self.status_code, self._payload = status, payload
        self.text = text if text is not None else json.dumps(payload)

    def json(self):
        if self._payload is None:
            raise ValueError("not json")
        return self._payload


class Clock:
    def __init__(self):
        self.now = 0.0
        self.sleeps = []

    def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.now += seconds


class OutageSession:
    """Connect failures while clock.now is inside an outage window, else a Longdo-style 200.

    Every attempt costs `attempt_seconds` of simulated time (production: about 3-8 s per failing attempt)."""

    def __init__(self, clock, windows=((0, 0),), error=refused, attempt_seconds=5.0, answer=None):
        self.clock, self.windows, self.error, self.attempt_seconds = clock, windows, error, attempt_seconds
        self.answer = answer or (lambda params: Resp(payload=body()))
        self.headers, self.calls = {}, []

    def get(self, url, params=None, timeout=None):
        self.calls.append((self.clock.now, dict(params), timeout))
        start = self.clock.now
        self.clock.now += self.attempt_seconds
        if any(a <= start < b for a, b in self.windows):
            raise self.error()
        return self.answer(params)


def make_client(session, clock, routes=8):
    return traveltime.RouteClient(FAKE_KEY, session=session, sleep=clock.sleep,
                                  max_requests=traveltime.max_requests_per_poll(routes))


# --------------------------------------------------------------------------
# Classification (no database)
# --------------------------------------------------------------------------

@pytest.mark.parametrize("factory, expected", [
    (refused, ("connect", "NewConnectionError")),
    (dns_failure, ("connect", "NameResolutionError")),
    (connect_timeout, ("connect", "ConnectTimeout")),
    (reset, ("response", "ConnectionError")),
    (read_timeout, ("response", "ReadTimeout")),
    (tls_failure, ("permanent", "SSLError")),
    (lambda: requests.exceptions.InvalidURL("bad"), ("permanent", "InvalidURL")),
])
def test_classification_of_shaped_exceptions(factory, expected):
    assert traveltime.classify_transport_error(factory()) == expected


def _serve(mode):
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(5)

    def run():
        while True:
            try:
                conn, _ = srv.accept()
            except OSError:
                return
            if mode == "silent":
                time.sleep(3)
            else:
                conn.recv(1024)
                conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok")
            conn.close()

    threading.Thread(target=run, daemon=True).start()
    return srv.getsockname()[1]


def _real_error(url, timeout):
    with pytest.raises(requests.RequestException) as info:
        requests.get(url, timeout=timeout)
    return info.value


def test_classification_of_real_library_exceptions():
    free = socket.socket()
    free.bind(("127.0.0.1", 0))
    port = free.getsockname()[1]
    free.close()
    assert traveltime.classify_transport_error(_real_error(f"http://127.0.0.1:{port}/", 3))[0] == "connect"
    assert traveltime.classify_transport_error(_real_error("http://no-such-host.invalid/", 3))[0] == "connect"
    assert traveltime.classify_transport_error(
        _real_error(f"http://127.0.0.1:{_serve('silent')}/", (2, 0.3))) == ("response", "ReadTimeout")
    assert traveltime.classify_transport_error(
        _real_error(f"https://127.0.0.1:{_serve('plain')}/", 3)) == ("permanent", "SSLError")


def test_policy_constants_are_bounded():
    assert traveltime.CONNECT_RETRY_DELAYS == (5, 10, 20, 30, 30, 30)
    assert sum(traveltime.CONNECT_RETRY_DELAYS) == 125 <= traveltime.POLL_RETRY_BUDGET_SEC == 150
    assert traveltime.RESPONSE_RETRY_DELAYS == (5,)
    assert traveltime.max_requests_per_poll(8) == 24
    assert (traveltime.CONNECT_TIMEOUT_SEC, traveltime.READ_TIMEOUT_SEC) == (5, 180)
    # permanent connect outage: 7 attempts x (3 IPv4 x 5 s) + 125 s backoff = 230 s < task timeout 300 s
    assert 7 * 3 * traveltime.CONNECT_TIMEOUT_SEC + sum(traveltime.CONNECT_RETRY_DELAYS) == 230 < 300
    assert len(traveltime.DEFAULT_OD_PAIRS) == 8 and traveltime.DELAY_BETWEEN_ROUTES_SEC == 1


# --------------------------------------------------------------------------
# RouteClient behaviour (no database)
# --------------------------------------------------------------------------

def test_outage_of_about_90_seconds_is_ridden_out():
    clock = Clock()
    session = OutageSession(clock, windows=((0, 95),))          # N = 6 failing attempts (t = 0, 10, 25, 50, 85 ... )
    client = make_client(session, clock)
    assert client.route(1, 2, 3, 4) == body()
    failures = sum(1 for t, *_ in session.calls if t < 95)
    assert failures == 5 and client.request_count == 6            # 5 refused + the successful attempt
    assert clock.sleeps == [5, 10, 20, 30, 30] and client.retry_sleep_spent == 95
    assert all(timeout == (5, 180) for *_, timeout in session.calls)


def test_outage_that_ends_inside_the_full_schedule():
    clock = Clock()
    session = OutageSession(clock, windows=((0, 150),))          # 6 failures, success on attempt 7 (t = 160)
    client = make_client(session, clock)
    assert client.route(1, 2, 3, 4) == body()
    assert client.request_count == 7 and clock.sleeps == [5, 10, 20, 30, 30, 30] and not client.circuit_open


def test_permanent_connection_failure_stops_and_opens_the_circuit():
    clock = Clock()
    session = OutageSession(clock, windows=((0, 10_000),))
    client = make_client(session, clock)
    with pytest.raises(traveltime.RouteRequestError, match=r"connection failure \(NewConnectionError\) after 7 attempts"):
        client.route(1, 2, 3, 4)
    assert client.circuit_open and client.request_count == 7 and sum(clock.sleeps) == 125
    with pytest.raises(traveltime.RouteRequestError, match="not requested: connection unavailable"):
        client.route(5, 6, 7, 8)
    assert client.request_count == 7                              # no further request after the circuit opened


@pytest.mark.parametrize("error", [dns_failure, connect_timeout])
def test_other_connect_stage_failures_use_the_same_schedule(error):
    clock = Clock()
    client = make_client(OutageSession(clock, windows=((0, 60),), error=error), clock)
    assert client.route(1, 2, 3, 4) == body() and clock.sleeps == [5, 10, 20, 30]


def test_poll_budget_is_shared_between_routes():
    clock = Clock()
    session = OutageSession(clock, windows=((0, 60), (90, 10_000)))
    client = make_client(session, clock)
    assert client.route(1, 2, 3, 4) == body()                     # first outage: 5+10+20+30 = 65 s of backoff
    assert client.retry_sleep_spent == 65
    with pytest.raises(traveltime.RouteRequestError, match="after 5 attempts"):
        client.route(1, 2, 3, 4)                                  # second outage: 5+10+20+30 fit (130), next 30 > 150
    assert client.retry_sleep_spent == 130 and client.circuit_open
    assert client.retry_sleep_spent <= traveltime.POLL_RETRY_BUDGET_SEC


@pytest.mark.parametrize("response, exc, match", [
    (Resp(200, text=f"throw 'Route Service API Key Error {FAKE_KEY}';"), traveltime.InvalidResponse, "API Key Error"),
    (Resp(200, payload=None, text="<html>maintenance</html>"), traveltime.InvalidResponse, "not JSON"),
    (Resp(401, text="unauthorized"), traveltime.RouteRequestError, r"HTTP 401 \(not retried\)"),
    (Resp(403, text="forbidden"), traveltime.RouteRequestError, r"HTTP 403 \(not retried\)"),
    (Resp(404, text="nope"), traveltime.RouteRequestError, r"HTTP 404 \(not retried\)"),
], ids=["invalid_key", "malformed", "401", "403", "404"])
def test_non_retryable_responses_make_exactly_one_request(response, exc, match):
    clock = Clock()
    client = make_client(OutageSession(clock, answer=lambda params: response), clock)
    with pytest.raises(exc, match=match) as info:
        client.route(1, 2, 3, 4)
    assert client.request_count == 1 and clock.sleeps == [] and FAKE_KEY not in str(info.value)


def test_tls_failure_is_not_retried():
    clock = Clock()
    client = make_client(OutageSession(clock, windows=((0, 10_000),), error=tls_failure), clock)
    with pytest.raises(traveltime.RouteRequestError, match=r"SSLError \(not retried\)"):
        client.route(1, 2, 3, 4)
    assert client.request_count == 1 and clock.sleeps == [] and not client.circuit_open


@pytest.mark.parametrize("error", [reset, read_timeout])
def test_response_stage_failures_retry_once(error):
    clock = Clock()
    client = make_client(OutageSession(clock, windows=((0, 10_000),), error=error), clock)
    with pytest.raises(traveltime.RouteRequestError, match="after 2 attempts"):
        client.route(1, 2, 3, 4)
    assert client.request_count == 2 and clock.sleeps == [5] and not client.circuit_open


def test_http_503_then_success():
    clock = Clock()
    answers = iter([Resp(503, text="busy"), Resp(payload=body())])
    client = make_client(OutageSession(clock, answer=lambda params: next(answers)), clock)
    assert client.route(1, 2, 3, 4) == body() and client.request_count == 2 and clock.sleeps == [5]


def test_request_cap_is_hard():
    clock = Clock()
    client = traveltime.RouteClient(FAKE_KEY, session=OutageSession(clock, answer=lambda p: Resp(503, text="x")),
                                    sleep=clock.sleep, max_requests=3)
    with pytest.raises(traveltime.RouteRequestError, match="after 2 attempts"):
        client.route(1, 2, 3, 4)
    with pytest.raises(traveltime.RouteRequestError, match="request cap 3 reached"):
        client.route(1, 2, 3, 4)
    assert client.request_count == 3


def test_worst_case_requests_and_sleep_per_poll():
    """Adversarial mixes never exceed 24 requests or 150 s of backoff for 8 routes."""
    patterns = {
        "always 503": dict(answer=lambda p: Resp(503, text="x")),
        "always refused": dict(windows=((0, 10_000),)),
        "refused then 503": dict(windows=((0, 140),), answer=lambda p: Resp(503, text="x")),
        "flapping": dict(windows=tuple((t, t + 55) for t in range(0, 2_000, 60))),
    }
    for name, kwargs in patterns.items():
        clock = Clock()
        client = make_client(OutageSession(clock, **kwargs), clock)
        for _ in range(8):
            try:
                client.route(1, 2, 3, 4)
            except traveltime.TravelTimeError:
                pass
        assert client.request_count <= 24, name
        assert sum(clock.sleeps) <= traveltime.POLL_RETRY_BUDGET_SEC, name


# --------------------------------------------------------------------------
# Collector + database (isolated test DB)
# --------------------------------------------------------------------------

def rows(dsn):
    return q(dsn, "SELECT route, fetched_at::text, distance_m FROM bkk_traffic.travel_times ORDER BY route")


def test_outage_then_success_writes_one_row_per_route(env):
    clock = Clock()
    session = OutageSession(clock, windows=((0, 95),))
    client = make_client(session, clock)
    result = traveltime.collect(FAKE_KEY, client=client, fetched_at=FETCHED, sleep=clock.sleep)
    assert (result["status"], result["received"], result["inserted"], result["failed_routes"]) == ("success", 8, 8, [])
    assert result["requests"] == 13                       # 6 attempts on route 1 + 7 single attempts
    got = rows(env["admin"])
    assert len(got) == 8 and {r[1] for r in got} == {FETCHED}  # one row per route, same poll key
    assert q(env["admin"], "SELECT count(*) - count(DISTINCT (route, fetched_at)) FROM bkk_traffic.travel_times")[0][0] == 0
    usage = q(env["admin"], "SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'traveltime_usage'")[0][0]
    assert usage["day_calls"] == 13                       # every attempt counted against the quota


def test_permanent_outage_writes_nothing_and_stops(env):
    clock = Clock()
    client = make_client(OutageSession(clock, windows=((0, 10_000),)), clock)
    with pytest.raises(traveltime.TravelTimeError, match="no route returned"):
        traveltime.collect(FAKE_KEY, client=client, fetched_at=FETCHED, sleep=clock.sleep)
    assert rows(env["admin"]) == [] and client.request_count == 7
    run = q(env["admin"], "SELECT status, requests, note FROM bkk_traffic.scrape_runs WHERE job = 'travel_times'")[0]
    assert run[:2] == ("failed", 7) and FAKE_KEY not in run[2]


def test_failed_route_gets_no_row_and_others_are_kept(env):
    clock = Clock()

    def answer(params):
        return Resp(404, text="nope") if params["flat"] == 13.7290 else Resp(payload=body())

    result = traveltime.collect(FAKE_KEY, client=make_client(OutageSession(clock, answer=answer), clock),
                                fetched_at=FETCHED, sleep=clock.sleep)
    assert result["received"] == 7 and result["failed_routes"] == ["สีลม -> อโศก: HTTP 404 (not retried)"]
    assert "สีลม -> อโศก" not in {r[0] for r in rows(env["admin"])}


def test_malformed_response_after_retries_rolls_back_the_poll(env):
    clock = Clock()
    calls = {"n": 0}

    def answer(params):
        calls["n"] += 1
        return Resp(payload={"data": [{"distance": "?", "interval": 1}]}) if params["flat"] == 13.7290 else Resp(payload=body())

    session = OutageSession(clock, windows=((0, 40),), answer=answer)   # route 1 needs retries, route 2 malformed
    with pytest.raises(traveltime.InvalidResponse):
        traveltime.collect(FAKE_KEY, client=make_client(session, clock), fetched_at=FETCHED, sleep=clock.sleep)
    assert rows(env["admin"]) == []                       # route 1's successful retry is rolled back too


def test_quota_reservation_covers_the_worst_case(env):
    def set_usage(calls):
        with storage.connect() as conn:
            storage.set_checkpoint(conn, "traveltime_usage", {"day": storage.now_str()[:10], "day_calls": calls,
                                                              "month": storage.now_str()[:7], "month_calls": calls})

    set_usage(traveltime.QUOTA_PER_DAY - 23)              # 23 left < 24 worst case: skip without requests
    clock = Clock()
    session = OutageSession(clock)
    assert traveltime.collect(FAKE_KEY, client=make_client(session, clock), sleep=clock.sleep)["status"] == "skipped_quota"
    assert session.calls == []
    set_usage(traveltime.QUOTA_PER_DAY - 24)              # exactly 24 left: the poll may run
    result = traveltime.collect(FAKE_KEY, client=make_client(session, clock), fetched_at=FETCHED, sleep=clock.sleep)
    assert result["status"] == "success" and result["usage"]["day"] <= traveltime.QUOTA_PER_DAY


def test_default_client_uses_the_poll_cap(env, monkeypatch):
    seen = {}

    class Recorder(traveltime.RouteClient):
        def __init__(self, *a, **k):
            seen.update(k)
            super().__init__(*a, session=OutageSession(Clock()), **{x: y for x, y in k.items() if x != "session"})

    monkeypatch.setattr(traveltime, "RouteClient", Recorder)
    traveltime.collect(FAKE_KEY, pairs=[("r1", 13.7, 100.5, 13.8, 100.6), ("r2", 13.7, 100.5, 13.8, 100.7)],
                       fetched_at=FETCHED, sleep=lambda s: None)
    assert seen["max_requests"] == 6
