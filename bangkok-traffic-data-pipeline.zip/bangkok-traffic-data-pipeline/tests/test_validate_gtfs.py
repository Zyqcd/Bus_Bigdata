"""Tests for read-only GTFS validation. Every feed is a tiny synthetic fixture
cleaned with the real cleaner into tmp_path; no network, no real data."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "data" / "scraper" / "processing"))
import clean_gtfs as cg  # noqa: E402
import namtang_scraper as ns  # noqa: E402
import validate_gtfs as vg  # noqa: E402

BASE = {
    "agency.txt": "agency_id,agency_name,agency_url,agency_timezone\n"
                  "A1,ขสมก.,https://a1,Asia/Bangkok\nA2,BTS,https://a2,Asia/Bangkok\n",
    "stops.txt": "stop_id,stop_name,stop_lat,stop_lon,zone_id,wheelchair_boarding\n"
                 "S1,สยาม,13.7456,100.5340,Z1,1\nS2,Silom,13.7290,100.5340,Z1,0\n"
                 "S3,Sathorn,13.7200,100.5300,Z2,\nS4,Bang Wa,13.7207,100.4578,Z2,1\n",
    "routes.txt": "route_id,agency_id,route_short_name,route_long_name,route_desc,route_type,"
                  "route_color\nR1,A1,1,Route one,,3,FF0000\nR2,A2,,Skytrain,,1,\n",
    "trips.txt": "route_id,service_id,trip_id,trip_headsign,direction_id,shape_id,"
                 "wheelchair_accessible\nR1,WK,T1,Siam,0,SH1,1\nR2,WK,T2,Silom,1,SH1,0\n"
                 "R1,WE,T3,Sathorn,0,,\n",
    "stop_times.txt": "trip_id,arrival_time,departure_time,stop_id,stop_sequence,timepoint\n"
                      "T1,08:00:00,08:00:00,S1,1,1\nT1,,,S2,2,0\nT1,08:20:00,08:21:00,S3,3,1\n"
                      "T2,24:50:00,24:50:00,S2,1,1\nT2,25:10:00,25:10:00,S4,2,1\n"
                      "T3,10:30:00,10:30:00,S3,1,1\nT3,10:45:00,10:45:00,S4,2,1\n",
    "calendar.txt": "service_id,monday,tuesday,wednesday,thursday,friday,saturday,sunday,"
                    "start_date,end_date\nWK,1,1,1,1,1,0,0,20260101,20261231\n"
                    "WE,0,0,0,0,0,1,1,20260101,20261231\n",
    "calendar_dates.txt": "service_id,date,exception_type\nWK,20260105,2\n",
    "fare_attributes.txt": "fare_id,price,currency_type,payment_method,transfers,agency_id\n"
                           "F1,15,THB,0,,A1\nF2,44,THB,1,0,A2\n",
    "fare_rules.txt": "fare_id,route_id,origin_id,destination_id\nF1,R1,Z1,Z2\nF2,R2,,\n",
    "shapes.txt": "shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n"
                  "SH1,13.70,100.50,1\nSH1,13.71,100.51,2\nSH1,13.72,100.52,3\n",
    "frequencies.txt": "trip_id,start_time,end_time,headway_secs\n"
                       "T1,06:00:00,07:00:00,600\nT3,10:30:00,10:30:00,0\n",
    "feed_info.txt": "feed_publisher_name,feed_lang,feed_start_date,feed_end_date,feed_version\n"
                     "OTP,tha,20260101,20261231,v1\n",
}


def build(tmp_path: Path, **overrides: str) -> Path:
    """Store a raw feed like the scraper does, clean it, return the clean dir."""
    files = {**BASE, **{k.replace("__", "."): v for k, v in overrides.items()}}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in files.items():
            zf.writestr(name, data.encode("utf-8"))
    body = buf.getvalue()
    raw = tmp_path / "raw" / "2026-10-01"
    raw.mkdir(parents=True)
    (raw / "gtfs.zip").write_bytes(body)
    manifest = {"source": "namtang_gtfs", "zip_sha256": hashlib.sha256(body).hexdigest(),
                "zip_bytes": len(body), "feed_version": "v1",
                "scrape_timestamp_bangkok": "2026-10-01T10:00:00+07:00",
                "members": ns.inspect_members(raw / "gtfs.zip")}
    (raw / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    meta = cg.clean_feed(raw, raw_root=tmp_path / "raw", clean_root=tmp_path / "clean",
                         log_path=tmp_path / "scrape_log.csv")
    assert meta["status"] == "success", meta
    return tmp_path / "clean" / "2026-10-01"


def validate(tmp_path: Path, clean_dir: Path) -> dict:
    return vg.validate_feed(clean_dir, metadata_dir=tmp_path / "metadata",
                            log_path=tmp_path / "scrape_log.csv")


def find(report: dict, section: str, prefix: str) -> dict:
    matches = [c for c in report["sections"][section]["checks"] if c["check"].startswith(prefix)]
    assert matches, f"no check {prefix!r} in {section}"
    return matches[0]


def rewrite_parquet(path: Path, column: str, row: int, value) -> None:
    """Simulate a defect in clean data that the cleaner itself would not produce."""
    table = pq.read_table(path)
    values = table.column(column).to_pylist()
    values[row] = value
    idx = table.schema.get_field_index(column)
    table = table.set_column(idx, table.schema.field(idx), pa.array(values, table.schema.field(idx).type))
    pq.write_table(table, path)


# --------------------------------------------------------------------------


def test_consistent_feed_has_no_errors_and_single_departure_is_warning(tmp_path):
    report = validate(tmp_path, build(tmp_path))
    assert report["errors"] == [], report["errors"]
    assert report["overall_status"] == vg.WARNING
    single = find(report, "frequencies", "single_departure rows")
    assert single["status"] == vg.WARNING and single["count"] == 1
    assert find(report, "frequencies", "is_single_departure flag")["status"] == vg.PASS
    rc = report["sections"]["row_counts"]
    assert rc["status"] == vg.PASS
    assert rc["totals"]["raw_rows"] == rc["totals"]["clean_rows"]
    assert rc["totals"]["rejected_rows"] == 0
    assert find(report, "row_counts", "single_departure rows present")["status"] == vg.PASS
    assert (tmp_path / "metadata" / "validation_2026-10-01.json").exists()
    assert (tmp_path / "metadata" / "validation_2026-10-01.md").exists()


def test_validation_does_not_modify_clean_or_raw_data(tmp_path):
    clean = build(tmp_path)
    files = sorted(p for p in (tmp_path / "raw").rglob("*") if p.is_file()) + \
        sorted(p for p in clean.rglob("*") if p.is_file())
    before = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    validate(tmp_path, clean)
    after = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    assert before == after
    assert sorted(p for p in clean.rglob("*") if p.is_file()) == sorted(
        p for p in files if clean in p.parents)


def test_exact_duplicates_are_reported_not_removed(tmp_path):
    agency = BASE["agency.txt"] + "A1,ขสมก.,https://a1,Asia/Bangkok\n"
    clean = build(tmp_path, agency__txt=agency)
    report = validate(tmp_path, clean)
    dup = report["sections"]["exact_duplicates"]["tables"]["agency"]
    assert dup == {"total_rows": 3, "unique_rows": 2, "exact_duplicate_rows": 1,
                   "duplicate_groups": 1, "affected_rows": 2}
    key = find(report, "logical_keys", "agency logical key")
    assert key["status"] == vg.WARNING and key["identical_groups"] == 1
    assert pq.ParquetFile(clean / "agency.parquet").metadata.num_rows == 3


def test_conflicting_primary_key_is_error(tmp_path):
    stops = BASE["stops.txt"] + "S1,Other name,13.75,100.53,Z1,1\n"
    report = validate(tmp_path, build(tmp_path, stops__txt=stops))
    key = find(report, "logical_keys", "stops logical key")
    assert key["status"] == vg.ERROR and key["conflicting_groups"] == 1
    assert key["examples"][0]["differing_columns"] == ["stop_name", "stop_lat", "stop_lon"]
    assert report["overall_status"] == vg.ERROR


def test_missing_foreign_key_is_error(tmp_path):
    st = BASE["stop_times.txt"] + "T3,11:00:00,11:00:00,S9,3,1\n"
    report = validate(tmp_path, build(tmp_path, stop_times__txt=st))
    fk = find(report, "foreign_keys", "stop_times.stop_id")
    assert fk["status"] == vg.ERROR
    assert fk["missing_parent_rows"] == 1 and fk["examples"][0]["stop_id"] == "S9"
    assert fk["percent"] == pytest.approx(100 / 8, rel=1e-3)


def test_optional_null_references_are_valid(tmp_path):
    report = validate(tmp_path, build(tmp_path))
    route = find(report, "foreign_keys", "fare_rules.route_id")
    shape = find(report, "foreign_keys", "trips.shape_id")
    origin = find(report, "foreign_keys", "fare_rules.origin_id")
    assert route["status"] == vg.PASS and route["null_rows"] == 0
    assert shape["status"] == vg.PASS and shape["null_rows"] == 1 and shape["null_allowed"]
    assert origin["status"] == vg.PASS and origin["null_rows"] == 1
    pattern = find(report, "fares", "fare_rules selector null pattern")
    assert pattern["patterns"] == {"route_id+origin_id+destination_id": 1, "route_id": 1}


def test_required_null_reference_is_error(tmp_path):
    trips = BASE["trips.txt"] + "R1,,T4,X,0,,\n"
    st = BASE["stop_times.txt"] + "T4,09:00:00,09:00:00,S1,1,1\nT4,09:10:00,09:10:00,S2,2,1\n"
    report = validate(tmp_path, build(tmp_path, trips__txt=trips, stop_times__txt=st))
    assert find(report, "foreign_keys", "trips.service_id")["status"] == vg.ERROR


def test_repeated_stop_sequence_is_error(tmp_path):
    st = BASE["stop_times.txt"] + "T1,08:30:00,08:30:00,S4,3,1\n"
    report = validate(tmp_path, build(tmp_path, stop_times__txt=st))
    assert find(report, "stop_times", "stop_sequence repeats")["status"] == vg.ERROR
    assert find(report, "logical_keys", "stop_times logical key")["status"] == vg.ERROR


def test_times_beyond_24h_are_valid(tmp_path):
    report = validate(tmp_path, build(tmp_path))
    over = find(report, "stop_times", "GTFS times >= 24:00:00")
    assert over["status"] == vg.PASS and over["count"] == 2
    assert over["max_time_secs"] == 25 * 3600 + 600
    assert find(report, "stop_times", "times do not go backwards")["status"] == vg.PASS


def test_invalid_time_relationships_are_errors(tmp_path):
    st = BASE["stop_times.txt"].replace("T1,08:20:00,08:21:00,S3,3,1",
                                        "T1,07:50:00,07:40:00,S3,3,1")
    report = validate(tmp_path, build(tmp_path, stop_times__txt=st))
    assert find(report, "stop_times", "departure_time >= arrival_time")["count"] == 1
    back = find(report, "stop_times", "times do not go backwards")
    assert back["status"] == vg.ERROR and back["count"] == 1


def test_trip_without_stop_times_and_missing_edge_time(tmp_path):
    trips = BASE["trips.txt"] + "R1,WK,T9,Nowhere,0,,\n"
    st = BASE["stop_times.txt"].replace("T3,10:45:00,10:45:00,S4,2,0", "T3,,,S4,2,0") \
        .replace("T3,10:45:00,10:45:00,S4,2,1", "T3,,,S4,2,0")
    report = validate(tmp_path, build(tmp_path, trips__txt=trips, stop_times__txt=st))
    no_st = find(report, "stop_times", "trips without stop_times")
    assert no_st["status"] == vg.ERROR and no_st["examples"] == ["T9"]
    assert find(report, "stop_times", "first/last stop")["status"] == vg.ERROR


def test_invalid_frequency_headway_and_overlap(tmp_path):
    freq = BASE["frequencies.txt"] + "T1,06:30:00,08:00:00,900\n"
    clean = build(tmp_path, frequencies__txt=freq)
    # A headway of 0 with a real window would be rejected by the cleaner;
    # simulate it in clean data to prove the validator catches it independently.
    rewrite_parquet(clean / "frequencies.parquet", "headway_secs", 0, 0)
    report = validate(tmp_path, clean)
    hw = find(report, "frequencies", "headway_secs > 0")
    assert hw["status"] == vg.ERROR and hw["count"] == 1
    assert find(report, "frequencies", "frequency windows do not overlap")["status"] == vg.ERROR
    sec = report["sections"]["frequencies"]
    assert sec["single_departure_rows"] == 1 and sec["headway_le_zero_rows"] == 2


def test_start_after_end_frequency_is_error(tmp_path):
    clean = build(tmp_path)
    rewrite_parquet(clean / "frequencies.parquet", "end_time_secs", 0, 3600)
    report = validate(tmp_path, clean)
    assert find(report, "frequencies", "start_time <= end_time")["status"] == vg.ERROR


def test_calendar_validation(tmp_path):
    cal = BASE["calendar.txt"] + "BAD,1,0,0,0,0,0,0,20261231,20260101\nNONE,0,0,0,0,0,0,0,20260101,20260301\n"
    cd = BASE["calendar_dates.txt"] + "WK,20260106,1\nWE,20260105,2\n"
    report = validate(tmp_path, build(tmp_path, calendar__txt=cal, calendar_dates__txt=cd))
    assert find(report, "calendar", "calendar start_date <= end_date")["status"] == vg.ERROR
    assert find(report, "calendar", "calendar services with no weekday")["count"] == 1
    assert find(report, "calendar", "calendar services expired")["count"] == 2  # BAD and NONE
    consistency = find(report, "calendar", "calendar_dates consistent with calendar")
    assert consistency["status"] == vg.WARNING and consistency["count"] == 2
    assert find(report, "calendar", "services not used by trips")["count"] == 2


def test_fare_validation(tmp_path):
    rules = BASE["fare_rules.txt"] + "F9,R1,Z1,Z1\nF2,R1,Z1,Z2\n,,,\n"
    report = validate(tmp_path, build(tmp_path, fare_rules__txt=rules))
    fid = find(report, "foreign_keys", "fare_rules.fare_id")
    assert fid["status"] == vg.ERROR and fid["missing_parent_rows"] == 1 and fid["null_rows"] == 1
    amb = find(report, "fares", "same selectors mapped to several fare_ids")
    assert amb["status"] == vg.WARNING and amb["count"] == 1
    assert find(report, "fares", "fare_rules selector null pattern")["count"] == 1
    assert find(report, "fares", "currency_type")["status"] == vg.PASS
    assert find(report, "fares", "transfers values")["status"] == vg.PASS


def test_lineage_mismatch_is_error(tmp_path):
    clean = build(tmp_path)
    meta = json.loads((clean / "metadata.json").read_text(encoding="utf-8"))
    meta["feed_version"] = "v2"
    (clean / "metadata.json").write_text(json.dumps(meta), encoding="utf-8")
    report = validate(tmp_path, clean)
    assert find(report, "lineage", "feed_version")["status"] == vg.ERROR
    assert find(report, "lineage", "lineage columns match")["status"] == vg.ERROR
    assert report["overall_status"] == vg.ERROR


def test_raw_zip_hash_mismatch_is_error(tmp_path):
    clean = build(tmp_path)
    manifest_path = tmp_path / "raw" / "2026-10-01" / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["zip_sha256"] = "0" * 64
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    assert find(validate(tmp_path, clean), "lineage", "feed SHA-256")["status"] == vg.ERROR


def test_row_count_mismatch_is_error(tmp_path):
    clean = build(tmp_path)
    table = pq.read_table(clean / "stops.parquet")
    pq.write_table(table.slice(0, table.num_rows - 1), clean / "stops.parquet")  # lose a row
    report = validate(tmp_path, clean)
    rc = find(report, "row_counts", "stops row counts")
    assert rc["status"] == vg.ERROR
    assert "raw 4 != clean 3" in rc["summary"]
    assert not report["sections"]["row_counts"]["tables"]["stops"]["source_rows_complete"]


def test_shapes_streaming_across_batches(tmp_path, monkeypatch):
    shapes = ("shape_id,shape_pt_lat,shape_pt_lon,shape_pt_sequence\n"
              "SH1,13.70,100.50,1\nSH1,13.70,100.50,2\nSH1,13.71,100.51,5\n"   # repeat + gap
              "SH2,13.80,100.60,1\nSH2,13.80,100.60,1\n"                       # exact duplicate
              "SH1,13.72,100.52,6\n"                                           # SH1 split
              "SH3,13.90,100.70,1\n")                                          # single point
    monkeypatch.setattr(vg, "BATCH_ROWS", 2)                                   # force batch edges
    report = validate(tmp_path, build(tmp_path, shapes__txt=shapes))
    sec = report["sections"]["shapes"]
    assert sec["rows"] == 7 and sec["shapes"] == 3
    assert find(report, "shapes", "exact duplicate rows")["count"] == 1
    assert find(report, "shapes", "duplicate logical key")["status"] == vg.WARNING  # identical
    assert find(report, "shapes", "repeated consecutive coordinates")["count"] == 2
    assert find(report, "shapes", "sequence ordering in file")["count"] == 2  # 1 break + 1 split
    assert find(report, "shapes", "shapes with fewer than 2 points")["count"] == 1
    assert find(report, "shapes", "shapes not used by trips")["count"] == 2


def test_validation_writes_lightweight_log_rows(tmp_path):
    validate(tmp_path, build(tmp_path))
    with (tmp_path / "scrape_log.csv").open(newline="", encoding="utf-8") as fh:
        rows = [r for r in csv.DictReader(fh) if r["stage"] == "validate"]
    assert len(rows) == 1 + len(BASE)
    run = next(r for r in rows if r["file"] == "__run__")
    assert run["status"] == vg.WARNING and run["rejected_rows"] == "0"
    assert {r["file"] for r in rows} == {"__run__", *BASE}


def test_identical_frequency_duplicate_is_warning_not_overlap_error(tmp_path):
    freq = BASE["frequencies.txt"] + "T1,06:00:00,07:00:00,600\n"
    report = validate(tmp_path, build(tmp_path, frequencies__txt=freq))
    assert find(report, "frequencies", "duplicate (trip_id")["status"] == vg.WARNING
    assert find(report, "frequencies", "frequency windows do not overlap")["status"] == vg.PASS
    assert report["errors"] == []


def test_mirrored_fare_checks_are_not_double_counted(tmp_path):
    rules = BASE["fare_rules.txt"] + "F9,R1,Z1,Z1\n"
    report = validate(tmp_path, build(tmp_path, fare_rules__txt=rules))
    names = [(e["section"], e["check"]) for e in report["errors"]]
    assert names.count(("foreign_keys", "fare_rules.fare_id -> fare_attributes.fare_id")) == 1
    assert not any(sec == "fares" and "references" in chk for sec, chk in names)
    assert find(report, "fares", "fare_rules.fare_id references")["status"] == vg.ERROR


def test_duplicated_source_row_breaks_coverage(tmp_path):
    clean = build(tmp_path)
    rewrite_parquet(clean / "stops.parquet", "source_row", 1, 1)   # row 2 claims to be row 1
    report = validate(tmp_path, clean)
    assert report["sections"]["row_counts"]["tables"]["stops"]["source_rows_complete"] is False
    assert find(report, "row_counts", "stops row counts")["status"] == vg.ERROR
