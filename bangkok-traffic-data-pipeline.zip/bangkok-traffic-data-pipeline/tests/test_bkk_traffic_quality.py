"""Phase 9.7: BKK Traffic quality pipeline (quality.py, event-type refresh, missing-eid detect /
recover, client deadline, DAG bkk_traffic_quality).

* No network: Longdo is replaced by fake clients / a fake HTTP session and a fake clock.
* Database tests use ONLY the isolated namtang_bkk_traffic_test_db through the guarded fixtures of
  test_bkk_traffic_pipeline (pipeline code runs as a bkk_traffic_app member).
* Report files go to pytest temporary directories.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))

from bkk_traffic import client as client_mod, config, quality, scrape, storage  # noqa: E402
from bkk_traffic.client import DeadlineExceeded, LongdoClient  # noqa: E402

from test_bkk_traffic_pipeline import EVENT_TYPES, FakeClient, api_item, dsns, env, q  # noqa: E402,F401

NOW = datetime(2026, 10, 3, 1, 30, 0)          # Bangkok wall-clock used as "now" in report tests
DAY = date(2026, 10, 2)                          # report day = yesterday


# --------------------------------------------------------------------------
# Seed helpers (test DB only)
# --------------------------------------------------------------------------

def baseline(env):
    q(env["admin"], "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('t', 'parquet:t', 'success')")
    return q(env["admin"], "SELECT max(load_id) FROM bkk_traffic.load_history")[0][0]


def incident(env, load_id, eid, start, **over):
    row = {"eid": eid, "title": f"t{eid}", "start_time": start, "traffic_relevance": "direct", "is_accident": 0,
           "is_bangkok": 1, "fetched_via": "realtime", "first_seen_at": start, "last_seen_at": start,
           "baseline_load_id": load_id, "latitude": 13.75, "longitude": 100.5, "event_type": "Trafficjam",
           "createtime": start, "province_guess": "bangkok", "severity": 1, "stop_time": start}
    row.update(over)
    cols = ", ".join(row)
    q(env["admin"], f"INSERT INTO bkk_traffic.incidents ({cols}) VALUES ({', '.join(['%s'] * len(row))})",
      *row.values())


def report_files(env, day=DAY):
    return env["data"] / "quality" / f"dt={day.isoformat()}"


def checks_of(report):
    return {c["check"]: c for c in report["checks"]}


# --------------------------------------------------------------------------
# quality.py (test DB)
# --------------------------------------------------------------------------

def test_empty_tables_report_has_data_fail(env):
    report = quality.run_quality_checks(DAY, now=NOW)
    assert report["overall"] == "FAIL" and [c["check"] for c in report["checks"]] == ["has_data"]
    out = report_files(env)
    assert {p.name for p in out.iterdir()} == {"report.json", "report.md", "quarantine_rows.csv",
                                               "missing_days.csv", "missing_eids_pending.csv"}
    assert json.loads((out / "report.json").read_text(encoding="utf-8"))["overall"] == "FAIL"


def test_field_null_checks_are_type_aware(env):
    lid = baseline(env)
    incident(env, lid, 1, "2026-10-02 08:00:00")
    incident(env, lid, 2, "2026-10-02 09:00:00", latitude=None, longitude=None, stop_time=None, severity=None)
    incident(env, lid, 3, "2026-10-02 10:00:00", title="", event_type="Unknown")
    incident(env, lid, 4, "2026-10-02 11:00:00", event_type="")
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01"))
    v = c["field_null_pct"]["value"]
    assert (v["latitude"], v["longitude"], v["stop_time"], v["severity"]) == (25.0, 25.0, 25.0, 25.0)
    assert (v["title"], v["event_type"], v["event_type_unknown"], v["start_time"]) == (25.0, 25.0, 25.0, 0.0)
    assert c["field_null_pct"]["status"] == "FAIL"                    # worst lat/lon/start 25 % >= 5 %


def test_validity_quarantine_flags_duplicates_sources(env):
    lid = baseline(env)
    incident(env, lid, 10, "2026-10-02 08:00:00", dq_flags="R4_stop_before_start,R6_bad_severity")
    incident(env, lid, 11, "2026-10-02 08:00:00", is_duplicate=1, fetched_via="backfill")
    incident(env, lid, 12, "2026-10-02 08:00:00", province_guess="bangkok(text)", is_bangkok=0)
    q(env["admin"], "INSERT INTO bkk_traffic.bronze_incidents VALUES (13, '{}', 'realtime', now(), now(), NULL)")
    q(env["admin"], "INSERT INTO bkk_traffic.quarantine VALUES (13, 'R5_no_title,R3_bad_start_time', '{}', "
                    "'2026-10-02 08:00:00')")
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01"))
    assert c["non_bangkok_rows"]["value"] == 1 and c["non_bangkok_rows"]["status"] == "FAIL"
    assert c["bangkok_by_text_only"]["value"] == 1 and c["bangkok_by_text_only"]["status"] == "WARN"
    assert c["clean_rule_flags"]["value"] == {"R4_stop_before_start": 1, "R6_bad_severity": 1}
    assert c["quarantine_rows"]["value"] == {"rows": 1, "R5_no_title": 1, "R3_bad_start_time": 1}
    assert c["quarantine_rows"]["status"] == "FAIL"                  # 1 / 4 = 25 %
    assert c["duplicate_reports_removed"]["value"] == 1
    assert c["rows_by_source"]["value"] == {"realtime": 2, "backfill": 1}
    assert c["bronze_not_cleaned"]["value"] == 1
    rows = list(csv.reader(open(report_files(env) / "quarantine_rows.csv", encoding="utf-8-sig")))
    assert rows == [["eid", "reasons", "detected_at"], ["13", "R5_no_title,R3_bad_start_time", "2026-10-02 08:00:00"]]


def test_freshness_uses_bangkok_now(env):
    lid = baseline(env)
    incident(env, lid, 20, "2026-10-03 00:00:00", createtime="2026-10-03 00:30:00")
    incident(env, lid, 21, "2026-10-03 00:00:00", createtime="2026-10-03 05:00:00")   # future: ignored
    with storage.connect() as conn:
        storage.set_checkpoint(conn, "realtime", {"last_success": "2026-10-03 01:00:00"})
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01"))
    assert c["realtime_last_success_hours"]["value"] == 0.5 and c["realtime_last_success_hours"]["status"] == "OK"
    assert c["newest_event_age_hours"]["value"] == 1.0 and "2026-10-03 00:30:00" in c["newest_event_age_hours"]["detail"]


def test_default_now_is_utc_plus_7(env, monkeypatch):
    seen = {}
    monkeypatch.setattr(quality, "_write_report", lambda day_s, checks, extras: seen.update(day=day_s) or {})
    lid = baseline(env)
    incident(env, lid, 25, "2026-10-02 08:00:00")
    quality.run_quality_checks()
    expected = (datetime.now(timezone.utc) + timedelta(hours=7)).date() - timedelta(days=1)
    assert seen["day"] == expected.isoformat()


def test_day_boundaries_and_7_day_comparison(env):
    lid = baseline(env)
    incident(env, lid, 30, "2026-10-02 00:00:00", is_accident=1)        # first second of the report day
    incident(env, lid, 31, "2026-10-02 23:59:59")                        # last second of the report day
    incident(env, lid, 32, "2026-10-03 00:00:00")                        # next day: excluded
    incident(env, lid, 33, "2026-10-01 23:59:59")                        # previous day: in the 7-day window
    for i, d in enumerate(range(25, 31)):                                # 2026-09-25 .. 2026-09-30
        incident(env, lid, 40 + i, f"2026-09-{d} 12:00:00", is_accident=1)
    incident(env, lid, 50, "2026-09-24 23:59:59")                        # 8 days before: excluded
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-09-20"))
    assert c["volume_vs_7d"]["value"] == {"day": 2, "avg_7d": 1.0}
    assert c["accident_share_vs_7d"]["value"] == {"day": 50.0, "prev_7d": 85.7}


def test_missing_and_low_days_in_the_coverage_window(env):
    lid = baseline(env)
    for d, n in (("2026-09-28", 10), ("2026-09-29", 2), ("2026-10-01", 10), ("2026-10-02", 10)):
        for i in range(n):
            incident(env, lid, int(d.replace("-", "")[2:]) * 100 + i, f"{d} 10:00:00")
    report = quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-09-27")
    c = checks_of(report)
    assert report["coverage_start"] == "2026-09-27"
    assert c["days_without_incidents"]["value"] == 1 and report["missing_days"] == ["2026-09-30"]
    assert c["days_abnormally_low"]["value"] == 1 and report["low_days"] == ["2026-09-29"]
    rows = list(csv.reader(open(report_files(env) / "missing_days.csv", encoding="utf-8-sig")))
    assert rows == [["date", "problem"], ["2026-09-30", "no_incidents"], ["2026-09-29", "abnormally_low"]]


def test_default_coverage_start_is_documented():
    assert quality.DEFAULT_COVERAGE_START == "2015-12-29"


def test_15_minute_coverage_and_first_day(env):
    lid = baseline(env)
    incident(env, lid, 60, "2026-10-02 08:00:00")
    for ts, local in ((1790874000, "2026-10-02 00:00:00"), (1790874840, "2026-10-02 00:14:00"),
                      (1790874900, "2026-10-02 00:15:00")):
        q(env["admin"], "INSERT INTO bkk_traffic.traffic_index VALUES (%s, %s, 3.0, %s)", ts, local, local)
    q(env["admin"], "INSERT INTO bkk_traffic.travel_times (route, fetched_at) VALUES ('r', '2026-10-02 23:50:00')")
    report = quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01")
    c = checks_of(report)
    assert c["traffic_index_coverage_pct"]["value"] == round(100 * 2 / 96, 1)          # slots 0 and 1 of 96
    assert len(report["traffic_index_missing_slots"]) == 94
    assert c["travel_times_coverage_pct"]["value"] == 100.0                            # started at slot 95
    report = quality.run_quality_checks(date(2026, 10, 1), now=NOW, coverage_start="2026-09-30")
    assert checks_of(report)["traffic_index_coverage_pct"]["value"] is None            # not started yet


def test_5_minute_history_days(env):
    lid = baseline(env)
    incident(env, lid, 70, "2026-10-02 08:00:00")
    base = 1790787600                                                                  # 2026-10-01 00:00 Bangkok
    rows = [(base + 300 * i, (datetime(2026, 10, 1) + timedelta(minutes=5 * i)).strftime("%Y-%m-%d %H:%M:%S"))
            for i in range(288 + 100)]                                                 # full day 1, partial day 2
    with storage.connect() as conn:
        conn.cursor().executemany("INSERT INTO traffic_index_history (ts, ts_local, index_value, source) "
                                  "VALUES (%s, %s, 1, 'history:2026')", rows)
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01"))
    assert c["traffic_index_5min_incomplete_days"]["value"] == 0                      # the last day is not counted


def test_failed_runs_window_and_missing_eids(env):
    lid = baseline(env)
    incident(env, lid, 80, "2026-10-02 08:00:00")
    for started, status in (("2026-10-02 01:31:00", "failed"), ("2026-10-02 01:29:00", "failed"),
                            ("2026-10-03 01:00:00", "success")):
        q(env["admin"], "INSERT INTO bkk_traffic.scrape_runs (job, started_at, status) VALUES ('realtime', %s, %s)",
          started, status)
    q(env["admin"], "INSERT INTO bkk_traffic.missing_eids (eid, detected_at, status) VALUES "
                    "(5, now(), 'pending'), (6, now(), 'pending'), (7, now(), 'recovered')")
    report = quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01")
    c = checks_of(report)
    assert c["failed_runs_24h"]["value"] == 1 and c["failed_runs_24h"]["status"] == "WARN"   # 01:29 is outside
    assert c["missing_eids_pending"]["value"] == 2
    rows = list(csv.reader(open(report_files(env) / "missing_eids_pending.csv", encoding="utf-8-sig")))
    assert rows == [["eid"], ["6"], ["5"]]


def test_parquet_check_and_report_markdown(env):
    from bkk_traffic import parquet_export, publish

    lid = baseline(env)
    incident(env, lid, 90, "2026-10-02 08:00:00")
    c = checks_of(quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01"))
    assert c["parquet_files_valid"]["status"] == "FAIL" and c["parquet_files_valid"]["value"] == 4   # no manifests
    publish.publish_parquet(publish.gate_checks(allow_drop=True))
    report = quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01")
    assert checks_of(report)["parquet_files_valid"]["status"] == "OK"
    md = (report_files(env) / "report.md").read_text(encoding="utf-8")
    assert md.startswith(f"# Data Quality Report {DAY.isoformat()}") and "| parquet_files_valid | ✅ OK |" in md
    assert parquet_export.PARQUET_DIR == env["data"] / "parquet"


def test_overall_status_drives_the_gate_result(env):
    lid = baseline(env)
    incident(env, lid, 95, "2026-10-02 08:00:00")
    report = quality.run_quality_checks(DAY, now=NOW, coverage_start="2026-10-01")
    statuses = {c["status"] for c in report["checks"]}
    assert report["overall"] == ("FAIL" if "FAIL" in statuses else "WARN" if "WARN" in statuses else "OK")


def test_quality_code_is_postgresql_and_key_free():
    code = (ROOT / "data" / "scraper" / "bkk_traffic" / "quality.py").read_text(encoding="utf-8").split('"""', 2)[-1]
    for banned in ("substr(", "datetime('now'", "date('now'", "date.today()", "datetime.now()", "sqlite3", "longdo_api_key"):
        assert banned not in code, banned


# --------------------------------------------------------------------------
# Event types (test DB)
# --------------------------------------------------------------------------

def event_types(env):
    return q(env["admin"], "SELECT id, name, name_en, icon, severity, xmin::text FROM bkk_traffic.event_types ORDER BY id")


def test_refresh_event_types_upserts_without_rewriting(env, monkeypatch):
    assert scrape.refresh_event_types() == {"received": 3, "inserted": 3, "updated": 0, "unchanged": 0, "requests": 1}
    before = event_types(env)
    assert scrape.refresh_event_types()["unchanged"] == 3 and event_types(env) == before
    changed = [dict(t) for t in EVENT_TYPES]
    changed[0]["icon"] = "accident-v2"
    monkeypatch.setattr(FakeClient, "event_types", lambda self: changed[:2])   # a shorter list: nothing deleted
    assert scrape.refresh_event_types() == {"received": 2, "inserted": 0, "updated": 1, "unchanged": 1, "requests": 0}
    assert [r[:4] for r in event_types(env)] == [(3, "อุบัติเหตุ", "Accident", "accident-v2"),
                                                 (10, "รถติด", "Trafficjam", "t.png"), (20, "ไฟไหม้", "Fire", "f.png")]


@pytest.mark.parametrize("payload, match", [
    ({"id": 1}, "non-empty JSON list"),
    ([], "non-empty JSON list"),
    (["x"], "not an object"),
    ([{"id": "1", "name": "x"}], "must be an integer"),
    ([{"id": True, "name": "x"}], "must be an integer"),
    ([{"name": "x"}], "must be an integer"),
    ([{"id": 1, "name": "a"}, {"id": 1, "name": "b"}], "duplicate event type id 1"),
    ([{"id": 1, "severity": "high"}], "severity must be an integer"),
    ([{"id": 1, "name": 5}], "name must be text"),
])
def test_malformed_event_types_change_nothing(env, monkeypatch, payload, match):
    scrape.refresh_event_types()
    before = event_types(env)
    monkeypatch.setattr(FakeClient, "event_types", lambda self: payload)
    with pytest.raises(scrape.InvalidEventTypes, match=match):
        scrape.refresh_event_types()
    assert event_types(env) == before


def test_event_type_api_failure_changes_nothing(env, monkeypatch):
    scrape.refresh_event_types()
    before = event_types(env)

    def boom(self):
        raise RuntimeError("GET https://traffic.longdo.com/geteventtype failed after 4 tries: HTTP 503")

    monkeypatch.setattr(FakeClient, "event_types", boom)
    with pytest.raises(RuntimeError, match="after 4 tries"):
        scrape.refresh_event_types()
    assert event_types(env) == before


# --------------------------------------------------------------------------
# Missing eids: detection (test DB)
# --------------------------------------------------------------------------

def seen(env, *eids):
    for e in eids:
        q(env["admin"], "INSERT INTO bkk_traffic.seen_eids VALUES (%s, 0, now())", e)


def missing(env):
    return [r[0] for r in q(env["admin"], "SELECT eid FROM bkk_traffic.missing_eids ORDER BY eid")]


def test_detection_without_a_baseline_does_nothing(env):
    seen(env, 100, 105)
    assert scrape.detect_missing_eids()["reason"].startswith("no coverage floor")
    assert missing(env) == []


def test_detection_uses_the_baseline_floor_and_persists_it(env):
    lid = baseline(env)
    incident(env, lid, 1000, "2026-10-02 08:00:00")
    incident(env, lid, 990, "2026-10-02 08:00:00")
    seen(env, 950, 1001, 1003, 1006)                                    # 950 below the floor: ignored
    q(env["admin"], "INSERT INTO bkk_traffic.bronze_incidents VALUES (1004, '{}', 'realtime', now(), now(), NULL)")
    result = scrape.detect_missing_eids()
    assert result == {"range": [1001, 1006], "candidates": 2, "new_missing": 2, "truncated": 0}
    assert missing(env) == [1002, 1005]
    cp = q(env["admin"], "SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'missing_eid_detection'")[0][0]
    assert cp["floor_eid"] == 1000
    q(env["admin"], "INSERT INTO bkk_traffic.bronze_incidents VALUES (1000, '{}', 'realtime', now(), now(), now())")
    q(env["admin"], "UPDATE bkk_traffic.incidents SET baseline_load_id = NULL WHERE eid = 1000")  # taken over later
    again = scrape.detect_missing_eids()                                # floor stays 1000, nothing new
    assert again["range"] == [1001, 1006] and again["new_missing"] == 0 and missing(env) == [1002, 1005]


def test_no_missing_when_everything_was_seen(env):
    lid = baseline(env)
    incident(env, lid, 2000, "2026-10-02 08:00:00")
    seen(env, 2001, 2002, 2003)
    assert scrape.detect_missing_eids()["new_missing"] == 0 and missing(env) == []


def test_detection_cap_keeps_the_newest(env):
    lid = baseline(env)
    incident(env, lid, 3000, "2026-10-02 08:00:00")
    seen(env, 3010)
    result = scrape.detect_missing_eids(max_new=4)
    assert result["candidates"] == 9 and result["new_missing"] == 4 and result["truncated"] == 5
    assert missing(env) == [3006, 3007, 3008, 3009]


# --------------------------------------------------------------------------
# Missing eids: recovery (test DB, fake client + fake clock)
# --------------------------------------------------------------------------

class Clock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now


class RecoverClient:
    """Fake LongdoClient for recovery: answers per eid, advances the fake clock per request,
    honours the deadline like the real client (no request may start after it)."""
    answers: dict = {}
    clock: Clock = None
    request_seconds = 12.0
    instances: list = []

    def __init__(self, source_tag="misc", deadline=None):
        self.source_tag, self.deadline, self.request_count = source_tag, deadline, 0
        type(self).instances.append(self)

    def event_by_id(self, eid):
        if self.deadline is not None and self.clock.now + self.request_seconds > self.deadline:
            raise DeadlineExceeded("no time left for a request")
        self.request_count += 1
        self.clock.now += self.request_seconds
        answer = type(self).answers.get(eid, "default")
        if answer == "default":
            return api_item(eid)
        if isinstance(answer, Exception):
            raise answer
        return answer

    def event_types(self):
        return [dict(t) for t in EVENT_TYPES]

    def save_raw(self, name, data):
        pass


@pytest.fixture
def recover_env(env, monkeypatch):
    clock = Clock()
    RecoverClient.answers, RecoverClient.clock, RecoverClient.instances = {}, clock, []
    RecoverClient.request_seconds = 12.0
    monkeypatch.setattr(scrape, "LongdoClient", RecoverClient)
    monkeypatch.setattr(scrape.time, "monotonic", clock.monotonic)
    scrape.refresh_event_types()
    return env


def pend(env, *eids):
    for e in eids:
        q(env["admin"], "INSERT INTO bkk_traffic.missing_eids (eid, detected_at, status) VALUES (%s, now(), 'pending')", e)


def statuses(env):
    return dict(q(env["admin"], "SELECT eid, status FROM bkk_traffic.missing_eids"))


def test_recovery_success_failure_and_partial(recover_env):
    pend(recover_env, 501, 502, 503, 504, 505)
    RecoverClient.answers = {502: None, 503: RuntimeError("HTTP 503"), 504: {"eid": "999", "title": "x"},
                             505: "not a dict"}
    result = scrape.recover_missing_eids(30, 360)
    assert {k: result[k] for k in ("attempted", "recovered", "not_available", "failed", "remaining_pending",
                                   "stop_reason")} == {"attempted": 5, "recovered": 1, "not_available": 1, "failed": 3,
                                                       "remaining_pending": 3, "stop_reason": "done"}
    assert statuses(recover_env) == {501: "recovered", 502: "not_available", 503: "pending", 504: "pending",
                                     505: "pending"}
    assert q(recover_env["admin"], "SELECT count(*) FROM bkk_traffic.incidents WHERE eid = 501")[0][0] == 1
    assert q(recover_env["admin"], "SELECT count(*) FROM bkk_traffic.incidents WHERE eid = 999")[0][0] == 0
    assert dict(q(recover_env["admin"], "SELECT eid, tries FROM bkk_traffic.missing_eids WHERE eid IN (503, 504)")) \
        == {503: 1, 504: 1}
    run = q(recover_env["admin"], "SELECT job, status, items, note FROM bkk_traffic.scrape_runs WHERE job = 'recover'")[0]
    assert run[:3] == ("recover", "success", 5) and "remaining_pending=3" in run[3] and "stop_reason=done" in run[3]


def test_recovery_stops_at_30_eids(recover_env):
    RecoverClient.request_seconds = 1.0
    pend(recover_env, *range(600, 640))                                   # 40 pending
    result = scrape.recover_missing_eids(30, 360)
    assert result["attempted"] == 30 and result["stop_reason"] == "limit" and result["remaining_pending"] == 10
    attempted = [e for e, s in statuses(recover_env).items() if s != "pending"]
    assert sorted(attempted) == list(range(610, 640))                     # newest first


def test_recovery_stops_at_the_time_limit(recover_env):
    pend(recover_env, *range(700, 730))                                   # 30 pending, 12 s per request
    result = scrape.recover_missing_eids(30, 60)
    assert result["attempted"] == 5 and result["stop_reason"] == "time" and result["remaining_pending"] == 25
    assert RecoverClient.instances[-1].deadline == 1000.0 + 60            # the deadline is passed to the client
    assert result["requests"] == 5 and result["seconds"] <= 60


def test_default_limits_are_30_eids_and_360_seconds(recover_env):
    assert (config.DEFAULT_RECOVER_PER_RUN, config.DEFAULT_RECOVER_MAX_SECONDS) == (30, 360)
    pend(recover_env, *range(800, 840))
    RecoverClient.request_seconds = 1.0
    result = scrape.recover_missing_eids()
    assert (result["limit"], result["max_seconds"], result["attempted"]) == (30, 360, 30)


def test_recovery_api_failure_keeps_everything_pending(recover_env):
    pend(recover_env, 901, 902)
    RecoverClient.answers = {901: RuntimeError("down"), 902: RuntimeError("down")}
    result = scrape.recover_missing_eids(30, 360)
    assert (result["failed"], result["recovered"], result["remaining_pending"]) == (2, 0, 2)
    assert set(statuses(recover_env).values()) == {"pending"}


def test_recovery_needs_no_api_key(recover_env, monkeypatch):
    monkeypatch.delenv("AIRFLOW_VAR_LONGDO_API_KEY", raising=False)
    pend(recover_env, 950)
    assert scrape.recover_missing_eids(30, 360)["recovered"] == 1
    for path in (ROOT / "data" / "scraper" / "bkk_traffic" / "scrape.py", ROOT / "airflow" / "dags" / "bkk_traffic_quality.py"):
        body = path.read_text(encoding="utf-8").split('"""', 2)[-1]
        assert "Variable.get(\"longdo_api_key\"" not in body and "longdo_api_key\")" not in body


def test_nothing_pending_is_a_no_op(recover_env):
    result = scrape.recover_missing_eids(30, 360)
    assert (result["attempted"], result["requests"], result["stop_reason"]) == (0, 0, "done")


# --------------------------------------------------------------------------
# LongdoClient deadline (no network; fake session, fake time, no-op lock)
# --------------------------------------------------------------------------

class FakeTime:
    def __init__(self):
        self.t = 1_000_000.0
        self.sleeps = []

    def time(self):
        return self.t

    def monotonic(self):
        return self.t

    def sleep(self, s):
        self.sleeps.append(s)
        self.t += s


class NoLock:
    LOCK_EX = LOCK_UN = 0

    @staticmethod
    def flock(fh, op):
        return None


class Resp:
    def __init__(self, status=200, payload=None):
        self.status_code, self._payload = status, payload

    def json(self):
        return self._payload

    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}")


class Session:
    def __init__(self, ft, responses, seconds=1.0):
        self.ft, self.responses, self.seconds, self.timeouts, self.headers = ft, list(responses), seconds, [], {}

    def get(self, url, params=None, timeout=None):
        self.timeouts.append(timeout)
        self.ft.t += self.seconds
        r = self.responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r


@pytest.fixture
def fake_client_env(tmp_path, monkeypatch):
    ft = FakeTime()
    monkeypatch.setattr(client_mod, "time", ft)
    monkeypatch.setattr(client_mod, "fcntl", NoLock)
    monkeypatch.setattr(config, "CHECKPOINT_DIR", tmp_path)
    monkeypatch.setattr(config, "RATE_LOCK_FILE", tmp_path / ".rate_limit.lock")
    return ft


def make(ft, responses, deadline_in=None, seconds=1.0):
    c = LongdoClient("t", deadline=None if deadline_in is None else ft.t + deadline_in)
    c.session = Session(ft, responses, seconds)
    return c


def test_no_deadline_keeps_the_original_retries(fake_client_env):
    import requests
    ft = fake_client_env
    c = make(ft, [requests.ConnectionError("x")] * 3 + [Resp(payload={"item": [{"eid": 1}]})])
    assert c.event_by_id(1) == {"eid": 1}
    assert [s for s in ft.sleeps if s >= 30] == [30, 60, 90] and c.session.timeouts == [config.REQUEST_TIMEOUT_SEC] * 4


def test_deadline_stops_retries_and_caps_the_timeout(fake_client_env):
    import requests
    ft = fake_client_env
    c = make(ft, [requests.ConnectionError("x"), Resp(payload={"item": []})], deadline_in=25)
    with pytest.raises(DeadlineExceeded, match="no time left to retry"):
        c.event_by_id(1)                                                  # the 30 s backoff would pass the deadline
    assert c.session.timeouts[0] <= 25 and c.request_count == 0 and all(s < 30 for s in ft.sleeps)


def test_deadline_blocks_a_crawl_delay_wait_it_cannot_afford(fake_client_env):
    ft = fake_client_env
    config.RATE_LOCK_FILE.write_text(str(ft.t))                           # last request just now: 10 s wait needed
    c = make(ft, [Resp(payload={"item": []})], deadline_in=5)
    with pytest.raises(DeadlineExceeded, match="crawl-delay"):
        c.event_by_id(1)
    assert c.session.timeouts == []                                        # no request was sent


def test_request_within_the_deadline_succeeds(fake_client_env):
    ft = fake_client_env
    c = make(ft, [Resp(payload={"item": [{"eid": 7}]})], deadline_in=120)
    assert c.event_by_id(7) == {"eid": 7} and c.session.timeouts[0] <= 120


# --------------------------------------------------------------------------
# DAG (only inside the Airflow image)
# --------------------------------------------------------------------------

def _dag_module():
    pytest.importorskip("airflow.sdk")
    spec = importlib.util.spec_from_file_location("bkk_quality_under_test", ROOT / "airflow" / "dags" / "bkk_traffic_quality.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_quality_dag_structure(monkeypatch):
    monkeypatch.delenv("BKK_TRAFFIC_SCHEDULE_ENABLED", raising=False)
    module = _dag_module()
    dag = module.quality_dag
    assert dag.dag_id == "bkk_traffic_quality"
    assert [t.task_id for t in dag.topological_sort()] == ["refresh_event_types", "detect_missing_eids",
                                                           "recover_missing_eids", "quality_checks", "gate"]
    api_pool = module.API_POOL
    assert {t.task_id: t.pool for t in dag.tasks} == {"refresh_event_types": api_pool, "detect_missing_eids": "default_pool",
                                                      "recover_missing_eids": api_pool, "quality_checks": "default_pool",
                                                      "gate": "default_pool"}
    assert dag.get_task("recover_missing_eids").execution_timeout == timedelta(minutes=8)
    assert module.quality_schedule() is None and dag.max_active_runs == 1 and not dag.catchup
    assert all(not t.multiple_outputs for t in dag.tasks)
    monkeypatch.setenv("BKK_TRAFFIC_SCHEDULE_ENABLED", "true")
    assert "0 1 * * *" in module.quality_schedule().summary


def test_report_day_comes_from_run_after_in_bangkok():
    module = _dag_module()
    import pendulum
    assert str(module.report_day_for(pendulum.datetime(2026, 10, 2, 18, 30, tz="UTC"))) == "2026-10-02"   # 01:30 BKK
    assert str(module.report_day_for(pendulum.datetime(2026, 10, 2, 16, 59, tz="UTC"))) == "2026-10-01"   # 23:59 BKK


@pytest.mark.parametrize("overall, expected", [("WARN", "success"), ("FAIL", "failed")])
def test_quality_dag_end_to_end(recover_env, monkeypatch, overall, expected):
    module = _dag_module()
    monkeypatch.setattr(module, "bkk_dsn", lambda: recover_env["app"])
    real = quality.run_quality_checks

    def forced(day, **kw):
        report = real(day, coverage_start="2026-10-01", **kw)
        report["overall"] = overall
        return report

    monkeypatch.setattr(quality, "run_quality_checks", forced)
    lid = baseline(recover_env)
    incident(recover_env, lid, 5000, "2026-10-02 08:00:00")
    seen(recover_env, 5002)
    run = module.quality_dag.test()
    states = {ti.task_id: ti.state for ti in run.get_task_instances()}
    upstream = {k: v for k, v in states.items() if k != "gate"}
    assert set(upstream.values()) == {"success"}, states
    assert states["gate"] == expected
    assert statuses(recover_env) == {5001: "recovered"}
    assert any(p.name.startswith("dt=") for p in (recover_env["data"] / "quality").iterdir())
