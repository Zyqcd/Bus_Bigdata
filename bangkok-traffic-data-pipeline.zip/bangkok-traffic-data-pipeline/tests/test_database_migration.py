from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MIGRATION_DIR = ROOT / "database" / "migrations" / "namtang"
LOAD_DIR = ROOT / "database" / "load"


def test_namtang_migrations_exist_in_order():
    assert [path.name for path in sorted(MIGRATION_DIR.glob("*.sql"))] == [
        "001_create_schema.sql",
        "002_create_tables.sql",
        "003_create_indexes.sql",
        "004_create_constraints.sql",
        "005_create_load_history.sql",
    ]


def test_source_tables_and_isolated_analysis_schema_are_declared():
    sql = (MIGRATION_DIR / "002_create_tables.sql").read_text(encoding="utf-8")
    for table in (
        "agency", "routes", "trips", "stop_times", "stops", "calendar",
        "calendar_dates", "shapes", "frequencies", "fare_attributes",
        "fare_rules", "feed_info",
    ):
        assert f"namtang.{table}" in sql
    assert "namtang_analysis.stop_times_analysis" in sql
    assert "unrealistic_segment_speed" in sql
    assert "zero_second_segment" in sql
    assert "public." not in sql.lower()


def test_loader_uses_copy_and_streams_batches():
    source = (LOAD_DIR / "load_namtang.py").read_text(encoding="utf-8")
    assert "iter_batches" in source
    assert "COPY" in source
    assert "--source-only" in source
    assert "5.96M" in source or "5.96" in source


def test_no_accident_objects_are_introduced_by_migrations_or_loader():
    for path in (*MIGRATION_DIR.glob("*.sql"), *LOAD_DIR.glob("*.py")):
        content = path.read_text(encoding="utf-8").lower()
        assert "create schema accident" not in content
        assert "create table accident" not in content
        assert "traffic_accident" not in content
