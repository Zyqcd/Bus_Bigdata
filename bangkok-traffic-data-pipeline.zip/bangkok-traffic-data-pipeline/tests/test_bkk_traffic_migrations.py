"""Phase 9.2: bkk_traffic migrations (database/migrations/bkk_traffic).

Static checks always run. Database checks run ONLY against the isolated
throwaway database `namtang_bkk_traffic_test_db` (BKK_TRAFFIC_TEST_DATABASE_URL,
e.g. host=127.0.0.1 port=5435 ...); production namtang_db (5433) and
itproject_db (5432) are refused by name, host and port before connecting.
The Namtang migrations are applied (read-only use of the files) into the same
test database to prove the two schemas coexist and the roles stay isolated.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
BKK_DIR = ROOT / "database" / "migrations" / "bkk_traffic"
BKK_MIGRATIONS = sorted(BKK_DIR.glob("*.sql"))
ROLLBACK = BKK_DIR / "rollback" / "rollback_bkk_traffic.sql"
NAMTANG_MIGRATIONS = sorted((ROOT / "database" / "migrations" / "namtang").glob("*.sql"))
TEST_DATABASE = "namtang_bkk_traffic_test_db"
ROLES = ("bkk_traffic_owner", "bkk_traffic_app", "bkk_traffic_readonly")
TABLES = {
    "bronze_incidents": ["eid"], "incidents": ["eid"], "quarantine": ["eid"], "seen_eids": ["eid"],
    "missing_eids": ["eid"], "traffic_index": ["ts"], "traffic_index_history": ["ts"],
    "travel_times": ["route", "fetched_at"], "event_types": ["id"], "checkpoints": ["job"],
    "scrape_runs": ["id"], "load_history": ["load_id"], "migration_history": ["version"],
}


def _code(path: Path) -> str:
    """SQL without -- comments (comments may name other schemas for documentation)."""
    return "\n".join(line.split("--", 1)[0] for line in path.read_text(encoding="utf-8").splitlines())


# --------------------------------------------------------------------------
# Static checks
# --------------------------------------------------------------------------

def test_bkk_migrations_are_numbered_and_contiguous():
    assert [p.name for p in BKK_MIGRATIONS] == [
        "001_create_schema.sql",
        "002_create_tables.sql",
        "003_create_indexes.sql",
        "004_create_constraints.sql",
        "005_create_roles_and_grants.sql",
        "006_parquet_baseline.sql",
    ]


@pytest.mark.parametrize("path", BKK_MIGRATIONS + [ROLLBACK], ids=lambda p: p.name)
def test_each_file_is_one_guarded_transaction(path):
    code = _code(path).strip()
    assert code.startswith("BEGIN;") and code.endswith("COMMIT;")
    assert "current_setting('bkk_traffic.expected_database', true) IS DISTINCT FROM current_database()" in code
    assert "lock_timeout" in code


@pytest.mark.parametrize("path", BKK_MIGRATIONS, ids=lambda p: p.name)
def test_each_migration_records_itself_and_stays_in_its_schema(path):
    code = _code(path)
    assert f"VALUES ('{path.stem}')" in code and "ON CONFLICT (version) DO NOTHING" in code
    lowered = code.lower()
    assert "namtang" not in lowered and "itproject" not in lowered
    assert "public." not in lowered
    assert not re.search(r"(^|;)\s*(drop|truncate)\s", lowered, re.MULTILINE)  # no destructive statements
    for statement in re.findall(r"create (?:table|index)[^;]*", lowered):
        assert "bkk_traffic." in statement


# --------------------------------------------------------------------------
# Isolated database
# --------------------------------------------------------------------------

def _isolated_dsn() -> str:
    dsn = os.environ.get("BKK_TRAFFIC_TEST_DATABASE_URL")
    if not dsn:
        pytest.skip("BKK_TRAFFIC_TEST_DATABASE_URL not set (start namtang_bkk_traffic_test_db)")
    psycopg = pytest.importorskip("psycopg")
    from psycopg.conninfo import conninfo_to_dict

    info = conninfo_to_dict(dsn)
    if (info.get("dbname") != TEST_DATABASE or info.get("host") in ("namtang_db", "itproject_db")
            or str(info.get("port")) in ("5432", "5433")):
        raise RuntimeError(f"refusing non-isolated database target: {info}")
    try:
        with psycopg.connect(dsn, connect_timeout=5) as conn:
            name = conn.execute("SELECT current_database()").fetchone()[0]
    except psycopg.OperationalError as exc:
        pytest.skip(f"isolated test database not reachable: {exc}")
    if name != TEST_DATABASE:
        raise RuntimeError(f"connected to {name!r}, expected {TEST_DATABASE!r}")
    return dsn


def _connect(dsn, autocommit=True):
    import psycopg

    conn = psycopg.connect(dsn, autocommit=autocommit)
    if conn.execute("SELECT current_database()").fetchone()[0] != TEST_DATABASE:
        conn.close()
        raise RuntimeError("refused: not the isolated test database")
    return conn


def _run_file(conn, path: Path, expected: str | None = TEST_DATABASE) -> None:
    """Run one migration file the way psql does: one script, guarded by expected_database."""
    import psycopg

    if expected is None:
        conn.execute("RESET bkk_traffic.expected_database")
    else:
        conn.execute(f"SET bkk_traffic.expected_database = '{expected}'")
    try:
        conn.execute(path.read_text(encoding="utf-8"))
    except psycopg.Error:
        if conn.info.transaction_status != psycopg.pq.TransactionStatus.IDLE:
            conn.execute("ROLLBACK")
        raise
    finally:
        conn.execute("RESET bkk_traffic.expected_database")


def _reset(dsn) -> None:
    with _connect(dsn) as conn:
        conn.execute("DROP SCHEMA IF EXISTS bkk_traffic CASCADE")
        conn.execute("DROP SCHEMA IF EXISTS namtang_analysis CASCADE")
        conn.execute("DROP SCHEMA IF EXISTS namtang CASCADE")
        for role in ROLES:
            if conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (role,)).fetchone():
                conn.execute(f"DROP OWNED BY {role}")
                conn.execute(f"DROP ROLE {role}")
        for migration in NAMTANG_MIGRATIONS:
            conn.execute(migration.read_text(encoding="utf-8"))


def _apply_all(dsn) -> None:
    with _connect(dsn) as conn:
        for migration in BKK_MIGRATIONS:
            _run_file(conn, migration)


def _clear_data(conn) -> None:
    conn.execute("TRUNCATE bkk_traffic.incidents, bkk_traffic.quarantine, bkk_traffic.bronze_incidents, "
                 "bkk_traffic.seen_eids, bkk_traffic.missing_eids, bkk_traffic.traffic_index, "
                 "bkk_traffic.traffic_index_history, bkk_traffic.travel_times, bkk_traffic.event_types, "
                 "bkk_traffic.checkpoints, bkk_traffic.scrape_runs RESTART IDENTITY")


@pytest.fixture(scope="module")
def dsn():
    dsn = _isolated_dsn()
    _reset(dsn)
    _apply_all(dsn)
    _apply_all(dsn)  # second pass: idempotent
    return dsn


@pytest.fixture
def db(dsn):
    with _connect(dsn) as conn:
        _clear_data(conn)
        yield conn
        _clear_data(conn)


def _bronze(conn, eid, ts="2026-10-02 10:00:00"):
    conn.execute("INSERT INTO bkk_traffic.bronze_incidents VALUES (%s, %s, 'realtime', %s, %s, NULL)",
                 (eid, '{"eid": %d}' % eid, ts, ts))


def _incident(conn, eid, **over):
    row = {"eid": eid, "nid": None, "title": f"t{eid}", "title_en": None, "comment": None, "comment_en": None,
           "latitude": 13.75, "longitude": 100.5, "severity": 1, "event_type_id": 3,
           "start_time": "2026-10-02 08:00:00", "stop_time": None, "createtime": "2026-10-02 08:01:00",
           "updatedtime": None, "contributor": "c", "source": "s", "status": "1", "event_type": "Accident",
           "traffic_relevance": "direct", "is_accident": 1, "is_bangkok": 1, "province_guess": "bangkok",
           "fetched_via": "realtime", "first_seen_at": "2026-10-02 10:00:00",
           "last_seen_at": "2026-10-02 10:00:00", "dq_flags": None}
    row.update(over)
    cols = ",".join(row)
    conn.execute(f"INSERT INTO bkk_traffic.incidents ({cols}) VALUES ({','.join(['%s'] * len(row))})",
                 list(row.values()))


# --------------------------------------------------------------------------
# Schema shape
# --------------------------------------------------------------------------

def test_schema_tables_and_no_public_tables(dsn):
    with _connect(dsn) as conn:
        tables = {r[0] for r in conn.execute(
            "SELECT tablename FROM pg_tables WHERE schemaname = 'bkk_traffic'")}
        assert tables == set(TABLES)
        assert conn.execute("SELECT count(*) FROM pg_tables WHERE schemaname = 'public'").fetchone()[0] == 0
        namtang = conn.execute("SELECT count(*) FROM pg_tables WHERE schemaname = 'namtang'").fetchone()[0]
        assert namtang == 14  # the Namtang migrations coexist unchanged


def test_migration_history_and_idempotency(dsn):
    def snapshot(conn):
        return (
            [r[0] for r in conn.execute("SELECT version FROM bkk_traffic.migration_history ORDER BY 1")],
            conn.execute("SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace "
                         "WHERE n.nspname = 'bkk_traffic'").fetchone()[0],
            conn.execute("SELECT count(*) FROM pg_constraint c JOIN pg_namespace n ON n.oid = c.connamespace "
                         "WHERE n.nspname = 'bkk_traffic'").fetchone()[0],
        )

    with _connect(dsn) as conn:
        before = snapshot(conn)
        assert before[0] == [p.stem for p in BKK_MIGRATIONS]
    _apply_all(dsn)
    with _connect(dsn) as conn:
        assert snapshot(conn) == before


def test_primary_keys(dsn):
    with _connect(dsn) as conn:
        for table, columns in TABLES.items():
            got = [r[0] for r in conn.execute(
                "SELECT a.attname FROM pg_index i "
                "JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey) "
                "WHERE i.indrelid = %s::regclass AND i.indisprimary "
                "ORDER BY array_position(i.indkey::int2[], a.attnum)", (f"bkk_traffic.{table}",))]
            assert got == columns, table


def test_foreign_keys_are_deferred_and_no_action(dsn):
    with _connect(dsn) as conn:
        fks = conn.execute(
            "SELECT conrelid::regclass::text, confrelid::regclass::text, condeferrable, condeferred, "
            "confdeltype, confupdtype FROM pg_constraint WHERE contype = 'f' "
            "AND connamespace = 'bkk_traffic'::regnamespace ORDER BY 1, 2").fetchall()
    assert fks == [
        # 006: the incidents FK to bronze is on the generated bronze_eid (NULL for Parquet baseline rows)
        ("bkk_traffic.incidents", "bkk_traffic.bronze_incidents", True, True, "a", "a"),
        ("bkk_traffic.incidents", "bkk_traffic.load_history", False, False, "a", "a"),
        ("bkk_traffic.quarantine", "bkk_traffic.bronze_incidents", True, True, "a", "a"),
        ("bkk_traffic.traffic_index_history", "bkk_traffic.load_history", False, False, "a", "a"),
        ("bkk_traffic.travel_times", "bkk_traffic.load_history", False, False, "a", "a"),
    ]


def test_expected_indexes(dsn):
    with _connect(dsn) as conn:
        idx = dict(conn.execute("SELECT indexname, indexdef FROM pg_indexes WHERE schemaname = 'bkk_traffic' "
                                "AND indexname LIKE 'ix_%'").fetchall())
    assert set(idx) == {
        "ix_bronze_incidents_pending", "ix_incidents_start_time", "ix_incidents_createtime",
        "ix_missing_eids_status_eid", "ix_scrape_runs_started_at", "ix_traffic_index_fetched_at",
        "ix_travel_times_fetched_at_route", "ix_load_history_source_sha256",
    }
    assert "WHERE (cleaned_at IS NULL)" in idx["ix_bronze_incidents_pending"]
    assert "(status, eid DESC)" in idx["ix_missing_eids_status_eid"]


def test_column_types_follow_the_timestamp_and_json_policy(dsn):
    with _connect(dsn) as conn:
        types = {(t, c): d for t, c, d in conn.execute(
            "SELECT table_name, column_name, data_type FROM information_schema.columns "
            "WHERE table_schema = 'bkk_traffic'")}
    for table, column in [("incidents", "start_time"), ("incidents", "createtime"), ("bronze_incidents", "cleaned_at"),
                          ("traffic_index_history", "ts_local"), ("travel_times", "fetched_at"),
                          ("scrape_runs", "started_at"), ("checkpoints", "updated_at")]:
        assert types[(table, column)] == "timestamp without time zone", (table, column)
    for table, column in [("load_history", "started_at"), ("migration_history", "applied_at")]:
        assert types[(table, column)] == "timestamp with time zone"
    assert types[("bronze_incidents", "raw_json")] == "json"
    assert types[("quarantine", "raw_json")] == "json"
    assert types[("travel_times", "raw_json")] == "json"
    assert types[("checkpoints", "state_json")] == "jsonb"
    assert types[("incidents", "is_accident")] == "smallint"
    assert types[("incidents", "eid")] == "bigint"
    assert ("incidents", "raw_json") not in types


# --------------------------------------------------------------------------
# Constraints
# --------------------------------------------------------------------------

@pytest.mark.parametrize("over", [
    {"is_accident": 2}, {"is_bangkok": -1}, {"is_duplicate": 5}, {"severity": 4},
    {"traffic_relevance": "other"}, {"title": None}, {"start_time": None}, {"traffic_relevance": None},
    {"fetched_via": None},
], ids=lambda o: next(iter(o.items())).__repr__())
def test_incident_rules_are_enforced(db, over):
    import psycopg

    _bronze(db, 1)
    with pytest.raises((psycopg.errors.CheckViolation, psycopg.errors.NotNullViolation)):
        _incident(db, 1, **over)


def test_other_check_constraints(db):
    import psycopg

    with pytest.raises(psycopg.errors.CheckViolation):
        db.execute("INSERT INTO bkk_traffic.missing_eids (eid, detected_at, status) VALUES (1, now(), 'lost')")
    with pytest.raises(psycopg.errors.CheckViolation):
        db.execute("INSERT INTO bkk_traffic.missing_eids (eid, detected_at, tries, status) "
                   "VALUES (1, now(), -1, 'pending')")
    with pytest.raises(psycopg.errors.CheckViolation):
        db.execute("INSERT INTO bkk_traffic.seen_eids VALUES (1, 2, now())")
    with pytest.raises(psycopg.errors.CheckViolation):
        db.execute("INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('r', 'x', 'done')")
    db.execute("INSERT INTO bkk_traffic.missing_eids (eid, detected_at, status) VALUES (1, now(), 'pending')")
    assert db.execute("SELECT tries FROM bkk_traffic.missing_eids").fetchone()[0] == 0


def test_null_primary_key_is_rejected_unlike_sqlite_rowid(db):
    # SQLite turns INSERT ... (NULL) into an auto rowid for INTEGER PRIMARY KEY; PostgreSQL refuses.
    import psycopg

    with pytest.raises(psycopg.errors.NotNullViolation):
        db.execute("INSERT INTO bkk_traffic.traffic_index VALUES (NULL, now(), 1.0, now())")


# --------------------------------------------------------------------------
# Deferred foreign keys
# --------------------------------------------------------------------------

def test_child_first_insert_commits(dsn, db):
    with _connect(dsn, autocommit=False) as conn:
        _incident(conn, 10)
        conn.execute("INSERT INTO bkk_traffic.quarantine VALUES (11, 'R5_no_title', '{}', now())")
        _bronze(conn, 10)
        _bronze(conn, 11)
        conn.commit()
    assert db.execute("SELECT count(*) FROM bkk_traffic.incidents").fetchone()[0] == 1


def test_orphan_child_fails_at_commit_not_at_insert(dsn, db):
    import psycopg

    with _connect(dsn, autocommit=False) as conn:
        _incident(conn, 20)  # accepted for now: the check is deferred
        with pytest.raises(psycopg.errors.ForeignKeyViolation):
            conn.commit()
    assert db.execute("SELECT count(*) FROM bkk_traffic.incidents").fetchone()[0] == 0


def test_parent_first_delete_like_migrate_v3_commits(dsn, db):
    _bronze(db, 30)
    _incident(db, 30)
    with _connect(dsn, autocommit=False) as conn:
        for table in ("bronze_incidents", "incidents", "quarantine"):  # migrate_v3_traffic_only order
            conn.execute(f"DELETE FROM bkk_traffic.{table} WHERE eid = 30")
        conn.commit()
    assert db.execute("SELECT count(*) FROM bkk_traffic.bronze_incidents").fetchone()[0] == 0


def test_deleting_only_the_parent_fails_and_rolls_back(dsn, db):
    import psycopg

    _bronze(db, 40)
    _incident(db, 40)
    with _connect(dsn, autocommit=False) as conn:
        conn.execute("DELETE FROM bkk_traffic.bronze_incidents WHERE eid = 40")
        with pytest.raises(psycopg.errors.ForeignKeyViolation):
            conn.commit()
    assert db.execute("SELECT count(*) FROM bkk_traffic.bronze_incidents").fetchone()[0] == 1


def test_constraints_can_be_made_immediate_for_debugging(dsn, db):
    import psycopg

    with _connect(dsn, autocommit=False) as conn:
        conn.execute("SET CONSTRAINTS ALL IMMEDIATE")
        with pytest.raises(psycopg.errors.ForeignKeyViolation):
            _incident(conn, 50)
        conn.rollback()


# --------------------------------------------------------------------------
# Timestamp and JSON policy
# --------------------------------------------------------------------------

def test_wall_clock_timestamps_do_not_shift_with_session_time_zone(db):
    import psycopg

    _bronze(db, 60, ts="2026-10-02 10:15:43")
    for zone in ("UTC", "Asia/Bangkok", "America/New_York"):
        db.execute(f"SET TIME ZONE '{zone}'")
        assert db.execute("SELECT first_fetched_at::text FROM bkk_traffic.bronze_incidents").fetchone()[0] \
            == "2026-10-02 10:15:43"
    db.execute("RESET TIME ZONE")
    # SQL ported from substr(start_time, 1, 10) = day uses a half-open range instead.
    _incident(db, 60, start_time="2026-10-02 23:59:59")
    assert db.execute("SELECT count(*) FROM bkk_traffic.incidents WHERE start_time >= %s::date "
                      "AND start_time < %s::date + 1", ("2026-10-02", "2026-10-02")).fetchone()[0] == 1
    with pytest.raises(psycopg.errors.DatetimeFieldOverflow):
        db.execute("UPDATE bkk_traffic.incidents SET createtime = '0000-00-00 00:00:00'")


def test_raw_json_is_stored_verbatim_and_validated(db):
    import psycopg

    raw = '{"eid": 70, "title": "รถชน \\u0000 test",  "b": 1, "a": 2}'
    db.execute("INSERT INTO bkk_traffic.bronze_incidents VALUES (70, %s, 'realtime', now(), now(), NULL)", (raw,))
    assert db.execute("SELECT raw_json::text FROM bkk_traffic.bronze_incidents").fetchone()[0] == raw
    with pytest.raises(psycopg.errors.UntranslatableCharacter):
        db.execute("SELECT raw_json::jsonb FROM bkk_traffic.bronze_incidents")  # why raw stays json (D3)
    with pytest.raises(psycopg.errors.InvalidTextRepresentation):
        db.execute("INSERT INTO bkk_traffic.bronze_incidents VALUES (71, '{bad', 'realtime', now(), now(), NULL)")


def test_checkpoint_state_round_trips_as_jsonb(db):
    from psycopg.types.json import Jsonb

    state = {"page": 925, "done": True, "anchor_time": None, "years_done": [2012, 2013]}
    for _ in range(2):
        db.execute("INSERT INTO bkk_traffic.checkpoints (job, state_json, updated_at) VALUES ('backfill', %s, %s) "
                   "ON CONFLICT (job) DO UPDATE SET state_json = EXCLUDED.state_json, updated_at = EXCLUDED.updated_at",
                   (Jsonb(state), "2026-10-02 15:45:26"))
    assert db.execute("SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'backfill'").fetchone()[0] == state
    assert db.execute("SELECT count(*) FROM bkk_traffic.checkpoints").fetchone()[0] == 1


# --------------------------------------------------------------------------
# Ported operations (SQLite -> PostgreSQL mapping, doc section 17)
# --------------------------------------------------------------------------

BRONZE_UPSERT = (
    "INSERT INTO bkk_traffic.bronze_incidents (eid, raw_json, fetched_via, first_fetched_at, last_fetched_at, "
    "cleaned_at) VALUES (%s, %s, %s, %s, %s, NULL) ON CONFLICT (eid) DO UPDATE SET raw_json = EXCLUDED.raw_json, "
    "last_fetched_at = EXCLUDED.last_fetched_at, fetched_via = EXCLUDED.fetched_via, cleaned_at = NULL")
SEEN_UPSERT = ("INSERT INTO bkk_traffic.seen_eids (eid, is_bangkok, seen_at) VALUES (%s, %s, %s) "
               "ON CONFLICT (eid) DO UPDATE SET is_bangkok = EXCLUDED.is_bangkok")
MARK_DUPLICATES = """
WITH ranked AS (
    SELECT eid, CASE WHEN ROW_NUMBER() OVER (
        PARTITION BY contributor, title, start_time, round(latitude::numeric, 4), round(longitude::numeric, 4)
        ORDER BY eid) > 1 THEN 1 ELSE 0 END AS dup
    FROM bkk_traffic.incidents)
UPDATE bkk_traffic.incidents i SET is_duplicate = r.dup
FROM ranked r WHERE r.eid = i.eid AND i.is_duplicate IS DISTINCT FROM r.dup"""


def test_bronze_and_seen_upserts_keep_first_seen_and_reset_cleaned_at(db):
    db.execute(BRONZE_UPSERT, (80, '{"v": 1}', "backfill", "2026-10-01 00:00:00", "2026-10-01 00:00:00"))
    db.execute("UPDATE bkk_traffic.bronze_incidents SET cleaned_at = '2026-10-01 00:01:00' WHERE eid = 80")
    db.execute(BRONZE_UPSERT, (80, '{"v": 2}', "realtime", "2026-10-02 00:00:00", "2026-10-02 00:00:00"))
    row = db.execute("SELECT raw_json::text, fetched_via, first_fetched_at::text, last_fetched_at::text, cleaned_at "
                     "FROM bkk_traffic.bronze_incidents").fetchone()
    assert row == ('{"v": 2}', "realtime", "2026-10-01 00:00:00", "2026-10-02 00:00:00", None)
    db.execute(SEEN_UPSERT, (80, 0, "2026-10-01 00:00:00"))
    db.execute(SEEN_UPSERT, (80, 1, "2026-10-02 00:00:00"))
    assert db.execute("SELECT is_bangkok, seen_at::text FROM bkk_traffic.seen_eids").fetchone() \
        == (1, "2026-10-01 00:00:00")


def test_mark_duplicates_port_matches_sqlite_semantics(db):
    # 13.802938 / 13.80295: SQLite 3.40.1 (Airflow 2.10 images) and round(::numeric) give 13.8029 / 13.803,
    # so these two reports are NOT duplicates; the friend's published Parquet keeps both (eid 313525/313529).
    for eid, lat in ((90, 13.802938), (91, 13.80295), (92, 13.802938)):
        _bronze(db, eid)
        _incident(db, eid, latitude=lat, longitude=100.585129, title="same", contributor="x")
    _bronze(db, 93)
    _incident(db, 93, latitude=None, longitude=None, title="nocoords", contributor="x")
    _bronze(db, 94)
    _incident(db, 94, latitude=None, longitude=None, title="nocoords", contributor="x")  # NULLs group together
    db.execute(MARK_DUPLICATES)
    flags = dict(db.execute("SELECT eid, is_duplicate FROM bkk_traffic.incidents").fetchall())
    assert flags == {90: 0, 91: 0, 92: 1, 93: 0, 94: 1}
    assert db.execute(MARK_DUPLICATES).rowcount == 0  # second run changes nothing


def test_insert_or_ignore_and_replace_ports(db):
    q = ("INSERT INTO bkk_traffic.traffic_index (ts, ts_local, index_value, fetched_at) "
         "VALUES (%s, %s, %s, %s) ON CONFLICT (ts) DO NOTHING")
    db.execute(q, (1759377300, "2026-10-02 10:55:00", 5.0, "2026-10-02 10:56:00"))
    db.execute(q, (1759377300, "2026-10-02 10:55:00", 9.0, "2026-10-02 10:57:00"))
    assert db.execute("SELECT index_value FROM bkk_traffic.traffic_index").fetchone()[0] == 5.0

    h = ("INSERT INTO bkk_traffic.traffic_index_history (ts, ts_local, index_value, source) VALUES (%s, %s, %s, %s) "
         "ON CONFLICT (ts) DO UPDATE SET index_value = EXCLUDED.index_value, source = EXCLUDED.source")
    db.execute(h, (1759377300, "2026-10-02 10:55:00", 5.0, "realtime"))
    db.execute(h, (1759377300, "2026-10-02 10:55:00", 6.0, "history:2026"))
    assert db.execute("SELECT index_value, source FROM bkk_traffic.traffic_index_history").fetchone() \
        == (6.0, "history:2026")

    e = ("INSERT INTO bkk_traffic.event_types (id, name, name_en, icon, severity) VALUES (%s, %s, %s, %s, %s) "
         "ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, name_en = EXCLUDED.name_en, "
         "icon = EXCLUDED.icon, severity = EXCLUDED.severity")
    db.execute(e, (3, "อุบัติเหตุ", "Accident", "a.png", 3))
    db.execute(e, (3, "อุบัติเหตุ", "Accident", None, None))
    assert db.execute("SELECT icon, severity FROM bkk_traffic.event_types").fetchone() == (None, None)

    t = ("INSERT INTO bkk_traffic.travel_times (route, fetched_at, distance_m, duration_s, duration_min, from_lat, "
         "from_lon, to_lat, to_lon, raw_json) VALUES (%s, %s, %s, %s, %s, 1, 2, 3, 4, %s) "
         "ON CONFLICT (route, fetched_at) DO UPDATE SET distance_m = EXCLUDED.distance_m, "
         "duration_s = EXCLUDED.duration_s, duration_min = EXCLUDED.duration_min, from_lat = EXCLUDED.from_lat, "
         "from_lon = EXCLUDED.from_lon, to_lat = EXCLUDED.to_lat, to_lon = EXCLUDED.to_lon, "
         "raw_json = EXCLUDED.raw_json")
    db.execute(t, ("A -> B", "2026-10-02 10:55:00", 1000, 60, 1.0, '{"meta": null}'))
    db.execute(t, ("A -> B", "2026-10-02 10:55:00", 1100, 66, 1.1, '{"meta": 1}'))
    assert db.execute("SELECT count(*), max(distance_m) FROM bkk_traffic.travel_times").fetchone() == (1, 1100)

    m = ("INSERT INTO bkk_traffic.missing_eids (eid, detected_at, tries, status) VALUES (%s, %s, 0, 'pending') "
         "ON CONFLICT (eid) DO NOTHING")
    db.cursor().executemany(m, [(100, "2026-10-02 01:00:00"), (101, "2026-10-02 01:00:00")])
    db.execute("UPDATE bkk_traffic.missing_eids SET status = 'recovered' WHERE eid = %s AND status <> 'recovered'",
               (100,))
    db.execute("UPDATE bkk_traffic.missing_eids SET status = 'not_available', tries = tries + 1, last_try_at = %s "
               "WHERE eid = %s", ("2026-10-02 01:05:00", 101))
    assert dict(db.execute("SELECT eid, status FROM bkk_traffic.missing_eids").fetchall()) \
        == {100: "recovered", 101: "not_available"}
    assert [r[0] for r in db.execute("SELECT eid FROM bkk_traffic.missing_eids WHERE status = 'pending' "
                                     "ORDER BY eid DESC LIMIT %s", (150,))] == []


def test_scrape_runs_identity_after_historical_load(db):
    db.execute("INSERT INTO bkk_traffic.scrape_runs (id, job, started_at, status) VALUES "
               "(1, 'realtime', '2026-09-01 00:00:00', 'success'), (7, 'backfill', '2026-09-01 00:15:00', 'failed')")
    db.execute("SELECT setval(pg_get_serial_sequence('bkk_traffic.scrape_runs', 'id'), "
               "(SELECT max(id) FROM bkk_traffic.scrape_runs))")
    new_id = db.execute("INSERT INTO bkk_traffic.scrape_runs (job, started_at, finished_at, requests, items, "
                        "new_items, status, note) VALUES ('realtime', %s, %s, 3, 263, 2, 'success', '') RETURNING id",
                        ("2026-10-02 19:00:00", "2026-10-02 19:00:39")).fetchone()[0]
    assert new_id == 8
    assert db.execute("SELECT count(*) FROM bkk_traffic.scrape_runs WHERE status = 'failed' "
                      "AND started_at >= (now() AT TIME ZONE 'Asia/Bangkok') - interval '1 day'").fetchone()[0] == 0
    # datetime('now', 'localtime') -> now() AT TIME ZONE 'Asia/Bangkok': independent of the session TimeZone,
    # unlike localtimestamp (the container default is UTC, 7 hours behind the stored wall-clock values).
    db.execute("SET TIME ZONE 'UTC'")
    utc_view = db.execute("SELECT date_trunc('minute', now() AT TIME ZONE 'Asia/Bangkok')").fetchone()[0]
    db.execute("SET TIME ZONE 'America/New_York'")
    assert db.execute("SELECT date_trunc('minute', now() AT TIME ZONE 'Asia/Bangkok')").fetchone()[0] == utc_view
    db.execute("RESET TIME ZONE")


# --------------------------------------------------------------------------
# Roles
# --------------------------------------------------------------------------

def test_app_role_has_dml_only_on_bkk_traffic(db):
    import psycopg

    db.execute("SET ROLE bkk_traffic_app")
    try:
        _bronze(db, 110)
        _incident(db, 110)
        db.execute("UPDATE bkk_traffic.incidents SET is_duplicate = 1 WHERE eid = 110")
        db.execute("INSERT INTO bkk_traffic.scrape_runs (job, started_at, status) VALUES ('t', now(), 'success')")
        db.execute("DELETE FROM bkk_traffic.incidents WHERE eid = 110")
        for statement in ("CREATE TABLE bkk_traffic.zz (x int)",
                          "ALTER TABLE bkk_traffic.incidents ADD COLUMN zz int",
                          "INSERT INTO bkk_traffic.migration_history (version) VALUES ('zz')",
                          "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('r', 'x', 'started')",
                          "SELECT count(*) FROM namtang.feed_info",
                          "SELECT count(*) FROM namtang_analysis.trips_analysis",
                          "CREATE TABLE public.zz (x int)"):
            with pytest.raises(psycopg.errors.InsufficientPrivilege):
                db.execute(statement)
    finally:
        db.execute("RESET ROLE")


def test_readonly_role_can_only_select(db):
    import psycopg

    db.execute("SET ROLE bkk_traffic_readonly")
    try:
        assert db.execute("SELECT count(*) FROM bkk_traffic.incidents").fetchone()[0] == 0
        for statement in ("INSERT INTO bkk_traffic.event_types (id) VALUES (1)",
                          "SELECT count(*) FROM namtang.agency"):
            with pytest.raises(psycopg.errors.InsufficientPrivilege):
                db.execute(statement)
    finally:
        db.execute("RESET ROLE")


def test_roles_cannot_log_in_and_own_only_bkk_traffic(dsn):
    with _connect(dsn) as conn:
        assert conn.execute("SELECT count(*) FROM pg_roles WHERE rolname LIKE 'bkk_traffic%' AND rolcanlogin"
                            ).fetchone()[0] == 0
        owned = conn.execute("SELECT DISTINCT n.nspname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace "
                             "WHERE pg_get_userbyid(c.relowner) LIKE 'bkk_traffic%' "
                             "AND n.nspname <> 'pg_toast'").fetchall()
        assert owned == [("bkk_traffic",)]


# --------------------------------------------------------------------------
# Guard, failure rollback and full rollback (keep last: they rebuild the schema)
# --------------------------------------------------------------------------

def test_guard_refuses_missing_or_wrong_target(dsn):
    import psycopg

    with _connect(dsn) as conn:
        for expected in (None, "namtang_db", "itproject_db"):
            with pytest.raises(psycopg.errors.RaiseException, match="migration refused"):
                _run_file(conn, BKK_MIGRATIONS[0], expected=expected)


def test_failed_migration_leaves_no_trace(dsn, tmp_path):
    import psycopg

    broken = tmp_path / "999_broken.sql"
    broken.write_text(BKK_MIGRATIONS[0].read_text(encoding="utf-8").replace(
        "COMMIT;",
        "CREATE TABLE bkk_traffic.zz_probe (x int);\n"
        "INSERT INTO bkk_traffic.migration_history (version) VALUES ('999_broken');\n"
        "SELECT 1 / 0;\nCOMMIT;"), encoding="utf-8")
    with _connect(dsn) as conn:
        with pytest.raises(psycopg.errors.DivisionByZero):
            _run_file(conn, broken)
        assert conn.execute("SELECT to_regclass('bkk_traffic.zz_probe')").fetchone()[0] is None
        assert conn.execute("SELECT count(*) FROM bkk_traffic.migration_history WHERE version = '999_broken'"
                            ).fetchone()[0] == 0


def test_out_of_order_migration_fails_atomically(dsn):
    import psycopg

    with _connect(dsn) as conn:
        _run_file(conn, ROLLBACK)
        with pytest.raises(psycopg.errors.InvalidSchemaName):
            _run_file(conn, BKK_MIGRATIONS[1])  # 002 before 001: schema missing
        assert conn.execute("SELECT count(*) FROM pg_namespace WHERE nspname = 'bkk_traffic'").fetchone()[0] == 0
    _apply_all(dsn)


def test_rollback_script_removes_only_bkk_traffic(dsn):
    with _connect(dsn) as conn:
        namtang_before = conn.execute("SELECT count(*) FROM pg_tables WHERE schemaname LIKE 'namtang%'").fetchone()[0]
        _run_file(conn, ROLLBACK)
        assert conn.execute("SELECT count(*) FROM pg_namespace WHERE nspname = 'bkk_traffic'").fetchone()[0] == 0
        assert conn.execute("SELECT count(*) FROM pg_roles WHERE rolname LIKE 'bkk_traffic%'").fetchone()[0] == 0
        assert conn.execute("SELECT count(*) FROM pg_tables WHERE schemaname LIKE 'namtang%'"
                            ).fetchone()[0] == namtang_before == 22
        _run_file(conn, ROLLBACK)  # idempotent
    _apply_all(dsn)
    with _connect(dsn) as conn:
        assert conn.execute("SELECT count(*) FROM bkk_traffic.migration_history").fetchone()[0] == len(BKK_MIGRATIONS) == 6
