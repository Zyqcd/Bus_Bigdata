"""Build the Phase 7 TEST-ONLY GTFS fixtures from the local real Namtang feed.

    python tests/fixtures/phase7/build_fixture.py

Reads data/raw/namtang/2026-10-01/gtfs.zip read-only and writes small,
byte-deterministic GTFS ZIPs next to this script. Rows are copied verbatim from
the real feed (exact source strings); only feed_info.feed_version is replaced by
a test-only value. The output is a test fixture, not production data, and is
never written under data/.

Selection (real routes that exercise real pipeline behaviour):
  * route 3393 (agency CCT)  - brings both real CCT agency rows (DQ-001 collision)
  * route 66   (agency SRT)  - real fare rules referencing missing zone 221 (DQ-002)
  * route 2547 (agency PPCT) - a real single_departure frequency row (DQ-004)

Variants:
  A  base fixture                         feed_version PHASE7-TEST-A
  B  same rows, different feed_version    feed_version PHASE7-TEST-B  (policy SHA mismatch)
  C  A without one stop that stop_times   feed_version PHASE7-TEST-C  (unexpected validation
     references                                                         ERROR not in policy)
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE_ZIP = ROOT / "data" / "raw" / "namtang" / "2026-10-01" / "gtfs.zip"
SOURCE_SHA256 = "6b1a6a2d2d77ea9c6fccfe955899e080946f46d459e2411316d5e7c766951f42"

ROUTES = ("3393", "66", "2547")
FARE_RULES_PER_ROUTE = 4          # zone-resolvable rules kept per route
ZONE_221_RULES = 2                # real zone-221 rules kept (route 66)
REMOVED_STOP_FOR_C = None         # chosen deterministically below
FILE_ORDER = ("agency.txt", "stops.txt", "routes.txt", "trips.txt", "stop_times.txt",
              "calendar.txt", "calendar_dates.txt", "fare_attributes.txt",
              "fare_rules.txt", "shapes.txt", "frequencies.txt", "feed_info.txt")
ZIP_DATE = (2026, 10, 1, 0, 0, 0)  # fixed timestamp -> deterministic bytes


def read_source() -> dict[str, tuple[list[str], list[list[str]]]]:
    actual = hashlib.sha256(SOURCE_ZIP.read_bytes()).hexdigest()
    if actual != SOURCE_SHA256:
        raise SystemExit(f"unexpected source feed {actual}; fixture is defined for {SOURCE_SHA256}")
    tables = {}
    with zipfile.ZipFile(SOURCE_ZIP) as zf:
        for name in FILE_ORDER:
            with zf.open(name) as raw:
                rows = list(csv.reader(io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")))
            tables[name] = (rows[0], [r for r in rows[1:] if r])
    return tables


def col(header: list[str], name: str) -> int:
    return header.index(name)


def select(tables) -> dict[str, tuple[list[str], list[list[str]]]]:
    def keep(name, predicate):
        header, rows = tables[name]
        return header, [r for r in rows if predicate(header, r)]

    routes = keep("routes.txt", lambda h, r: r[col(h, "route_id")] in ROUTES)
    agency_ids = {r[col(routes[0], "agency_id")] for r in routes[1]}
    agency = keep("agency.txt", lambda h, r: r[col(h, "agency_id")] in agency_ids)
    trips = keep("trips.txt", lambda h, r: r[col(h, "route_id")] in ROUTES)
    trip_ids = {r[col(trips[0], "trip_id")] for r in trips[1]}
    services = {r[col(trips[0], "service_id")] for r in trips[1]}
    shape_ids = {r[col(trips[0], "shape_id")] for r in trips[1]}
    stop_times = keep("stop_times.txt", lambda h, r: r[col(h, "trip_id")] in trip_ids)
    stop_ids = {r[col(stop_times[0], "stop_id")] for r in stop_times[1]}
    stops = keep("stops.txt", lambda h, r: r[col(h, "stop_id")] in stop_ids)
    zones = {r[col(stops[0], "zone_id")] for r in stops[1]}

    fh, frows = tables["fare_rules.txt"]
    rid, oid, did = col(fh, "route_id"), col(fh, "origin_id"), col(fh, "destination_id")
    # Only fares owned by a selected agency, so the fixture adds no orphan
    # fare_attributes.agency_id reference that the real feed does not have.
    ah, arows = tables["fare_attributes.txt"]
    fare_agency = {r[col(ah, "fare_id")]: r[col(ah, "agency_id")] for r in arows}
    fare_rules, per_route, zone221 = [], {}, 0
    for r in frows:
        if r[rid] not in ROUTES or fare_agency.get(r[col(fh, "fare_id")]) not in agency_ids:
            continue
        if "221" in (r[oid], r[did]):
            if zone221 < ZONE_221_RULES and r[did] in zones | {""} and r[oid] in zones | {"221", ""}:
                fare_rules.append(r)
                zone221 += 1
            continue
        if r[oid] in zones | {""} and r[did] in zones | {""} \
                and per_route.get(r[rid], 0) < FARE_RULES_PER_ROUTE:
            fare_rules.append(r)
            per_route[r[rid]] = per_route.get(r[rid], 0) + 1
    fare_ids = {r[col(fh, "fare_id")] for r in fare_rules}
    fare_attributes = keep("fare_attributes.txt", lambda h, r: r[col(h, "fare_id")] in fare_ids)

    return {
        "agency.txt": agency, "stops.txt": stops, "routes.txt": routes, "trips.txt": trips,
        "stop_times.txt": stop_times,
        "calendar.txt": keep("calendar.txt", lambda h, r: r[col(h, "service_id")] in services),
        "calendar_dates.txt": keep("calendar_dates.txt",
                                   lambda h, r: r[col(h, "service_id")] in services),
        "fare_attributes.txt": fare_attributes, "fare_rules.txt": (fh, fare_rules),
        "shapes.txt": keep("shapes.txt", lambda h, r: r[col(h, "shape_id")] in shape_ids),
        "frequencies.txt": keep("frequencies.txt", lambda h, r: r[col(h, "trip_id")] in trip_ids),
        "feed_info.txt": tables["feed_info.txt"],
    }


def with_feed_version(tables, version: str):
    header, rows = tables["feed_info.txt"]
    i = col(header, "feed_version")
    out = dict(tables)
    out["feed_info.txt"] = (header, [[*r[:i], version, *r[i + 1:]] for r in rows])
    return out


def without_stop(tables, stop_id: str):
    header, rows = tables["stops.txt"]
    out = dict(tables)
    out["stops.txt"] = (header, [r for r in rows if r[col(header, "stop_id")] != stop_id])
    return out


def write_zip(tables, path: Path) -> dict:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in FILE_ORDER:
            header, rows = tables[name]
            text = io.StringIO()
            writer = csv.writer(text, lineterminator="\n")
            writer.writerow(header)
            writer.writerows(rows)
            info = zipfile.ZipInfo(name, date_time=ZIP_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, text.getvalue().encode("utf-8"))
    path.write_bytes(buf.getvalue())
    return {"file": path.name, "sha256": hashlib.sha256(buf.getvalue()).hexdigest(),
            "bytes": len(buf.getvalue()),
            "row_counts": {name: len(tables[name][1]) for name in FILE_ORDER}}


def main() -> None:
    base = select(read_source())
    # Variant C removes a stop used by stop_times but by no fare rule, so the only new
    # finding is the orphan stop_times.stop_id reference.
    fh, frows = base["fare_rules.txt"]
    fare_zones = {r[col(fh, "origin_id")] for r in frows} | {r[col(fh, "destination_id")] for r in frows}
    sh, srows = base["stops.txt"]
    removed = sorted(r[col(sh, "stop_id")] for r in srows
                     if r[col(sh, "zone_id")] not in fare_zones)[0]
    variants = {
        "A": with_feed_version(base, "PHASE7-TEST-A"),
        "B": with_feed_version(base, "PHASE7-TEST-B"),
        "C": without_stop(with_feed_version(base, "PHASE7-TEST-C"), removed),
    }
    manifest = {
        "warning": "TEST-ONLY fixtures for Phase 7. Derived from real Namtang rows; not production data.",
        "derived_from_feed_sha256": SOURCE_SHA256,
        "routes": list(ROUTES),
        "variant_C_removed_stop_id": removed,
        "variants": {},
    }
    for key, tables in variants.items():
        info = write_zip(tables, HERE / f"namtang_phase7_{key}.zip")
        info["feed_version"] = f"PHASE7-TEST-{key}"
        manifest["variants"][key] = info
        print(key, info["sha256"], info["bytes"], "bytes", info["row_counts"])
    (HERE / "fixture_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n",
                                                encoding="utf-8")


if __name__ == "__main__":
    main()
