"""Phase 9.3: the ported BKK Traffic pipeline (data/scraper/bkk_traffic) and its staged DAGs.

* No network: traffic.longdo.com is replaced by FakeClient (TEST-ONLY synthetic items).
* Database tests use ONLY the isolated namtang_bkk_traffic_test_db (guarded by the
  helpers of test_bkk_traffic_migrations). The pipeline runs as a login user that is a
  member of bkk_traffic_app, proving the ported code needs no DDL or superuser rights.
* Files go to pytest temporary directories (config paths are monkeypatched).
* Airflow tests run only where Airflow is installed (the airflow-cli image).
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))
sys.path.insert(0, str(ROOT / "database" / "load"))

from bkk_traffic import clean, config, history, maintenance, parquet_export, publish, scrape, storage  # noqa: E402
from bkk_traffic.client import LongdoClient  # noqa: E402

import load_bkk_traffic as L  # noqa: E402

PACKAGE = ROOT / "data" / "scraper" / "bkk_traffic"
DAG_FOLDER = ROOT / "airflow" / "dags"            # registered in Phase 9.4 (previously staged)
BKK_DAGS = [DAG_FOLDER / "bkk_traffic_pipeline.py", DAG_FOLDER / "bkk_traffic_maintenance.py"]
APP_USER, APP_PASSWORD = "bkk_test_app", "bkk_test_app"
BANGKOK = ("13.7563", "100.5018")
CHIANG_MAI = ("18.7883", "98.9853")
EVENT_TYPES = [{"id": 3, "name": "อุบัติเหตุ", "name_en": "Accident", "icon": "a.png", "severity": 3},
               {"id": 10, "name": "รถติด", "name_en": "Trafficjam", "icon": "t.png", "severity": 1},
               {"id": 20, "name": "ไฟไหม้", "name_en": "Fire", "icon": "f.png", "severity": 2}]


def api_item(eid: int, **over) -> dict:
    """TEST-ONLY item shaped like a traffic.longdo.com incident."""
    item = {"eid": str(eid), "nid": str(eid * 10), "title": f"อุบัติเหตุ รถชน ถนนพระราม 4 #{eid}",
            "title_en": f"Accident on Rama 4 #{eid}", "comment": "ช่องซ้ายปิด", "comment_en": None,
            "latitude": BANGKOK[0], "longitude": BANGKOK[1], "severity": "3", "severity_level": "1",
            "start_time": "2026-10-03 08:00:00", "stop_time": "2026-10-03 09:00:00",
            "createtime": "2026-10-03 08:01:00", "updatedtime": "", "contributor": f"tester{eid}",
            "source": "test", "status": "1"}
    item.update(over)
    return item


class FakeClient:
    """Stands in for LongdoClient; never opens a network connection."""
    pages: dict[int, list[dict]] = {}
    events: dict[int, dict | None] = {}
    index: dict = {}
    history_files: dict[int, str] = {}     # year -> CSV text of Longdo's yearly traffic-index file

    def __init__(self, source_tag: str = "misc", deadline: float | None = None):
        self.source_tag = source_tag
        self.request_count = 0

    def incident_page(self, page, limit=None):
        self.request_count += 1
        return list(type(self).pages.get(page, [])), max(type(self).pages, default=None)

    def event_by_id(self, eid):
        self.request_count += 1
        return type(self).events.get(eid)

    def traffic_index(self):
        self.request_count += 1
        return dict(type(self).index)

    def event_types(self):
        self.request_count += 1
        return [dict(t) for t in EVENT_TYPES]

    def save_raw(self, name, data):
        LongdoClient.save_raw(self, name, data)

    def get_text(self, url, params=None):
        self.request_count += 1
        year = int(url.rstrip("/").rsplit("/", 1)[-1])
        return type(self).history_files.get(year, "timestamp,datetime,index\n")


# --------------------------------------------------------------------------
# Static checks (no database)
# --------------------------------------------------------------------------

def _code(path: Path) -> str:
    """Source without the module docstring and comment lines (docstrings may name what was replaced)."""
    text = path.read_text(encoding="utf-8")
    if '"""' in text:
        text = text.split('"""', 2)[-1]
    return "\n".join(line for line in text.splitlines() if not line.lstrip().startswith("#"))


@pytest.mark.parametrize("path", sorted(PACKAGE.glob("*.py")) + BKK_DAGS,
                         ids=lambda p: p.name)
def test_ported_code_has_no_sqlite_and_no_namtang_dependency(path):
    code = _code(path)
    assert "sqlite3" not in code and "executescript" not in code and "PRAGMA" not in code
    assert "namtang." not in code and "namtang_analysis" not in code
    assert "import namtang_scraper" not in code and "run_pipeline" not in code


def test_no_code_runs_airflow_db_clean():
    for path in [*BKK_DAGS, PACKAGE / "maintenance.py"]:
        body = _code(path)
        assert "db clean" not in body and "BashOperator" not in body


def test_published_schemas_equal_the_loader_schemas():
    assert parquet_export.INCIDENT_SCHEMA.equals(L.INCIDENT_SCHEMA)
    assert parquet_export.TRAFFIC_INDEX_SCHEMA.equals(L.TRAFFIC_INDEX_SCHEMA)
    assert parquet_export.TRAVEL_TIMES_SCHEMA.equals(L.TRAVEL_TIMES_SCHEMA)


def test_bkk_dags_are_registered_next_to_the_unchanged_namtang_dag():
    live = {p.name for p in DAG_FOLDER.glob("*.py")}
    assert live == {"namtang_gtfs_pipeline.py", "bkk_traffic_pipeline.py", "bkk_traffic_maintenance.py",
                    "bkk_traffic_quality.py"}                       # Phase 9.7
    assert not (ROOT / "airflow" / "bkk_traffic_dags").exists()


def test_typed_timestamp_rules():
    types = ([("อุบัติเหตุ", "Accident")], {3: "Accident"})
    row, flags, rejects = clean.apply_rules(clean.normalize(api_item(1), *types))
    assert rejects == [] and row["updatedtime"] is None            # '' -> NULL
    row, flags, rejects = clean.apply_rules(clean.normalize(api_item(2, createtime="0000-00-00 00:00:00"), *types))
    assert "R10_bad_createtime" in rejects                          # quarantined, never stored as garbage
    row, flags, rejects = clean.apply_rules(clean.normalize(api_item(3, stop_time="2026-10-03 07:00:00"), *types))
    assert row["stop_time"] is None and flags == ["R4_stop_before_start"]   # friend rule unchanged
    row, flags, rejects = clean.apply_rules(clean.normalize(api_item(4, start_time="1970-01-01 00:00:00"), *types))
    assert "R3_start_out_of_range" in rejects and not flags


def test_timestamps_are_bangkok_wall_clock_regardless_of_machine_timezone():
    # Our Airflow containers run in UTC (the friend's compose set TZ=Asia/Bangkok); found in Phase 9.3.
    from datetime import datetime, timedelta, timezone

    assert config.bangkok_from_epoch(0) == datetime(1970, 1, 1, 7, 0, 0)
    assert config.bangkok_from_epoch(1790942100).strftime("%Y-%m-%d %H:%M:%S") == "2026-10-02 18:55:00"
    utc_plus_7 = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(hours=7)
    assert abs((config.bangkok_now() - utc_plus_7).total_seconds()) < 5
    assert abs((datetime.strptime(storage.now_str(), "%Y-%m-%d %H:%M:%S") - utc_plus_7).total_seconds()) < 5


def test_maintenance_deletes_only_old_bkk_logs(tmp_path):
    old = time.time() - 30 * 86400
    files = {
        "dag_id=bkk_traffic_pipeline/run_id=a/task_id=scrape/attempt=1.log": old,
        "dag_id=bkk_traffic_pipeline/run_id=b/task_id=scrape/attempt=1.log": time.time(),
        "dag_id=namtang_gtfs_pipeline/run_id=a/task_id=scrape/attempt=1.log": old,
        "dag_processor/old.log": old,
        "scheduler/old.log": old,
    }
    for rel, mtime in files.items():
        path = tmp_path / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("log", encoding="utf-8")
        os.utime(path, (mtime, mtime))
    result = maintenance.delete_old_bkk_logs(tmp_path)
    assert result["removed_files"] == 1 and result["kept_files"] == 1
    remaining = {p.relative_to(tmp_path).as_posix() for p in tmp_path.rglob("*.log")}
    assert remaining == set(files) - {"dag_id=bkk_traffic_pipeline/run_id=a/task_id=scrape/attempt=1.log"}


# --------------------------------------------------------------------------
# Database tests (isolated test DB; pipeline runs as a bkk_traffic_app member)
# --------------------------------------------------------------------------

@pytest.fixture(scope="module")
def dsns():
    import test_bkk_traffic_migrations as mig

    admin = mig._isolated_dsn()
    mig._reset(admin)
    mig._apply_all(admin)
    with mig._connect(admin) as conn:
        if not conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (APP_USER,)).fetchone():
            conn.execute(f"CREATE ROLE {APP_USER} LOGIN PASSWORD '{APP_PASSWORD}'")
        conn.execute(f"GRANT bkk_traffic_app TO {APP_USER}")
    from psycopg.conninfo import conninfo_to_dict, make_conninfo

    info = conninfo_to_dict(admin)
    app = make_conninfo(**{**info, "user": APP_USER, "password": APP_PASSWORD})
    return admin, app


@pytest.fixture
def env(dsns, tmp_path, monkeypatch):
    import test_bkk_traffic_migrations as mig

    admin, app = dsns
    with mig._connect(admin) as conn:
        conn.execute("TRUNCATE bkk_traffic.incidents, bkk_traffic.quarantine, bkk_traffic.bronze_incidents, "
                     "bkk_traffic.seen_eids, bkk_traffic.missing_eids, bkk_traffic.traffic_index, "
                     "bkk_traffic.traffic_index_history, bkk_traffic.travel_times, bkk_traffic.event_types, "
                     "bkk_traffic.checkpoints, bkk_traffic.scrape_runs, bkk_traffic.load_history RESTART IDENTITY")
    data = tmp_path / "bkk_data"
    for name, sub in (("DATA_DIR", ""), ("RAW_DIR", "raw"), ("PARQUET_DIR", "parquet"),
                      ("QUALITY_DIR", "quality"), ("CHECKPOINT_DIR", "checkpoints")):
        monkeypatch.setattr(config, name, data / sub if sub else data)
    monkeypatch.setattr(config, "RATE_LOCK_FILE", data / "checkpoints" / ".rate_limit.lock")
    monkeypatch.setattr(publish, "GATE_FILE", data / "quality" / "gate_last.json")
    monkeypatch.setattr(parquet_export, "PARQUET_DIR", data / "parquet")
    monkeypatch.setattr(scrape, "LongdoClient", FakeClient)
    monkeypatch.setattr(history, "LongdoClient", FakeClient)
    FakeClient.pages, FakeClient.events, FakeClient.history_files = {}, {}, {}
    FakeClient.index = {"time": 1790960700, "index": 4.25}
    storage.configure(app)
    yield {"admin": admin, "app": app, "data": data}
    storage.configure(None)


def q(dsn, sql, *args):
    import test_bkk_traffic_migrations as mig

    with mig._connect(dsn) as conn:
        cur = conn.execute(sql, args or None)
        return cur.fetchall() if cur.description else cur.rowcount


def test_realtime_scrape_writes_bronze_silver_quarantine_and_logs(env):
    FakeClient.pages = {
        1: [api_item(101), api_item(102, latitude=CHIANG_MAI[0], longitude=CHIANG_MAI[1]),       # outside Bangkok
            api_item(103, severity="20", title="ไฟไหม้บ้าน", title_en="House fire"),            # not traffic
            api_item(104, start_time="0000-00-00 00:00:00"),                                       # R3 -> quarantine
            api_item(105, createtime="2026-13-45 99:00:00")],                                       # R10 -> quarantine
        2: [api_item(101), api_item(105, createtime="2026-13-45 99:00:00")],                                                          # all known: stop
    }
    result = scrape.run_realtime_incidents(max_pages=30)
    assert result == {"items": 7, "new": 3}
    admin = env["admin"]
    assert [r[0] for r in q(admin, "SELECT eid FROM bkk_traffic.seen_eids ORDER BY eid")] == [101, 102, 103, 104, 105]
    assert [r[0] for r in q(admin, "SELECT eid FROM bkk_traffic.bronze_incidents ORDER BY eid")] == [101, 104, 105]
    inc = q(admin, "SELECT eid, is_accident, is_bangkok, event_type, start_time::text, updatedtime, fetched_via, "
                   "baseline_load_id, bronze_eid FROM bkk_traffic.incidents")
    assert inc == [(101, 1, 1, "Accident", "2026-10-03 08:00:00", None, "realtime", None, 101)]
    assert dict(q(admin, "SELECT eid, reasons FROM bkk_traffic.quarantine")) == {
        104: "R3_bad_start_time", 105: "R10_bad_createtime"}
    raw = q(admin, "SELECT raw_json::text FROM bkk_traffic.bronze_incidents WHERE eid = 101")[0][0]
    assert json.loads(raw)["title_en"] == "Accident on Rama 4 #101"
    assert q(admin, "SELECT job, status, items, new_items FROM bkk_traffic.scrape_runs") == [("realtime", "success", 7, 3)]
    cp = q(admin, "SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'realtime'")[0][0]
    assert cp["max_eid"] == 101 and cp["max_start_time"] == "2026-10-03 08:00:00"
    assert (env["data"] / "checkpoints" / "realtime.json").is_file()
    assert any((env["data"] / "raw" / "incidents_realtime").rglob("*.json.gz"))
    assert len(q(admin, "SELECT * FROM bkk_traffic.event_types")) == 3


def test_traffic_index_sample_and_sample_without_time(env):
    scrape.run_traffic_index()
    scrape.run_traffic_index()                      # same ts: ON CONFLICT DO NOTHING
    rows = q(env["admin"], "SELECT ts, ts_local::text, index_value FROM bkk_traffic.traffic_index")
    hist = q(env["admin"], "SELECT ts, ts_local::text, source FROM bkk_traffic.traffic_index_history")
    assert len(rows) == 1 and rows[0][2] == 4.25 and hist[0][2] == "realtime" and hist[0][1] == rows[0][1]
    FakeClient.index = {"index": 3.0}               # no "time": skipped, never a fabricated key
    scrape.run_traffic_index()
    assert len(q(env["admin"], "SELECT * FROM bkk_traffic.traffic_index")) == 1


def test_clean_stage_marks_duplicates(env):
    FakeClient.pages = {1: [api_item(201, contributor="same", title="รถชน แยกอโศก"),
                            api_item(202, contributor="same", title="รถชน แยกอโศก"),
                            api_item(203, contributor="same", title="รถชน แยกอโศก", latitude="13.80295")]}
    scrape.run_realtime_incidents(max_pages=1)
    assert publish.run_clean_stage() == {"clean": 0, "quarantined": 0, "flagged": 0, "duplicates": 1}
    assert dict(q(env["admin"], "SELECT eid, is_duplicate FROM bkk_traffic.incidents")) == {201: 0, 202: 1, 203: 0}


def test_gate_publish_and_verify_round_trip(env):
    FakeClient.pages = {1: [api_item(300 + i) for i in range(12)]
                        + [api_item(320, severity="10", title="รถติดหนัก", title_en="Heavy traffic")]}
    scrape.run_realtime_incidents(max_pages=1)
    scrape.run_traffic_index()
    publish.run_clean_stage()
    gate = publish.gate_checks()
    assert gate["passed"], gate
    published = publish.publish_parquet(gate)
    assert {n: r["rows"] for n, r in published.items()} == {
        "incidents_bangkok": 13, "accidents_bangkok": 12, "traffic_index": 1, "travel_times": 0}
    # the pipeline's own output is accepted by the snapshot loader's validator
    snapshot = L.validate_snapshot(env["data"] / "parquet")
    assert snapshot.reports["accidents_bangkok"].rows == 12
    assert parquet_export.verify_postgresql()["incidents_bangkok"] == {
        "postgresql_rows": 13, "manifest_rows": 13, "file_rows": 13}
    again = publish.publish_parquet(publish.gate_checks())
    assert all(r.get("skipped") for r in again.values())       # unchanged signature: nothing rewritten


def test_failed_gate_publishes_nothing(env):
    FakeClient.pages = {1: [api_item(401)]}
    scrape.run_realtime_incidents(max_pages=1)
    q(env["admin"], "UPDATE bkk_traffic.incidents SET is_bangkok = 0")
    gate = publish.gate_checks()
    assert not gate["passed"] and {c["check"]: c["status"] for c in gate["checks"]}["G3_non_bangkok_rows"] == "FAIL"
    with pytest.raises(publish.GateFailed):
        publish.publish_parquet()
    assert not (env["data"] / "parquet").exists()


def test_pipeline_takes_over_a_parquet_baseline_row(env, tmp_path):
    import test_bkk_traffic_parquet_loader as lt

    rows = lt.default_rows()
    L.run(env["admin"], lt.make_snapshot(tmp_path / "snap", rows), "namtang_bkk_traffic_test_db")
    assert q(env["admin"], "SELECT baseline_load_id, bronze_eid FROM bkk_traffic.incidents WHERE eid = 1") == [(1, None)]
    FakeClient.pages = {1: [api_item(1, title="อุบัติเหตุ แก้ไขแล้ว")]}
    scrape.run_realtime_incidents(max_pages=1)
    assert q(env["admin"], "SELECT baseline_load_id, bronze_eid, title FROM bkk_traffic.incidents WHERE eid = 1") \
        == [(None, 1, "อุบัติเหตุ แก้ไขแล้ว")]
    assert q(env["admin"], "SELECT count(*) FROM bkk_traffic.incidents WHERE baseline_load_id = 1")[0][0] == 4
    with pytest.raises(L.LoadError, match="pipeline-written rows"):
        L.run(env["admin"], tmp_path / "snap", "namtang_bkk_traffic_test_db")


def test_missing_eids_detect_and_recover(env):
    # Phase 9.7: detection uses the coverage floor (highest eid owned by the Parquet baseline), not a
    # backfill anchor (docs/integration/bkk_traffic_quality_mapping.md D1).
    q(env["admin"], "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('t', 'parquet:t', 'success')")
    q(env["admin"], "INSERT INTO bkk_traffic.incidents (eid, title, start_time, traffic_relevance, is_accident, "
                    "is_bangkok, fetched_via, first_seen_at, last_seen_at, baseline_load_id) VALUES "
                    "(499, 'baseline', '2026-10-02 08:00:00', 'direct', 0, 1, 'backfill', now(), now(), 1)")
    FakeClient.pages = {1: [api_item(e, start_time="2026-10-03 08:00:00") for e in range(500, 620) if e % 10]}
    scrape.run_realtime_incidents(max_pages=1)
    detected = scrape.detect_missing_eids()
    assert detected["range"] == [500, 619]
    assert detected["new_missing"] == len([e for e in range(500, 620) if e % 10 == 0]) == 12
    FakeClient.events = {600: api_item(600), 610: None}
    result = scrape.recover_missing_eids(limit=150, max_seconds=360)
    assert result["recovered"] == 1 and result["not_available"] == 11 and result["stop_reason"] == "done"
    status = dict(q(env["admin"], "SELECT eid, status FROM bkk_traffic.missing_eids WHERE eid IN (600, 610)"))
    assert status == {600: "recovered", 610: "not_available"}


def test_app_role_cannot_touch_namtang_or_ddl(env):
    import psycopg

    with psycopg.connect(env["app"]) as conn:
        for statement in ("SELECT count(*) FROM namtang.feed_info", "CREATE TABLE bkk_traffic.zz (x int)",
                          "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('x','y','failed')"):
            with pytest.raises(psycopg.errors.InsufficientPrivilege):
                conn.execute(statement)
            conn.rollback()


# --------------------------------------------------------------------------
# Airflow (only inside the Airflow image)
# --------------------------------------------------------------------------

def _load_dag_module(name: str):
    pytest.importorskip("airflow.sdk")
    spec = importlib.util.spec_from_file_location(f"bkk_{name}_under_test", DAG_FOLDER / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_dags_folder_parses_without_errors():
    pytest.importorskip("airflow.sdk")
    try:
        from airflow.dag_processing.dagbag import DagBag
    except ImportError:  # older Airflow
        from airflow.models.dagbag import DagBag

    bag = DagBag(dag_folder=str(DAG_FOLDER))       # examples disabled via AIRFLOW__CORE__LOAD_EXAMPLES
    assert bag.import_errors == {}
    assert set(bag.dag_ids) == {"namtang_gtfs_pipeline", "bkk_traffic_pipeline", "bkk_traffic_maintenance",
                                "bkk_traffic_quality"}               # Phase 9.7


def test_pipeline_dag_structure_and_defaults(monkeypatch):
    monkeypatch.delenv("BKK_TRAFFIC_SCHEDULE_ENABLED", raising=False)
    module = _load_dag_module("bkk_traffic_pipeline")
    dag = module.pipeline_dag
    assert [t.task_id for t in dag.topological_sort()] == ["scrape", "update_history", "collect_travel_times",
                                                           "clean", "validate", "publish", "verify_postgresql"]
    assert module.pipeline_schedule() is None
    assert dag.max_active_runs == 1 and not dag.catchup
    api_pool = os.environ.get("BKK_TRAFFIC_API_POOL", "default_pool")   # longdo_api in the Airflow stack
    assert {t.task_id: t.pool for t in dag.tasks} == {"scrape": api_pool, "update_history": api_pool,
                                                      "collect_travel_times": api_pool,
                                                      "clean": "default_pool",
                                                      "validate": "default_pool", "publish": "default_pool",
                                                      "verify_postgresql": "default_pool"}
    assert all(not t.multiple_outputs for t in dag.tasks)
    monkeypatch.setenv("BKK_TRAFFIC_SCHEDULE_ENABLED", "true")
    assert "*/15" in module.pipeline_schedule().summary


def test_pipeline_dag_end_to_end_in_airflow(env, monkeypatch):
    module = _load_dag_module("bkk_traffic_pipeline")
    monkeypatch.setattr(module, "bkk_dsn", lambda: env["app"])
    dag = module.pipeline_dag
    FakeClient.pages = {1: [api_item(700 + i) for i in range(5)]}
    FakeClient.history_files = {2026: "timestamp,datetime,index\n1790787000,2026-09-30T23:50,2.7\n"
                                      "1790787300,2026-09-30T23:55,3.0\n"}
    run = dag.test()
    states = {ti.task_id: ti.state for ti in run.get_task_instances()}
    assert set(states.values()) == {"success"}, states
    assert q(env["admin"], "SELECT count(*) FROM bkk_traffic.incidents")[0][0] == 5
    # no longdo_api_key Variable in the test Airflow: travel times are skipped without a request
    assert q(env["admin"], "SELECT status, requests, note FROM bkk_traffic.scrape_runs WHERE job = 'travel_times'")         == [("skipped", 0, "no longdo_api_key")]
    assert q(env["admin"], "SELECT ts, source FROM bkk_traffic.traffic_index_history WHERE source LIKE 'history:%' "
                           "ORDER BY ts") == [(1790787000, "history:2026"), (1790787300, "history:2026")]
    assert json.loads((env["data"] / "parquet" / "incidents_bangkok" / "_manifest.json").read_text())["total_rows"] == 5
