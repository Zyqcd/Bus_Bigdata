"""Phase 9.5: traffic-index history port (data/scraper/bkk_traffic/history.py).

* No network: Longdo's yearly file is served by the FakeClient of test_bkk_traffic_pipeline
  (TEST-ONLY CSV text shaped exactly like the real files: timestamp,datetime,index).
* Database tests use ONLY the isolated namtang_bkk_traffic_test_db through the guarded
  fixtures of test_bkk_traffic_pipeline (pipeline code runs as a bkk_traffic_app member).
* Nothing here generates missing points; several tests prove that gaps stay gaps.
"""

from __future__ import annotations

import importlib.util
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "data" / "scraper"))

from bkk_traffic import config, history, scrape, storage  # noqa: E402

from test_bkk_traffic_pipeline import FakeClient, dsns, env, q  # noqa: E402,F401  (fixtures)

NOW = datetime(2026, 10, 3, 3, 0, 0)          # Bangkok wall-clock used for parsing in unit tests
T2350 = 1790787000                             # 2026-09-30 23:50 Asia/Bangkok
UTC = timezone.utc


def line(ts: int, value, shift_hours: int = 0) -> str:
    local = datetime.fromtimestamp(ts, UTC) + timedelta(hours=7 + shift_hours)
    return f"{ts},{local:%Y-%m-%dT%H:%M},{value}"


def year_file(*lines: str) -> str:
    return "timestamp,datetime,index\n" + "".join(f"{x}\n" for x in lines)


def errors_of(text: str, year: int = 2026) -> str:
    with pytest.raises(history.HistoryValidationError) as info:
        history.parse_year(text, year, now=NOW)
    return str(info.value)


# --------------------------------------------------------------------------
# 1-3, 5, 7, 9, 12: parsing and validation (no database)
# --------------------------------------------------------------------------

def test_timestamp_conversion_is_explicit_bangkok_time():
    assert history.local_text(T2350) == "2026-09-30 23:50:00"
    assert history.local_text(0) == "1970-01-01 07:00:00"
    assert config.bangkok_from_epoch(1767200400) == datetime(2026, 1, 1, 0, 0)    # first point of the 2026 file


@pytest.mark.parametrize("ts", [0, 1325350800, 1767200400, T2350, 1790969700])
def test_local_time_is_exactly_utc_plus_7(ts):
    utc = datetime.fromtimestamp(ts, UTC).replace(tzinfo=None)
    assert config.bangkok_from_epoch(ts) - utc == timedelta(hours=7)


def test_source_datetime_must_equal_ts_in_utc_plus_7():
    ok = history.parse_year(year_file(line(T2350, 2.7), line(T2350 + 300, 3.0)), 2026, now=NOW)
    assert ok.rows == [(T2350, "2026-09-30 23:50:00", 2.7), (T2350 + 300, "2026-09-30 23:55:00", 3.0)]
    assert "!= ts" in errors_of(year_file(line(T2350, 2.7, shift_hours=-7)))       # a UTC-labelled file
    assert "!= ts" in errors_of(year_file(line(T2350, 2.7, shift_hours=+7)))       # a double-shifted file


def test_duplicate_observations():
    parsed = history.parse_year(year_file(line(T2350, 2.7), line(T2350, 2.7), line(T2350 + 300, 3.0)), 2026, now=NOW)
    assert len(parsed.rows) == 2 and parsed.duplicates_collapsed == 1
    assert "conflicting duplicate ts" in errors_of(year_file(line(T2350, 2.7), line(T2350, 2.8)))


def test_missing_intervals_are_reported_never_generated():
    parsed = history.parse_year(year_file(line(T2350 - 900, 1.0), line(T2350 - 600, 1.1), line(T2350 + 300, 3.0)),
                                2026, now=NOW)
    assert [r[0] for r in parsed.rows] == [T2350 - 900, T2350 - 600, T2350 + 300]       # nothing added
    assert parsed.quality["gaps_over_5min"] == 1 and parsed.quality["largest_gap_minutes"] == 15
    assert parsed.quality["misaligned_ts"] == 0


@pytest.mark.parametrize("text, expected", [
    (year_file("abc,2026-09-30T23:50,2.7"), "unparseable"),
    (year_file(f"{T2350},2026-09-30T23:50,high"), "unparseable"),
    (year_file(f"{T2350},2026-09-30T23:50,"), "unparseable"),
    (year_file(",,"), "unparseable"),
    (year_file(f"{T2350},2026-09-30T23:50,nan"), "outside"),
    (year_file(f"{T2350},2026-09-30T23:50,10.5"), "outside"),
    (year_file(f"{T2350},2026-09-30T23:50,-0.1"), "outside"),
    (year_file(line(1767200400 - 300, 1.0)), "outside [2026-01-01"),            # 2025-12-31 23:55 in the 2026 file
    (year_file(line(1790971200 + 3600, 1.0)), "outside [2026-01-01"),           # one hour in the future
    ("ts,local,value\n1790787000,2026-09-30T23:50,2.7\n", "header"),
], ids=["ts_text", "value_text", "value_blank", "blank_row", "nan", "above_10", "negative", "previous_year",
        "future", "header"])
def test_invalid_observations_reject_the_whole_file(text, expected):
    assert expected in errors_of(text)


def test_one_bad_row_rejects_all_good_rows():
    good = [line(T2350 - 300 * i, 2.0) for i in range(50)]
    assert "1 invalid row" in errors_of(year_file(*good, f"{T2350 + 300},bad,3.0"))


def test_history_code_is_postgresql_only():
    code = (ROOT / "data" / "scraper" / "bkk_traffic" / "history.py").read_text(encoding="utf-8").split('"""', 2)[-1]
    assert "sqlite3" not in code and "executemany" not in code and "fromtimestamp(ts)" not in code
    assert "storage.connect()" in code and "ON CONFLICT (ts) DO UPDATE" in code


# --------------------------------------------------------------------------
# Database tests (isolated test DB; pipeline role)
# --------------------------------------------------------------------------

def history_rows(dsn):
    return q(dsn, "SELECT ts, ts_local::text, index_value, source, baseline_load_id, xmin::text "
                  "FROM bkk_traffic.traffic_index_history ORDER BY ts")


def test_valid_observations_are_stored(env):
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 3.0))}
    result = history.run(years=[2026])
    y = result["years"]["2026"]
    assert (y["rows"], y["inserted"], y["updated"], y["unchanged"]) == (2, 2, 0, 0)
    assert [r[:4] for r in history_rows(env["admin"])] == [(T2350, "2026-09-30 23:50:00", 2.7, "history:2026"),
                                                          (T2350 + 300, "2026-09-30 23:55:00", 3.0, "history:2026")]
    assert q(env["admin"], "SELECT job, status, items, new_items FROM bkk_traffic.scrape_runs") == [
        ("traffic_index_history", "success", 2, 2)]
    cp = q(env["admin"], "SELECT state_json FROM bkk_traffic.checkpoints WHERE job = 'traffic_index_history'")[0][0]
    assert cp["latest_file_point"] == "2026-09-30 23:55:00" and len(cp["file_sha256"]["2026"]) == 64
    raw = list((env["data"] / "raw" / "traffic_index_history").glob("2026_*.csv"))
    assert len(raw) == 1 and raw[0].read_text(encoding="utf-8") == FakeClient.history_files[2026]


def test_rerun_with_the_same_file_changes_nothing(env):
    FakeClient.history_files = {2026: year_file(*(line(T2350 - 300 * i, 2.0 + i / 10) for i in range(30)))}
    history.run(years=[2026])
    before = history_rows(env["admin"])
    again = history.run(years=[2026])["years"]["2026"]
    assert (again["inserted"], again["updated"], again["unchanged"]) == (0, 0, 30)
    assert history_rows(env["admin"]) == before                      # same rows, same tuple versions (xmin)
    assert len(list((env["data"] / "raw" / "traffic_index_history").glob("2026_*.csv"))) == 1   # one copy per content


def test_existing_gap_remains_a_gap(env):
    # realtime samples after the file's last point (the production situation of 2026-10-02/03)
    for ts in (1790942100, 1790967300):                              # 2026-10-02 18:55 and 2026-10-03 01:55
        FakeClient.index = {"time": ts, "index": 5.0}
        scrape.run_traffic_index()
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 3.0))}
    history.run(years=[2026])
    window = q(env["admin"], "SELECT count(*) FROM bkk_traffic.traffic_index_history WHERE ts > %s AND ts < %s",
               1790942100, 1790967300)[0][0]
    assert window == 0                                                # nothing generated inside the 7-hour gap
    assert len(history_rows(env["admin"])) == 4


def test_file_value_replaces_realtime_sample_but_not_the_reverse(env):
    FakeClient.index = {"time": T2350 + 300, "index": 9.9}           # provisional realtime sample
    scrape.run_traffic_index()
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 3.0))}
    result = history.run(years=[2026])["years"]["2026"]
    assert (result["inserted"], result["updated"]) == (1, 1)
    assert q(env["admin"], "SELECT index_value, source FROM bkk_traffic.traffic_index_history WHERE ts = %s",
             T2350 + 300) == [(3.0, "history:2026")]
    assert q(env["admin"], "SELECT index_value FROM bkk_traffic.traffic_index WHERE ts = %s", T2350 + 300) == [(9.9,)]
    scrape.run_traffic_index()                                        # the same realtime sample again
    assert q(env["admin"], "SELECT index_value, source FROM bkk_traffic.traffic_index_history WHERE ts = %s",
             T2350 + 300) == [(3.0, "history:2026")]
    with storage.connect() as conn:
        checks = history.verify(conn)
    assert checks["file_replaced_realtime"] == 1 and checks["ts_local_mismatches"] == 0


def test_identical_baseline_rows_stay_untouched_changed_ones_are_taken_over(env):
    q(env["admin"], "INSERT INTO bkk_traffic.load_history (run_id, source_db, status) VALUES ('t', 'parquet:t', 'success')")
    q(env["admin"], "INSERT INTO bkk_traffic.traffic_index_history (ts, ts_local, index_value, source, baseline_load_id) "
                    "VALUES (%s, '2026-09-30 23:50:00', 2.7, 'history:2026', 1), "
                    "(%s, '2026-09-30 23:55:00', 2.9, 'history:2026', 1)", T2350, T2350 + 300)
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 3.0))}
    history.run(years=[2026])
    assert dict(q(env["admin"], "SELECT ts, baseline_load_id FROM bkk_traffic.traffic_index_history")) == {
        T2350: 1, T2350 + 300: None}


def test_invalid_file_writes_nothing_and_records_the_failure(env):
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 99))}
    with pytest.raises(history.HistoryValidationError):
        history.run(years=[2026])
    assert history_rows(env["admin"]) == []
    assert q(env["admin"], "SELECT job, status FROM bkk_traffic.scrape_runs") == [("traffic_index_history", "failed")]
    assert q(env["admin"], "SELECT count(*) FROM bkk_traffic.checkpoints WHERE job = 'traffic_index_history'")[0][0] == 0


def test_transaction_rollback_on_a_timezone_shift(env):
    # a stored row whose ts_local is 7 h off (as a container-TZ bug would write) blocks the whole year
    q(env["admin"], "INSERT INTO bkk_traffic.traffic_index_history (ts, ts_local, index_value, source) "
                    "VALUES (%s, '2026-09-30 16:55:00', 3.0, 'realtime')", T2350 + 300)
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7), line(T2350 + 300, 3.0))}
    with pytest.raises(history.HistoryValidationError, match="timezone shift"):
        history.run(years=[2026])
    assert [r[:4] for r in history_rows(env["admin"])] == [(T2350 + 300, "2026-09-30 16:55:00", 3.0, "realtime")]
    assert q(env["admin"], "SELECT status FROM bkk_traffic.scrape_runs") == [("failed",)]


def test_each_year_is_atomic(env):
    FakeClient.history_files = {2025: year_file(line(1767200400 - 300, 1.5)),            # valid 2025-12-31 23:55
                                2026: year_file(line(T2350, 2.7), "bad,row,1")}
    with pytest.raises(history.HistoryValidationError):
        history.run(years=[2025, 2026])
    assert [r[3] for r in history_rows(env["admin"])] == ["history:2025"]                 # 2026 rolled back entirely


def test_refresh_throttle_and_year_selection(env):
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7))}
    first = history.run(refresh_hours=24)                           # empty table: every year 2012-2026 requested
    assert sorted(first["years"]) == [str(y) for y in range(2012, 2027)]
    assert history.run(refresh_hours=24)["skipped"] is True        # refreshed < 24 h ago
    with storage.connect() as conn:
        assert history.years_to_refresh(conn, datetime(2026, 10, 3)) == list(range(2012, 2027))
    for year in range(2012, 2026):                                  # every year now has a row
        q(env["admin"], "INSERT INTO bkk_traffic.traffic_index_history (ts, ts_local, index_value, source) "
                        "VALUES (%s, %s, 1, 'history:x')", int(datetime(year, 6, 1, tzinfo=UTC).timestamp()) - 25200,
          f"{year}-06-01 00:00:00")
    with storage.connect() as conn:
        assert history.years_to_refresh(conn, datetime(2026, 10, 3)) == [2026]
        assert history.years_to_refresh(conn, datetime(2027, 1, 3)) == [2026, 2027]


def test_api_requests_go_through_the_client(env):
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7))}
    calls = []
    original = FakeClient.get_text
    FakeClient.get_text = lambda self, url, params=None: calls.append(url) or original(self, url, params)
    try:
        history.run(years=[2026])
    finally:
        FakeClient.get_text = original
    assert calls == ["https://traffic.longdo.com/api/raw/trafficindex/2026"]
    assert q(env["admin"], "SELECT requests FROM bkk_traffic.scrape_runs")[0][0] == 1


def test_namtang_schemas_are_untouched(env):
    def state():
        tables = [r[0] for r in q(env["admin"], "SELECT schemaname || '.' || tablename FROM pg_tables "
                                                "WHERE schemaname IN ('namtang', 'namtang_analysis') ORDER BY 1")]
        return tables, [q(env["admin"], f"SELECT count(*) FROM {t}")[0][0] for t in tables]

    before = state()
    FakeClient.history_files = {2026: year_file(line(T2350, 2.7))}
    history.run(years=[2026])
    assert state() == before and len(before[0]) == 22


# --------------------------------------------------------------------------
# Airflow (only inside the Airflow image)
# --------------------------------------------------------------------------

def test_update_history_task_position_and_pool(monkeypatch):
    pytest.importorskip("airflow.sdk")
    spec = importlib.util.spec_from_file_location("bkk_pipeline_history_test",
                                                  ROOT / "airflow" / "dags" / "bkk_traffic_pipeline.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    dag = module.pipeline_dag
    task = dag.get_task("update_history")
    assert [t.task_id for t in task.upstream_list] == ["scrape"]
    assert [t.task_id for t in task.downstream_list] == ["collect_travel_times"]     # Phase 9.6
    assert task.pool == dag.get_task("scrape").pool and task.retries == 0
    assert module.pipeline_schedule() is None
