"""Phase 8: operational readiness - pipeline lock/lease, manual vs Airflow overlap,
operator logging, and real transactional rollback in the isolated test database.

No production resource is used: locks live in tmp_path, pipelines run on the
TEST-ONLY Phase 7 fixtures, and database tests target namtang_test_db only
(skipped without NAMTANG_TEST_DATABASE_URL)."""

from __future__ import annotations

import csv
import json
import os
import socket
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

import phase7_support as p7
import run_pipeline as rp
import load_namtang as ld

A, B = p7.variant("A"), p7.variant("B")


@pytest.fixture(autouse=True)
def production_untouched():
    before = p7.production_snapshot()
    yield
    assert p7.production_snapshot() == before


def dead_pid() -> int:
    proc = subprocess.Popen([sys.executable, "-c", "pass"])
    proc.wait()
    return proc.pid


def write_lock(path: Path, **record) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(record), encoding="utf-8")
    return record


def lease_record(run_id: str, expires_in: timedelta) -> dict:
    now = datetime.now(timezone.utc)
    return {"run_id": run_id, "kind": "airflow", "pid": 1, "host": "airflow-scheduler",
            "stage": "scrape", "acquired_at_utc": now.isoformat(),
            "expires_at_utc": (now + expires_in).isoformat()}


# --------------------------------------------------------------------------
# Lock / lease rules
# --------------------------------------------------------------------------

def test_active_process_lock_is_respected(tmp_path):
    lock_path = tmp_path / "x.lock"
    write_lock(lock_path, run_id="manual-1", pid=os.getpid(), host=socket.gethostname())
    with pytest.raises(rp.PipelineLocked, match="manual-1"):
        rp.PipelineLock(lock_path, "manual-2").acquire()
    assert json.loads(lock_path.read_text())["run_id"] == "manual-1"


def test_stale_process_lock_on_this_host_is_recovered(tmp_path):
    lock_path = tmp_path / "x.lock"
    write_lock(lock_path, run_id="crashed", pid=dead_pid(), host=socket.gethostname())
    lock = rp.PipelineLock(lock_path, "manual-2")
    lock.acquire()
    assert json.loads(lock_path.read_text())["run_id"] == "manual-2"
    lock.release()
    assert not lock_path.exists()


def test_process_lock_from_another_host_is_never_guessed_stale(tmp_path):
    lock_path = tmp_path / "x.lock"
    write_lock(lock_path, run_id="other-host", pid=dead_pid(), host="some-other-host")
    with pytest.raises(rp.PipelineLocked, match="other-host"):
        rp.PipelineLock(lock_path, "manual-2").acquire()


def test_unreadable_lock_is_never_stale(tmp_path):
    lock_path = tmp_path / "x.lock"
    lock_path.write_text("{not json", encoding="utf-8")
    with pytest.raises(rp.PipelineLocked, match="cannot be read"):
        rp.PipelineLock(lock_path, "manual").acquire()
    assert lock_path.read_text(encoding="utf-8") == "{not json"


def test_airflow_lease_is_reentrant_for_the_same_run_and_refreshed(tmp_path):
    lock_path = tmp_path / "x.lock"
    first = rp.PipelineLock(lock_path, "airflow-run1", kind="airflow",
                            ttl=timedelta(hours=6), stage="scrape")
    first.acquire()
    before = json.loads(lock_path.read_text())
    later = rp.PipelineLock(lock_path, "airflow-run1", kind="airflow",
                            ttl=timedelta(hours=6), stage="clean")
    later.acquire()                                          # same DAG run: re-enters
    after = json.loads(lock_path.read_text())
    assert after["run_id"] == "airflow-run1" and after["stage"] == "clean"
    assert after["expires_at_utc"] >= before["expires_at_utc"]


def test_active_airflow_lease_blocks_other_runs(tmp_path):
    lock_path = tmp_path / "x.lock"
    write_lock(lock_path, **lease_record("airflow-run1", timedelta(hours=1)))
    with pytest.raises(rp.PipelineLocked, match="lease expires"):
        rp.PipelineLock(lock_path, "manual").acquire()      # manual run between tasks
    with pytest.raises(rp.PipelineLocked):
        rp.PipelineLock(lock_path, "airflow-run2", kind="airflow",
                        ttl=timedelta(hours=6)).acquire()


def test_expired_airflow_lease_is_recovered(tmp_path):
    lock_path = tmp_path / "x.lock"
    write_lock(lock_path, **lease_record("airflow-crashed", timedelta(seconds=-1)))
    lock = rp.PipelineLock(lock_path, "manual")
    lock.acquire()
    assert json.loads(lock_path.read_text())["run_id"] == "manual"


def test_only_the_owner_can_release(tmp_path):
    lock_path = tmp_path / "x.lock"
    owner = rp.PipelineLock(lock_path, "airflow-run1", kind="airflow", ttl=timedelta(hours=6))
    owner.acquire()
    stranger = rp.PipelineLock(lock_path, "airflow-run2", kind="airflow", ttl=timedelta(hours=6))
    assert stranger.release_if_owner() is False
    stranger.acquired = True
    stranger.release()                                       # wrong owner: no effect
    assert json.loads(lock_path.read_text())["run_id"] == "airflow-run1"
    assert owner.release_if_owner() is True and not lock_path.exists()


def test_takeover_never_deletes_a_lock_that_changed_owner(tmp_path):
    """Recovering a stale lock must not delete a fresh lock created meanwhile."""
    lock_path = tmp_path / "x.lock"
    stale = write_lock(lock_path, **lease_record("airflow-crashed", timedelta(seconds=-1)))
    fresh = write_lock(lock_path, **lease_record("airflow-new", timedelta(hours=1)))
    lock = rp.PipelineLock(lock_path, "manual")
    assert lock._remove_if(stale) is False                   # content no longer matches
    assert json.loads(lock_path.read_text()) == fresh        # restored untouched
    assert not list(tmp_path.glob("*.removing"))


# --------------------------------------------------------------------------
# Manual runner vs Airflow lease
# --------------------------------------------------------------------------

def test_manual_run_refused_while_airflow_run_holds_lease(tmp_path):
    paths = p7.isolated_paths(tmp_path)
    write_lock(paths.lock_path, **lease_record("airflow-scheduled__2026-10-03", timedelta(hours=6)))
    calls = []
    stages = rp.Stages(scrape=lambda: calls.append("scrape"), clean=None, validate=None,
                       analysis=None, load=None)
    result = rp.run_pipeline(paths, stages, load=False)
    assert result["status"] == "locked" and rp.EXIT_CODES["locked"] == 3
    assert "airflow-scheduled__2026-10-03" in result["error"] and calls == []
    assert json.loads(paths.lock_path.read_text())["kind"] == "airflow"    # not stolen


# --------------------------------------------------------------------------
# Operator logging
# --------------------------------------------------------------------------

def log_rows(paths) -> list[dict]:
    with paths.log_path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def test_awaiting_policy_log_names_feed_and_expected_policy_file(tmp_path):
    paths = p7.isolated_paths(tmp_path)
    stages = rp.default_stages(paths, None, "phase8")
    stages.scrape = p7.fixture_scraper(paths, "A")
    result = rp.run_pipeline(paths, stages, load=False)
    assert result["status"] == "awaiting_policy"
    clean_name = Path(result["feed"]["clean_dir"]).name
    expected_policy = str(paths.metadata_dir / f"data_quality_policy_{clean_name}.json")
    gate = next(r for r in log_rows(paths) if r["stage"] == "policy_gate")
    final = log_rows(paths)[-1]
    for row in (gate, final):
        assert A["sha256"] in row["error"] and expected_policy in row["error"]
    assert (final["stage"], final["status"]) == ("pipeline", "awaiting_policy")
    assert gate["zip_sha256"] == A["sha256"] and gate["feed_version"] == "PHASE7-TEST-A"


# --------------------------------------------------------------------------
# Real database: transactional rollback and load logging (isolated test DB)
# --------------------------------------------------------------------------

@pytest.fixture
def test_db():
    dsn = p7.isolated_test_dsn()
    p7.reset_test_database(dsn)
    return dsn


def run(paths, key, dsn):
    stages = rp.default_stages(paths, dsn, f"phase8-{key}")
    stages.scrape = p7.fixture_scraper(paths, key)
    return rp.run_pipeline(paths, stages, dsn=dsn)


def test_load_failure_rolls_back_and_keeps_previous_snapshot(tmp_path, test_db, monkeypatch):
    paths = p7.isolated_paths(tmp_path)
    p7.install_policy(paths, run(paths, "A", test_db)["feed"]["clean_dir"])
    loaded_a = run(paths, "A", test_db)
    assert loaded_a["status"] == "success"
    state_a = p7.db_state(test_db)

    load_row = [r for r in log_rows(paths) if r["stage"] == "load"][-1]
    assert load_row["status"] == "loaded"
    assert load_row["error"] == f"previous=None current={A['sha256']}"
    assert f"db previous=None current={A['sha256']}" in log_rows(paths)[-1]["error"]

    # Approve SHA-B, then make the COPY fail after several tables were truncated/copied.
    p7.install_policy(paths, run(paths, "B", test_db)["feed"]["clean_dir"],
                      feed_sha256=B["sha256"])
    real_copy, copied = ld.copy_table, []

    def failing_copy(cur, schema, table, path, batch_size):
        if len(copied) == 5:
            raise RuntimeError("simulated failure during COPY")
        copied.append(table)
        return real_copy(cur, schema, table, path, batch_size)

    monkeypatch.setattr(ld, "copy_table", failing_copy)
    failed = run(paths, "B", test_db)
    assert failed["status"] == "failed" and failed["failed_stage"] == "load"
    assert "simulated failure during COPY" in failed["error"] and len(copied) == 5
    assert p7.db_state(test_db) == state_a                    # rolled back completely
    assert [r for r in log_rows(paths) if r["stage"] == "load"][-1]["status"] == "failed"

    # The next run (failure fixed) retries cleanly and replaces A with B exactly once.
    monkeypatch.setattr(ld, "copy_table", real_copy)
    retried = run(paths, "B", test_db)
    assert retried["status"] == "success"
    history = p7.db_state(test_db)["load_history"]
    assert history == [(A["sha256"], "PHASE7-TEST-A", "success", None),
                       (B["sha256"], "PHASE7-TEST-B", "success", A["sha256"])]


# --------------------------------------------------------------------------
# DQ policy approval requirement (approval.approved must be true)
# --------------------------------------------------------------------------

KNOWN_ERRORS = [
    {"section": "logical_keys", "check": "agency logical key ['agency_id']", "table": "agency", "count": 4},
    {"section": "foreign_keys", "check": "fare_rules.origin_id -> stops.zone_id", "table": "fare_rules", "count": 61},
    {"section": "foreign_keys", "check": "fare_rules.destination_id -> stops.zone_id", "table": "fare_rules", "count": 59},
]
KNOWN_ISSUES = [
    {"id": "DQ-001", "validation_severity": "ERROR", "affected_table": "agency", "affected_rows": 4},
    {"id": "DQ-002", "validation_severity": "ERROR", "affected_table": "fare_rules", "affected_rows": 120},
]
SHA = "c" * 64


def policy_file(tmp_path, approval="approved", sha=SHA) -> Path:
    policy = {"feed": {"feed_sha256": sha}, "issues": KNOWN_ISSUES}
    if approval == "approved":
        policy["approval"] = {"approved": True, "approved_by": "reviewer"}
    elif approval is not None:
        policy["approval"] = approval
    path = tmp_path / "data_quality_policy_test.json"
    path.write_text(json.dumps(policy), encoding="utf-8")
    return path


def test_gate_missing_policy_awaits(tmp_path):
    g = rp.policy_gate({"errors": KNOWN_ERRORS, "warnings": []}, {"feed_sha256": SHA},
                       tmp_path / "data_quality_policy_absent.json")
    assert g["decision"] == "awaiting_policy" and "no reviewed DQ policy" in g["reason"]


def test_gate_wrong_sha_awaits(tmp_path):
    g = rp.policy_gate({"errors": KNOWN_ERRORS, "warnings": []}, {"feed_sha256": SHA},
                       policy_file(tmp_path, sha="d" * 64))
    assert g["decision"] == "awaiting_policy" and "different feed" in g["reason"]


@pytest.mark.parametrize("approval", [
    {"approved": False, "approved_by": None},       # explicit draft
    None,                                           # no approval block at all
    {"approved": "true"},                           # not the boolean true
    {"approved_by": "someone"},                     # approved flag missing
    "yes",                                          # malformed block
])
def test_gate_unapproved_policy_awaits(tmp_path, approval):
    g = rp.policy_gate({"errors": KNOWN_ERRORS, "warnings": []}, {"feed_sha256": SHA},
                       policy_file(tmp_path, approval=approval))
    assert g["decision"] == "awaiting_policy" and "not approved" in g["reason"]
    assert g["covered"] == []                        # never evaluated as covered


def test_gate_approved_policy_passes(tmp_path):
    g = rp.policy_gate({"errors": KNOWN_ERRORS, "warnings": []}, {"feed_sha256": SHA},
                       policy_file(tmp_path))
    assert g["decision"] == "pass" and g["approved_by"] == "reviewer"
    assert {c["table"] for c in g["covered"]} == {"agency", "fare_rules"}


def test_gate_approved_policy_still_rejects_uncovered_error(tmp_path):
    extra = {"section": "stop_times", "check": "stop_times.stop_id -> stops.stop_id",
             "table": "stop_times", "count": 1}
    g = rp.policy_gate({"errors": [*KNOWN_ERRORS, extra], "warnings": []}, {"feed_sha256": SHA},
                       policy_file(tmp_path))
    assert g["decision"] == "awaiting_policy"
    assert [u["table"] for u in g["uncovered"]] == ["stop_times"]


def test_existing_production_policy_is_approved_and_passes():
    """Read-only: the approved 20260930 policy still covers its validation report."""
    report_path = p7.ROOT / "data" / "metadata" / "validation_2026-10-01.json"
    policy_path = p7.ROOT / "data" / "metadata" / "data_quality_policy_2026-10-01.json"
    if not report_path.exists():
        pytest.skip("real metadata not present in this checkout")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    g = rp.policy_gate(report, {"feed_sha256": report["feed"]["feed_sha256"]}, policy_path)
    assert g["decision"] == "pass" and g["approved_by"] == "tatphong.t@ku.th"


def test_real_draft_policy_is_refused_even_at_the_active_path(tmp_path):
    """The 20261001 DRAFT must not pass the gate even if saved under the active name."""
    draft = p7.ROOT / "data" / "metadata" / "data_quality_policy_2026-10-02.DRAFT.json"
    report_path = p7.ROOT / "data" / "metadata" / "validation_2026-10-02.json"
    if not draft.exists() or not report_path.exists():
        pytest.skip("draft policy not present in this checkout")
    active = tmp_path / "data_quality_policy_2026-10-02.json"     # temporary copy only
    active.write_bytes(draft.read_bytes())
    report = json.loads(report_path.read_text(encoding="utf-8"))
    g = rp.policy_gate(report, {"feed_sha256": report["feed"]["feed_sha256"]}, active)
    assert g["decision"] == "awaiting_policy" and "not approved" in g["reason"]


def test_runner_stops_on_unapproved_policy_before_analysis(tmp_path):
    paths = p7.isolated_paths(tmp_path)
    stages = rp.default_stages(paths, None, "phase8-approval")
    stages.scrape = p7.fixture_scraper(paths, "A")
    first = rp.run_pipeline(paths, stages, load=False)
    target = p7.install_policy(paths, first["feed"]["clean_dir"])
    policy = json.loads(target.read_text(encoding="utf-8"))
    policy["approval"] = {"approved": False, "approved_by": None}  # reviewed counts, not approved
    target.write_text(json.dumps(policy), encoding="utf-8")
    result = rp.run_pipeline(paths, stages, load=False)
    assert result["status"] == "awaiting_policy" and "not approved" in result["error"]
    assert "analysis" not in result["stages"]
    assert not (paths.analysis_root / Path(first["feed"]["clean_dir"]).name).exists()
