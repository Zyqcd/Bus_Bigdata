# Project Rules

## 1. Project Overview

This project analyzes traffic, accidents, and public
transportation in Bangkok.

The current data engineering scope is:

Namtang GTFS
→ Scraping / Download
→ Raw Data
→ Data Cleaning
→ Clean Data
→ Handoff to the analysis / ML team

The current responsibility of this module is data collection
and data preparation. Do not implement ML models unless explicitly requested.

---

## 2. Data Source

Current primary data source:

Namtang GTFS

Source:
https://namtang-api.otp.go.th/download/namtang-gtfs.zip

The source uses the GTFS format.

Important GTFS files may include:

- agency.txt
- routes.txt
- trips.txt
- stop_times.txt
- stops.txt
- calendar.txt
- shapes.txt

Do not assume that every file or column exists.
Always inspect the actual downloaded feed before processing.

---

## 3. Project Structure

frontend/
    Frontend application.

backend/
    Backend API and business logic.

data/scraper/
    Scraping and data-processing code.

data/raw/
    Original downloaded source data.

data/clean/
    Cleaned and standardized data.

data/metadata/
    Scraping logs and dataset metadata.

---

## 4. Raw Data Rules

Raw data is immutable.

Never:

- modify raw files
- overwrite raw source data
- delete raw data automatically
- fabricate missing values
- silently transform source data

Always preserve the original downloaded GTFS ZIP.

Raw data should be organized by date or feed version.

Example:

data/raw/namtang/YYYY-MM-DD/
    gtfs.zip

---

## 5. Clean Data Rules

Clean data must be stored separately from raw data.

Cleaning may include:

- column normalization
- datatype conversion
- date/time normalization
- whitespace cleanup
- duplicate detection
- missing-value handling
- schema validation
- coordinate validation

Do not overwrite raw data during cleaning.

Large datasets should use Parquet.

---

## 6. Data Integrity

Never fabricate records to reach a target row count.

The target of 1 million rows means collecting
real source records, not duplicating existing records.

Every scraping run should record:

- scrape timestamp
- source
- feed version if available
- downloaded file
- row counts
- status
- errors

---

## 7. Scraper Requirements

The scraper should:

1. Download the source data.
2. Save the original source.
3. Validate the download.
4. Extract GTFS files.
5. Inspect schemas.
6. Record row counts.
7. Process clean data.
8. Save clean data as Parquet.
9. Write scraping metadata/logs.

Network failures should be handled safely.

Do not silently ignore failed downloads.

---

## 8. Code Quality

Prefer:

- Python 3.x
- pathlib for paths
- pandas / pyarrow for tabular processing
- clear functions
- type hints where useful
- logging instead of excessive print statements

Avoid:

- hard-coded absolute paths
- unnecessary dependencies
- duplicated code
- destructive operations
- silently swallowing exceptions

---

## 9. AI Coding Rules

Before modifying code:

1. Inspect the existing project structure.
2. Read relevant files.
3. Understand the current implementation.
4. Make the smallest reasonable change.
5. Do not rewrite unrelated code.

Do not create new files or directories unless they are necessary.

Do not modify frontend or backend code when working on the
data pipeline unless explicitly requested.

---

## 10. Git Rules

Do not commit:

- large raw datasets
- generated clean datasets
- temporary files
- secrets
- API keys

Source code, configuration templates, documentation,
and processing logic may be committed.

Never commit API keys or credentials.

---

## 11. Important Principle

Correctness is more important than reaching a target
number of rows.

Never create fake or duplicated records merely to
reach 1 million rows.